package essentialcraft.api;

import net.minecraft.entity.player.*;
import net.minecraft.item.*;

public interface IWindResistHandler
{
    boolean resistWind(final EntityPlayer p0, final ItemStack p1);
}
