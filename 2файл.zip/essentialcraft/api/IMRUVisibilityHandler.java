package essentialcraft.api;

import net.minecraft.item.*;

public interface IMRUVisibilityHandler
{
    boolean canSeeMRU(final ItemStack p0);
}
