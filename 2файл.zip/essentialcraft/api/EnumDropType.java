package essentialcraft.api;

import net.minecraft.util.*;
import net.minecraft.block.material.*;

public enum EnumDropType implements IStringSerializable
{
    FIRE(0, "fire", 1, MapColor.field_151676_q), 
    WATER(1, "water", 2, MapColor.field_151662_n), 
    EARTH(2, "earth", 3, MapColor.field_151664_l), 
    AIR(3, "air", 4, MapColor.field_151659_e), 
    ELEMENTAL(4, "elemental", 0, MapColor.field_151678_z), 
    MITHRILINE(5, "mithriline", -1, MapColor.field_151651_C);
    
    private final int index;
    private final String name;
    private final int indexOre;
    private final MapColor mapColor;
    public static final EnumDropType[] CAN_BE_FARMED;
    public static final EnumDropType[] NORMAL;
    
    private EnumDropType(final int index, final String name, final int indexOre, final MapColor mapColor) {
        this.index = index;
        this.name = name;
        this.indexOre = indexOre;
        this.mapColor = mapColor;
    }
    
    public String func_176610_l() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    public int getIndex() {
        return this.index;
    }
    
    public int getIndexOre() {
        return this.indexOre;
    }
    
    public MapColor getMapColor() {
        return this.mapColor;
    }
    
    public static EnumDropType fromIndex(final int i) {
        return values()[i % 6];
    }
    
    public static EnumDropType fromIndexOre(final int i) {
        return values()[(i + 4) % 5];
    }
    
    static {
        CAN_BE_FARMED = new EnumDropType[] { EnumDropType.FIRE, EnumDropType.WATER, EnumDropType.EARTH, EnumDropType.AIR };
        NORMAL = new EnumDropType[] { EnumDropType.FIRE, EnumDropType.WATER, EnumDropType.EARTH, EnumDropType.AIR, EnumDropType.ELEMENTAL };
    }
}
