package essentialcraft.api;

import net.minecraft.util.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import java.util.*;

public class DiscoveryEntry
{
    public List<PageEntry> pages;
    public String id;
    public ItemStack displayStack;
    public List<ItemStack> referalItemStackLst;
    public String name;
    public String shortDescription;
    public ResourceLocation displayTexture;
    public boolean isNew;
    
    public DiscoveryEntry(final String id) {
        this.pages = new ArrayList<PageEntry>();
        this.displayStack = ItemStack.field_190927_a;
        this.referalItemStackLst = new ArrayList<ItemStack>();
        this.isNew = false;
        this.id = id;
    }
    
    public DiscoveryEntry setName(final String name) {
        this.name = name;
        return this;
    }
    
    public DiscoveryEntry setNew() {
        this.isNew = true;
        return this;
    }
    
    public DiscoveryEntry setDisplayStack(final Object obj) {
        if (obj instanceof ItemStack) {
            this.displayStack = (ItemStack)obj;
        }
        if (obj instanceof Block) {
            this.displayStack = new ItemStack((Block)obj, 1, 0);
        }
        if (obj instanceof Item) {
            this.displayStack = new ItemStack((Item)obj, 1, 0);
        }
        if (obj instanceof ResourceLocation) {
            this.displayTexture = (ResourceLocation)obj;
        }
        return this;
    }
    
    public DiscoveryEntry setDesc(final String s) {
        this.shortDescription = s;
        return this;
    }
    
    public DiscoveryEntry apendPage(final PageEntry page) {
        this.pages.add(page);
        return this;
    }
    
    public DiscoveryEntry setReferal(final ItemStack... stacks) {
        Collections.addAll(this.referalItemStackLst, stacks);
        for (final ItemStack stack : stacks) {
            stack.func_190920_e(1);
            ApiCore.IS_TO_DISCOVERY_MAP.put(stack.toString(), this);
        }
        return this;
    }
}
