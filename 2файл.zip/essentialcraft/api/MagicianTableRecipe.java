package essentialcraft.api;

import net.minecraftforge.registries.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;

public class MagicianTableRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public Ingredient[] requiredItems;
    public ItemStack result;
    public int mruRequired;
    
    public MagicianTableRecipe(final Ingredient[] requiredItems, final ItemStack result, final int mruRequired) {
        this.requiredItems = new Ingredient[] { Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a };
        this.result = ItemStack.field_190927_a;
        for (int i = 0; i < 5 && i < requiredItems.length; ++i) {
            final Ingredient ing = requiredItems[i];
            this.requiredItems[i] = ((ing == null) ? Ingredient.field_193370_a : ing);
        }
        this.result = result;
        this.mruRequired = mruRequired;
    }
    
    public MagicianTableRecipe(final MagicianTableRecipe recipeByResult) {
        this.requiredItems = new Ingredient[] { Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a, Ingredient.field_193370_a };
        this.result = ItemStack.field_190927_a;
        this.requiredItems = recipeByResult.requiredItems.clone();
        this.result = recipeByResult.result.func_77946_l();
        this.mruRequired = recipeByResult.mruRequired;
    }
    
    public boolean matches(final ItemStack[] input) {
        if (input.length < 5) {
            return false;
        }
        for (int i = 0; i < 5; ++i) {
            if (!this.requiredItems[i].apply(input[i])) {
                return false;
            }
        }
        return true;
    }
    
    public String toString() {
        String retStr = super.toString();
        for (int i = 0; i < this.requiredItems.length; ++i) {
            retStr = retStr + "||item_" + i + ":" + this.requiredItems[i];
        }
        retStr = retStr + "||output:" + this.result;
        retStr = retStr + "||mru:" + this.mruRequired;
        return retStr;
    }
    
    public boolean func_77569_a(final InventoryCrafting invCrafting, final World world) {
        if (invCrafting.func_70302_i_() >= 5) {
            boolean ret = true;
            for (int i = 0; i < 5; ++i) {
                if (!this.requiredItems[i].apply(invCrafting.func_70301_a(i))) {
                    ret = false;
                }
            }
            return ret;
        }
        return false;
    }
    
    public ItemStack func_77572_b(final InventoryCrafting inv) {
        return this.result;
    }
    
    public boolean func_194133_a(final int width, final int height) {
        return width * height >= 5;
    }
    
    public ItemStack func_77571_b() {
        return this.result;
    }
}
