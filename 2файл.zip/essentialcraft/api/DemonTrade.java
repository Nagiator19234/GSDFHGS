package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.registry.*;
import java.util.*;
import com.google.common.collect.*;

public class DemonTrade
{
    public static final List<DemonTrade> TRADES;
    public static final Set<EntityEntry> ALL_MOBS;
    public ItemStack desiredItem;
    public EntityEntry entityType;
    
    public DemonTrade(final ItemStack is) {
        this.desiredItem = ItemStack.field_190927_a;
        this.desiredItem = is;
        DemonTrade.TRADES.add(this);
    }
    
    public DemonTrade(final EntityEntry e) {
        this.desiredItem = ItemStack.field_190927_a;
        this.entityType = e;
        DemonTrade.ALL_MOBS.add(e);
        DemonTrade.TRADES.add(this);
    }
    
    public DemonTrade(final ResourceLocation e) {
        this((EntityEntry)ForgeRegistries.ENTITIES.getValue(e));
    }
    
    public static void removeTrade(final DemonTrade tra) {
        if (tra.entityType != null) {
            DemonTrade.ALL_MOBS.remove(tra.entityType);
        }
        DemonTrade.TRADES.remove(tra);
    }
    
    public static void removeTrade(final ItemStack is) {
        DemonTrade toRemove = null;
        for (final DemonTrade tra : DemonTrade.TRADES) {
            if (ItemStack.func_77989_b(tra.desiredItem, is)) {
                toRemove = tra;
                break;
            }
        }
        removeTrade(toRemove);
    }
    
    public static void removeTrade(final EntityEntry e) {
        DemonTrade toRemove = null;
        for (final DemonTrade tra : DemonTrade.TRADES) {
            if (tra.entityType != null && tra.entityType.equals(e)) {
                toRemove = tra;
                break;
            }
        }
        removeTrade(toRemove);
    }
    
    public static void removeTrade(final ResourceLocation e) {
        removeTrade((EntityEntry)ForgeRegistries.ENTITIES.getValue(e));
    }
    
    static {
        TRADES = Lists.newArrayList();
        ALL_MOBS = Sets.newHashSet();
    }
}
