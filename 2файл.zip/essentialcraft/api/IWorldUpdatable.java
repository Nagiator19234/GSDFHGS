package essentialcraft.api;

import net.minecraft.util.math.*;
import net.minecraft.world.*;

public interface IWorldUpdatable<T>
{
    void update(final BlockPos p0, final World p1, final T p2);
}
