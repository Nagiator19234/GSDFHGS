package essentialcraft.api;

import net.minecraft.item.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraft.util.*;

public class GunRegistry
{
    public static final List<GunMaterial> GUN_MATERIALS;
    public static final List<LenseMaterial> LENSE_MATERIALS;
    public static final List<ScopeMaterial> SCOPE_MATERIALS;
    public static final List<ScopeMaterial> SCOPE_MATERIALS_SNIPER;
    
    public static ScopeMaterial getScopeFromID(final String id) {
        for (final ScopeMaterial material : GunRegistry.SCOPE_MATERIALS) {
            if (material.id.equalsIgnoreCase(id)) {
                return material;
            }
        }
        return null;
    }
    
    public static ScopeMaterial getScopeSniperFromID(final String id) {
        for (final ScopeMaterial material : GunRegistry.SCOPE_MATERIALS_SNIPER) {
            if (material.id.equalsIgnoreCase(id)) {
                return material;
            }
        }
        return null;
    }
    
    public static LenseMaterial getLenseFromID(final String id) {
        for (final LenseMaterial material : GunRegistry.LENSE_MATERIALS) {
            if (material.id.equalsIgnoreCase(id)) {
                return material;
            }
        }
        return null;
    }
    
    public static GunMaterial getGunFromID(final String id) {
        for (final GunMaterial material : GunRegistry.GUN_MATERIALS) {
            if (material.id.equalsIgnoreCase(id)) {
                return material;
            }
        }
        return null;
    }
    
    static {
        GUN_MATERIALS = new ArrayList<GunMaterial>();
        LENSE_MATERIALS = new ArrayList<LenseMaterial>();
        SCOPE_MATERIALS = new ArrayList<ScopeMaterial>();
        SCOPE_MATERIALS_SNIPER = new ArrayList<ScopeMaterial>();
    }
    
    public static class ScopeMaterial
    {
        public String id;
        public ItemStack recipe;
        public boolean sniper;
        public HashMap<GunType, ArrayList<DummyData>> materialData;
        public HashMap<String, String> textures;
        
        public ScopeMaterial(final String id, final boolean sniper) {
            this.recipe = ItemStack.field_190927_a;
            this.materialData = new HashMap<GunType, ArrayList<DummyData>>();
            this.textures = new HashMap<String, String>();
            this.id = id;
            this.sniper = sniper;
        }
        
        public ScopeMaterial setRecipe(final ItemStack recipe) {
            this.recipe = recipe;
            return this;
        }
        
        public ScopeMaterial setTextures(final String... textures) {
            if (textures.length == 3) {
                this.textures.put("pistol", textures[0]);
                this.textures.put("rifle", textures[1]);
                this.textures.put("sniper", textures[2]);
                for (int i = 0; i < 3; ++i) {
                    ApiCore.registerTexture(new ResourceLocation(textures[i]));
                }
            }
            return this;
        }
        
        public ScopeMaterial setTexture(final String texture) {
            this.textures.put("sniper", texture);
            ApiCore.registerTexture(new ResourceLocation(texture));
            return this;
        }
        
        public ScopeMaterial appendData(final String key, final float value, final GunType gun) {
            final ArrayList<DummyData> data = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
            data.add(new DummyData(key, (Object)value));
            this.materialData.put(gun, data);
            return this;
        }
        
        public ScopeMaterial appendData(final String key, final float value) {
            for (final GunType gun : GunType.values()) {
                final ArrayList<DummyData> d = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
                d.add(new DummyData(key, (Object)value));
                this.materialData.put(gun, d);
            }
            return this;
        }
        
        public ScopeMaterial register() {
            if (!this.sniper) {
                GunRegistry.SCOPE_MATERIALS.add(this);
            }
            else {
                GunRegistry.SCOPE_MATERIALS_SNIPER.add(this);
            }
            return this;
        }
    }
    
    public static class LenseMaterial
    {
        public HashMap<GunType, ArrayList<DummyData>> materialData;
        public String id;
        public ItemStack recipe;
        public HashMap<String, String> textures;
        
        public LenseMaterial(final String id) {
            this.materialData = new HashMap<GunType, ArrayList<DummyData>>();
            this.recipe = ItemStack.field_190927_a;
            this.textures = new HashMap<String, String>();
            this.id = id;
        }
        
        public LenseMaterial setRecipe(final ItemStack recipe) {
            this.recipe = recipe;
            return this;
        }
        
        public LenseMaterial setTextures(final String... textures) {
            if (textures.length == 4) {
                this.textures.put("pistol", textures[0]);
                this.textures.put("rifle", textures[1]);
                this.textures.put("sniper", textures[2]);
                this.textures.put("gatling", textures[3]);
                for (int i = 0; i < 4; ++i) {
                    ApiCore.registerTexture(new ResourceLocation(textures[i]));
                }
            }
            return this;
        }
        
        public LenseMaterial appendData(final String key, final float value, final GunType gun) {
            final ArrayList<DummyData> data = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
            data.add(new DummyData(key, (Object)value));
            this.materialData.put(gun, data);
            return this;
        }
        
        public LenseMaterial appendData(final String key, final float value) {
            for (final GunType gun : GunType.values()) {
                final ArrayList<DummyData> data = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
                data.add(new DummyData(key, (Object)value));
                this.materialData.put(gun, data);
            }
            return this;
        }
        
        public LenseMaterial register() {
            GunRegistry.LENSE_MATERIALS.add(this);
            return this;
        }
    }
    
    public static class GunMaterial
    {
        public HashMap<GunType, ArrayList<DummyData>> materialData;
        public String id;
        public ItemStack recipe;
        public HashMap<String, String> baseTextures;
        public HashMap<String, String> handleTextures;
        public HashMap<String, String> deviceTextures;
        
        public GunMaterial(final String id) {
            this.materialData = new HashMap<GunType, ArrayList<DummyData>>();
            this.recipe = ItemStack.field_190927_a;
            this.baseTextures = new HashMap<String, String>();
            this.handleTextures = new HashMap<String, String>();
            this.deviceTextures = new HashMap<String, String>();
            this.id = id;
        }
        
        public GunMaterial setRecipe(final ItemStack recipe) {
            this.recipe = recipe;
            return this;
        }
        
        public GunMaterial setTextures(final String... textures) {
            if (textures.length == 12) {
                this.baseTextures.put("pistol", textures[0]);
                this.baseTextures.put("rifle", textures[1]);
                this.baseTextures.put("sniper", textures[2]);
                this.baseTextures.put("gatling", textures[3]);
                this.handleTextures.put("pistol", textures[4]);
                this.handleTextures.put("rifle", textures[5]);
                this.handleTextures.put("sniper", textures[6]);
                this.handleTextures.put("gatling", textures[7]);
                this.deviceTextures.put("pistol", textures[8]);
                this.deviceTextures.put("rifle", textures[9]);
                this.deviceTextures.put("sniper", textures[10]);
                this.deviceTextures.put("gatling", textures[11]);
                for (int i = 0; i < 12; ++i) {
                    ApiCore.registerTexture(new ResourceLocation(textures[i]));
                }
            }
            return this;
        }
        
        public GunMaterial appendData(final String key, final float value, final GunType gun) {
            final ArrayList<DummyData> data = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
            data.add(new DummyData(key, (Object)value));
            this.materialData.put(gun, data);
            return this;
        }
        
        public GunMaterial appendData(final String key, final float value) {
            for (final GunType gun : GunType.values()) {
                final ArrayList<DummyData> data = this.materialData.computeIfAbsent(gun, k -> new ArrayList());
                data.add(new DummyData(key, (Object)value));
                this.materialData.put(gun, data);
            }
            return this;
        }
        
        public GunMaterial register() {
            GunRegistry.GUN_MATERIALS.add(this);
            return this;
        }
    }
    
    public enum GunType implements IStringSerializable
    {
        PISTOL(0, "pistol"), 
        RIFLE(1, "rifle"), 
        SNIPER(2, "sniper"), 
        GATLING(3, "gatling");
        
        private int index;
        private String name;
        
        private GunType(final int i, final String s) {
            this.index = i;
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static GunType fromIndex(final int i) {
            return values()[i];
        }
    }
}
