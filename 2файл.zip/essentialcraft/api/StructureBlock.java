package essentialcraft.api;

import net.minecraft.block.*;
import net.minecraft.util.math.*;

public class StructureBlock
{
    public Block blk;
    public int metadata;
    public int x;
    public int y;
    public int z;
    
    public StructureBlock(final Block block, final int meta, final int x, final int y, final int z) {
        this.blk = block;
        this.metadata = meta;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public StructureBlock(final Block block, final int meta, final BlockPos pos) {
        this(block, meta, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
    }
}
