package essentialcraft.api;

import java.util.*;

public class CorruptionEffectRegistry
{
    public static final List<ICorruptionEffect> EFFECTS;
    
    public static void addEffect(final ICorruptionEffect effect) {
        if (effect != null) {
            CorruptionEffectRegistry.EFFECTS.add(effect);
        }
    }
    
    public static ArrayList<ICorruptionEffect> findSuitableEffects(final int maxCost) {
        final ArrayList<ICorruptionEffect> retLst = new ArrayList<ICorruptionEffect>();
        for (final ICorruptionEffect effect : CorruptionEffectRegistry.EFFECTS) {
            if (effect.getStickiness() <= maxCost) {
                retLst.add(effect);
                if (!effect.getType().equals(EnumCorruptionEffect.BODY)) {
                    continue;
                }
                retLst.add(effect);
                retLst.add(effect);
            }
        }
        return retLst;
    }
    
    static {
        EFFECTS = new ArrayList<ICorruptionEffect>();
    }
}
