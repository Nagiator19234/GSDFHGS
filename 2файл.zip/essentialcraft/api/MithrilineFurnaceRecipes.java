package essentialcraft.api;

import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;
import net.minecraftforge.oredict.*;
import java.util.*;

public class MithrilineFurnaceRecipes
{
    public static final List<MithrilineFurnaceRecipe> RECIPES;
    
    public static void addRecipe(final Ingredient input, final ItemStack result, final float cost, final int req) {
        addRecipe(new MithrilineFurnaceRecipe(input, result, cost, req));
    }
    
    public static void addRecipe(final ItemStack input, final ItemStack result, final float cost, final int req) {
        final Ingredient is = Ingredient.func_193369_a(new ItemStack[] { input.func_77946_l() });
        addRecipe(new MithrilineFurnaceRecipe(is, result, cost, req));
    }
    
    public static void addRecipe(final String input, final ItemStack result, final float cost, final int req) {
        final Ingredient is = (Ingredient)new OreIngredient(input);
        addRecipe(new MithrilineFurnaceRecipe(is, result, cost, req));
    }
    
    public static void addRecipe(final Object input, final ItemStack result, final float cost, final int req) {
        final Ingredient is = IngredientUtils.getIngredient(input);
        addRecipe(new MithrilineFurnaceRecipe(is, result, cost, req));
    }
    
    public static void addRecipe(final MithrilineFurnaceRecipe rec) {
        MithrilineFurnaceRecipes.RECIPES.add(rec);
    }
    
    public static void removeRecipeByInput(final ItemStack component) {
        removeRecipe(getRecipeByInput(component));
    }
    
    public static void removeRecipeByInput(final String oreDictName) {
        try {
            removeRecipe(getRecipeByInput((ItemStack)OreDictionary.getOres(oreDictName).get(0)));
        }
        catch (Exception ex) {}
    }
    
    public static void removeRecipeByResult(final ItemStack result) {
        removeRecipe(getRecipeByResult(result));
    }
    
    public static void removeRecipe(final ItemStack input, final ItemStack result) {
        for (final MithrilineFurnaceRecipe rec : MithrilineFurnaceRecipes.RECIPES) {
            if (rec != null && rec.input.apply(input) && rec.result.func_77969_a(result)) {
                removeRecipe(rec);
            }
        }
    }
    
    public static void removeRecipe(final String input, final ItemStack result) {
        try {
            for (final MithrilineFurnaceRecipe rec : MithrilineFurnaceRecipes.RECIPES) {
                if (rec != null && rec.input.apply((ItemStack)OreDictionary.getOres(input).get(0)) && rec.result.func_77969_a(result)) {
                    removeRecipe(rec);
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public static void removeRecipe(final MithrilineFurnaceRecipe rec) {
        MithrilineFurnaceRecipes.RECIPES.remove(rec);
    }
    
    public static MithrilineFurnaceRecipe getRecipeByInput(final ItemStack is) {
        return MithrilineFurnaceRecipes.RECIPES.stream().filter(recipe -> recipe.input.apply(is)).findAny().orElse(null);
    }
    
    public static MithrilineFurnaceRecipe getRecipeByResult(final ItemStack is) {
        return MithrilineFurnaceRecipes.RECIPES.stream().filter(recipe -> recipe.result.func_77969_a(is)).findAny().orElse(null);
    }
    
    static {
        RECIPES = new ArrayList<MithrilineFurnaceRecipe>();
    }
}
