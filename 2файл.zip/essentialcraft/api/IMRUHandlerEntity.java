package essentialcraft.api;

public interface IMRUHandlerEntity extends IMRUHandler
{
    boolean getFlag();
    
    void setFlag(final boolean p0);
    
    boolean canAlwaysStay();
    
    void setAlwaysStay(final boolean p0);
}
