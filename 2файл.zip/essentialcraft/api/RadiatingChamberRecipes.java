package essentialcraft.api;

import net.minecraft.item.*;
import com.google.common.collect.*;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.item.crafting.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraftforge.oredict.*;

public class RadiatingChamberRecipes
{
    public static final List<RadiatingChamberRecipe> RECIPES;
    
    public static RadiatingChamberRecipe getRecipeByResult(final ItemStack result) {
        for (final RadiatingChamberRecipe rec : RadiatingChamberRecipes.RECIPES) {
            if (rec.result.func_77969_a(result)) {
                return rec;
            }
        }
        return null;
    }
    
    public static List<RadiatingChamberRecipe> getRecipesByInput(final ItemStack[] input) {
        final List<RadiatingChamberRecipe> ret = (List<RadiatingChamberRecipe>)Lists.newArrayList();
        for (final RadiatingChamberRecipe rec : RadiatingChamberRecipes.RECIPES) {
            if (rec.matches(input)) {
                ret.add(rec);
            }
        }
        return ret;
    }
    
    public static RadiatingChamberRecipe getRecipeByInputAndBalance(final ItemStack[] input, final float balance) {
        for (final RadiatingChamberRecipe rec : RadiatingChamberRecipes.RECIPES) {
            if (rec.matches(input, balance)) {
                return rec;
            }
        }
        return null;
    }
    
    public static boolean addRecipe(final RadiatingChamberRecipe rec) {
        try {
            RadiatingChamberRecipes.RECIPES.add(rec);
            return true;
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + rec + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Ingredient[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2) {
        try {
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(input, result, mruRequired, balanceBound1, balanceBound2);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Ingredient[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2, final float modifier) {
        try {
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(input, result, mruRequired, balanceBound1, balanceBound2, modifier);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final ItemStack[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = Ingredient.func_193369_a(new ItemStack[] { input[i].func_77946_l() });
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final ItemStack[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2, final float modifier) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = Ingredient.func_193369_a(new ItemStack[] { input[i].func_77946_l() });
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2, modifier);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final UnformedItemStack[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient((Object)input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final UnformedItemStack[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2, final float modifier) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient((Object)input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2, modifier);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final String[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = (Ingredient)new OreIngredient(input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final String[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2, final float modifier) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = (Ingredient)new OreIngredient(input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2, modifier);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Object[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient(input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Object[] input, final ItemStack result, final int mruRequired, final float balanceBound1, final float balanceBound2, final float modifier) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient(input[i]);
            }
            final RadiatingChamberRecipe addedRecipe = new RadiatingChamberRecipe(ingredients, result, mruRequired, balanceBound1, balanceBound2, modifier);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipe(final RadiatingChamberRecipe rec) {
        try {
            RadiatingChamberRecipes.RECIPES.remove(rec);
            return true;
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe " + rec + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipeByInput(final ItemStack[] input) {
        try {
            for (final RadiatingChamberRecipe removedRecipe : getRecipesByInput(input)) {
                removeRecipe(removedRecipe);
            }
            return true;
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe " + Arrays.toString(input) + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipeByInput(final ItemStack[] input, final float balance) {
        try {
            final RadiatingChamberRecipe removedRecipe = getRecipeByInputAndBalance(input, balance);
            return removeRecipe(removedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe " + Arrays.toString(input) + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipeByResult(final ItemStack result) {
        try {
            final RadiatingChamberRecipe removedRecipe = getRecipeByResult(result);
            return removeRecipe(removedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe with result" + result + "on side " + side);
            return false;
        }
    }
    
    static {
        RECIPES = Lists.newArrayList();
    }
}
