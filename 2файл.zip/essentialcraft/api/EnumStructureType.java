package essentialcraft.api;

public enum EnumStructureType
{
    MRUCUEC, 
    MRU_COIL;
}
