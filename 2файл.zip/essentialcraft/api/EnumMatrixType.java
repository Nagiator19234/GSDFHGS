package essentialcraft.api;

import net.minecraft.util.*;

public enum EnumMatrixType implements IStringSerializable
{
    EMPTY("empty"), 
    CHAOS("chaos"), 
    FROZEN("frozen"), 
    MAGIC("magic"), 
    SHADE("shade");
    
    private int index;
    private String name;
    
    private EnumMatrixType(final String s) {
        this.index = this.ordinal();
        this.name = s;
    }
    
    public String func_176610_l() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    public int getIndex() {
        return this.index;
    }
    
    public static EnumMatrixType fromIndex(final int i) {
        return values()[i];
    }
}
