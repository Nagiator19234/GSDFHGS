package essentialcraft.api;

public enum EnumSpellType
{
    CONSUMING, 
    MIRACLE, 
    SORCERY;
}
