package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.item.crafting.*;
import java.util.*;
import DummyCore.Utils.*;
import com.google.common.collect.*;

public class WindImbueRecipe
{
    public ItemStack result;
    public Ingredient input;
    public int enderEnergy;
    public static final List<WindImbueRecipe> RECIPES;
    
    public static WindImbueRecipe getRecipeByInput(final ItemStack input) {
        if (input.func_190926_b()) {
            return null;
        }
        for (final WindImbueRecipe rec : WindImbueRecipe.RECIPES) {
            if (rec.input.apply(input)) {
                return rec;
            }
        }
        return null;
    }
    
    public static WindImbueRecipe getRecipeByResult(final ItemStack result) {
        if (result.func_190926_b()) {
            return null;
        }
        for (final WindImbueRecipe rec : WindImbueRecipe.RECIPES) {
            if (result.func_77969_a(rec.result)) {
                return rec;
            }
        }
        return null;
    }
    
    public WindImbueRecipe(final Ingredient input, final ItemStack result, final int enderEnergy) {
        this.result = ItemStack.field_190927_a;
        this.input = Ingredient.field_193370_a;
        this.input = input;
        this.result = result;
        this.enderEnergy = enderEnergy;
        WindImbueRecipe.RECIPES.add(this);
    }
    
    public WindImbueRecipe(final ItemStack input, final ItemStack result, final int enderEnergy) {
        this.result = ItemStack.field_190927_a;
        this.input = Ingredient.field_193370_a;
        this.input = Ingredient.func_193369_a(new ItemStack[] { input });
        this.result = result;
        this.enderEnergy = enderEnergy;
        WindImbueRecipe.RECIPES.add(this);
    }
    
    public WindImbueRecipe(final Object input, final ItemStack result, final int enderEnergy) {
        this.result = ItemStack.field_190927_a;
        this.input = Ingredient.field_193370_a;
        this.input = IngredientUtils.getIngredient(input);
        this.result = result;
        this.enderEnergy = enderEnergy;
        WindImbueRecipe.RECIPES.add(this);
    }
    
    public static void removeRecipe(final WindImbueRecipe rec) {
        WindImbueRecipe.RECIPES.remove(rec);
    }
    
    public static void removeRecipeByInput(final ItemStack c) {
        removeRecipe(getRecipeByInput(c));
    }
    
    public static void removeRecipeByResult(final ItemStack r) {
        removeRecipe(getRecipeByResult(r));
    }
    
    public static void removeRecipe(final ItemStack s, final ItemStack r) {
        WindImbueRecipe toRemove = null;
        for (final WindImbueRecipe rec : WindImbueRecipe.RECIPES) {
            if (rec.input.apply(s) && rec.result.func_77969_a(r)) {
                toRemove = rec;
                break;
            }
        }
        removeRecipe(toRemove);
    }
    
    static {
        RECIPES = Lists.newArrayList();
    }
}
