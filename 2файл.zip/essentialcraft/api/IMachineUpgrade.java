package essentialcraft.api;

public interface IMachineUpgrade
{
    public enum UpgradeType
    {
        EFFICENCY, 
        SPEED, 
        TICK;
    }
}
