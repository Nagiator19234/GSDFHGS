package essentialcraft.api;

public interface IMRUDisplay
{
    IMRUHandler getMRUHandler();
}
