package essentialcraft.api;

import net.minecraft.item.*;
import java.util.*;

public interface IMRUResistHandler
{
    List<Float> getMRUResistances(final ItemStack p0);
}
