package essentialcraft.api;

public interface IESPEHandlerItem extends IESPEHandler
{
    boolean getStorage();
    
    void setStorage(final boolean p0);
}
