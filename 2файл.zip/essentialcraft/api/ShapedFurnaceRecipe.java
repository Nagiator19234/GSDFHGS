package essentialcraft.api;

import net.minecraftforge.registries.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;

public class ShapedFurnaceRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public ItemStack smelted;
    public ItemStack result;
    
    public ShapedFurnaceRecipe(final ItemStack smelted, final ItemStack result) {
        this.smelted = ItemStack.field_190927_a;
        this.result = ItemStack.field_190927_a;
        this.smelted = smelted;
        this.result = result;
    }
    
    public boolean func_77569_a(final InventoryCrafting inv, final World worldIn) {
        return inv.func_70301_a(0).func_77969_a(this.smelted) && inv.func_70301_a(1).func_77969_a(this.result);
    }
    
    public ItemStack func_77572_b(final InventoryCrafting inv) {
        return this.result;
    }
    
    public boolean func_194133_a(final int width, final int height) {
        return width * height >= 1;
    }
    
    public ItemStack func_77571_b() {
        return this.result;
    }
}
