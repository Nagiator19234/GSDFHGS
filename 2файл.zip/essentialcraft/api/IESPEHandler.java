package essentialcraft.api;

import net.minecraft.nbt.*;

public interface IESPEHandler
{
    double getMaxESPE();
    
    void setMaxESPE(final double p0);
    
    double getESPE();
    
    void setESPE(final double p0);
    
    double addESPE(final double p0, final boolean p1);
    
    double extractESPE(final double p0, final boolean p1);
    
    int getTier();
    
    void setTier(final int p0);
    
    NBTTagCompound writeToNBT(final NBTTagCompound p0);
    
    void readFromNBT(final NBTTagCompound p0);
}
