package essentialcraft.api;

import net.minecraft.world.*;
import net.minecraft.entity.player.*;

public interface IWorldEvent
{
    void onEventBeginning(final World p0);
    
    void worldTick(final World p0, final int p1);
    
    void playerTick(final EntityPlayer p0, final int p1);
    
    void onEventEnd(final World p0);
    
    int getEventDuration(final World p0);
    
    boolean possibleToApply(final World p0);
    
    float getEventProbability(final World p0);
    
    String getEventID();
}
