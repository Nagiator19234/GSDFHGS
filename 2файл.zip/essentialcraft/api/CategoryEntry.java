package essentialcraft.api;

import net.minecraft.util.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.item.*;

public class CategoryEntry
{
    public List<DiscoveryEntry> discoveries;
    public String id;
    public ItemStack displayStack;
    public String name;
    public String shortDescription;
    public ResourceLocation displayTexture;
    public int reqTier;
    public ResourceLocation specificBookTextures;
    public int textColor;
    
    public CategoryEntry(final String id) {
        this.discoveries = new ArrayList<DiscoveryEntry>();
        this.displayStack = ItemStack.field_190927_a;
        this.textColor = 2236962;
        this.id = id;
    }
    
    public CategoryEntry setName(final String name) {
        this.name = name;
        return this;
    }
    
    public CategoryEntry setTier(final int tier) {
        this.reqTier = tier;
        return this;
    }
    
    public CategoryEntry setTextColor(final int color) {
        this.textColor = color;
        return this;
    }
    
    public CategoryEntry setDisplayStack(final Object obj) {
        if (obj instanceof ItemStack) {
            this.displayStack = (ItemStack)obj;
        }
        if (obj instanceof Block) {
            this.displayStack = new ItemStack((Block)obj, 1, 0);
        }
        if (obj instanceof Item) {
            this.displayStack = new ItemStack((Item)obj, 1, 0);
        }
        if (obj instanceof ResourceLocation) {
            this.displayTexture = (ResourceLocation)obj;
        }
        return this;
    }
    
    public CategoryEntry setDesc(final String desc) {
        this.shortDescription = desc;
        return this;
    }
    
    public CategoryEntry setSpecificTexture(final ResourceLocation location) {
        this.specificBookTextures = location;
        return this;
    }
    
    public CategoryEntry apendDiscovery(final DiscoveryEntry disc) {
        this.discoveries.add(disc);
        return this;
    }
}
