package essentialcraft.api;

import java.util.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import com.google.common.collect.*;
import java.lang.reflect.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.*;

public class ApiCore
{
    public static final int GENERATOR_MAX_MRU_GENERIC = 10000;
    public static final int DEVICE_MAX_MRU_GENERIC = 5000;
    public static final List<Item> MRU_VISIBLE_LIST;
    public static final HashMap<Item, ArrayList<Float>> ITEM_RESISTANCE_MAP;
    public static final List<CategoryEntry> CATEGORY_LIST;
    public static final HashMap<String, DiscoveryEntry> IS_TO_DISCOVERY_MAP;
    @CapabilityInject(IMRUHandler.class)
    public static Capability<IMRUHandler> MRU_HANDLER_CAPABILITY;
    @CapabilityInject(IMRUHandlerItem.class)
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    @CapabilityInject(IMRUHandlerEntity.class)
    public static Capability<IMRUHandlerEntity> MRU_HANDLER_ENTITY_CAPABILITY;
    
    public static IPlayerData getPlayerData(final EntityPlayer player) {
        try {
            final Class<?> ecUtilsClass = Class.forName("essentialcraft.utils.common.ECUtils");
            final Method getData = ecUtilsClass.getMethod("getData", EntityPlayer.class);
            return (IPlayerData)getData.invoke(null, player);
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static void registerBlockInStructure(final EnumStructureType structure, final Block registered) {
        try {
            final Class<?> ecUtilsClass = Class.forName("essentialcraft.utils.common.ECUtils");
            final Field hashMultimapFld = ecUtilsClass.getDeclaredField("STRUCTURE_TO_BLOCKS_MAP");
            hashMultimapFld.setAccessible(true);
            final HashMultimap<EnumStructureType, Block> hashMap = (HashMultimap<EnumStructureType, Block>)hashMultimapFld.get(null);
            hashMap.put((Object)structure, (Object)registered);
        }
        catch (Exception e) {}
    }
    
    public static void registerBlockMRUResistance(final Block registered, final int metadata, final float resistance) {
        try {
            final Class<?> ecUtilsClass = Class.forName("essentialcraft.utils.common.ECUtils");
            final Method regBlk = ecUtilsClass.getMethod("registerBlockResistance", Block.class, Integer.TYPE, Float.TYPE);
            regBlk.setAccessible(true);
            regBlk.invoke(null, registered, metadata, resistance);
        }
        catch (Exception e) {}
    }
    
    public static DiscoveryEntry findDiscoveryByIS(final ItemStack referal) {
        if (referal.func_190926_b() || referal.func_77973_b() == null) {
            return null;
        }
        final int size = referal.func_190916_E();
        referal.func_190920_e(1);
        final DiscoveryEntry de = ApiCore.IS_TO_DISCOVERY_MAP.get(referal.toString());
        referal.func_190920_e(size);
        return de;
    }
    
    public static void allowItemToSeeMRU(final Item item) {
        ApiCore.MRU_VISIBLE_LIST.add(item);
    }
    
    public static void setItemResistances(final Item item, final float cResist, final float rResist, final float cAffect) {
        final ArrayList<Float> res = new ArrayList<Float>();
        res.add(cResist);
        res.add(rResist);
        res.add(cAffect);
        ApiCore.ITEM_RESISTANCE_MAP.put(item, res);
    }
    
    public static boolean tryToDecreaseMRUInStorage(final EntityPlayer player, final int amount) {
        try {
            final Class<?> ecUtilsClass = Class.forName("essentialcraft.utils.common.ECUtils");
            final Method tryToDecreaseMRUInStorage = ecUtilsClass.getMethod("tryToDecreaseMRUInStorage", EntityPlayer.class, Integer.TYPE);
            return Boolean.parseBoolean(tryToDecreaseMRUInStorage.invoke(null, player, -amount).toString());
        }
        catch (Exception e) {
            return false;
        }
    }
    
    public static void increaseCorruptionAt(final World world, final float x, final float y, final float z, final int amount) {
        try {
            final Class<?> ecUtilsClass = Class.forName("essentialcraft.utils.common.ECUtils");
            final Method increaseCorruptionAt = ecUtilsClass.getMethod("increaseCorruptionAt", World.class, Float.TYPE, Float.TYPE, Float.TYPE, Integer.TYPE);
            increaseCorruptionAt.setAccessible(true);
            increaseCorruptionAt.invoke(null, world, x, y, z, amount);
        }
        catch (Exception e) {}
    }
    
    public static Entity getClosestMRUCUEntity(final World world, final BlockPos pos, final int radius) {
        final List<Entity> entities = (List<Entity>)world.func_175647_a((Class)Entity.class, new AxisAlignedBB(pos).func_72314_b((double)radius, (double)(radius / 2), (double)radius), e -> e.hasCapability((Capability)ApiCore.MRU_HANDLER_ENTITY_CAPABILITY, (EnumFacing)null));
        Entity ret = null;
        if (!entities.isEmpty()) {
            double minDistance = 0.0;
            final Coord3D main = new Coord3D(pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5);
            for (int i = 0; i < entities.size(); ++i) {
                final Entity presence = entities.get(i);
                final Coord3D current = new Coord3D(presence.field_70165_t, presence.field_70163_u, presence.field_70161_v);
                final DummyDistance dist = new DummyDistance(main, current);
                if (i == 0) {
                    ret = presence;
                    minDistance = dist.getDistance();
                }
                else if (dist.getDistance() < minDistance) {
                    ret = presence;
                    minDistance = dist.getDistance();
                }
            }
        }
        return ret;
    }
    
    public static IMRUHandlerEntity getClosestMRUCU(final World world, final BlockPos pos, final int radius) {
        return (IMRUHandlerEntity)getClosestMRUCUEntity(world, pos, radius).getCapability((Capability)ApiCore.MRU_HANDLER_ENTITY_CAPABILITY, (EnumFacing)null);
    }
    
    public static void registerTexture(final ResourceLocation texture) {
        if (FMLCommonHandler.instance().getEffectiveSide().isServer()) {
            return;
        }
        try {
            final Class<?> coreClass = Class.forName("essentialcraft.common.mod.EssentialCraftCore");
            final Class<?> proxyClass = Class.forName("essentialcraft.proxy.CommonProxy");
            final Field proxyField = coreClass.getDeclaredField("proxy");
            proxyField.setAccessible(true);
            final Method regMethod = proxyClass.getDeclaredMethod("registerTexture", ResourceLocation.class);
            regMethod.setAccessible(true);
            regMethod.invoke(proxyField.get(null), texture);
        }
        catch (Exception ex) {}
    }
    
    static {
        MRU_VISIBLE_LIST = new ArrayList<Item>();
        ITEM_RESISTANCE_MAP = new HashMap<Item, ArrayList<Float>>();
        CATEGORY_LIST = new ArrayList<CategoryEntry>();
        IS_TO_DISCOVERY_MAP = new HashMap<String, DiscoveryEntry>();
        ApiCore.MRU_HANDLER_CAPABILITY = null;
        ApiCore.MRU_HANDLER_ITEM_CAPABILITY = null;
        ApiCore.MRU_HANDLER_ENTITY_CAPABILITY = null;
    }
}
