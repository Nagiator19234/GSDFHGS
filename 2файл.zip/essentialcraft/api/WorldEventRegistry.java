package essentialcraft.api;

import net.minecraft.world.*;
import java.util.*;

public class WorldEventRegistry
{
    public static final List<IWorldEvent> EVENTS;
    public static IWorldEvent currentEvent;
    public static int currentEventDuration;
    
    public static void registerWorldEvent(final IWorldEvent event) {
        WorldEventRegistry.EVENTS.add(event);
    }
    
    public static IWorldEvent selectRandomEvent(final World world) {
        final IWorldEvent event = WorldEventRegistry.EVENTS.get(world.field_73012_v.nextInt(WorldEventRegistry.EVENTS.size()));
        if (world.field_73012_v.nextFloat() <= event.getEventProbability(world) && event.possibleToApply(world) && event.getEventDuration(world) > 0) {
            return event;
        }
        return null;
    }
    
    public static IWorldEvent getEventByID(final String id) {
        for (final IWorldEvent event : WorldEventRegistry.EVENTS) {
            if (event.getEventID().equals(id)) {
                return event;
            }
        }
        return null;
    }
    
    public static String[] getAllIDs() {
        final String[] ret = new String[WorldEventRegistry.EVENTS.size()];
        for (int i = 0; i < ret.length; ++i) {
            ret[i] = WorldEventRegistry.EVENTS.get(i).getEventID();
        }
        return ret;
    }
    
    static {
        EVENTS = new ArrayList<IWorldEvent>();
        WorldEventRegistry.currentEvent = null;
        WorldEventRegistry.currentEventDuration = -1;
    }
}
