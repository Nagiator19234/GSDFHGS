package essentialcraft.api;

import net.minecraft.nbt.*;

public interface IMRUHandler
{
    int getMaxMRU();
    
    void setMaxMRU(final int p0);
    
    int getMRU();
    
    void setMRU(final int p0);
    
    int addMRU(final int p0, final boolean p1);
    
    int extractMRU(final int p0, final boolean p1);
    
    float getBalance();
    
    void setBalance(final float p0);
    
    boolean getShade();
    
    void setShade(final boolean p0);
    
    NBTTagCompound writeToNBT(final NBTTagCompound p0);
    
    void readFromNBT(final NBTTagCompound p0);
}
