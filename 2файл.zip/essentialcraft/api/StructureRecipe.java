package essentialcraft.api;

import net.minecraftforge.registries.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;

public class StructureRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public List<StructureBlock> structure;
    public ItemStack referal;
    
    public StructureRecipe(final ItemStack ref, final StructureBlock... positions) {
        this.structure = new ArrayList<StructureBlock>();
        this.referal = ItemStack.field_190927_a;
        this.referal = ref;
        this.structure = Arrays.asList(positions);
    }
    
    public boolean func_77569_a(final InventoryCrafting inv, final World worldIn) {
        return false;
    }
    
    public ItemStack func_77572_b(final InventoryCrafting inv) {
        return this.referal;
    }
    
    public boolean func_194133_a(final int width, final int height) {
        return width * height >= this.structure.size();
    }
    
    public ItemStack func_77571_b() {
        return this.referal;
    }
}
