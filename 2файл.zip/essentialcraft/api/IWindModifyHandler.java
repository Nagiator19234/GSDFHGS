package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.entity.player.*;

public interface IWindModifyHandler
{
    float getModifier(final ItemStack p0, final EntityPlayer p1);
}
