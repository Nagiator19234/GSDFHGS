package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.util.*;
import java.util.*;
import it.unimi.dsi.fastutil.doubles.*;

public class MagicianTableUpgrades
{
    public static final List<ItemStack> UPGRADE_STACKS;
    public static final DoubleList UPGRADE_EFFICIENCIES;
    public static final List<ResourceLocation> UPGRADE_TEXTURES;
    
    public static void addUpgrade(final ItemStack stack, final double efficiency, final ResourceLocation texture) {
        MagicianTableUpgrades.UPGRADE_STACKS.add(stack.func_77946_l());
        MagicianTableUpgrades.UPGRADE_EFFICIENCIES.add(efficiency);
        MagicianTableUpgrades.UPGRADE_TEXTURES.add(texture);
    }
    
    public static boolean isItemUpgrade(final ItemStack stack) {
        for (final ItemStack s : MagicianTableUpgrades.UPGRADE_STACKS) {
            if (s.func_77969_a(stack)) {
                return true;
            }
        }
        return false;
    }
    
    public static ItemStack createStackByUpgradeID(final int uid) {
        if (MagicianTableUpgrades.UPGRADE_STACKS.size() > uid) {
            return MagicianTableUpgrades.UPGRADE_STACKS.get(uid);
        }
        return ItemStack.field_190927_a;
    }
    
    public static int getUpgradeIDByItemStack(final ItemStack stack) {
        for (int i = 0; i < MagicianTableUpgrades.UPGRADE_STACKS.size(); ++i) {
            if (stack.func_77969_a((ItemStack)MagicianTableUpgrades.UPGRADE_STACKS.get(i))) {
                return i;
            }
        }
        return -1;
    }
    
    static {
        UPGRADE_STACKS = new ArrayList<ItemStack>();
        UPGRADE_EFFICIENCIES = (DoubleList)new DoubleArrayList();
        UPGRADE_TEXTURES = new ArrayList<ResourceLocation>();
    }
}
