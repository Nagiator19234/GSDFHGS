package essentialcraft.api;

public class WorldEventEntry
{
    public IWorldEvent possibleEvent;
    public float weightOfEvent;
}
