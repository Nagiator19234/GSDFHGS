package essentialcraft.api;

import net.minecraft.nbt.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import java.util.*;
import DummyCore.Utils.*;

public interface ICorruptionEffect
{
    void readFromNBTTagCompound(final NBTTagCompound p0, final int p1);
    
    NBTTagCompound writeToNBTTagCompound(final NBTTagCompound p0, final int p1);
    
    EnumCorruptionEffect getType();
    
    void onPlayerTick(final EntityPlayer p0);
    
    ResourceLocation getEffectIcon();
    
    int getStickiness();
    
    ICorruptionEffect copy();
    
    boolean canMultiply();
    
    ArrayList<UnformedItemStack> cureItems();
    
    boolean effectEquals(final ICorruptionEffect p0);
    
    String getLocalizedName();
    
    String getLocalizedDesc();
}
