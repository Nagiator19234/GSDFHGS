package essentialcraft.api;

import net.minecraft.world.*;
import net.minecraft.util.math.*;

public interface IColdBlock
{
    float getColdModifier(final IBlockAccess p0, final BlockPos p1);
}
