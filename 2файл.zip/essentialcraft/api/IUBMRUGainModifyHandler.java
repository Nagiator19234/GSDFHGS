package essentialcraft.api;

import net.minecraft.item.*;
import java.util.*;
import net.minecraft.entity.player.*;

public interface IUBMRUGainModifyHandler
{
    float getModifiedValue(final float p0, final ItemStack p1, final Random p2, final EntityPlayer p3);
}
