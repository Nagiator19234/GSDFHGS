package essentialcraft.api;

public interface IMRUHandlerItem extends IMRUHandler
{
    boolean getStorage();
    
    void setStorage(final boolean p0);
}
