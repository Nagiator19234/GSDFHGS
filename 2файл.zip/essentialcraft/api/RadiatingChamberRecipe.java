package essentialcraft.api;

import net.minecraftforge.registries.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;

public class RadiatingChamberRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public Ingredient[] recipeItems;
    public ItemStack result;
    public int mruRequired;
    public float upperBalanceLine;
    public float lowerBalanceLine;
    public float costModifier;
    
    public RadiatingChamberRecipe(final Ingredient[] ingred, final ItemStack res, final int mruReq, final float balancePoint1, final float balancePoint2) {
        this.recipeItems = new Ingredient[] { Ingredient.field_193370_a, Ingredient.field_193370_a };
        this.result = ItemStack.field_190927_a;
        for (int i = 0; i < 2 && i < ingred.length; ++i) {
            final Ingredient ing = ingred[i];
            this.recipeItems[i] = ((ing == null) ? Ingredient.field_193370_a : ing);
        }
        this.result = res;
        this.mruRequired = mruReq;
        this.upperBalanceLine = Math.max(balancePoint1, balancePoint2);
        this.lowerBalanceLine = Math.min(balancePoint1, balancePoint2);
        this.costModifier = 1.0f;
    }
    
    public RadiatingChamberRecipe(final Ingredient[] ingred, final ItemStack res, final int mruReq, final float balancePoint1, final float balancePoint2, final float modifier) {
        this.recipeItems = new Ingredient[] { Ingredient.field_193370_a, Ingredient.field_193370_a };
        this.result = ItemStack.field_190927_a;
        for (int i = 0; i < 2 && i < ingred.length; ++i) {
            final Ingredient ing = ingred[i];
            this.recipeItems[i] = ((ing == null) ? Ingredient.field_193370_a : ing);
        }
        this.result = res;
        this.mruRequired = mruReq;
        this.upperBalanceLine = Math.max(balancePoint1, balancePoint2);
        this.lowerBalanceLine = Math.min(balancePoint1, balancePoint2);
        this.costModifier = modifier;
    }
    
    public RadiatingChamberRecipe(final RadiatingChamberRecipe other) {
        this.recipeItems = new Ingredient[] { Ingredient.field_193370_a, Ingredient.field_193370_a };
        this.result = ItemStack.field_190927_a;
        this.recipeItems = other.recipeItems;
        this.result = other.result;
        this.mruRequired = other.mruRequired;
        this.upperBalanceLine = other.upperBalanceLine;
        this.lowerBalanceLine = other.lowerBalanceLine;
        this.costModifier = other.costModifier;
    }
    
    public boolean matches(final ItemStack[] input, final float balance) {
        if (input.length < 2 || balance < this.lowerBalanceLine || balance > this.upperBalanceLine) {
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            if (!this.recipeItems[i].apply(input[i])) {
                return false;
            }
        }
        return true;
    }
    
    public boolean matches(final ItemStack[] input) {
        if (input.length < 2) {
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            if (!this.recipeItems[i].apply(input[i])) {
                return false;
            }
        }
        return true;
    }
    
    public String toString() {
        String retStr = super.toString();
        for (int i = 0; i < this.recipeItems.length; ++i) {
            retStr = retStr + "||item_" + i + ":" + this.recipeItems[i];
        }
        retStr = retStr + "||output:" + this.result;
        retStr = retStr + "||mru:" + this.mruRequired;
        retStr = retStr + "||upperBalance:" + this.upperBalanceLine;
        retStr = retStr + "||lowerBalance:" + this.lowerBalanceLine;
        return retStr;
    }
    
    public boolean func_77569_a(final InventoryCrafting invCrafting, final World world) {
        if (invCrafting.func_70302_i_() >= 2) {
            boolean ret = true;
            for (int i = 0; i < 2; ++i) {
                if (!this.recipeItems[i].apply(invCrafting.func_70301_a(i))) {
                    ret = false;
                }
            }
            return ret;
        }
        return false;
    }
    
    public ItemStack func_77572_b(final InventoryCrafting inv) {
        return this.result;
    }
    
    public boolean func_194133_a(final int width, final int height) {
        return width * height >= 2;
    }
    
    public ItemStack func_77571_b() {
        return this.result;
    }
}
