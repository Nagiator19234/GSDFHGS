package essentialcraft.api;

import net.minecraft.util.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;

public class PageEntry
{
    public String pageTitle;
    public String pageText;
    public ResourceLocation pageImgLink;
    public String pageID;
    public IRecipe pageRecipe;
    public ItemStack[] displayedItems;
    
    public PageEntry setTitle(final String title) {
        this.pageTitle = title;
        return this;
    }
    
    public PageEntry setText(final String text) {
        this.pageText = text;
        return this;
    }
    
    public PageEntry setImg(final ResourceLocation img) {
        this.pageImgLink = img;
        return this;
    }
    
    public PageEntry setRecipe(final IRecipe recipe) {
        this.pageRecipe = recipe;
        return this;
    }
    
    public PageEntry setDisplayStacks(final ItemStack... stacks) {
        this.displayedItems = stacks;
        return this;
    }
    
    public PageEntry(final String id) {
        this.displayedItems = new ItemStack[0];
        this.pageID = id;
    }
}
