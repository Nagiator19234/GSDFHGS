package essentialcraft.api;

import net.minecraft.world.*;
import net.minecraft.util.math.*;

public interface IHotBlock
{
    float getHeatModifier(final IBlockAccess p0, final BlockPos p1);
}
