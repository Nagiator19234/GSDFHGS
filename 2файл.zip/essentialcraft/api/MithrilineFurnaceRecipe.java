package essentialcraft.api;

import net.minecraft.item.crafting.*;
import net.minecraft.item.*;

public class MithrilineFurnaceRecipe
{
    public final Ingredient input;
    public final ItemStack result;
    public final float energy;
    public final int stackSize;
    
    public MithrilineFurnaceRecipe(final Ingredient input, final ItemStack result, final float energy, final int stackSize) {
        this.input = input;
        this.result = result;
        this.energy = energy;
        this.stackSize = stackSize;
    }
}
