package essentialcraft.api;

import net.minecraft.tileentity.*;

public interface IStructurePiece
{
    EnumStructureType getStructure();
    
    TileEntity structureController();
    
    void setStructureController(final TileEntity p0, final EnumStructureType p1);
}
