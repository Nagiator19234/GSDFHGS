package essentialcraft.api;

import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.nbt.*;
import net.minecraftforge.oredict.*;
import net.minecraft.util.text.translation.*;
import java.util.*;
import DummyCore.Utils.*;

public class OreSmeltingRecipe
{
    public static final ArrayList<OreSmeltingRecipe> RECIPES;
    public static final HashMap<String, OreSmeltingRecipe> RECIPE_MAP;
    public String oreName;
    public String outputName;
    public int color;
    public int dropAmount;
    
    public OreSmeltingRecipe(final String oreName, final int color) {
        this(oreName, color, 1);
    }
    
    public OreSmeltingRecipe(final String oreName, final int color, final int dropAmount) {
        this(oreName, "", color, dropAmount);
    }
    
    public OreSmeltingRecipe(final String oreName, final String outputName, final int color, final int dropAmount) {
        this.oreName = oreName;
        this.outputName = outputName;
        this.color = color;
        this.dropAmount = dropAmount;
    }
    
    public OreSmeltingRecipe(final String oreName, final String outputName, final int color) {
        this(oreName, outputName, color, 1);
    }
    
    public OreSmeltingRecipe register() {
        boolean flag = true;
        for (final OreSmeltingRecipe rec : OreSmeltingRecipe.RECIPES) {
            if (rec.oreName == this.oreName) {
                flag = false;
            }
        }
        if (flag) {
            OreSmeltingRecipe.RECIPES.add(this);
            OreSmeltingRecipe.RECIPE_MAP.put(this.oreName, this);
        }
        return this;
    }
    
    public static OreSmeltingRecipe addRecipe(final String oreName, final int color) {
        return new OreSmeltingRecipe(oreName, color).register();
    }
    
    public static OreSmeltingRecipe addRecipe(final String oreName, final int color, final int dropAmount) {
        return new OreSmeltingRecipe(oreName, color, dropAmount).register();
    }
    
    public static OreSmeltingRecipe addRecipe(final String oreName, final String outputName, final int color, final int dropAmount) {
        return new OreSmeltingRecipe(oreName, outputName, color, dropAmount).register();
    }
    
    public static OreSmeltingRecipe addRecipe(final String oreName, final String outputName, final int color) {
        return new OreSmeltingRecipe(oreName, outputName, color).register();
    }
    
    public static boolean removeRecipe(final OreSmeltingRecipe rec) {
        return OreSmeltingRecipe.RECIPES.remove(rec) && OreSmeltingRecipe.RECIPE_MAP.remove(rec.oreName, rec);
    }
    
    public static int getColorFromItemStack(final ItemStack stk) {
        if (stk.func_77973_b() == ItemsCore.magicalAlloy) {
            if (!stk.func_77942_o()) {
                if (stk.func_77952_i() < OreSmeltingRecipe.RECIPES.size()) {
                    return OreSmeltingRecipe.RECIPES.get(stk.func_77952_i()).color;
                }
                return 16777215;
            }
            else {
                final NBTTagCompound tag = stk.func_77978_p();
                if (tag.func_74764_b("ore")) {
                    return OreSmeltingRecipe.RECIPE_MAP.get(tag.func_74779_i("ore")).color;
                }
            }
        }
        return 16777215;
    }
    
    public static String getLocalizedOreName(final ItemStack stk) {
        if (stk.func_77973_b() != ItemsCore.magicalAlloy) {
            return "";
        }
        if (stk.func_77952_i() >= OreSmeltingRecipe.RECIPES.size()) {
            return "";
        }
        OreSmeltingRecipe ore;
        if (!stk.func_77942_o()) {
            if (stk.func_77952_i() >= OreSmeltingRecipe.RECIPES.size()) {
                return "";
            }
            ore = OreSmeltingRecipe.RECIPES.get(stk.func_77952_i());
        }
        else {
            final NBTTagCompound tag = stk.func_77978_p();
            if (!tag.func_74764_b("ore")) {
                return "";
            }
            ore = OreSmeltingRecipe.RECIPE_MAP.get(tag.func_74779_i("ore"));
        }
        final List<ItemStack> oreLst = (List<ItemStack>)OreDictionary.getOres(ore.oreName, false);
        if (oreLst != null && !oreLst.isEmpty()) {
            return oreLst.get(0).func_82833_r();
        }
        return I18n.func_74838_a("tile." + ore.oreName + ".name");
    }
    
    public static ItemStack getAlloyStack(final OreSmeltingRecipe rec, final int stackSize) {
        final ItemStack ret = new ItemStack(ItemsCore.magicalAlloy, stackSize, 0);
        final NBTTagCompound tag = MiscUtils.getStackTag(ret);
        tag.func_74778_a("ore", rec.oreName);
        return ret;
    }
    
    public static int getIndex(final ItemStack stk) {
        if (stk.func_77973_b() == ItemsCore.magicalAlloy && stk.func_77942_o()) {
            final NBTTagCompound tag = stk.func_77978_p();
            if (tag.func_74764_b("ore")) {
                return OreSmeltingRecipe.RECIPES.indexOf(OreSmeltingRecipe.RECIPE_MAP.get(tag.func_74779_i("ore")));
            }
        }
        return stk.func_77952_i();
    }
    
    static {
        RECIPES = new ArrayList<OreSmeltingRecipe>();
        RECIPE_MAP = new HashMap<String, OreSmeltingRecipe>();
        addRecipe("oreCoal", "gemCoal", 3421236);
        addRecipe("oreIron", 14860458);
        addRecipe("oreGold", 16297771);
        addRecipe("oreDiamond", "gemDiamond", 6155509);
        addRecipe("oreEmerald", "gemEmerald", 1564002);
        addRecipe("oreQuartz", "gemQuartz", 13745841);
        addRecipe("oreRedstone", "dustRedstone", 9372419, 8);
        addRecipe("oreLapis", "gemLapis", 1851561, 16);
        addRecipe("oreCopper", 12339200);
        addRecipe("oreTin", 12839423);
        addRecipe("oreLead", 8162503);
        addRecipe("oreSilver", 15793662);
        addRecipe("oreCobalt", 9576);
        addRecipe("oreArdite", 13215031);
        addRecipe("oreNickel", 15066301);
        addRecipe("oreAluminum", 12961221);
        addRecipe("oreUranium", 4305408);
        addRecipe("oreIridium", 15466495);
        addRecipe("oreAlchemite", "gemAlchemite", 16715303, 5);
        addRecipe("oreFireElemental", "gemFireElemental", 16711680, 3);
        addRecipe("oreWaterElemental", "gemWaterElemental", 255, 3);
        addRecipe("oreEarthElemental", "gemEarthElemental", 8215098, 3);
        addRecipe("oreAirElemental", "gemAirElemental", 16777215, 3);
        addRecipe("oreElemental", "gemElemental", 16711935, 3);
        addRecipe("oreMithriline", "dustMithriline", 65280, 8);
        addRecipe("oreSaltpeter", "dustSaltpeter", 10065301, 5);
        addRecipe("oreSulfur", "dustSulfur", 16777113, 5);
        addRecipe("orePlatinum", 7305353);
        addRecipe("oreMithril", 3887711);
    }
}
