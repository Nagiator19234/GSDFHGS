package essentialcraft.api;

import net.minecraft.entity.*;

public interface IShadeHandlerEntity
{
    float shadeBurstValue(final Entity p0);
}
