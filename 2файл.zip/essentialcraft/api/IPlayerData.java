package essentialcraft.api;

import net.minecraft.nbt.*;
import java.util.*;

public interface IPlayerData
{
    int getOverhaulDamage();
    
    void modifyOverhaulDamage(final int p0);
    
    int getPlayerRadiation();
    
    void modifyRadiation(final int p0);
    
    int getPlayerWindPoints();
    
    void modifyWindpoints(final int p0);
    
    boolean isWindbound();
    
    void modifyWindbound(final boolean p0);
    
    int getPlayerUBMRU();
    
    void modifyUBMRU(final int p0);
    
    int getMatrixTypeID();
    
    void modifyMatrixType(final int p0);
    
    List<ICorruptionEffect> getEffects();
    
    void readFromNBTTagCompound(final NBTTagCompound p0);
    
    NBTTagCompound writeToNBTTagCompound(final NBTTagCompound p0);
    
    UUID carrierUUID();
}
