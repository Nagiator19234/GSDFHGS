package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.item.crafting.*;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.relauncher.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraftforge.oredict.*;
import com.google.common.collect.*;

public class MagicianTableRecipes
{
    public static final List<MagicianTableRecipe> RECIPES;
    
    public static List<MagicianTableRecipe> getRecipesByComponent(final ItemStack component) {
        final List<MagicianTableRecipe> retLst = new ArrayList<MagicianTableRecipe>();
        for (final MagicianTableRecipe rec : MagicianTableRecipes.RECIPES) {
            for (final Ingredient ing : rec.requiredItems) {
                if (ing.apply(component)) {
                    retLst.add(rec);
                }
            }
        }
        return retLst;
    }
    
    public static MagicianTableRecipe getRecipeByResult(final ItemStack result) {
        for (final MagicianTableRecipe rec : MagicianTableRecipes.RECIPES) {
            if (rec.result.func_77969_a(result)) {
                return rec;
            }
        }
        return null;
    }
    
    public static MagicianTableRecipe getRecipeByInput(final ItemStack[] input) {
        for (final MagicianTableRecipe rec : MagicianTableRecipes.RECIPES) {
            if (rec.matches(input)) {
                return rec;
            }
        }
        return null;
    }
    
    public static boolean addRecipe(final MagicianTableRecipe rec) {
        try {
            MagicianTableRecipes.RECIPES.add(rec);
            return true;
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + rec + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Ingredient[] input, final ItemStack result, final int mruRequired) {
        try {
            final MagicianTableRecipe addedRecipe = new MagicianTableRecipe(input, result, mruRequired);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final ItemStack[] input, final ItemStack result, final int mruRequired) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = Ingredient.func_193369_a(new ItemStack[] { input[i] });
            }
            final MagicianTableRecipe addedRecipe = new MagicianTableRecipe(ingredients, result, mruRequired);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final UnformedItemStack[] input, final ItemStack result, final int mruRequired) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < input.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient((Object)input[i]);
            }
            final MagicianTableRecipe addedRecipe = new MagicianTableRecipe(ingredients, result, mruRequired);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final String[] input, final ItemStack result, final int mruRequired) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < ingredients.length; ++i) {
                ingredients[i] = (Ingredient)new OreIngredient(input[i]);
            }
            final MagicianTableRecipe addedRecipe = new MagicianTableRecipe(ingredients, result, mruRequired);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean addRecipe(final Object[] input, final ItemStack result, final int mruRequired) {
        try {
            final Ingredient[] ingredients = new Ingredient[input.length];
            for (int i = 0; i < ingredients.length; ++i) {
                ingredients[i] = IngredientUtils.getIngredient(input[i]);
            }
            final MagicianTableRecipe addedRecipe = new MagicianTableRecipe(ingredients, result, mruRequired);
            return addRecipe(addedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to add recipe " + Arrays.toString(input) + " with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipe(final MagicianTableRecipe rec) {
        try {
            MagicianTableRecipes.RECIPES.remove(rec);
            return true;
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe " + rec + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipeByResult(final ItemStack result) {
        try {
            final MagicianTableRecipe removedRecipe = getRecipeByResult(result);
            return removeRecipe(removedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe with the result " + result + " on side " + side);
            return false;
        }
    }
    
    public static boolean removeRecipeByInput(final ItemStack[] input) {
        try {
            final MagicianTableRecipe removedRecipe = getRecipeByInput(input);
            return removeRecipe(removedRecipe);
        }
        catch (Exception e) {
            final Side side = FMLCommonHandler.instance().getEffectiveSide();
            Notifier.notifyCustomMod("EssentialCraftAPI", "Unable to remove recipe " + Arrays.toString(input) + " on side " + side);
            return false;
        }
    }
    
    static {
        RECIPES = Lists.newArrayList();
    }
}
