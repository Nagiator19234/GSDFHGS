package essentialcraft.api;

import net.minecraft.item.*;
import net.minecraft.entity.player.*;

public interface ISpell
{
    EnumSpellType getSpellType(final ItemStack p0);
    
    int getUBMRURequired(final ItemStack p0);
    
    void onSpellUse(final int p0, final int p1, final EntityPlayer p2, final ItemStack p3, final ItemStack p4);
    
    int getRequiredContainerTier(final ItemStack p0);
    
    int getAttunementRequired(final ItemStack p0);
    
    boolean requiresSpecificAttunement(final ItemStack p0);
    
    boolean canUseSpell(final ItemStack p0, final EntityPlayer p1);
}
