package essentialcraft.api;

public enum EnumCorruptionEffect
{
    BODY, 
    MIND, 
    MATRIX;
}
