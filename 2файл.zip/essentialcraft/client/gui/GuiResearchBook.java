package essentialcraft.client.gui;

import net.minecraft.nbt.*;
import org.lwjgl.input.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.util.text.*;
import net.minecraftforge.oredict.*;
import net.minecraft.client.renderer.texture.*;
import essentialcraft.common.mod.*;
import essentialcraft.api.*;
import essentialcraft.utils.cfg.*;
import java.util.*;
import net.minecraft.item.crafting.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.*;
import DummyCore.Utils.*;
import net.minecraft.client.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import essentialcraft.common.block.*;
import net.minecraft.client.*;

public class GuiResearchBook extends GuiScreen
{
    protected static RenderItem itemRender;
    public int currentDepth;
    public static int currentPage;
    public static CategoryEntry currentCategory;
    public static DiscoveryEntry currentDiscovery;
    public static int currentDiscoveryPage;
    public static List<Object[]> hoveringText;
    public static List<Object[]> prevState;
    public static final int DISCOVERIES_PER_PAGE = 48;
    public NBTTagCompound bookTag;
    public boolean isLeftMouseKeyPressed;
    public boolean isRightMouseKeyPressed;
    public static final ResourceLocation DEFAULT_BOOK_TEXTURE;
    public static float ticksOpened;
    public static int ticksBeforePressing;
    public String numberString;
    public int pressDelay;
    
    public GuiResearchBook() {
        this.isLeftMouseKeyPressed = false;
        this.isRightMouseKeyPressed = false;
        this.numberString = "";
    }
    
    public void func_73876_c() {
        ++GuiResearchBook.ticksOpened;
        --GuiResearchBook.ticksBeforePressing;
        --this.pressDelay;
        if (!this.numberString.isEmpty() && this.pressDelay <= 0) {
            int buttonID = -1;
            try {
                buttonID = Integer.parseInt(this.numberString);
            }
            catch (NumberFormatException e) {
                Notifier.notifyCustomMod("EssentialCraft", "[ERROR]" + this.numberString + " is not a valid number!");
            }
            if (buttonID > -1) {
                --buttonID;
                if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null) {
                    buttonID += 3;
                }
                if (buttonID >= 0 && this.field_146292_n.size() > buttonID) {
                    final GuiButton button = this.field_146292_n.get(buttonID);
                    if (button.field_146124_l) {
                        this.func_146284_a(button);
                    }
                }
            }
            this.numberString = "";
        }
    }
    
    protected void func_73869_a(final char typed, final int keyID) {
        try {
            super.func_73869_a(typed, keyID);
            if (keyID == 14 && GuiResearchBook.currentCategory != null && this.field_146292_n.size() > 0) {
                final GuiButton button = this.field_146292_n.get(0);
                if (button.field_146124_l) {
                    this.func_146284_a(button);
                }
            }
            if (typed == '0' || typed == '1' || typed == '2' || typed == '3' || typed == '4' || typed == '5' || typed == '6' || typed == '7' || typed == '8' || typed == '9' || typed == '0') {
                this.numberString += typed;
                this.pressDelay = 20;
            }
            if (keyID == 40) {
                this.pressDelay = 0;
            }
            if (GuiResearchBook.currentCategory != null && (keyID == 205 || keyID == 203)) {
                final int press = (keyID == 205) ? 2 : 1;
                if (this.field_146292_n.size() > press) {
                    final GuiButton button2 = this.field_146292_n.get(press);
                    if (button2.field_146124_l) {
                        this.func_146284_a(button2);
                    }
                }
            }
        }
        catch (Exception ex) {}
    }
    
    public void func_73866_w_() {
        this.isLeftMouseKeyPressed = Mouse.isButtonDown(0);
        this.isRightMouseKeyPressed = Mouse.isButtonDown(1);
        this.field_146292_n.clear();
        this.field_146293_o.clear();
        this.bookTag = this.field_146297_k.field_71439_g.func_184614_ca().func_77978_p();
        if (GuiResearchBook.currentCategory == null) {
            this.initCategories();
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null) {
            this.initDiscoveries();
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery != null) {
            this.initPage();
        }
        GuiResearchBook.ticksBeforePressing = 1;
    }
    
    public void func_146278_c(final int tint) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        final int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        if (GuiResearchBook.currentCategory == null) {
            this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null && GuiResearchBook.currentCategory.specificBookTextures != null) {
            this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null && GuiResearchBook.currentCategory.specificBookTextures == null) {
            this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery != null) {
            if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
            }
            else {
                this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
            }
        }
        this.func_73729_b(k, l, 0, 0, 256, 180);
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.func_146276_q_();
        final int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        final int dWheel = Mouse.getDWheel();
        if (GuiResearchBook.currentDiscovery != null) {
            if (dWheel < 0 && this.field_146292_n.size() > 1) {
                final GuiButton button = this.field_146292_n.get(2);
                if (button.field_146124_l) {
                    this.func_146284_a(button);
                }
            }
            if (dWheel > 0 && this.field_146292_n.size() > 1) {
                final GuiButton button = this.field_146292_n.get(1);
                if (button.field_146124_l) {
                    this.func_146284_a(button);
                }
            }
        }
        else if (GuiResearchBook.currentCategory != null) {
            if (dWheel < 0 && this.field_146292_n.size() > 1) {
                final GuiButton button = this.field_146292_n.get(2);
                if (button.field_146124_l) {
                    this.func_146284_a(button);
                }
            }
            if (dWheel > 0 && this.field_146292_n.size() > 1) {
                final GuiButton button = this.field_146292_n.get(1);
                if (button.field_146124_l) {
                    this.func_146284_a(button);
                }
            }
        }
        if (this.isRightMouseKeyPressed && !Mouse.isButtonDown(1)) {
            this.isRightMouseKeyPressed = false;
        }
        if (!this.isRightMouseKeyPressed && Mouse.isButtonDown(1)) {
            this.isRightMouseKeyPressed = true;
            if (!GuiResearchBook.prevState.isEmpty()) {
                final Object[] tryArray = GuiResearchBook.prevState.get(GuiResearchBook.prevState.size() - 1);
                GuiResearchBook.currentPage = Integer.parseInt(tryArray[1].toString());
                GuiResearchBook.currentDiscoveryPage = Integer.parseInt(tryArray[2].toString());
                GuiResearchBook.currentDiscovery = (DiscoveryEntry)tryArray[0];
                GuiResearchBook.prevState.remove(GuiResearchBook.prevState.size() - 1);
                this.func_73866_w_();
            }
        }
        if (this.isLeftMouseKeyPressed && !Mouse.isButtonDown(0)) {
            this.isLeftMouseKeyPressed = false;
        }
        GuiResearchBook.hoveringText.clear();
        this.func_146278_c(0);
        if (GuiResearchBook.currentCategory == null) {
            this.drawCategories(mouseX, mouseY);
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null) {
            this.drawDiscoveries(mouseX, mouseY);
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery != null) {
            this.drawPage(mouseX, mouseY);
        }
        this.drawAllText();
        if (!this.numberString.isEmpty()) {
            GlStateManager.func_179109_b(0.0f, 0.0f, 500.0f);
            GlStateManager.func_179124_c(1.0f / (5.0f - this.pressDelay), 1.0f / (5.0f - this.pressDelay), 1.0f / (5.0f - this.pressDelay));
            this.func_73732_a(this.field_146289_q, this.numberString, k + 128, l + 172, 16777215);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            GlStateManager.func_179109_b(0.0f, 0.0f, -500.0f);
        }
        RenderHelper.func_74519_b();
    }
    
    public void drawAllText() {
        for (final Object[] drawable : GuiResearchBook.hoveringText) {
            final List<String> listToDraw = (List<String>)drawable[0];
            final int x = Integer.parseInt(drawable[1].toString());
            final int y = Integer.parseInt(drawable[2].toString());
            final FontRenderer renderer = (FontRenderer)drawable[3];
            this.drawHoveringText(listToDraw, x, y, renderer);
        }
    }
    
    public void initDiscoveries() {
        GuiResearchBook.currentPage = 0;
        final int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        final GuiButtonNoSound back = new GuiButtonNoSound(0, k + 236, l + 7, 14, 18, "");
        this.field_146292_n.add(back);
        final GuiButtonNoSound page_left = new GuiButtonNoSound(1, k + 7, l + 158, 24, 13, "");
        final GuiButtonNoSound page_right = new GuiButtonNoSound(2, k + 227, l + 158, 24, 13, "");
        final int discAmount = GuiResearchBook.currentCategory.discoveries.size();
        if (discAmount - 48 * (GuiResearchBook.currentDiscoveryPage + 1) <= 0) {
            page_left.field_146124_l = false;
        }
        if (discAmount - 48 * (GuiResearchBook.currentDiscoveryPage + 1) > 0) {
            page_right.field_146124_l = true;
        }
        else {
            page_right.field_146124_l = false;
        }
        this.field_146292_n.add(page_left);
        this.field_146292_n.add(page_right);
        for (int i = 48 * GuiResearchBook.currentDiscoveryPage; i < discAmount - 48 * GuiResearchBook.currentDiscoveryPage; ++i) {
            int dx = k + 22 * (i / 6) + 12;
            if (i >= 24) {
                dx += 40;
            }
            final int dy = l + 22 * (i % 6) + 22;
            final GuiButtonNoSound btnAdd = new GuiButtonNoSound(i + 3, dx, dy, 20, 20, "");
            this.field_146292_n.add(btnAdd);
        }
    }
    
    public void initCategories() {
        if (this.bookTag == null) {
            (this.bookTag = new NBTTagCompound()).func_74768_a("tier", 3);
        }
        GuiResearchBook.currentDiscoveryPage = 0;
        final int k = (this.field_146294_l - 256) / 2 + 128;
        final int l = (this.field_146295_m - 168) / 2;
        if (ApiCore.CATEGORY_LIST != null) {
            for (int i = 0; i < ApiCore.CATEGORY_LIST.size(); ++i) {
                final CategoryEntry cat = ApiCore.CATEGORY_LIST.get(i);
                if (cat != null) {
                    final GuiButtonNoSound added = new GuiButtonNoSound(i, k + 30 * (i / 5) + 8, l + 30 * (i % 5) + 28, 20, 20, "");
                    added.field_146124_l = false;
                    final int reqTier = cat.reqTier;
                    final int tier = this.bookTag.func_74762_e("tier");
                    if (tier >= reqTier) {
                        added.field_146124_l = true;
                    }
                    this.field_146292_n.add(added);
                }
            }
        }
    }
    
    public void initPage() {
        final int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        final GuiButtonNoSound back = new GuiButtonNoSound(0, k + 236, l + 7, 14, 18, "");
        this.field_146292_n.add(back);
        final GuiButtonNoSound page_left = new GuiButtonNoSound(1, k + 7, l + 158, 24, 13, "");
        final GuiButtonNoSound page_right = new GuiButtonNoSound(2, k + 227, l + 158, 24, 13, "");
        final int pagesMax = GuiResearchBook.currentDiscovery.pages.size();
        if (GuiResearchBook.currentPage <= 0) {
            page_left.field_146124_l = false;
        }
        if (GuiResearchBook.currentPage + 2 >= pagesMax) {
            page_right.field_146124_l = false;
        }
        this.field_146292_n.add(page_left);
        this.field_146292_n.add(page_right);
    }
    
    public void drawPage(final int mouseX, final int mouseZ) {
        final int pagesMax = GuiResearchBook.currentDiscovery.pages.size();
        for (final GuiButton btn : this.field_146292_n) {
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final int id = btn.field_146127_k;
            if (id == 0) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 49, 238, 14, 18);
            }
            if (id == 1) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover && btn.field_146124_l) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                if (!btn.field_146124_l) {
                    GlStateManager.func_179124_c(0.3f, 0.3f, 0.3f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 243, 24, 13);
            }
            if (id == 2) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover && btn.field_146124_l) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                if (!btn.field_146124_l) {
                    GlStateManager.func_179124_c(0.3f, 0.3f, 0.3f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 25, 243, 24, 13);
            }
        }
        for (int ik = 0; ik < this.field_146292_n.size(); ++ik) {
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            final GuiButton btn = this.field_146292_n.get(ik);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final int id = btn.field_146127_k;
            if (id == 0 && hover) {
                final List<String> catStr = new ArrayList<String>();
                catStr.add(I18n.func_74838_a("essentialcraft.text.button.back"));
                this.addHoveringText(catStr, mouseX, mouseZ);
            }
        }
        this.drawPage_0(mouseX, mouseZ);
        if (GuiResearchBook.currentPage + 1 < pagesMax) {
            this.drawPage_1(mouseX, mouseZ);
        }
    }
    
    public void drawPage_0(final int mouseX, final int mouseY) {
        final PageEntry page = GuiResearchBook.currentDiscovery.pages.get(GuiResearchBook.currentPage);
        final int k = (this.field_146294_l - 256) / 2;
        int l = (this.field_146295_m - 168) / 2;
        if (GuiResearchBook.currentPage == 0) {
            String added = "";
            if (page.pageTitle == null || page.pageTitle.isEmpty()) {
                if (GuiResearchBook.currentDiscovery.name == null || GuiResearchBook.currentDiscovery.name.isEmpty()) {
                    added = TextFormatting.BOLD + I18n.func_74838_a("ec3book.discovery_" + GuiResearchBook.currentDiscovery.id + ".name");
                }
                else {
                    added = GuiResearchBook.currentDiscovery.name;
                }
            }
            else {
                added = page.pageTitle;
            }
            this.field_146289_q.func_175063_a(added, (float)(k + 6), (float)(l + 10), 11176191);
        }
        else if (page.pageTitle != null && !page.pageTitle.isEmpty()) {
            this.field_146289_q.func_175063_a(page.pageTitle, (float)(k + 6), (float)(l + 10), 16777215);
        }
        if (page.pageImgLink != null) {
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            GlStateManager.func_179140_f();
            this.field_146297_k.field_71446_o.func_110577_a(page.pageImgLink);
            func_152125_a(k + 16, l + 10, 0.0f, 0.0f, 256, 256, 100, 100, 256.0f, 256.0f);
            l += 86;
        }
        if (page.displayedItems != null) {
            for (int i = 0; i < page.displayedItems.length; ++i) {
                final ItemStack is = page.displayedItems[i];
                if (!is.func_190926_b()) {
                    this.drawIS(is, k + 10 + i % 4 * 20, l + 10 + i / 4 * 20, mouseX, mouseY, 0);
                }
            }
            for (int i = 0; i < page.displayedItems.length; ++i) {
                final ItemStack is = page.displayedItems[i];
                if (!is.func_190926_b()) {
                    this.drawIS(is, k + 10 + i % 4 * 20, l + 10 + i / 4 * 20, mouseX, mouseY, 1);
                }
            }
            l += page.displayedItems.length / 4 * 20;
        }
        if (page.pageRecipe != null) {
            if (page.displayedItems != null) {
                l += page.displayedItems.length / 4 * 20;
            }
            l += this.drawRecipe(mouseX, mouseY, k, l, page.pageRecipe);
        }
        if (page.pageText != null && !page.pageText.isEmpty()) {
            RenderHelper.func_74519_b();
            GlStateManager.func_179147_l();
            GlStateManager.func_179112_b(770, 771);
            GlStateManager.func_179140_f();
            this.field_146289_q.func_78264_a(true);
            this.field_146289_q.func_78279_b(page.pageText, k + 12, l + 25, 110, GuiResearchBook.currentCategory.textColor);
            this.field_146289_q.func_78264_a(false);
            GlStateManager.func_179145_e();
            GlStateManager.func_179084_k();
            RenderHelper.func_74518_a();
            RenderHelper.func_74520_c();
        }
    }
    
    public void drawPage_1(final int mouseX, final int mouseY) {
        if (GuiResearchBook.currentDiscovery.pages.size() > GuiResearchBook.currentPage + 1) {
            final PageEntry page = GuiResearchBook.currentDiscovery.pages.get(GuiResearchBook.currentPage + 1);
            final int k = (this.field_146294_l - 256) / 2 + 128;
            int l = (this.field_146295_m - 168) / 2;
            if (page.pageTitle != null && !page.pageTitle.isEmpty()) {
                this.field_146289_q.func_175063_a(page.pageTitle, (float)(k + 6), (float)(l + 10), 16777215);
            }
            if (page.pageImgLink != null) {
                GlStateManager.func_179140_f();
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                this.field_146297_k.field_71446_o.func_110577_a(page.pageImgLink);
                func_152125_a(k + 16, l + 10, 0.0f, 0.0f, 256, 256, 100, 100, 256.0f, 256.0f);
                l += 86;
            }
            if (page.displayedItems != null) {
                for (int i = 0; i < page.displayedItems.length; ++i) {
                    final ItemStack is = page.displayedItems[i];
                    if (!is.func_190926_b()) {
                        this.drawIS(is, k + 10 + i % 4 * 20, l + 10 + i / 4 * 20, mouseX, mouseY, 0);
                    }
                }
                for (int i = 0; i < page.displayedItems.length; ++i) {
                    final ItemStack is = page.displayedItems[i];
                    if (!is.func_190926_b()) {
                        this.drawIS(is, k + 10 + i % 4 * 20, l + 10 + i / 4 * 20, mouseX, mouseY, 1);
                    }
                }
                l += page.displayedItems.length / 4 * 20;
            }
            if (page.pageRecipe != null) {
                if (page.displayedItems != null) {
                    l += page.displayedItems.length / 4 * 20;
                }
                l += this.drawRecipe(mouseX, mouseY, k, l, page.pageRecipe);
            }
            if (page.pageText != null && !page.pageText.isEmpty()) {
                final List<String> display = this.parse(page.pageText);
                for (int j = 0; j < display.size(); ++j) {
                    RenderHelper.func_74519_b();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179140_f();
                    this.field_146289_q.func_78264_a(true);
                    this.field_146289_q.func_78279_b(page.pageText, k + 12, l + 25, 110, GuiResearchBook.currentCategory.textColor);
                    this.field_146289_q.func_78264_a(false);
                    GlStateManager.func_179145_e();
                    GlStateManager.func_179084_k();
                    RenderHelper.func_74518_a();
                    RenderHelper.func_74520_c();
                }
            }
        }
    }
    
    public int drawRecipe(final int mouseX, final int mouseZ, final int k, final int l, final IRecipe toDraw) {
        if (toDraw instanceof ShapedOreRecipe) {
            return this.drawShapedOreRecipe(mouseX, mouseZ, k, l, (ShapedOreRecipe)toDraw);
        }
        if (toDraw instanceof ShapelessOreRecipe) {
            return this.drawShapelessOreRecipe(mouseX, mouseZ, k, l, (ShapelessOreRecipe)toDraw);
        }
        if (toDraw instanceof RadiatingChamberRecipe) {
            return this.drawRadiatingChamberRecipe(mouseX, mouseZ, k, l, (RadiatingChamberRecipe)toDraw);
        }
        if (toDraw instanceof MagicianTableRecipe) {
            return this.drawMagicianTableRecipe(mouseX, mouseZ, k, l, (MagicianTableRecipe)toDraw);
        }
        if (toDraw instanceof StructureRecipe) {
            return this.drawStructureRecipe(mouseX, mouseZ, k, l, (StructureRecipe)toDraw);
        }
        return 0;
    }
    
    public int drawMagicianTableRecipe(final int mouseX, final int mouseZ, final int k, final int l, final MagicianTableRecipe toDraw) {
        this.field_146289_q.func_78276_b(I18n.func_74838_a("essentialcraft.txt.magicianRecipe"), k + 24, l + 12, 2236962);
        this.field_146289_q.func_78276_b(I18n.func_74838_a("MRU Required: " + toDraw.mruRequired), k + 26, l + 83, 2236962);
        GlStateManager.func_179140_f();
        RenderHelper.func_74518_a();
        RenderHelper.func_74520_c();
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        DrawUtils.bindTexture("essentialcraft", "textures/gui/mrustorage.png");
        DrawUtils.drawTexturedModalRect(k + 7, l + 20, 0, 0, 18, 72, 1);
        final int percentageScaled = MathUtils.pixelatedTextureSize(toDraw.mruRequired, 5000, 72);
        final TextureAtlasSprite icon = (TextureAtlasSprite)EssentialCraftCore.proxy.getClientIcon("mru");
        DrawUtils.drawTexture(k + 8, l - 1 + 74 - percentageScaled + 20, icon, 16, percentageScaled - 2, 2.0f);
        this.drawSlotInRecipe(k, l, 13, 8);
        this.drawSlotInRecipe(k, l, 49, 8);
        this.drawSlotInRecipe(k, l, 13, 44);
        this.drawSlotInRecipe(k, l, 49, 44);
        this.drawSlotInRecipe(k, l, 31, 26);
        this.drawSlotInRecipe(k, l, 87, 26);
        if (toDraw.requiredItems.length > 0) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[0], System.currentTimeMillis() / 50L), k + 26 + 18, l + 25 + 18, mouseX, mouseZ, 0);
        }
        if (toDraw.requiredItems.length > 1) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[1], System.currentTimeMillis() / 50L), k + 26, l + 25, mouseX, mouseZ, 0);
        }
        if (toDraw.requiredItems.length > 2) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[2], System.currentTimeMillis() / 50L), k + 26 + 36, l + 25, mouseX, mouseZ, 0);
        }
        if (toDraw.requiredItems.length > 3) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[3], System.currentTimeMillis() / 50L), k + 26, l + 25 + 36, mouseX, mouseZ, 0);
        }
        if (toDraw.requiredItems.length > 4) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[4], System.currentTimeMillis() / 50L), k + 26 + 36, l + 25 + 36, mouseX, mouseZ, 0);
        }
        this.drawIS(toDraw.result, k + 26 + 74, l + 25 + 18, mouseX, mouseZ, 0);
        if (toDraw.requiredItems.length > 0) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[0], System.currentTimeMillis() / 50L), k + 26 + 18, l + 25 + 18, mouseX, mouseZ, 1);
        }
        if (toDraw.requiredItems.length > 1) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[1], System.currentTimeMillis() / 50L), k + 26, l + 25, mouseX, mouseZ, 1);
        }
        if (toDraw.requiredItems.length > 2) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[2], System.currentTimeMillis() / 50L), k + 26 + 36, l + 25, mouseX, mouseZ, 1);
        }
        if (toDraw.requiredItems.length > 3) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[3], System.currentTimeMillis() / 50L), k + 26, l + 25 + 36, mouseX, mouseZ, 1);
        }
        if (toDraw.requiredItems.length > 4) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.requiredItems[4], System.currentTimeMillis() / 50L), k + 26 + 36, l + 25 + 36, mouseX, mouseZ, 1);
        }
        this.drawIS(toDraw.result, k + 26 + 74, l + 25 + 18, mouseX, mouseZ, 1);
        return 80;
    }
    
    public int drawRadiatingChamberRecipe(final int mouseX, final int mouseZ, final int k, final int l, final RadiatingChamberRecipe toDraw) {
        this.field_146289_q.func_78276_b(I18n.func_74838_a("essentialcraft.txt.radiatingRecipe"), k + 8, l + 12, 2236962);
        this.field_146289_q.func_78276_b(I18n.func_74838_a("MRU Required: " + toDraw.mruRequired), k + 26, l + 83, 2236962);
        TextFormatting addeddCF = TextFormatting.RESET;
        float upperBalance = toDraw.upperBalanceLine;
        if (upperBalance > 2.0f) {
            upperBalance = 2.0f;
        }
        if (upperBalance > 1.0f) {
            addeddCF = TextFormatting.RED;
        }
        else if (upperBalance < 1.0f) {
            addeddCF = TextFormatting.BLUE;
        }
        else {
            addeddCF = TextFormatting.AQUA;
        }
        String balanceUpper = Float.toString(upperBalance);
        if (balanceUpper.length() > 4) {
            balanceUpper = balanceUpper.substring(0, 4);
        }
        this.field_146289_q.func_78276_b(I18n.func_74838_a(I18n.func_74838_a("essentialcraft.txt.format.upperBalance") + addeddCF + balanceUpper), k + 44, l + 32, 2236962);
        float lowerBalance = toDraw.lowerBalanceLine;
        if (lowerBalance < 0.0f) {
            lowerBalance = 0.0f;
        }
        if (lowerBalance > 1.0f) {
            addeddCF = TextFormatting.RED;
        }
        else if (lowerBalance < 1.0f) {
            addeddCF = TextFormatting.BLUE;
        }
        else {
            addeddCF = TextFormatting.AQUA;
        }
        String balanceLower = Float.toString(lowerBalance);
        if (balanceLower.length() > 4) {
            balanceLower = balanceLower.substring(0, 4);
        }
        this.field_146289_q.func_78276_b(I18n.func_74838_a(I18n.func_74838_a("essentialcraft.txt.format.lowerBalance") + addeddCF + balanceLower), k + 44, l + 32 + 36, 2236962);
        this.field_146289_q.func_78276_b("MRU/t " + (int)toDraw.costModifier, k + 44 + 18, l + 32 + 18, 2236962);
        GlStateManager.func_179140_f();
        RenderHelper.func_74518_a();
        RenderHelper.func_74520_c();
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        DrawUtils.bindTexture("essentialcraft", "textures/gui/mrustorage.png");
        DrawUtils.drawTexturedModalRect(k + 7, l + 20, 0, 0, 18, 72, 1);
        final int percentageScaled = MathUtils.pixelatedTextureSize((int)(toDraw.mruRequired * toDraw.costModifier), 5000, 72);
        final TextureAtlasSprite icon = (TextureAtlasSprite)EssentialCraftCore.proxy.getClientIcon("mru");
        DrawUtils.drawTexture(k + 8, l - 1 + 74 - percentageScaled + 20, icon, 16, percentageScaled - 2, 2.0f);
        final int positionY = 8;
        this.drawSlotInRecipe(k, l, 13, 4 + positionY);
        this.drawSlotInRecipe(k, l, 31, 22 + positionY);
        this.drawSlotInRecipe(k, l, 13, 40 + positionY);
        if (toDraw.recipeItems.length > 0) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.recipeItems[0], System.currentTimeMillis() / 50L), k + 26, l + 21 + positionY, mouseX, mouseZ, 0);
        }
        if (toDraw.recipeItems.length > 1) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.recipeItems[1], System.currentTimeMillis() / 50L), k + 26, l + 21 + 36 + positionY, mouseX, mouseZ, 0);
        }
        this.drawIS(toDraw.result, k + 26 + 18, l + 21 + 18 + positionY, mouseX, mouseZ, 0);
        if (toDraw.recipeItems.length > 0) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.recipeItems[0], System.currentTimeMillis() / 50L), k + 26, l + 21 + positionY, mouseX, mouseZ, 1);
        }
        if (toDraw.recipeItems.length > 1) {
            this.drawIS(IngredientUtils.getStackToDraw(toDraw.recipeItems[1], System.currentTimeMillis() / 50L), k + 26, l + 21 + 36 + positionY, mouseX, mouseZ, 1);
        }
        this.drawIS(toDraw.result, k + 26 + 18, l + 21 + 18 + positionY, mouseX, mouseZ, 1);
        return 90;
    }
    
    public int drawStructureRecipe(final int mouseX, final int mouseZ, final int k, int l, final StructureRecipe toDraw) {
        try {
            this.field_146289_q.func_78276_b(I18n.func_74838_a("essentialcraft.txt.structure"), k + 8, l + 12, 2236962);
            l += 5;
            final StructureRecipe recipe = toDraw;
            int highestStructureBlk = 0;
            for (final StructureBlock blk : recipe.structure) {
                if (blk.y > highestStructureBlk) {
                    highestStructureBlk = blk.y;
                }
            }
            for (final StructureBlock blk : recipe.structure) {
                if (!Config.renderStructuresFromAbove) {
                    this.drawSB(blk, k + 52 + blk.x * 12 - blk.z * 12, l + 32 + highestStructureBlk * 20 - blk.y * 20 + blk.z * 12 + blk.x * 12, mouseX, mouseZ, 0);
                }
                else {
                    this.drawSB(blk, k + 52 + blk.x * 12, l + 32 + highestStructureBlk * 20 + blk.z * 12, mouseX, mouseZ, 0);
                }
            }
            this.drawIS(recipe.referal, k + 52, l + 144, mouseX, mouseZ, 0);
            for (final StructureBlock blk : recipe.structure) {
                if (!Config.renderStructuresFromAbove) {
                    this.drawSB(blk, k + 52 + blk.x * 12 - blk.z * 12, l + 32 + highestStructureBlk * 20 - blk.y * 20 + blk.z * 12 + blk.x * 12, mouseX, mouseZ, 1);
                }
                else {
                    this.drawSB(blk, k + 52 + blk.x * 12, l + 32 + highestStructureBlk * 20 + blk.z * 12, mouseX, mouseZ, 1);
                }
            }
            this.drawIS(recipe.referal, k + 52, l + 144, mouseX, mouseZ, 1);
            return 60 + highestStructureBlk * 20;
        }
        catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public int getCraftingIndex(final int i, final int width, final int height) {
        int index;
        if (width == 1) {
            if (height == 3) {
                index = i * 3 + 1;
            }
            else if (height == 2) {
                index = i * 3 + 1;
            }
            else {
                index = 4;
            }
        }
        else if (height == 1) {
            index = i + 3;
        }
        else if (width == 2) {
            if ((index = i) > 1) {
                ++index;
                if (i > 3) {
                    ++index;
                }
            }
        }
        else if (height == 2) {
            index = i + 3;
        }
        else {
            index = i;
        }
        return index;
    }
    
    public int drawShapedOreRecipe(final int mouseX, final int mouseZ, final int k, final int l, final ShapedOreRecipe toDraw) {
        this.field_146289_q.func_78276_b(I18n.func_74838_a("essentialcraft.txt.shapedRecipe"), k + 8, l + 12, 2236962);
        final ShapedOreRecipe recipe = toDraw;
        for (int i = 0; i < 9; ++i) {
            this.drawSlotInRecipe(k, l + 6, i % 3 * 18, i / 3 * 18);
        }
        this.drawSlotInRecipe(k, l + 6, 80, 18);
        DrawUtils.bindTexture("minecraft", "textures/gui/container/crafting_table.png");
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        this.func_73729_b(k + 78 - 10, l + 23 + 18, 90, 35, 22, 15);
        final Random rnd = new Random(System.currentTimeMillis() / 1000L);
        final int[] drawingID = new int[9];
        for (int j = 0; j < recipe.getWidth() * recipe.getHeight(); ++j) {
            final int m = this.getCraftingIndex(j, recipe.getWidth(), recipe.getHeight());
            final Ingredient drawable = (Ingredient)toDraw.func_192400_c().get(j);
            ItemStack needToDraw = ItemStack.field_190927_a;
            if (drawable.func_193365_a().length > 0) {
                drawingID[j] = rnd.nextInt(drawable.func_193365_a().length);
                needToDraw = drawable.func_193365_a()[drawingID[j]];
            }
            if (!needToDraw.func_190926_b()) {
                this.drawIS(needToDraw, k + 13 + m % 3 * 18, l + 23 + m / 3 * 18, mouseX, mouseZ, 0);
            }
        }
        this.drawIS(recipe.func_77571_b(), k + 93, l + 41, mouseX, mouseZ, 0);
        for (int j = 0; j < recipe.getRecipeHeight() * recipe.getRecipeWidth(); ++j) {
            final int m = this.getCraftingIndex(j, recipe.getRecipeWidth(), recipe.getRecipeHeight());
            final Ingredient drawable = (Ingredient)recipe.func_192400_c().get(j);
            ItemStack needToDraw = ItemStack.field_190927_a;
            if (drawable.func_193365_a().length > 0) {
                needToDraw = drawable.func_193365_a()[drawingID[j]];
            }
            if (!needToDraw.func_190926_b()) {
                this.drawIS(needToDraw, k + 13 + m % 3 * 18, l + 23 + m / 3 * 18, mouseX, mouseZ, 1);
            }
        }
        this.drawIS(recipe.func_77571_b(), k + 93, l + 41, mouseX, mouseZ, 1);
        return 56;
    }
    
    public int drawShapelessOreRecipe(final int mouseX, final int mouseZ, final int k, final int l, final ShapelessOreRecipe toDraw) {
        this.field_146289_q.func_78276_b(I18n.func_74838_a("essentialcraft.txt.shapelessRecipe"), k + 8, l + 12, 2236962);
        final NonNullList<Ingredient> input = (NonNullList<Ingredient>)toDraw.func_192400_c();
        int width;
        int height;
        if (input.size() > 4) {
            height = (width = 3);
        }
        else if (input.size() > 1) {
            height = (width = 2);
        }
        else {
            height = (width = 1);
        }
        for (int i = 0; i < 9; ++i) {
            this.drawSlotInRecipe(k, l + 6, i % 3 * 18, i / 3 * 18);
        }
        this.drawSlotInRecipe(k, l + 6, 80, 18);
        DrawUtils.bindTexture("minecraft", "textures/gui/container/crafting_table.png");
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        this.func_73729_b(k + 78 - 10, l + 23 + 18, 90, 35, 22, 15);
        final Random rnd = new Random(System.currentTimeMillis() / 1000L);
        final int[] drawingID = new int[9];
        for (int j = 0; j < input.size(); ++j) {
            final int m = this.getCraftingIndex(j, width, height);
            final Ingredient drawable = (Ingredient)input.get(j);
            ItemStack needToDraw = ItemStack.field_190927_a;
            if (drawable.func_193365_a().length > 0) {
                drawingID[j] = rnd.nextInt(drawable.func_193365_a().length);
                needToDraw = drawable.func_193365_a()[drawingID[j]];
            }
            if (!needToDraw.func_190926_b()) {
                this.drawIS(needToDraw, k + 13 + m % 3 * 18, l + 23 + m / 3 * 18, mouseX, mouseZ, 0);
            }
        }
        this.drawIS(toDraw.func_77571_b(), k + 93, l + 41, mouseX, mouseZ, 0);
        for (int j = 0; j < input.size(); ++j) {
            final int m = this.getCraftingIndex(j, width, height);
            final Ingredient drawable = (Ingredient)input.get(j);
            ItemStack needToDraw = ItemStack.field_190927_a;
            if (drawable.func_193365_a().length > 0) {
                needToDraw = drawable.func_193365_a()[drawingID[j]];
            }
            if (!needToDraw.func_190926_b()) {
                this.drawIS(needToDraw, k + 13 + m % 3 * 18, l + 23 + m / 3 * 18, mouseX, mouseZ, 1);
            }
        }
        this.drawIS(toDraw.func_77571_b(), k + 93, l + 41, mouseX, mouseZ, 1);
        return 56;
    }
    
    public void drawSlotInRecipe(final int k, final int l, final int defaultX, final int defaultY) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
        RenderHelper.func_74519_b();
        GlStateManager.func_179091_B();
        this.func_73733_a(k + 12 + defaultX, l + 16 + defaultY, k + 12 + 18 + defaultX, l + 16 + 18 + defaultY, -1996510465, -2004326776);
        this.func_73733_a(k + 12 + defaultX, l + 16 + defaultY, k + 12 + 1 + defaultX, l + 16 + 18 + defaultY, -10092442, -13434829);
        this.func_73733_a(k + 12 + defaultX, l + 16 + 17 + defaultY, k + 12 + 18 + defaultX, l + 16 + 18 + defaultY, -13434829, -15663087);
        this.func_73733_a(k + 12 + 17 + defaultX, l + 16 + defaultY, k + 12 + 18 + defaultX, l + 16 + 18 + defaultY, -6750055, -15663087);
        this.func_73733_a(k + 12 + defaultX, l + 16 + defaultY, k + 12 + 18 + defaultX, l + 16 + 1 + defaultY, -10092442, -6750055);
    }
    
    public List<String> parse(final String s) {
        final List<String> rtLst = new ArrayList<String>();
        final int maxSymbols = 24;
        int cycle = 1;
        String added = "";
        for (int i = 0; i < s.length(); ++i) {
            if (i + 1 < s.length()) {
                final String substr = s.substring(i, i + 1);
                if (substr.equals("|")) {
                    rtLst.add(added);
                    rtLst.add("");
                    added = "";
                    ++i;
                }
                added += s.substring(i, i + 1);
            }
            else {
                added += s.substring(s.length() - 1);
            }
            if (added.length() > maxSymbols || added.length() + maxSymbols * (cycle - 1) == s.length() || i == s.length() - 1) {
                int index = added.lastIndexOf(" ");
                if (index == -1) {
                    index = 24;
                }
                if (index >= added.length()) {
                    index = added.length() - 1;
                }
                if (i == s.length() - 1) {
                    index = added.length() - 1;
                }
                final String add = added.substring(0, index + 1);
                rtLst.add(add);
                final String nxtCycle = added.substring(index + 1);
                added = "" + nxtCycle;
                ++cycle;
            }
        }
        return rtLst;
    }
    
    public void drawDiscoveries(final int mouseX, final int mouseZ) {
        final int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        this.field_146289_q.func_175063_a(TextFormatting.GOLD + " " + TextFormatting.BOLD + I18n.func_74838_a("essentialcraft.txt.book.startup"), (float)(k + 6), (float)(l + 10), 16777215);
        final CategoryEntry cat = GuiResearchBook.currentCategory;
        if (cat.name != null && !cat.name.isEmpty()) {
            this.field_146289_q.func_175063_a(TextFormatting.GOLD + " " + cat.name, (float)(k + 6 + 128), (float)(l + 10), 16777215);
        }
        else {
            this.field_146289_q.func_175063_a(TextFormatting.GOLD + " " + I18n.func_74838_a("ec3book.category_" + GuiResearchBook.currentCategory.id + ".name"), (float)(k + 6 + 128), (float)(l + 10), 16777215);
        }
        RenderHelper.func_74520_c();
        for (final GuiButton btn : this.field_146292_n) {
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final int id = btn.field_146127_k;
            if (id == 0) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 49, 238, 14, 18);
            }
            if (id == 1) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover && btn.field_146124_l) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                if (!btn.field_146124_l) {
                    GlStateManager.func_179124_c(0.3f, 0.3f, 0.3f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 243, 24, 13);
            }
            if (id == 2) {
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (hover && btn.field_146124_l) {
                    GlStateManager.func_179124_c(1.0f, 0.8f, 1.0f);
                }
                if (!btn.field_146124_l) {
                    GlStateManager.func_179124_c(0.3f, 0.3f, 0.3f);
                }
                this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 25, 243, 24, 13);
            }
            if (id > 2) {
                final DiscoveryEntry disc = cat.discoveries.get(48 * GuiResearchBook.currentDiscoveryPage + id - 3);
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                if (GuiResearchBook.currentCategory == null || GuiResearchBook.currentCategory.specificBookTextures == null) {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                }
                else {
                    this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.currentCategory.specificBookTextures);
                }
                if (disc.isNew) {
                    GlStateManager.func_179124_c(1.0f, 1.0f, 0.0f);
                }
                if (!hover) {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 222, 20, 20);
                }
                else {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 28, 222, 20, 20);
                }
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                if (!disc.displayStack.func_190926_b()) {
                    GuiResearchBook.itemRender.func_180450_b(disc.displayStack, btn.field_146128_h + 2, btn.field_146129_i + 2);
                }
                else if (disc.displayTexture != null) {
                    this.field_146297_k.field_71446_o.func_110577_a(disc.displayTexture);
                    func_146110_a(btn.field_146128_h + 2, btn.field_146129_i + 2, 0.0f, 0.0f, 16, 16, 16.0f, 16.0f);
                }
                if (!func_146271_m()) {
                    continue;
                }
                GlStateManager.func_179109_b(0.0f, 0.0f, 500.0f);
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                this.func_73731_b(this.field_146289_q, btn.field_146127_k - 2 + "", btn.field_146128_h + 15, btn.field_146129_i + 14, 16777215);
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                GlStateManager.func_179109_b(0.0f, 0.0f, -500.0f);
            }
        }
        RenderHelper.func_74518_a();
        for (int ik = 0; ik < this.field_146292_n.size(); ++ik) {
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            final GuiButton btn = this.field_146292_n.get(ik);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final int id = btn.field_146127_k;
            if (id == 0 && hover) {
                final List<String> catStr = new ArrayList<String>();
                catStr.add(I18n.func_74838_a("essentialcraft.text.button.back"));
                this.addHoveringText(catStr, mouseX, mouseZ);
            }
            if (id > 2 && hover) {
                final DiscoveryEntry disc = cat.discoveries.get(48 * GuiResearchBook.currentDiscoveryPage + id - 3);
                GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                final List<String> discStr = new ArrayList<String>();
                if (disc.name == null || disc.name.isEmpty()) {
                    discStr.add(TextFormatting.BOLD + I18n.func_74838_a("ec3book.discovery_" + disc.id + ".name"));
                }
                else {
                    discStr.add(disc.name);
                }
                if (disc.shortDescription == null || disc.shortDescription.isEmpty()) {
                    discStr.add(TextFormatting.ITALIC + I18n.func_74838_a("ec3book.discovery_" + disc.id + ".desc"));
                }
                else {
                    discStr.add(disc.shortDescription);
                }
                if (disc.isNew) {
                    discStr.add(TextFormatting.GOLD + "New");
                }
                discStr.add(I18n.func_74838_a("essentialcraft.txt.contains") + disc.pages.size() + I18n.func_74838_a("essentialcraft.txt.pages"));
                this.addHoveringText(discStr, mouseX, mouseZ);
            }
        }
    }
    
    public void drawCategories(final int mouseX, final int mouseZ) {
        int k = (this.field_146294_l - 256) / 2;
        final int l = (this.field_146295_m - 168) / 2;
        this.field_146289_q.func_175063_a(TextFormatting.GOLD + " " + TextFormatting.BOLD + I18n.func_74838_a("essentialcraft.txt.book.startup"), (float)(k + 6), (float)(l + 10), 16777215);
        this.field_146289_q.func_175063_a(TextFormatting.GOLD + " " + TextFormatting.BOLD + I18n.func_74838_a("essentialcraft.txt.book.categories"), (float)(k + 134), (float)(l + 10), 16777215);
        this.field_146289_q.func_175063_a(TextFormatting.GOLD + I18n.func_74838_a("essentialcraft.txt.book.containedKnowledge"), (float)(k + 16), (float)(l + 25), 16777215);
        final int tier = this.bookTag.func_74762_e("tier");
        for (int i = 0; i <= tier; ++i) {
            this.field_146289_q.func_175063_a(TextFormatting.GRAY + "-" + TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.book.tier_" + i), (float)(k + 16), (float)(l + 35 + i * 10), 16777215);
        }
        this.field_146289_q.func_175063_a(TextFormatting.GOLD + I18n.func_74838_a("essentialcraft.txt.book.edition"), (float)(k + 16), (float)(l + 90), 16777215);
        this.field_146289_q.func_78276_b(TextFormatting.DARK_GREEN + FMLCommonHandler.instance().findContainerFor((Object)EssentialCraftCore.core).getDisplayVersion() + "r", k + 16, l + 100, 16777215);
        k += 128;
        this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        RenderHelper.func_74520_c();
        for (int ik = 0; ik < this.field_146292_n.size(); ++ik) {
            final GuiButton btn = this.field_146292_n.get(ik);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final CategoryEntry cat = ApiCore.CATEGORY_LIST.get(ik);
            final int reqTier = cat.reqTier;
            if (tier >= reqTier) {
                this.field_146297_k.field_71446_o.func_110577_a(GuiResearchBook.DEFAULT_BOOK_TEXTURE);
                if (!hover) {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 222, 20, 20);
                }
                else {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 28, 222, 20, 20);
                }
                if (!cat.displayStack.func_190926_b()) {
                    GuiResearchBook.itemRender.func_180450_b(cat.displayStack, btn.field_146128_h + 2, btn.field_146129_i + 2);
                }
                else if (cat.displayTexture != null) {
                    this.field_146297_k.field_71446_o.func_110577_a(cat.displayTexture);
                    func_146110_a(btn.field_146128_h + 2, btn.field_146129_i + 2, 0.0f, 0.0f, 16, 16, 16.0f, 16.0f);
                }
                if (func_146271_m()) {
                    GlStateManager.func_179109_b(0.0f, 0.0f, 500.0f);
                    this.func_73731_b(this.field_146289_q, btn.field_146127_k + 1 + "", btn.field_146128_h + 15, btn.field_146129_i + 14, 16777215);
                    GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                    GlStateManager.func_179109_b(0.0f, 0.0f, -500.0f);
                }
            }
        }
        RenderHelper.func_74518_a();
        for (int ik = 0; ik < this.field_146292_n.size(); ++ik) {
            final GuiButton btn = this.field_146292_n.get(ik);
            final boolean hover = mouseX >= btn.field_146128_h && mouseZ >= btn.field_146129_i && mouseX < btn.field_146128_h + btn.field_146120_f && mouseZ < btn.field_146129_i + btn.field_146121_g;
            final CategoryEntry cat = ApiCore.CATEGORY_LIST.get(ik);
            final int reqTier = cat.reqTier;
            if (tier >= reqTier && hover) {
                final List<String> catStr = new ArrayList<String>();
                if (cat.name == null || cat.name.isEmpty()) {
                    catStr.add(TextFormatting.BOLD + I18n.func_74838_a("ec3book.category_" + cat.id + ".name"));
                }
                else {
                    catStr.add(cat.name);
                }
                if (cat.shortDescription == null || cat.shortDescription.isEmpty()) {
                    catStr.add(TextFormatting.ITALIC + I18n.func_74838_a("ec3book.category_" + cat.id + ".desc"));
                }
                else {
                    catStr.add(cat.shortDescription);
                }
                catStr.add(I18n.func_74838_a("essentialcraft.txt.contains") + cat.discoveries.size() + I18n.func_74838_a("essentialcraft.txt.entries"));
                this.addHoveringText(catStr, mouseX, mouseZ);
            }
        }
    }
    
    public void drawIS(ItemStack toDraw, final int pX, final int pZ, final int mX, final int mZ, final int phase) {
        if (!toDraw.func_190926_b()) {
            toDraw = (ItemStack)MathUtils.randomElement((Iterable)MiscUtils.getSubItemsToDraw(toDraw), new Random(System.currentTimeMillis() / 1000L));
            if (phase == 0) {
                RenderHelper.func_74520_c();
                GuiResearchBook.itemRender.func_180450_b(toDraw, pX, pZ);
                RenderHelper.func_74518_a();
                if (toDraw.func_190916_E() > 1) {
                    GlStateManager.func_179109_b(0.0f, 0.0f, 500.0f);
                    this.field_146289_q.func_175063_a(toDraw.func_190916_E() + "", (float)(pX + 10), (float)(pZ + 10), 16777215);
                    GlStateManager.func_179109_b(0.0f, 0.0f, -500.0f);
                }
            }
            else {
                final boolean hover = mX >= pX && mZ >= pZ && mX < pX + 16 && mZ < pZ + 16;
                if (hover) {
                    final List<String> catStr = (List<String>)toDraw.func_82840_a((EntityPlayer)this.field_146297_k.field_71439_g, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
                    final DiscoveryEntry ds = ApiCore.findDiscoveryByIS(toDraw);
                    if (ds != null && ds != GuiResearchBook.currentDiscovery) {
                        catStr.add(TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.is.press"));
                        if (Mouse.isButtonDown(0) && !this.isLeftMouseKeyPressed) {
                            GuiResearchBook.prevState.add(new Object[] { GuiResearchBook.currentDiscovery, GuiResearchBook.currentPage, GuiResearchBook.currentDiscoveryPage });
                            this.isLeftMouseKeyPressed = true;
                            GuiResearchBook.currentPage = 0;
                            GuiResearchBook.currentDiscoveryPage = 0;
                            Label_0468: {
                                if ((GuiResearchBook.currentDiscovery = ds) != null) {
                                    for (int i = 0; i < ds.pages.size(); ++i) {
                                        final PageEntry entry = ds.pages.get(i);
                                        if (entry != null) {
                                            if (entry.displayedItems != null && entry.displayedItems.length > 0) {
                                                for (final ItemStack is : entry.displayedItems) {
                                                    if (toDraw.func_77969_a(is)) {
                                                        GuiResearchBook.currentPage = i - i % 2;
                                                        break Label_0468;
                                                    }
                                                }
                                            }
                                            if (entry.pageRecipe != null) {
                                                final ItemStack result = entry.pageRecipe.func_77571_b();
                                                if (result.func_77969_a(toDraw)) {
                                                    GuiResearchBook.currentPage = i - i % 2;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            this.func_73866_w_();
                        }
                    }
                    this.addHoveringText(catStr, mX, mZ);
                }
            }
        }
    }
    
    public void drawSB(final StructureBlock drawable, final int pX, final int pZ, final int mX, final int mZ, final int phase) {
        ItemStack toDraw;
        if (drawable.blk == Blocks.field_150350_a || Item.func_150898_a(drawable.blk) == null) {
            if (drawable.blk == Blocks.field_150355_j) {
                toDraw = new ItemStack(BlocksCore.water);
            }
            else if (drawable.blk == Blocks.field_150353_l) {
                toDraw = new ItemStack(BlocksCore.lava);
            }
            else if (drawable.blk == Blocks.field_150480_ab) {
                toDraw = new ItemStack(BlocksCore.fire);
            }
            else if (drawable.blk == Blocks.field_150350_a) {
                toDraw = new ItemStack(BlocksCore.air);
            }
            else {
                toDraw = ItemStack.field_190927_a;
            }
        }
        else {
            toDraw = new ItemStack(drawable.blk, 1, drawable.metadata);
        }
        if (phase == 0) {
            RenderHelper.func_74520_c();
            GuiResearchBook.itemRender.func_180450_b(toDraw, pX, pZ);
            RenderHelper.func_74518_a();
        }
        else {
            final boolean hover = mX >= pX && mZ >= pZ && mX < pX + 16 && mZ < pZ + 16;
            if (hover) {
                final List<String> catStr = (List<String>)toDraw.func_82840_a((EntityPlayer)this.field_146297_k.field_71439_g, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
                catStr.add(I18n.func_74838_a("essentialcraft.txt.relativePosition"));
                catStr.add("x: " + drawable.x);
                catStr.add("y: " + drawable.y);
                catStr.add("z: " + drawable.z);
                Label_0622: {
                    if (ApiCore.findDiscoveryByIS(toDraw) != null) {
                        catStr.add(TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.is.press"));
                        if (Mouse.isButtonDown(0) && !this.isLeftMouseKeyPressed) {
                            GuiResearchBook.prevState.add(new Object[] { GuiResearchBook.currentDiscovery, GuiResearchBook.currentPage, GuiResearchBook.currentDiscoveryPage });
                            this.isLeftMouseKeyPressed = true;
                            final DiscoveryEntry switchTo = ApiCore.findDiscoveryByIS(toDraw);
                            GuiResearchBook.currentPage = 0;
                            GuiResearchBook.currentDiscoveryPage = 0;
                            if ((GuiResearchBook.currentDiscovery = switchTo) != null) {
                                for (int i = 0; i < switchTo.pages.size(); ++i) {
                                    final PageEntry entry = switchTo.pages.get(i);
                                    if (entry != null) {
                                        if (entry.displayedItems != null && entry.displayedItems.length > 0) {
                                            for (final ItemStack is : entry.displayedItems) {
                                                if (toDraw.func_77969_a(is)) {
                                                    GuiResearchBook.currentPage = i - i % 2;
                                                    break Label_0622;
                                                }
                                            }
                                        }
                                        if (entry.pageRecipe != null) {
                                            final ItemStack result = entry.pageRecipe.func_77571_b();
                                            if (result.func_77969_a(toDraw)) {
                                                GuiResearchBook.currentPage = i - i % 2;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.addHoveringText(catStr, mX, mZ);
            }
        }
    }
    
    protected void func_73864_a(final int mouseX, final int mouseY, final int mouseButton) {
        try {
            super.func_73864_a(mouseX, mouseY, mouseButton);
        }
        catch (Exception ex) {}
    }
    
    protected void func_146284_a(final GuiButton b) {
        if (GuiResearchBook.ticksBeforePressing > 0) {
            return;
        }
        if (GuiResearchBook.currentCategory == null) {
            final CategoryEntry cat = GuiResearchBook.currentCategory = ApiCore.CATEGORY_LIST.get(b.field_146127_k);
            this.func_73866_w_();
            return;
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery == null) {
            if (b.field_146127_k == 0) {
                GuiResearchBook.currentCategory = null;
                this.func_73866_w_();
                return;
            }
            if (b.field_146127_k == 1) {
                ++GuiResearchBook.currentDiscoveryPage;
                this.func_73866_w_();
                return;
            }
            if (b.field_146127_k == 2) {
                --GuiResearchBook.currentDiscoveryPage;
                this.func_73866_w_();
                return;
            }
            if (b.field_146127_k > 2) {
                final DiscoveryEntry disc = GuiResearchBook.currentDiscovery = GuiResearchBook.currentCategory.discoveries.get(48 * GuiResearchBook.currentDiscoveryPage + b.field_146127_k - 3);
                this.func_73866_w_();
                return;
            }
        }
        if (GuiResearchBook.currentCategory != null && GuiResearchBook.currentDiscovery != null) {
            if (b.field_146127_k == 0) {
                GuiResearchBook.currentDiscovery = null;
                this.func_73866_w_();
                return;
            }
            if (b.field_146127_k == 1) {
                GuiResearchBook.currentPage -= 2;
                this.func_73866_w_();
                return;
            }
            if (b.field_146127_k == 2) {
                GuiResearchBook.currentPage += 2;
                this.func_73866_w_();
            }
        }
    }
    
    protected void func_146285_a(final ItemStack stack, final int x, final int y) {
        final List<String> list = (List<String>)stack.func_82840_a((EntityPlayer)this.field_146297_k.field_71439_g, (ITooltipFlag)(this.field_146297_k.field_71474_y.field_82882_x ? ITooltipFlag.TooltipFlags.ADVANCED : ITooltipFlag.TooltipFlags.NORMAL));
        for (int k = 0; k < list.size(); ++k) {
            if (k == 0) {
                list.set(k, stack.func_77953_t().field_77934_f + list.get(k));
            }
            else {
                list.set(k, TextFormatting.GRAY + list.get(k));
            }
        }
        final FontRenderer font = stack.func_77973_b().getFontRenderer(stack);
        this.drawHoveringText(list, x, y, (font == null) ? this.field_146289_q : font);
    }
    
    protected void addHoveringText(final List<String> list, final int x, final int y) {
        GuiResearchBook.hoveringText.add(new Object[] { list, x, y, this.field_146289_q });
    }
    
    protected void drawHoveringText(final List<String> list, final int x, final int y, final FontRenderer font) {
        GlStateManager.func_179140_f();
        if (!list.isEmpty()) {
            GlStateManager.func_179101_C();
            RenderHelper.func_74518_a();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            int k = 0;
            for (final String s : list) {
                final int l = font.func_78256_a(s);
                if (l > k) {
                    k = l;
                }
            }
            int j2 = x + 12;
            int k2 = y - 12;
            int i1 = 8;
            if (list.size() > 1) {
                i1 += 2 + (list.size() - 1) * 10;
            }
            if (j2 + k > this.field_146294_l) {
                j2 -= 28 + k;
            }
            if (k2 + i1 + 6 > this.field_146295_m) {
                k2 = this.field_146295_m - i1 - 6;
            }
            this.field_73735_i = 600.0f;
            GuiResearchBook.itemRender.field_77023_b = 600.0f;
            final int j3 = -267386872;
            this.func_73733_a(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j3, j3);
            this.func_73733_a(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j3, j3);
            this.func_73733_a(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j3, j3);
            this.func_73733_a(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j3, j3);
            this.func_73733_a(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j3, j3);
            final int k3 = 1347420415;
            final int l2 = (k3 & 0xFEFEFE) >> 1 | (k3 & 0xFF000000);
            this.func_73733_a(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k3, l2);
            this.func_73733_a(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k3, l2);
            this.func_73733_a(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k3, k3);
            this.func_73733_a(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l2, l2);
            for (int i2 = 0; i2 < list.size(); ++i2) {
                final String s2 = list.get(i2);
                font.func_175063_a(s2, (float)j2, (float)k2, -1);
                if (i2 == 0) {
                    k2 += 2;
                }
                k2 += 10;
            }
            this.field_73735_i = 0.0f;
            GuiResearchBook.itemRender.field_77023_b = 0.0f;
            GlStateManager.func_179145_e();
            GlStateManager.func_179126_j();
            RenderHelper.func_74519_b();
            GlStateManager.func_179091_B();
        }
        GlStateManager.func_179145_e();
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    static {
        GuiResearchBook.itemRender = Minecraft.func_71410_x().func_175599_af();
        GuiResearchBook.hoveringText = new ArrayList<Object[]>();
        GuiResearchBook.prevState = new ArrayList<Object[]>();
        DEFAULT_BOOK_TEXTURE = new ResourceLocation("essentialcraft", "textures/gui/research_book_generic.png");
    }
}
