package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiMoonWell extends GuiCommon
{
    public GuiMoonWell(final Container c, final TileEntity tile) {
        super(c, tile);
        this.elementList.add(new GuiMRUStorage(7, 4, tile));
        this.elementList.add(new GuiMRUState(25, 58, tile, 0));
        this.elementList.add(new GuiMoonState(25, 40));
        this.elementList.add(new GuiHeightState(152, 40, tile));
        this.elementList.add(new GuiMRUGenerated(43, 40, tile, "moonwell"));
        this.elementList.add(new GuiBalanceState(25, 22, tile));
    }
}
