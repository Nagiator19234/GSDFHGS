package essentialcraft.client.gui;

import net.minecraft.client.gui.inventory.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.inventory.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import DummyCore.Utils.*;

public class GuiMagicalChest extends GuiContainer
{
    TileMagicalChest tile;
    
    public GuiMagicalChest(final InventoryPlayer inventoryPlayer, final TileMagicalChest chest) {
        super((Container)new ContainerMagicalChest(inventoryPlayer, chest));
        this.tile = chest;
        if (this.tile.func_145832_p() == 0) {
            this.field_146999_f = 176;
            this.field_147000_g = 222;
        }
        else if (this.tile.func_145832_p() == 1) {
            this.field_146999_f = 256;
            this.field_147000_g = 256;
        }
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
    
    protected void func_146976_a(final float partialTicks, final int mX, final int mY) {
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        if (this.tile.func_145832_p() == 0) {
            DrawUtils.bindTexture("essentialcraft", "textures/gui/magical_chest.png");
        }
        else {
            DrawUtils.bindTexture("essentialcraft", "textures/gui/void_chest.png");
        }
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
    }
}
