package essentialcraft.client.gui;

import net.minecraft.client.gui.inventory.*;
import essentialcraft.common.inventory.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import DummyCore.Utils.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import java.util.*;

public class GuiFilter extends GuiContainer
{
    public InventoryMagicFilter filter;
    
    public GuiFilter(final Container c, final InventoryMagicFilter inv) {
        super(c);
        this.filter = inv;
    }
    
    protected boolean func_146983_a(final int slot) {
        return false;
    }
    
    public void func_73866_w_() {
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        if (this.filter.filterStack.func_77952_i() == 1 || this.filter.filterStack.func_77952_i() == 3) {
            this.field_146292_n.add(new GuiButton(0, k + 20, l + 6, 20, 20, ""));
            this.field_146292_n.add(new GuiButton(1, k + 20, l + 30, 20, 20, ""));
            this.field_146292_n.add(new GuiButton(2, k + 20, l + 54, 20, 20, ""));
        }
        super.func_73866_w_();
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        MiscUtils.handleButtonPress(par1GuiButton.field_146127_k, (Class)this.getClass(), (Class)par1GuiButton.getClass(), (EntityPlayer)this.field_146297_k.field_71439_g, 0, 0, 0);
    }
    
    protected void func_146976_a(final float partialTicks, final int mouseX, final int mouseY) {
        DrawUtils.bindTexture("minecraft", "textures/gui/container/dispenser.png");
        this.func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
    }
    
    public void func_73863_a(final int mX, final int mY, final float partialTicks) {
        this.func_146276_q_();
        if (!this.filter.filterStack.func_77969_a(this.field_146297_k.field_71439_g.func_184614_ca())) {
            this.filter.filterStack = this.field_146297_k.field_71439_g.func_184614_ca();
        }
        if (!ItemStack.func_77970_a(this.filter.filterStack, this.field_146297_k.field_71439_g.func_184614_ca())) {
            this.filter.filterStack = this.field_146297_k.field_71439_g.func_184614_ca();
        }
        super.func_73863_a(mX, mY, partialTicks);
        for (int ik = 0; ik < this.field_146292_n.size(); ++ik) {
            RenderHelper.func_74518_a();
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
            final GuiButton btn = this.field_146292_n.get(ik);
            final boolean hover = mX >= btn.field_146128_h && mY >= btn.field_146129_i && mX < btn.field_146128_h + btn.field_146120_f && mY < btn.field_146129_i + btn.field_146121_g;
            final int id = btn.field_146127_k;
            if (id == 0) {
                DrawUtils.bindTexture("essentialcraft", "textures/gui/guiFilterButtons.png");
                if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreMeta")) {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 20, 0, 20, 20);
                }
                else {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 0, 20, 20);
                }
            }
            if (id == 1) {
                DrawUtils.bindTexture("essentialcraft", "textures/gui/guiFilterButtons.png");
                if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreNBT")) {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 20, 20, 20, 20);
                }
                else {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 20, 20, 20);
                }
            }
            if (id == 2) {
                DrawUtils.bindTexture("essentialcraft", "textures/gui/guiFilterButtons.png");
                if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreOreDict")) {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 20, 40, 20, 20);
                }
                else {
                    this.func_73729_b(btn.field_146128_h, btn.field_146129_i, 0, 40, 20, 20);
                }
            }
            if (hover) {
                if (id == 0) {
                    final List<String> drawedLst = new ArrayList<String>();
                    if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreMeta")) {
                        drawedLst.add("Metadata: Ignored");
                    }
                    else {
                        drawedLst.add("Metadata: Not Ignored");
                    }
                    this.drawHoveringText(drawedLst, mX, mY, this.field_146289_q);
                }
                if (id == 1) {
                    final List<String> drawedLst = new ArrayList<String>();
                    if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreNBT")) {
                        drawedLst.add("NBT Tag: Ignored");
                    }
                    else {
                        drawedLst.add("NBT Tag: Not Ignored");
                    }
                    this.drawHoveringText(drawedLst, mX, mY, this.field_146289_q);
                }
                if (id == 2) {
                    final List<String> drawedLst = new ArrayList<String>();
                    if (MiscUtils.getStackTag(this.filter.filterStack).func_74767_n("ignoreOreDict")) {
                        drawedLst.add("Ore Dictionary: Ignored");
                    }
                    else {
                        drawedLst.add("Ore Dictionary: Not Ignored");
                    }
                    this.drawHoveringText(drawedLst, mX, mY, this.field_146289_q);
                }
            }
        }
        this.func_191948_b(mX, mY);
    }
    
    protected void drawHoveringText(final List<String> list, final int x, final int y, final FontRenderer font) {
        GlStateManager.func_179140_f();
        if (!list.isEmpty()) {
            GlStateManager.func_179101_C();
            RenderHelper.func_74518_a();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            int k = 0;
            for (final String s : list) {
                final int l = font.func_78256_a(s);
                if (l > k) {
                    k = l;
                }
            }
            int j2 = x + 12;
            int k2 = y - 12;
            int i1 = 8;
            if (list.size() > 1) {
                i1 += 2 + (list.size() - 1) * 10;
            }
            if (j2 + k > this.field_146294_l) {
                j2 -= 28 + k;
            }
            if (k2 + i1 + 6 > this.field_146295_m) {
                k2 = this.field_146295_m - i1 - 6;
            }
            this.field_73735_i = 600.0f;
            this.field_146296_j.field_77023_b = 600.0f;
            final int j3 = -267386872;
            this.func_73733_a(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j3, j3);
            this.func_73733_a(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j3, j3);
            this.func_73733_a(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j3, j3);
            this.func_73733_a(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j3, j3);
            this.func_73733_a(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j3, j3);
            final int k3 = 1347420415;
            final int l2 = (k3 & 0xFEFEFE) >> 1 | (k3 & 0xFF000000);
            this.func_73733_a(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k3, l2);
            this.func_73733_a(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k3, l2);
            this.func_73733_a(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k3, k3);
            this.func_73733_a(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l2, l2);
            for (int i2 = 0; i2 < list.size(); ++i2) {
                final String s2 = list.get(i2);
                font.func_175063_a(s2, (float)j2, (float)k2, -1);
                if (i2 == 0) {
                    k2 += 2;
                }
                k2 += 10;
            }
            this.field_73735_i = 0.0f;
            this.field_146296_j.field_77023_b = 0.0f;
            GlStateManager.func_179145_e();
            GlStateManager.func_179126_j();
            RenderHelper.func_74519_b();
            GlStateManager.func_179091_B();
        }
        GlStateManager.func_179145_e();
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
    }
}
