package essentialcraft.client.gui.element;

import net.minecraft.util.*;
import DummyCore.Utils.*;
import net.minecraft.client.*;

public class GuiMoonState extends GuiTextElement
{
    public GuiMoonState(final int i, final int j) {
        super(i, j);
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 18, 18);
        DrawUtils.bindTexture("essentialcraft", "textures/gui/gui_moon_phases.png");
        final int moonPhase = Minecraft.func_71410_x().field_71441_e.func_72853_d();
        this.drawTexturedModalRect(posX + 1, posY + 1, 16 * moonPhase, 0, 16, 16);
        this.drawText(posX, posY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
    }
}
