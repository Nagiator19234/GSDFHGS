package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import DummyCore.Utils.*;

public class GuiProgressBar_MagicianTable extends GuiTextElement
{
    public TileMagicianTable tile;
    
    public GuiProgressBar_MagicianTable(final int i, final int j, final TileMagicianTable table) {
        super(i, j);
        this.tile = table;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        DrawUtils.bindTexture("essentialcraft", "textures/gui/gui_magiciantable.png");
        final int current = (int)this.tile.progressLevel;
        final int max = (int)this.tile.progressRequired;
        final int progress = MathUtils.pixelatedTextureSize(current, max, 18);
        this.drawTexturedModalRect(posX, posY, 0, 0, 54, 54);
        this.drawTexturedModalRect(posX, posY + 18, 54, 18, progress, 18);
        this.drawTexturedModalRect(posX + 18, posY, 72, 0, 18, progress);
        this.drawTexturedModalRect(posX + 54 - progress, posY + 18, 108 - progress, 18, progress, 18);
        this.drawTexturedModalRect(posX + 18, posY + 54 - progress, 72, 54 - progress, 18, progress);
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
    }
}
