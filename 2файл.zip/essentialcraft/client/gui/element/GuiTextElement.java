package essentialcraft.client.gui.element;

import DummyCore.Client.*;
import net.minecraft.util.*;

public abstract class GuiTextElement extends GuiElement
{
    private ResourceLocation rec;
    public int x;
    public int y;
    
    public GuiTextElement(final int i, final int j) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/slot_common.png");
        this.x = i;
        this.y = j;
    }
    
    public ResourceLocation getElementTexture() {
        return this.rec;
    }
    
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 16, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 32, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 48, posY, 1, 0, 17, 18);
        this.drawText(posX, posY);
    }
    
    public abstract void drawText(final int p0, final int p1);
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
}
