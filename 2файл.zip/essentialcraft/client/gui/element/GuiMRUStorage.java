package essentialcraft.client.gui.element;

import DummyCore.Client.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.api.*;
import net.minecraft.client.renderer.texture.*;
import essentialcraft.common.mod.*;
import DummyCore.Utils.*;

public class GuiMRUStorage extends GuiElement
{
    private ResourceLocation rec;
    public int x;
    public int y;
    public IMRUHandler tile;
    
    public GuiMRUStorage(final int i, final int j, final IMRUHandler t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mrustorage.png");
        this.x = i;
        this.y = j;
        this.tile = t;
    }
    
    public GuiMRUStorage(final int i, final int j, final TileEntity t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mrustorage.png");
        this.x = i;
        this.y = j;
        if (t.hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
            this.tile = (IMRUHandler)t.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
        }
        else {
            if (!(t instanceof IMRUDisplay)) {
                throw new IllegalArgumentException("Tile does not handle MRU");
            }
            this.tile = ((IMRUDisplay)t).getMRUHandler();
        }
    }
    
    public ResourceLocation getElementTexture() {
        return this.rec;
    }
    
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 18, 72);
        final int percentageScaled = MathUtils.pixelatedTextureSize(this.tile.getMRU(), this.tile.getMaxMRU(), 72);
        final TextureAtlasSprite icon = (TextureAtlasSprite)EssentialCraftCore.proxy.getClientIcon("mru");
        DrawUtils.drawTexture(posX + 1, posY + 73 - percentageScaled, icon, 16, percentageScaled - 2, 0.0f);
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
}
