package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import net.minecraft.client.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraft.util.*;
import essentialcraft.common.item.*;
import net.minecraft.client.gui.*;

public class GuiWeatherState extends GuiTextElement
{
    public TileWeatherController tile;
    
    public GuiWeatherState(final int i, final int j, final TileWeatherController t) {
        super(i, j);
        this.tile = t;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 16, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 32, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 48, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 64, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 80, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 96, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 111, posY, 1, 0, 17, 18);
        this.drawText(posX, posY);
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final FontRenderer fontRenderer = Minecraft.func_71410_x().field_71466_p;
        if (this.tile.func_70301_a(1).func_190926_b()) {
            fontRenderer.func_175063_a("No Catalyst!", (float)(posX + 4), (float)(posY + 5), 16776960);
        }
        else if (this.tile.func_70301_a(2).func_190916_E() >= this.tile.func_70301_a(2).func_77976_d()) {
            fontRenderer.func_175063_a("Bottle Storage Full!", (float)(posX + 4), (float)(posY + 5), 16776960);
        }
        else if (this.tile.getCapability(CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, null).getMRU() < 100) {
            fontRenderer.func_175063_a("No MRU!", (float)(posX + 4), (float)(posY + 5), 16711680);
        }
        else if (this.tile.func_70301_a(1).func_77973_b() == ItemsCore.clearing_catalyst) {
            if (this.tile.func_145831_w().func_72896_J()) {
                fontRenderer.func_175063_a("Clearing Skies...", (float)(posX + 4), (float)(posY + 5), 65280);
            }
            else {
                fontRenderer.func_175063_a("Already Clear!", (float)(posX + 4), (float)(posY + 5), 16711680);
            }
        }
        else if (this.tile.func_70301_a(1).func_77973_b() == ItemsCore.raining_catalyst) {
            if (!this.tile.func_145831_w().func_72896_J() || this.tile.func_145831_w().func_72911_I()) {
                fontRenderer.func_175063_a("Making Rain...", (float)(posX + 4), (float)(posY + 5), 65280);
            }
            else {
                fontRenderer.func_175063_a("Already Raining!", (float)(posX + 4), (float)(posY + 5), 16711680);
            }
        }
        else if (this.tile.func_70301_a(1).func_77973_b() == ItemsCore.thundering_catalyst) {
            if (!this.tile.func_145831_w().func_72911_I()) {
                fontRenderer.func_175063_a("Creating Thunder...", (float)(posX + 4), (float)(posY + 5), 65280);
            }
            else {
                fontRenderer.func_175063_a("Already Thundering!", (float)(posX + 4), (float)(posY + 5), 16711680);
            }
        }
        else {
            fontRenderer.func_175063_a("Invalid Item!", (float)(posX + 4), (float)(posY + 5), 16711680);
        }
    }
}
