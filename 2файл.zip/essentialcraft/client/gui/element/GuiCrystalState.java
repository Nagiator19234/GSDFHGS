package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import essentialcraft.common.tile.*;
import net.minecraft.client.gui.*;
import net.minecraft.item.*;

public class GuiCrystalState extends GuiTextElement
{
    public TileCrystalController tile;
    
    public GuiCrystalState(final int i, final int j, final TileEntity t) {
        super(i, j);
        this.tile = (TileCrystalController)t;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        if (this.tile.getCapability(CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, null).getMRU() > 0) {
            this.drawTexturedModalRect(posX, posY, 0, 0, 17, 17);
            this.drawTexturedModalRect(posX, posY + 19, 0, 1, 17, 17);
            this.drawTexturedModalRect(posX, posY + 17, 0, 1, 17, 2);
            for (int x = 0; x < 5; ++x) {
                this.drawTexturedModalRect(posX + 16 + 16 * x, posY, 1, 0, 16, 17);
                this.drawTexturedModalRect(posX + 16 + 16 * x, posY + 19, 1, 1, 16, 17);
                this.drawTexturedModalRect(posX + 16 + 16 * x, posY + 17, 1, 1, 16, 2);
            }
            this.drawTexturedModalRect(posX + 3 + 80, posY, 1, 0, 17, 17);
            this.drawTexturedModalRect(posX + 3 + 80, posY + 19, 1, 1, 17, 17);
            this.drawTexturedModalRect(posX + 3 + 80, posY + 17, 1, 1, 17, 2);
            GlStateManager.func_179094_E();
            GlStateManager.func_179121_F();
            this.drawText(posX, posY);
        }
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final TileElementalCrystal crystal = this.tile.getCrystal();
        final FontRenderer fontRenderer = Minecraft.func_71410_x().field_71466_p;
        if (crystal != null) {
            fontRenderer.func_175063_a("Fire: " + (int)crystal.fire + "%", (float)(posX + 2), (float)(posY + 4), 16777215);
            fontRenderer.func_175063_a("Water: " + (int)crystal.water + "%", (float)(posX + 2), (float)(posY + 14), 16777215);
            fontRenderer.func_175063_a("Earth: " + (int)crystal.earth + "%", (float)(posX + 2), (float)(posY + 24), 16777215);
            fontRenderer.func_175063_a("Air: " + (int)crystal.air + "%", (float)(posX + 50), (float)(posY + 4), 16777215);
            fontRenderer.func_175063_a("Size: " + (int)crystal.size + "%", (float)(posX + 50), (float)(posY + 14), 16777215);
            final ItemStack e = this.tile.func_70301_a(1);
            if (!e.func_190926_b()) {
                final int rarity = (int)(e.func_77952_i() / 4.0f);
                final float chance = (float)(2 * (rarity + 1));
                fontRenderer.func_175063_a("Chance: " + (int)chance + "%", (float)(posX + 50), (float)(posY + 24), 16777215);
            }
        }
    }
}
