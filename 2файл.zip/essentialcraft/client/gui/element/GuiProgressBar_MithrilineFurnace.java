package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;

public class GuiProgressBar_MithrilineFurnace extends GuiTextElement
{
    public TileMithrilineFurnace tile;
    
    public GuiProgressBar_MithrilineFurnace(final int i, final int j, final TileMithrilineFurnace furnace) {
        super(i, j);
        this.tile = furnace;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        DrawUtils.bindTexture("essentialcraft", "textures/gui/mithrilinefurnaceelements.png");
        final double current = this.tile.progress;
        final double max = this.tile.reqProgress;
        if (max > 0.0) {
            final double m = current / max;
            final int n = MathHelper.func_76128_c(m * 14.0);
            this.drawTexturedModalRect(posX, posY - n, 14, 14 - n, 14, n);
        }
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
    }
}
