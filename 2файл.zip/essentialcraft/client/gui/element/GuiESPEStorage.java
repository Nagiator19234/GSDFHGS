package essentialcraft.client.gui.element;

import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.capabilities.espe.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;

public class GuiESPEStorage extends GuiElement
{
    private ResourceLocation rec;
    public int x;
    public int y;
    public IESPEHandler tile;
    
    public GuiESPEStorage(final int i, final int j, final IESPEHandler t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mithrilinefurnaceelements.png");
        this.x = i;
        this.y = j;
        this.tile = t;
    }
    
    public GuiESPEStorage(final int i, final int j, final TileEntity t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mithrilinefurnaceelements.png");
        this.x = i;
        this.y = j;
        if (!t.hasCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null)) {
            throw new IllegalArgumentException("Tile does not handle ESPE");
        }
        this.tile = (IESPEHandler)t.getCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null);
    }
    
    public ResourceLocation getElementTexture() {
        return this.rec;
    }
    
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        final double current = this.tile.getESPE();
        final double max = this.tile.getMaxESPE();
        final double m = current / max;
        final int n = MathHelper.func_76128_c(m * 18.0);
        this.drawTexturedModalRect(posX, posY, 0, 14, 18, 18);
        this.drawTexturedModalRect(posX, posY + 18 - n, 18, 32 - n, 18, n);
        this.drawTexturedModalRect(posX + 70, posY - 49, 0, 32, 28, 28);
        this.drawTexturedModalRect(posX + 77, posY - 16, 0, 0, 14, 14);
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
}
