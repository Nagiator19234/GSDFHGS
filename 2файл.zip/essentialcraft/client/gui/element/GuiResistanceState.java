package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import net.minecraft.util.*;
import essentialcraft.common.tile.*;
import net.minecraft.client.*;

public class GuiResistanceState extends GuiTextElement
{
    public TileEntity tile;
    
    public GuiResistanceState(final int i, final int j, final TileEntity t) {
        super(i, j);
        this.tile = t;
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        super.draw(posX, posY, mouseX, mouseY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        if (this.tile instanceof TileMRUCUECStateChecker) {
            final TileMRUCUECController controllerTile = (TileMRUCUECController)((TileMRUCUECStateChecker)this.tile).structureController();
            if (controllerTile != null) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a(controllerTile.resistance + " MROV", (float)(posX + 2), (float)(posY + 5), 16777215, true);
            }
        }
    }
}
