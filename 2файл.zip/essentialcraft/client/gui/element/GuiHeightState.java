package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.*;
import net.minecraft.init.*;
import DummyCore.Client.*;
import net.minecraft.block.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraft.client.*;

public class GuiHeightState extends GuiTextElement
{
    public TileEntity tile;
    public int mru;
    
    public GuiHeightState(final int i, final int j, final TileEntity t) {
        super(i, j);
        this.tile = t;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX - 18, posY - 1, 0, 0, 18, 18);
        this.drawTexturedModalRect(posX, posY, 0, 1, 18, 17);
        this.drawTexturedModalRect(posX, posY - 16, 0, 1, 18, 16);
        this.drawTexturedModalRect(posX, posY - 16 - 16, 0, 0, 18, 17);
        GlStateManager.func_179124_c(0.0f, 0.6f, 0.0f);
        DrawUtils.drawScaledTexturedRect(posX + 1, posY, TextureUtils.fromBlock((Block)Blocks.field_150349_c), 16, 1, 1.0f);
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        DrawUtils.drawScaledTexturedRect(posX + 1, posY + 1, TextureUtils.fromBlock(Blocks.field_150346_d), 16, 2, 1.0f);
        DrawUtils.drawScaledTexturedRect(posX + 1, posY + 3, TextureUtils.fromBlock(Blocks.field_150348_b), 16, 11, 1.0f);
        DrawUtils.drawScaledTexturedRect(posX + 1, posY + 15, TextureUtils.fromBlock(Blocks.field_150357_h), 16, 1, 1.0f);
        final Random rnd = new Random(143535645L);
        for (int i = 0; i < 10; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 3 + rnd.nextInt(11), TextureUtils.fromBlock(Blocks.field_150351_n), 2, 2, 2.0f);
        }
        for (int i = 0; i < 2; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 9 + rnd.nextInt(11), TextureUtils.fromBlock(Blocks.field_150484_ah), 1, 1, 2.0f);
        }
        for (int i = 0; i < 12; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 3 + rnd.nextInt(11), TextureUtils.fromBlock(Blocks.field_150402_ci), 1, 1, 2.0f);
        }
        for (int i = 0; i < 6; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 3 + rnd.nextInt(11), TextureUtils.fromBlock(Blocks.field_150406_ce, 8), 1, 1, 2.0f);
        }
        for (int i = 0; i < 4; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 6 + rnd.nextInt(8), TextureUtils.fromBlock(Blocks.field_150340_R), 1, 1, 2.0f);
        }
        for (int i = 0; i < 8; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 12 + rnd.nextInt(2), TextureUtils.fromBlock((Block)Blocks.field_150353_l), 1, 1, 2.0f);
        }
        for (int i = 0; i < 8; ++i) {
            DrawUtils.drawScaledTexturedRect(posX + 1 + rnd.nextInt(15), posY + 14, TextureUtils.fromBlock(Blocks.field_150357_h), 1, 1, 2.0f);
        }
        int pos = MathUtils.pixelatedTextureSize(this.tile.func_174877_v().func_177956_o(), 256, 50);
        if (pos > 45) {
            pos = 45;
        }
        GlStateManager.func_179124_c(0.0f, 1.0f, 0.0f);
        DrawUtils.drawScaledTexturedRect(posX + 1, posY + 14 - pos, TextureUtils.fromBlock(Blocks.field_150475_bE), 16, 1, 2.0f);
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        this.drawText(posX, posY);
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        Minecraft.func_71410_x().field_71466_p.func_175063_a(this.tile.func_174877_v().func_177956_o() + "", (float)(posX - 15 - Integer.toString(this.tile.func_174877_v().func_177956_o()).length()), (float)(posY + 5), 16777215);
    }
}
