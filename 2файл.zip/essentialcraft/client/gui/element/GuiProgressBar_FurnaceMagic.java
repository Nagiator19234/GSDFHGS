package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;

public class GuiProgressBar_FurnaceMagic extends GuiTextElement
{
    public TileFurnaceMagic tile;
    
    public GuiProgressBar_FurnaceMagic(final int i, final int j, final TileFurnaceMagic table) {
        super(i, j);
        this.tile = table;
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        DrawUtils.bindTexture("essentialcraft", "textures/gui/progressbars.png");
        int current = this.tile.progressLevel;
        if (current == 0) {
            current = this.tile.smeltingLevel;
        }
        final int max = TileFurnaceMagic.smeltingTime / (this.tile.func_145832_p() / 4 + 1);
        final int progress = MathUtils.pixelatedTextureSize(current, max, 25);
        this.drawTexturedModalRect(posX, posY, 0, 17, 24, 17);
        this.drawTexturedModalRect(posX, posY, 0, 0, progress, 17);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
    }
}
