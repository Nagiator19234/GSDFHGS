package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import net.minecraft.client.*;
import net.minecraft.inventory.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import net.minecraft.client.gui.*;

public class GuiRepairState extends GuiTextElement
{
    public TileEntity tile;
    public int slotNum;
    
    public GuiRepairState(final int i, final int j, final TileEntity t, final int slot) {
        super(i, j);
        this.tile = t;
        this.slotNum = slot;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 16, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 32, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 48, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 64, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 80, posY, 1, 0, 17, 18);
        this.drawText(posX, posY);
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final FontRenderer fontRenderer = Minecraft.func_71410_x().field_71466_p;
        final IInventory inventory = (IInventory)this.tile;
        if (inventory.func_70301_a(1).func_190926_b()) {
            fontRenderer.func_175063_a("Nothing To Fix!", (float)(posX + 5), (float)(posY + 6), 16776960);
        }
        else if (!inventory.func_70301_a(1).func_77973_b().isRepairable()) {
            fontRenderer.func_175063_a("Can't Fix This!", (float)(posX + 5), (float)(posY + 6), 16711680);
        }
        else if (inventory.func_70301_a(1).func_77952_i() == 0) {
            fontRenderer.func_175063_a("Already Fixed!", (float)(posX + 5), (float)(posY + 6), 16776960);
        }
        else if (((IMRUHandler)this.tile.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)).getMRU() == 0) {
            fontRenderer.func_175063_a("No MRU!", (float)(posX + 5), (float)(posY + 6), 16711680);
        }
        else {
            fontRenderer.func_175063_a("Working...", (float)(posX + 5), (float)(posY + 6), 65280);
        }
    }
}
