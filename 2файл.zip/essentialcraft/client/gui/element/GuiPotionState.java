package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.*;
import net.minecraft.init.*;
import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.potion.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.texture.*;

public class GuiPotionState extends GuiTextElement
{
    public TilePotionSpreader tile;
    
    public GuiPotionState(final int i, final int j, final TileEntity t) {
        super(i, j);
        this.tile = (TilePotionSpreader)t;
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 17);
        this.drawTexturedModalRect(posX + 19, posY, 1, 0, 17, 17);
        this.drawTexturedModalRect(posX, posY + 19, 0, 1, 17, 17);
        this.drawTexturedModalRect(posX + 19, posY + 19, 1, 1, 17, 17);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 2, 17);
        this.drawTexturedModalRect(posX + 17, posY + 19, 1, 1, 2, 17);
        this.drawTexturedModalRect(posX, posY + 17, 0, 1, 17, 2);
        this.drawTexturedModalRect(posX + 19, posY + 17, 1, 1, 17, 2);
        this.drawTexturedModalRect(posX + 17, posY + 17, 1, 1, 2, 2);
        GlStateManager.func_179094_E();
        TextureAtlasSprite icon = TextureUtils.fromItem((Item)Items.field_151068_bn);
        DrawUtils.drawTexture_Items(posX + 9, posY + 9, icon, 18, 18, 10.0f);
        if (this.tile.potionID != null) {
            icon = TextureUtils.fromItem((Item)Items.field_151068_bn);
            final int j = ((Potion)Potion.field_188414_b.func_82594_a((Object)this.tile.potionID)).func_76401_j();
            float f = 0.0f;
            float f2 = 0.0f;
            float f3 = 0.0f;
            f += (j >> 16 & 0xFF) / 255.0f;
            f2 += (j >> 8 & 0xFF) / 255.0f;
            f3 += (j >> 0 & 0xFF) / 255.0f;
            GlStateManager.func_179124_c(f, f2, f3);
            final int scale = MathUtils.pixelatedTextureSize(8 - this.tile.potionUseTime / 2, 8, 16);
            int scaledPos = scale - 4;
            if (scaledPos < 0) {
                scaledPos = 0;
            }
            DrawUtils.drawTexture_Items(posX + 9, posY + 9 + scaledPos, icon, 18, 18 - scale, 10.0f);
        }
        GlStateManager.func_179121_F();
        this.drawText(posX, posY);
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
    }
}
