package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import essentialcraft.common.item.*;
import net.minecraft.client.*;
import net.minecraft.util.math.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import essentialcraft.api.*;

public class GuiBoundGemState extends GuiTextElement
{
    public TileEntity tile;
    public int slotNum;
    
    public GuiBoundGemState(final int i, final int j, final TileEntity t, final int slot) {
        super(i, j);
        this.tile = t;
        this.slotNum = slot;
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        super.draw(posX, posY, mouseX, mouseY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final IInventory inventory = (IInventory)this.tile;
        if (!(inventory.func_70301_a(this.slotNum).func_77973_b() instanceof ItemBoundGem)) {
            Minecraft.func_71410_x().field_71466_p.func_175065_a("No Bound Gem!", (float)(posX + 6), (float)(posY + 5), 16711680, true);
        }
        else if (inventory.func_70301_a(this.slotNum).func_77978_p() == null) {
            Minecraft.func_71410_x().field_71466_p.func_175065_a("Gem Not Bound!", (float)(posX + 4), (float)(posY + 5), 16711680, true);
        }
        else {
            final int[] o = ItemBoundGem.getCoords(inventory.func_70301_a(this.slotNum));
            final BlockPos pos = new BlockPos(o[0], o[1], o[2]);
            if (this.tile.func_145831_w().func_175625_s(pos) == null) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("No Tile At Pos!", (float)(posX + 5), (float)(posY + 5), 16711680, true);
            }
            else if (!this.tile.func_145831_w().func_175625_s(pos).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("Not Magical!", (float)(posX + 12), (float)(posY + 5), 16711680, true);
            }
            else if (MathUtils.getDifference((float)this.tile.func_174877_v().func_177958_n(), (float)o[0]) > 16.0f || MathUtils.getDifference((float)this.tile.func_174877_v().func_177956_o(), (float)o[1]) > 16.0f || MathUtils.getDifference((float)this.tile.func_174877_v().func_177952_p(), (float)o[2]) > 16.0f) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("Not In Range!", (float)(posX + 8), (float)(posY + 5), 16711680, true);
            }
            else if (this.tile.func_174877_v().equals((Object)pos)) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("Bound To Self!", (float)(posX + 5), (float)(posY + 5), 16711680, true);
            }
            else if (((IMRUHandler)this.tile.func_145831_w().func_175625_s(pos).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)).getMRU() <= 0) {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("No MRU In Tile!", (float)(posX + 6), (float)(posY + 5), 16776960, true);
            }
            else {
                Minecraft.func_71410_x().field_71466_p.func_175065_a("Working", (float)(posX + 22), (float)(posY + 5), 65280, true);
            }
        }
    }
}
