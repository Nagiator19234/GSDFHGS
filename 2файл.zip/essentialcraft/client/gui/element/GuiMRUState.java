package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import net.minecraft.client.*;

public class GuiMRUState extends GuiTextElement
{
    public IMRUHandler tile;
    public int mru;
    
    public GuiMRUState(final int i, final int j, final IMRUHandler t, final int mruToSearch) {
        super(i, j);
        this.tile = t;
    }
    
    public GuiMRUState(final int i, final int j, final TileEntity t, final int mruToSearch) {
        super(i, j);
        if (t.hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
            this.tile = (IMRUHandler)t.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
        }
        else {
            if (!(t instanceof IMRUDisplay)) {
                throw new IllegalArgumentException("Tile does not handle MRU");
            }
            this.tile = ((IMRUDisplay)t).getMRUHandler();
        }
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 16, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 32, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 48, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 64, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 80, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 96, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 111, posY, 1, 0, 17, 18);
        this.drawText(posX, posY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        Minecraft.func_71410_x().field_71466_p.func_175065_a("" + this.tile.getMRU() + "/" + this.tile.getMaxMRU() + " MRU", (float)(posX + 2), (float)(posY + 5), 16777215, true);
    }
}
