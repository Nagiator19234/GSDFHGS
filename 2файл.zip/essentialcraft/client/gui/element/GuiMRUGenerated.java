package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import net.minecraft.client.*;
import DummyCore.Utils.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import essentialcraft.api.*;
import net.minecraft.world.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.tile.*;
import net.minecraft.client.renderer.*;
import net.minecraft.block.state.*;

public class GuiMRUGenerated extends GuiTextElement
{
    public TileEntity tile;
    public String tileValue;
    
    public GuiMRUGenerated(final int i, final int j, final TileEntity t, final String tileType) {
        super(i, j);
        this.tile = t;
        this.tileValue = tileType;
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        if (this.tileValue.equals("matrixAbsorber")) {
            Minecraft.func_71410_x().field_71466_p.func_175063_a(TileMatrixAbsorber.mruUsage + "UBMRU > " + TileMatrixAbsorber.mruGenerated + "MRU", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
        if (this.tileValue.equals("heatGenerator") && this.tile instanceof TileHeatGenerator) {
            final TileHeatGenerator furnace = (TileHeatGenerator)this.tile;
            DrawUtils.bindTexture("minecraft", "textures/gui/container/furnace.png");
            this.drawTexturedModalRect(posX + 100, posY + 2, 55, 36, 15, 15);
            if (furnace.currentBurnTime > 0) {
                final int scaledSize = MathUtils.pixelatedTextureSize(furnace.currentBurnTime, furnace.currentMaxBurnTime, 14) + 1;
                this.drawTexturedModalRect(posX + 101, posY + 2 + 15 - scaledSize, 176, 15 - scaledSize, 15, scaledSize);
            }
            float mruGenerated = (float)TileHeatGenerator.mruGenerated;
            float mruFactor = 1.0f;
            final Block[] b = { furnace.func_145831_w().func_180495_p(furnace.func_174877_v().func_177982_a(2, 0, 0)).func_177230_c(), furnace.func_145831_w().func_180495_p(furnace.func_174877_v().func_177982_a(-2, 0, 0)).func_177230_c(), furnace.func_145831_w().func_180495_p(furnace.func_174877_v().func_177982_a(0, 0, 2)).func_177230_c(), furnace.func_145831_w().func_180495_p(furnace.func_174877_v().func_177982_a(0, 0, -2)).func_177230_c() };
            final int[] ox = { 2, -2, 0, 0 };
            final int[] oz = { 0, 0, 2, -2 };
            for (int i = 0; i < 4; ++i) {
                if (b[i] == Blocks.field_150350_a) {
                    mruFactor *= 0.0f;
                }
                else if (b[i] == Blocks.field_150424_aL) {
                    mruFactor *= 0.75f;
                }
                else if (b[i] == Blocks.field_150353_l) {
                    mruFactor *= 0.95f;
                }
                else if (b[i] == Blocks.field_150480_ab) {
                    mruFactor *= 0.7f;
                }
                else if (b[i] instanceof IHotBlock) {
                    mruFactor *= ((IHotBlock)b[i]).getHeatModifier((IBlockAccess)this.tile.func_145831_w(), this.tile.func_174877_v().func_177982_a(ox[i], 0, oz[i]));
                }
                else {
                    mruFactor *= 0.5f;
                }
            }
            mruGenerated *= mruFactor;
            Minecraft.func_71410_x().field_71466_p.func_175063_a((int)mruGenerated + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
        if (this.tileValue.equals("ultraHeatGenerator") && this.tile instanceof TileUltraHeatGenerator) {
            final TileUltraHeatGenerator furnace2 = (TileUltraHeatGenerator)this.tile;
            DrawUtils.bindTexture("minecraft", "textures/gui/container/furnace.png");
            this.drawTexturedModalRect(posX + 100, posY + 2, 55, 36, 15, 15);
            if (furnace2.currentBurnTime > 0) {
                final int scaledSize = MathUtils.pixelatedTextureSize(furnace2.currentBurnTime, furnace2.currentMaxBurnTime, 14) + 1;
                this.drawTexturedModalRect(posX + 101, posY + 2 + 15 - scaledSize, 176, 15 - scaledSize, 15, scaledSize);
            }
            final Block[] b2 = { furnace2.func_145831_w().func_180495_p(furnace2.func_174877_v().func_177982_a(2, 0, 0)).func_177230_c(), furnace2.func_145831_w().func_180495_p(furnace2.func_174877_v().func_177982_a(-2, 0, 0)).func_177230_c(), furnace2.func_145831_w().func_180495_p(furnace2.func_174877_v().func_177982_a(0, 0, 2)).func_177230_c(), furnace2.func_145831_w().func_180495_p(furnace2.func_174877_v().func_177982_a(0, 0, -2)).func_177230_c() };
            for (int j = 0; j < 4; ++j) {
                if (b2[j] != Blocks.field_150350_a) {
                    if (b2[j] != Blocks.field_150424_aL) {
                        if (b2[j] != Blocks.field_150353_l) {
                            if (b2[j] != Blocks.field_150480_ab) {
                                if (b2[j] instanceof IHotBlock) {}
                            }
                        }
                    }
                }
            }
            final double heat = furnace2.heat;
            double mruGenerated2;
            if (heat < 1000.0) {
                mruGenerated2 = heat / 100.0;
            }
            else if (heat > 10000.0) {
                mruGenerated2 = 80.0 + heat / 1000.0;
            }
            else {
                mruGenerated2 = heat / 124.0;
            }
            Minecraft.func_71410_x().field_71466_p.func_175063_a(mruGenerated2 + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
            Minecraft.func_71410_x().field_71466_p.func_175063_a("Heat: " + (int)furnace2.heat + "C", (float)(posX + 82), (float)(posY - 10), 16777215);
        }
        if (this.tileValue.equals("naturalFurnace") && this.tile instanceof TileFlowerBurner) {
            final TileFlowerBurner furnace3 = (TileFlowerBurner)this.tile;
            Minecraft.func_71410_x().field_71466_p.func_175063_a(TileFlowerBurner.mruGenerated + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
            DrawUtils.bindTexture("essentialcraft", "textures/gui/slot_common.png");
            this.drawTexturedModalRect(posX + 82, posY, 0, 0, 18, 18);
            final RenderItem renderitem = Minecraft.func_71410_x().func_175599_af();
            if (furnace3.burnedFlower != null) {
                final BlockPos pos = new BlockPos(furnace3.burnedFlower.func_177958_n(), furnace3.burnedFlower.func_177956_o(), furnace3.burnedFlower.func_177952_p());
                final IBlockState b3 = furnace3.func_145831_w().func_180495_p(pos);
                if (b3 != null && b3.func_177230_c() != Blocks.field_150350_a && Item.func_150898_a(b3.func_177230_c()) != null) {
                    renderitem.func_175042_a(b3.func_177230_c().getPickBlock(b3, new RayTraceResult(Vec3d.field_186680_a, EnumFacing.DOWN, pos), furnace3.func_145831_w(), furnace3.burnedFlower, (EntityPlayer)Minecraft.func_71410_x().field_71439_g), posX + 83, posY + 1);
                }
            }
            DrawUtils.bindTexture("minecraft", "textures/gui/container/furnace.png");
            this.drawTexturedModalRect(posX + 82, posY - 15, 55, 36, 15, 15);
            if (furnace3.burnTime > 0) {
                final int scaledSize2 = MathUtils.pixelatedTextureSize(furnace3.burnTime, 600, 14) + 1;
                this.drawTexturedModalRect(posX + 83, posY - scaledSize2, 176, 15 - scaledSize2, 15, scaledSize2);
            }
        }
        if (this.tileValue.equals("ultraNaturalFurnace") && this.tile instanceof TileUltraFlowerBurner) {
            final TileUltraFlowerBurner furnace4 = (TileUltraFlowerBurner)this.tile;
            Minecraft.func_71410_x().field_71466_p.func_175063_a(furnace4.mruProduced + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
            DrawUtils.bindTexture("essentialcraft", "textures/gui/slot_common.png");
            this.drawTexturedModalRect(posX + 82, posY, 0, 0, 18, 18);
            final RenderItem renderitem = Minecraft.func_71410_x().func_175599_af();
            if (furnace4.burnedFlower != null) {
                final BlockPos pos = furnace4.burnedFlower;
                final IBlockState b3 = furnace4.func_145831_w().func_180495_p(pos);
                if (b3 != null && Item.func_150898_a(b3.func_177230_c()) != null) {
                    renderitem.func_175042_a(b3.func_177230_c().getPickBlock(b3, new RayTraceResult(Vec3d.field_186680_a, EnumFacing.DOWN, pos), furnace4.func_145831_w(), furnace4.burnedFlower, (EntityPlayer)Minecraft.func_71410_x().field_71439_g), posX + 83, posY + 1);
                }
            }
            DrawUtils.bindTexture("minecraft", "textures/gui/container/furnace.png");
            this.drawTexturedModalRect(posX + 82, posY - 15, 55, 36, 15, 15);
            if (furnace4.burnTime > 0) {
                final int scaledSize2 = MathUtils.pixelatedTextureSize(furnace4.burnTime, 600, 14) + 1;
                this.drawTexturedModalRect(posX + 83, posY - scaledSize2, 176, 15 - scaledSize2, 15, scaledSize2);
            }
        }
        if (this.tileValue.equals("cold") && this.tile instanceof TileColdDistillator) {
            final TileColdDistillator cold = (TileColdDistillator)this.tile;
            Minecraft.func_71410_x().field_71466_p.func_175063_a(cold.getMRU() + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
        if (this.tileValue.equals("enderGenerator")) {
            Minecraft.func_71410_x().field_71466_p.func_175063_a(TileEnderGenerator.mruGenerated + " MRU/hit", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
        if (this.tileValue.equals("sunray")) {
            Minecraft.func_71410_x().field_71466_p.func_175063_a(TileSunRayAbsorber.mruGenerated + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
        if (this.tileValue.equals("moonwell")) {
            double mruGenerated3 = TileMoonWell.mruGenerated;
            final int moonPhase = this.tile.func_145831_w().field_73011_w.func_76559_b(this.tile.func_145831_w().func_72820_D());
            final double moonFactor = Math.abs(1.0 - moonPhase * 0.25);
            mruGenerated3 *= moonFactor;
            double heightFactor = 1.0;
            if (this.tile.func_174877_v().func_177956_o() > TileMoonWell.maxHeight) {
                heightFactor = 0.0;
            }
            else {
                heightFactor = 1.0 - this.tile.func_174877_v().func_177956_o() / TileMoonWell.maxHeight;
                mruGenerated3 *= heightFactor;
            }
            Minecraft.func_71410_x().field_71466_p.func_175063_a((int)mruGenerated3 + " MRU/t", (float)(posX + 2), (float)(posY + 5), 16777215);
        }
    }
}
