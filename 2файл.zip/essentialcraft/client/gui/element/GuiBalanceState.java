package essentialcraft.client.gui.element;

import net.minecraft.tileentity.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import net.minecraft.client.*;

public class GuiBalanceState extends GuiTextElement
{
    public IMRUHandler tile;
    
    public GuiBalanceState(final int i, final int j, final IMRUHandler t) {
        super(i, j);
        this.tile = t;
    }
    
    public GuiBalanceState(final int i, final int j, final TileEntity t) {
        super(i, j);
        if (t.hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
            this.tile = (IMRUHandler)t.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
        }
        else {
            if (!(t instanceof IMRUDisplay)) {
                throw new IllegalArgumentException("Tile does not handle MRU");
            }
            this.tile = ((IMRUDisplay)t).getMRUHandler();
        }
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        super.draw(posX, posY, mouseX, mouseY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final float balance = this.tile.getBalance();
        String str = Float.toString(this.tile.getBalance());
        if (str.length() > 6) {
            str = str.substring(0, 6);
        }
        for (int i = str.length() - 1; i > 0; --i) {
            if (i > 2) {
                final char c = str.charAt(i);
                if (c == '0') {
                    str = str.substring(0, i);
                }
            }
        }
        String balanceType = "Pure";
        int color = 65535;
        if (balance < 1.0f) {
            balanceType = "Frozen";
            color = 255;
        }
        if (balance > 1.0f) {
            balanceType = "Chaos";
            color = 16711680;
        }
        Minecraft.func_71410_x().field_71466_p.func_175065_a(balanceType + ": " + str, (float)(posX + 2), (float)(posY + 5), color, true);
    }
}
