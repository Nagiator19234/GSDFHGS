package essentialcraft.client.gui.element;

import essentialcraft.common.tile.*;
import net.minecraft.client.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraft.util.*;
import net.minecraft.client.gui.*;

public class GuiEnchantmentState extends GuiTextElement
{
    public TileMagicalEnchanter tile;
    
    public GuiEnchantmentState(final int i, final int j, final TileMagicalEnchanter t) {
        super(i, j);
        this.tile = t;
    }
    
    @Override
    public ResourceLocation getElementTexture() {
        return super.getElementTexture();
    }
    
    @Override
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 16, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 32, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 48, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 64, posY, 1, 0, 16, 18);
        this.drawTexturedModalRect(posX + 17 + 80, posY, 1, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17 + 97, posY, 0, 0, 17, 18);
        this.drawTexturedModalRect(posX + 17 + 111, posY, 1, 0, 17, 18);
        this.drawText(posX, posY);
    }
    
    @Override
    public int getX() {
        return super.getX();
    }
    
    @Override
    public int getY() {
        return super.getY();
    }
    
    @Override
    public void drawText(final int posX, final int posY) {
        final FontRenderer fontRenderer = Minecraft.func_71410_x().field_71466_p;
        if (this.tile.func_70301_a(1).func_190926_b()) {
            fontRenderer.func_175063_a("Nothing To Enchant!", (float)(posX + 4), (float)(posY + 5), 16776960);
        }
        else if (!this.tile.func_70301_a(2).func_190926_b()) {
            fontRenderer.func_175063_a("Output Must Be Empty!", (float)(posX + 4), (float)(posY + 5), 16711680);
        }
        else if (this.tile.getCapability(CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, null).getMRU() < 100) {
            fontRenderer.func_175063_a("No MRU!", (float)(posX + 4), (float)(posY + 5), 16711680);
        }
        else if (!this.tile.func_70301_a(1).func_77956_u()) {
            fontRenderer.func_175063_a("Item Can't Be Enchanted!", (float)(posX + 4), (float)(posY + 5), 16711680);
        }
        else {
            try {
                if (this.tile.getEnchantmentsForStack(this.tile.func_70301_a(1)) == null || this.tile.getEnchantmentsForStack(this.tile.func_70301_a(1)).isEmpty()) {
                    fontRenderer.func_175063_a("Item Can't Be Enchanted!", (float)(posX + 4), (float)(posY + 5), 16711680);
                }
                else if (this.tile.getMaxPower() <= 0) {
                    fontRenderer.func_175063_a("No Bookshelves!", (float)(posX + 4), (float)(posY + 5), 16711680);
                }
                else {
                    fontRenderer.func_175063_a("Enchanting Item...", (float)(posX + 4), (float)(posY + 5), 65280);
                }
            }
            catch (Exception e) {
                fontRenderer.func_175063_a("Item Can't Be Enchanted!", (float)(posX + 4), (float)(posY + 5), 16711680);
                return;
            }
        }
        fontRenderer.func_175063_a(this.tile.getMaxPower() + "", (float)(posX + 122), (float)(posY + 5), 16777215);
    }
}
