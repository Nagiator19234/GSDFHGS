package essentialcraft.client.gui.element;

import DummyCore.Client.*;
import net.minecraft.tileentity.*;
import net.minecraftforge.fluids.capability.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import DummyCore.Utils.*;
import net.minecraftforge.fluids.*;
import net.minecraft.client.renderer.texture.*;

public class GuiFluidTank extends GuiElement
{
    private ResourceLocation rec;
    public int x;
    public int y;
    public IFluidTankProperties tank;
    
    public GuiFluidTank(final int i, final int j, final IFluidHandler t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mrustorage.png");
        this.x = i;
        this.y = j;
        this.tank = t.getTankProperties()[0];
    }
    
    public GuiFluidTank(final int i, final int j, final IFluidTankProperties t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mrustorage.png");
        this.x = i;
        this.y = j;
        this.tank = t;
    }
    
    public GuiFluidTank(final int i, final int j, final TileEntity t) {
        this.rec = new ResourceLocation("essentialcraft", "textures/gui/mrustorage.png");
        this.x = i;
        this.y = j;
        if (!t.hasCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, (EnumFacing)null)) {
            throw new IllegalArgumentException("Tile does not handle fluids");
        }
        this.tank = ((IFluidHandler)t.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, (EnumFacing)null)).getTankProperties()[0];
    }
    
    public ResourceLocation getElementTexture() {
        return this.rec;
    }
    
    public void draw(final int posX, final int posY, final int mouseX, final int mouseY) {
        this.drawTexturedModalRect(posX, posY, 0, 0, 18, 54);
        this.drawTexturedModalRect(posX, posY + 53, 0, 71, 18, 1);
        if (this.tank != null) {
            final FluidStack fStk = this.tank.getContents();
            if (fStk != null && fStk.amount > 0) {
                final TextureAtlasSprite icon = Minecraft.func_71410_x().func_147117_R().func_110572_b(fStk.getFluid().getFlowing().toString());
                final int scale = MathUtils.pixelatedTextureSize(fStk.amount, this.tank.getCapacity(), 52);
                DrawUtils.drawTexture(posX + 1, posY + 1 + 52 - scale, icon, 16, scale, 1.0f);
            }
        }
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
}
