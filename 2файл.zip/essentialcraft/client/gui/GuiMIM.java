package essentialcraft.client.gui;

import net.minecraft.tileentity.*;
import net.minecraft.util.*;
import essentialcraft.client.gui.element.*;
import net.minecraft.client.renderer.*;
import net.minecraft.inventory.*;
import DummyCore.Client.*;
import net.minecraft.client.*;
import java.util.*;

public class GuiMIM extends GuiCommon
{
    public GuiMIM(final Container c, final TileEntity tile) {
        super(c, tile);
        this.guiGenLocation = new ResourceLocation("essentialcraft", "textures/gui/mim.png");
        this.elementList.add(new GuiMRUStorage(4, 72, tile));
        this.field_146999_f = 196;
        this.field_147000_g = 256;
    }
    
    protected void func_146976_a(final float f1, final int i1, final int i2) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation);
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        for (final Slot slt : this.field_147002_h.field_75151_b) {
            this.renderSlot(slt);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        }
        for (final GuiElement element : this.elementList) {
            Minecraft.func_71410_x().field_71446_o.func_110577_a(element.getElementTexture());
            element.draw(k + element.getX(), l + element.getY(), i1, i2);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        }
    }
}
