package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiMRUAcceptor extends GuiCommon
{
    public GuiMRUAcceptor(final Container c, final TileEntity tile) {
        super(c, tile);
        this.elementList.add(new GuiBoundGemState(48, 50, tile, 0));
    }
}
