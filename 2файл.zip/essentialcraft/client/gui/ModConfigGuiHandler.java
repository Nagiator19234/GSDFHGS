package essentialcraft.client.gui;

import net.minecraftforge.fml.client.*;
import net.minecraft.client.*;
import java.util.*;
import net.minecraft.client.gui.*;

public class ModConfigGuiHandler implements IModGuiFactory
{
    public void initialize(final Minecraft minecraftInstance) {
    }
    
    public Set<IModGuiFactory.RuntimeOptionCategoryElement> runtimeGuiCategories() {
        return null;
    }
    
    public boolean hasConfigGui() {
        return true;
    }
    
    public GuiScreen createConfigGui(final GuiScreen parentScreen) {
        return (GuiScreen)new GuiModConfiguration(parentScreen);
    }
}
