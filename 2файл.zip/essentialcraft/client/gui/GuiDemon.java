package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import essentialcraft.common.inventory.*;
import essentialcraft.common.entity.*;

public class GuiDemon extends GuiCommon
{
    public ResourceLocation DguiGenLocation;
    
    public GuiDemon(final Container c) {
        super(c);
        this.DguiGenLocation = new ResourceLocation("essentialcraft", "textures/gui/demon.png");
    }
    
    private void drawItemStack(final ItemStack stack, final int x, final int y, final String text) {
        FontRenderer font = null;
        if (stack != null) {
            font = stack.func_77973_b().getFontRenderer(stack);
        }
        if (font == null) {
            font = this.field_146289_q;
        }
        this.field_146296_j.func_180450_b(stack, x, y);
        this.field_146296_j.func_180453_a(font, stack, x, y, text);
    }
    
    protected void func_146976_a(final float f1, final int i1, final int i2) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.field_146297_k.field_71446_o.func_110577_a(this.DguiGenLocation);
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        final ContainerDemon cd = (ContainerDemon)this.field_147002_h;
        final EntityDemon demon = (EntityDemon)cd.entity;
        if (demon != null && !demon.desiredItem.func_190926_b()) {
            GlStateManager.func_179109_b(0.0f, 0.0f, 100.0f);
            this.drawItemStack(demon.desiredItem, k + 80, l + 30, demon.desiredItem.func_190916_E() + "");
            this.field_146289_q.func_78276_b(demon.desiredItem.func_82833_r(), k + 5, l + 59, 16777215);
            GlStateManager.func_179109_b(0.0f, 0.0f, -100.0f);
        }
    }
}
