package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import essentialcraft.common.tile.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiMithrilineFurnace extends GuiCommon
{
    public GuiMithrilineFurnace(final Container c, final TileMithrilineFurnace tile) {
        super(c, (TileEntity)tile);
        this.elementList.add(new GuiESPEStorage(4, 64, tile));
        this.elementList.add(new GuiProgressBar_MithrilineFurnace(81, 62, tile));
    }
}
