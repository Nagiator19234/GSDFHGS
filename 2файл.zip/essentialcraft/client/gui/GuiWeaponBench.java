package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.*;
import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import essentialcraft.common.tile.*;
import net.minecraft.util.text.translation.*;

public class GuiWeaponBench extends GuiCommon
{
    public ResourceLocation guiGenLocation_0;
    public ResourceLocation guiGenLocation_1;
    public ResourceLocation guiGenLocation_2;
    public ResourceLocation guiGenLocation_3;
    
    public GuiWeaponBench(final Container c, final TileEntity tile) {
        super(c, tile);
        this.guiGenLocation_0 = new ResourceLocation("essentialcraft", "textures/gui/pistol_maker.png");
        this.guiGenLocation_1 = new ResourceLocation("essentialcraft", "textures/gui/rifle_maker.png");
        this.guiGenLocation_2 = new ResourceLocation("essentialcraft", "textures/gui/sniper_maker.png");
        this.guiGenLocation_3 = new ResourceLocation("essentialcraft", "textures/gui/gatling_maker.png");
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.field_146292_n.add(new GuiButton(0, k + 145, l + 20, 28, 12, "Done"));
    }
    
    protected void func_146284_a(final GuiButton par1GuiButton) {
        MiscUtils.handleButtonPress(par1GuiButton.field_146127_k, (Class)this.getClass(), (Class)GuiButton.class, (EntityPlayer)Minecraft.func_71410_x().field_71439_g, this.genericTile.func_174877_v().func_177958_n(), this.genericTile.func_174877_v().func_177956_o(), this.genericTile.func_174877_v().func_177952_p());
    }
    
    private void drawItemStack(final ItemStack stack, final int x, final int y, final String text) {
        FontRenderer font = null;
        if (stack != null) {
            font = stack.func_77973_b().getFontRenderer(stack);
        }
        if (font == null) {
            font = this.field_146289_q;
        }
        this.field_146296_j.func_180450_b(stack, x, y);
        this.field_146296_j.func_180453_a(font, stack, x, y - 0, text);
    }
    
    protected void func_146976_a(final float f1, final int i1, final int i2) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        final TileWeaponMaker w = (TileWeaponMaker)this.genericTile;
        String t = "item.ec3.gun.pistol.name";
        if (w.index == 1) {
            t = "item.ec3.gun.rifle.name";
        }
        if (w.index == 2) {
            t = "item.ec3.gun.sniper.name";
        }
        if (w.index == 3) {
            t = "item.ec3.gun.gatling.name";
        }
        if (w.index == 0) {
            this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation_0);
        }
        if (w.index == 1) {
            this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation_1);
        }
        if (w.index == 2) {
            this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation_2);
        }
        if (w.index == 3) {
            this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation_3);
        }
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        this.field_146289_q.func_78276_b(I18n.func_74838_a(t), k + 60, l + 5, 0);
        if (!w.previewStack.func_190926_b()) {
            this.drawItemStack(w.previewStack, k + 153, l + 5, "");
        }
        if (!w.areIngridientsCorrect()) {
            this.field_146292_n.get(0).field_146124_l = false;
        }
        else {
            this.field_146292_n.get(0).field_146124_l = true;
        }
    }
}
