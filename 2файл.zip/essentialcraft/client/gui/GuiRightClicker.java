package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiRightClicker extends GuiCommon
{
    public GuiRightClicker(final Container c, final TileEntity tile) {
        super(c, tile);
        this.elementList.add(new GuiMRUStorage(7, 4, tile));
        this.elementList.add(new GuiMRUState(25, 58, tile, 0));
    }
}
