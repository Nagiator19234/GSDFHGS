package essentialcraft.client.gui;

import essentialcraft.common.tile.*;
import net.minecraft.util.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import essentialcraft.api.*;
import net.minecraft.client.renderer.*;
import essentialcraft.client.render.tile.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.*;
import essentialcraft.client.render.*;
import essentialcraft.utils.common.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraft.util.text.*;
import net.minecraft.client.gui.*;

public class GuiPlayerPentacle extends GuiScreen
{
    public int energy;
    protected int xSize;
    protected int ySize;
    protected int renderTime;
    protected long timeOpened;
    public TilePlayerPentacle pentacle;
    private static final ResourceLocation field_147529_c;
    private static final ResourceLocation field_147526_d;
    
    public GuiPlayerPentacle(final TileEntity tile) {
        this.xSize = 176;
        this.ySize = 166;
        this.pentacle = (TilePlayerPentacle)tile;
        this.timeOpened = tile.func_145831_w().func_82737_E();
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    public GuiPlayerPentacle() {
        this.xSize = 176;
        this.ySize = 166;
    }
    
    protected void func_146284_a(final GuiButton button) {
        final EffectButton eb = (EffectButton)button;
        if (eb.field_146124_l) {
            final List<ICorruptionEffect> effects = ECUtils.getData((EntityPlayer)Minecraft.func_71410_x().field_71439_g).getEffects();
            if (effects.size() > button.field_146127_k) {
                final ICorruptionEffect effect = effects.get(eb.listIndex);
                if (effect.getType().ordinal() <= this.pentacle.tier || (GuiScreen.func_146272_n() && Minecraft.func_71410_x().field_71439_g.field_71075_bZ.field_75098_d)) {
                    if (GuiScreen.func_146272_n() && Minecraft.func_71410_x().field_71439_g.field_71075_bZ.field_75098_d) {
                        MiscUtils.handleButtonPress(eb.listIndex, (Class)this.getClass(), (Class)eb.getClass(), (EntityPlayer)Minecraft.func_71410_x().field_71439_g, this.pentacle.func_174877_v().func_177958_n(), this.pentacle.func_174877_v().func_177956_o(), this.pentacle.func_174877_v().func_177952_p(), "||isCreative:true");
                    }
                    else {
                        this.pentacle.consumeEnderstarEnergy(effects.get(button.field_146127_k).getStickiness());
                        MiscUtils.handleButtonPress(eb.listIndex, (Class)this.getClass(), (Class)eb.getClass(), (EntityPlayer)Minecraft.func_71410_x().field_71439_g, this.pentacle.func_174877_v().func_177958_n(), this.pentacle.func_174877_v().func_177956_o(), this.pentacle.func_174877_v().func_177952_p());
                    }
                }
            }
        }
    }
    
    public void func_73866_w_() {
        final int k = (this.field_146294_l - this.xSize) / 2;
        final int l = (this.field_146295_m - this.ySize) / 2;
        this.field_146292_n.add(new EffectButton(0, k + 76, l - 40, 20, 20, "0", 0));
        this.field_146292_n.add(new EffectButton(1, k - 36, l + 40, 20, 20, "1", 1));
        this.field_146292_n.add(new EffectButton(2, k + 186, l + 40, 20, 20, "2", 2));
        this.field_146292_n.add(new EffectButton(3, k + 76, l + 16, 20, 20, "3", 3));
        this.field_146292_n.add(new EffectButton(4, k + 30, l + 10, 20, 20, "4", 4));
        this.field_146292_n.add(new EffectButton(5, k + 126, l + 10, 20, 20, "5", 5));
        this.field_146292_n.add(new EffectButton(6, k + 20, l + 57, 20, 20, "6", 6));
        this.field_146292_n.add(new EffectButton(7, k + 132, l + 57, 20, 20, "7", 7));
        this.field_146292_n.add(new EffectButton(8, k + 0, l + 101, 20, 20, "8", 8));
        this.field_146292_n.add(new EffectButton(9, k + 150, l + 101, 20, 20, "9", 9));
        this.field_146292_n.add(new EffectButton(10, k + 42, l + 126, 20, 20, "10", 10));
        this.field_146292_n.add(new EffectButton(11, k + 110, l + 126, 20, 20, "11", 11));
        this.field_146292_n.add(new EffectButton(12, k + 76, l + 156, 20, 20, "12", 12));
        this.field_146292_n.add(new EffectButton(13, k + 0, l + 174, 20, 20, "13", 13));
        this.field_146292_n.add(new EffectButton(14, k + 150, l + 174, 20, 20, "14", 14));
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.renderTime = (int)(Minecraft.func_71410_x().field_71441_e.func_82737_E() - this.timeOpened);
        final int k = (this.field_146294_l - this.xSize) / 2;
        final int l = (this.field_146295_m - this.ySize) / 2;
        float opacityIndex = this.renderTime / 100.0f;
        if (opacityIndex > 1.0f) {
            opacityIndex = 1.0f;
        }
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j(7425);
        GlStateManager.func_179131_c(0.0f, 0.2f, 0.05f, opacityIndex);
        final ScaledResolution res = new ScaledResolution(Minecraft.func_71410_x());
        Minecraft.func_71410_x().field_71446_o.func_110577_a(GuiPlayerPentacle.field_147529_c);
        this.func_73729_b(0, 0, mouseX, mouseY, res.func_78326_a(), res.func_78328_b());
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        GlStateManager.func_179131_c(0.0f, 0.7f, 1.0f, 0.6f * opacityIndex);
        GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(GuiPlayerPentacle.field_147526_d);
        this.func_73729_b(0, 0, (int)(Minecraft.func_71410_x().field_71439_g.field_70173_aa % 24000L), (int)(Minecraft.func_71410_x().field_71439_g.field_70173_aa % 24000L), res.func_78326_a(), res.func_78328_b());
        GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
        GlStateManager.func_179121_F();
        final TilePlayerPentacle p = this.pentacle;
        if (p.tier == -1) {
            GlStateManager.func_179131_c(0.2f, 0.2f, 0.2f, opacityIndex);
        }
        if (p.tier == 0) {
            GlStateManager.func_179131_c(0.0f, 1.0f, 0.0f, opacityIndex);
        }
        if (p.tier == 1) {
            GlStateManager.func_179131_c(0.0f, 0.0f, 1.0f, opacityIndex);
        }
        if (p.tier == 2) {
            GlStateManager.func_179131_c(0.5f, 0.0f, 0.5f, opacityIndex);
        }
        if (p.tier == 3) {
            GlStateManager.func_179131_c(1.0f, 0.0f, 0.0f, opacityIndex);
        }
        final int uv = 256;
        final int uu = 256;
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderPlayerPentacle.rune);
        this.func_73729_b(k - uv / 6, l - uu / 6, 0, 0, uv, uu);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179103_j(7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        if (opacityIndex == 1.0f) {
            GuiInventory.func_147046_a((int)(k + uv / 2.9f), (int)(l + uu / 2.5f), 20, 0.0f, 0.0f, (EntityLivingBase)Minecraft.func_71410_x().field_71439_g);
            Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderHandlerEC.whitebox);
            GlStateManager.func_179124_c(0.058f, 0.058f, 0.058f);
            this.func_73729_b((int)(k + uv / 2.9f) - 32, (int)(l + uu / 2.5f) + 2, 0, 0, 64, 8);
            GlStateManager.func_179124_c(0.2f, 0.2f, 0.1f);
            this.func_73729_b((int)(k + uv / 2.9f) - 32, (int)(l + uu / 2.5f) + 2, 0, 0, 61, 5);
            if (ECUtils.getData((EntityPlayer)Minecraft.func_71410_x().field_71439_g) != null) {
                final PlayerGenericData data = ECUtils.getData((EntityPlayer)Minecraft.func_71410_x().field_71439_g);
                final int index = MathUtils.pixelatedTextureSize(data.getOverhaulDamage(), 72000, 61);
                GlStateManager.func_179124_c(0.73f, 0.0f, 0.0f);
                this.func_73729_b((int)(k + uv / 2.9f) - 32, (int)(l + uu / 2.5f) + 2, 0, 0, index, 5);
                this.energy = this.pentacle.getEnderstarEnergy();
                String displayEnergy;
                for (displayEnergy = this.energy + ""; 5 - displayEnergy.length() > 0; displayEnergy = " " + displayEnergy) {}
                displayEnergy += " ESPE";
                this.func_73731_b(this.field_146289_q, displayEnergy, (int)(k + uv / 2.9f) - 32, (int)(l + uu / 2.5f) + 22, 16777215);
            }
        }
        if (opacityIndex == 1.0f) {
            super.func_73863_a(mouseX, mouseY, partialTicks);
        }
    }
    
    static {
        field_147529_c = new ResourceLocation("textures/environment/end_sky.png");
        field_147526_d = new ResourceLocation("textures/entity/end_portal.png");
    }
    
    public static class EffectButton extends GuiButton
    {
        public int listIndex;
        
        public EffectButton(final int id, final int x, final int y, final int sX, final int sY, final String name) {
            super(id, x, y, sX, sY, name);
        }
        
        public EffectButton(final int id, final int x, final int y, final int sX, final int sY, final String name, final int index) {
            super(id, x, y, sX, sY, name);
            this.listIndex = index;
            final PlayerGenericData data = ECUtils.getData((EntityPlayer)Minecraft.func_71410_x().field_71439_g);
            final ArrayList<ICorruptionEffect> effects = (ArrayList<ICorruptionEffect>)(ArrayList)data.getEffects();
            if (effects.size() <= this.listIndex) {
                this.field_146124_l = false;
            }
            else if (effects.get(this.listIndex) == null) {
                this.field_146124_l = false;
            }
        }
        
        public void func_191745_a(final Minecraft mc, final int mX, final int mY, final float pt) {
            if (!this.field_146124_l) {
                return;
            }
            super.func_191745_a(mc, mX, mY, pt);
            final PlayerGenericData data = ECUtils.getData((EntityPlayer)mc.field_71439_g);
            final ArrayList<ICorruptionEffect> effects = (ArrayList<ICorruptionEffect>)(ArrayList)data.getEffects();
            if (effects.size() <= this.listIndex) {
                this.field_146124_l = false;
            }
            else if (effects.get(this.listIndex) == null) {
                this.field_146124_l = false;
            }
            else {
                final ICorruptionEffect effect = effects.get(this.listIndex);
                FontRenderer renderer = Minecraft.func_71410_x().field_71466_p;
                final GuiPlayerPentacle gui = (GuiPlayerPentacle)Minecraft.func_71410_x().field_71462_r;
                ResourceLocation loc = effects.get(this.listIndex).getEffectIcon();
                if (gui.pentacle.tier < effect.getType().ordinal()) {
                    renderer = Minecraft.func_71410_x().field_71464_q;
                    loc = GuiPlayerPentacle.field_147526_d;
                }
                if (GuiScreen.func_146272_n() && mc.field_71439_g.field_71075_bZ.field_75098_d) {
                    renderer = Minecraft.func_71410_x().field_71466_p;
                    loc = effects.get(this.listIndex).getEffectIcon();
                }
                mc.field_71446_o.func_110577_a(loc);
                final int x0 = this.field_146128_h + 2;
                final int y0 = this.field_146129_i + 2;
                final int dx = 16;
                final int dy = 16;
                final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
                tessellator.startDrawingQuads();
                tessellator.addVertexWithUV((double)(x0 + 0), (double)(y0 + dy), (double)this.field_73735_i, 0.0, 1.0);
                tessellator.addVertexWithUV((double)(x0 + dx), (double)(y0 + dy), (double)this.field_73735_i, 1.0, 1.0);
                tessellator.addVertexWithUV((double)(x0 + dx), (double)(y0 + 0), (double)this.field_73735_i, 1.0, 0.0);
                tessellator.addVertexWithUV((double)(x0 + 0), (double)(y0 + 0), (double)this.field_73735_i, 0.0, 0.0);
                tessellator.draw();
                if (mX >= this.field_146128_h && mX <= this.field_146128_h + 20 && mY >= this.field_146129_i && mY <= this.field_146129_i + 20) {
                    GlStateManager.func_179109_b(0.0f, 0.0f, 100.0f);
                    final String name = effect.getLocalizedName();
                    final String desc = effect.getLocalizedDesc();
                    int length = name.length();
                    if (desc.length() / 2 >= name.length()) {
                        length = desc.length() / 2;
                    }
                    this.func_73733_a(mX + 5, mY + 5, mX + length * 6, mY + 25, 587202559, 587202559);
                    this.func_73731_b(renderer, name, mX + 5, mY + 5, 16777215);
                    boolean enable = effect.getStickiness() <= gui.energy;
                    String additional = "";
                    if (GuiScreen.func_146272_n() && mc.field_71439_g.field_71075_bZ.field_75098_d) {
                        enable = true;
                        additional = " [Creative]";
                    }
                    GlStateManager.func_179152_a(0.5f, 0.5f, 1.0f);
                    this.func_73731_b(renderer, TextFormatting.ITALIC + desc, (mX + 5) * 2, (mY + 15) * 2, 16777215);
                    this.func_73731_b(renderer, TextFormatting.ITALIC + "" + (enable ? TextFormatting.DARK_GREEN : TextFormatting.RED) + "" + effect.getStickiness() + " ESPE" + additional, (mX + 5) * 2, (mY + 20) * 2, 16777215);
                    GlStateManager.func_179152_a(2.0f, 2.0f, 1.0f);
                    GlStateManager.func_179109_b(0.0f, 0.0f, -100.0f);
                }
            }
        }
    }
}
