package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiMagmaticSmeltery extends GuiCommon
{
    public GuiMagmaticSmeltery(final Container c, final TileEntity tile) {
        super(c, tile);
        this.elementList.add(new GuiMRUStorage(7, 4, tile));
        this.elementList.add(new GuiBalanceState(43, 40, tile));
        this.elementList.add(new GuiBoundGemState(43, 4, tile, 0));
        this.elementList.add(new GuiMRUState(25, 58, tile, 0));
        this.elementList.add(new GuiFluidTank(25, 4, tile));
    }
}
