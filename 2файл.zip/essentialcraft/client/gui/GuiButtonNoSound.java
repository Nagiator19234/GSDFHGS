package essentialcraft.client.gui;

import net.minecraft.client.gui.*;
import essentialcraft.common.registry.*;
import net.minecraft.client.audio.*;

public class GuiButtonNoSound extends GuiButton
{
    public GuiButtonNoSound(final int id, final int x, final int y, final int width, final int height, final String buttonText) {
        super(id, x, y, width, height, buttonText);
    }
    
    public void func_146113_a(final SoundHandler soundHandler) {
        soundHandler.func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundRegistry.bookPageTurn, 1.0f));
    }
}
