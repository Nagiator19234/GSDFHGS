package essentialcraft.client.gui;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import essentialcraft.common.tile.*;
import net.minecraft.tileentity.*;
import essentialcraft.client.gui.element.*;

public class GuiMagicianTable extends GuiCommon
{
    public GuiMagicianTable(final Container c, final TileMagicianTable tile) {
        super(c, (TileEntity)tile);
        this.elementList.add(new GuiMRUStorage(7, 4, tile));
        this.elementList.add(new GuiProgressBar_MagicianTable(25, 4, tile));
        this.elementList.add(new GuiMRUState(25, 58, tile, 0));
        this.elementList.add(new GuiBalanceState(88, 22, tile));
        this.elementList.add(new GuiBoundGemState(88, 40, tile, 0));
    }
}
