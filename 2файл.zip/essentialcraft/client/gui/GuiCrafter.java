package essentialcraft.client.gui;

import essentialcraft.common.tile.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.inventory.*;
import DummyCore.Client.*;
import net.minecraft.client.*;
import java.util.*;
import net.minecraft.item.*;

public class GuiCrafter extends GuiCommon
{
    public TileCrafter crafter;
    
    public GuiCrafter(final Container c, final TileCrafter inv) {
        super(c);
        this.guiGenLocation = new ResourceLocation("textures/gui/container/crafting_table.png");
        this.crafter = inv;
    }
    
    protected void func_146976_a(final float f1, final int i1, final int i2) {
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.field_146297_k.field_71446_o.func_110577_a(this.guiGenLocation);
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        RenderHelper.func_74518_a();
        RenderHelper.func_74520_c();
        for (final Slot slt : this.field_147002_h.field_75151_b) {
            this.renderSlot(slt);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        }
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        RenderHelper.func_74519_b();
        for (final GuiElement element : this.elementList) {
            Minecraft.func_71410_x().field_71446_o.func_110577_a(element.getElementTexture());
            element.draw(k + element.getX(), l + element.getY(), i1, i2);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        }
    }
    
    public void func_73866_w_() {
        super.func_73866_w_();
    }
    
    public void renderSlot(final Slot slt) {
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.field_146297_k.field_71446_o.func_110577_a(this.slotLocation);
        if (slt.field_75222_d != 9) {
            this.func_73729_b(k + slt.field_75223_e - 1, l + slt.field_75221_f - 1, 7, 83, 18, 18);
        }
        if (slt.field_75222_d < 9 && this.crafter.hasFrame() && !slt.func_75216_d()) {
            final ItemStack[] retStk = this.crafter.getRecipeFromFrame();
            if (!retStk[slt.field_75222_d].func_190926_b()) {
                this.field_146296_j.field_77023_b = 100.0f;
                this.field_73735_i = 100.0f;
                GlStateManager.func_179131_c(0.5f, 0.5f, 0.5f, 1.0f);
                this.field_146296_j.func_180450_b(retStk[slt.field_75222_d], k + slt.field_75223_e, l + slt.field_75221_f);
                this.field_146296_j.field_77023_b = 0.0f;
                this.field_73735_i = 0.0f;
            }
        }
    }
}
