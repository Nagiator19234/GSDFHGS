package essentialcraft.client.gui;

import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import DummyCore.Client.*;
import essentialcraft.common.tile.*;
import net.minecraft.util.*;
import essentialcraft.common.inventory.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import essentialcraft.client.gui.element.*;
import net.minecraft.client.*;
import net.minecraft.nbt.*;
import essentialcraft.network.*;
import essentialcraft.common.mod.*;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import org.lwjgl.input.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import net.minecraft.client.util.*;
import java.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;

public class GuiMIMScreen extends GuiContainer
{
    TileMIMScreen screen;
    EntityPlayer player;
    int scrollIndex;
    int maxScrollIndex;
    ItemStack selectedStack;
    List<GuiElement> elementList;
    boolean secondPress;
    int recipeSelected;
    int lastPressedTime;
    GuiTextField search;
    GuiTextField stackSize;
    int[] btnActions;
    HashMap<ItemStack, TileMIMCraftingManager.CraftingPattern> craftsByItemStack;
    public static boolean packetArrived;
    final ResourceLocation textures;
    final ResourceLocation stextures;
    boolean isLeftMouseButtonPressed;
    
    public GuiMIMScreen(final TileMIMScreen par1, final EntityPlayer par2) {
        super((Container)new ContainerMIMScreen(par2.field_71071_by, par1));
        this.selectedStack = ItemStack.field_190927_a;
        this.elementList = new ArrayList<GuiElement>();
        this.btnActions = new int[] { 1, -1, 2, -2, 4, -4, 5, -5, 8, -8, 10, -10, 16, -16, 32, -32, 50, -50, 64, -64, 100, -100, 128, -128, Integer.MAX_VALUE, -2147483647 };
        this.craftsByItemStack = new HashMap<ItemStack, TileMIMCraftingManager.CraftingPattern>();
        this.textures = new ResourceLocation("essentialcraft", "textures/gui/mimScreen.png");
        this.stextures = new ResourceLocation("essentialcraft", "textures/gui/mimScreenSlider.png");
        this.elementList.add(new GuiMRUStorage(7, 59, par1));
        this.screen = par1;
        this.player = par2;
        this.field_146999_f = 256;
        this.field_147000_g = 256;
        GuiMIMScreen.packetArrived = true;
    }
    
    public void func_73876_c() {
        if (this.lastPressedTime > 0) {
            --this.lastPressedTime;
        }
        else {
            this.secondPress = false;
        }
        super.func_73876_c();
    }
    
    public void func_146281_b() {
        super.func_146281_b();
        Keyboard.enableRepeatEvents(false);
    }
    
    public boolean isValidInt(final char c, final int keyID) {
        return keyID == 1 || keyID == 3 || keyID == 22 || keyID == 24 || keyID == 14 || keyID == 199 || keyID == 203 || keyID == 205 || keyID == 207 || keyID == 211 || c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9';
    }
    
    protected void func_73869_a(final char c, final int keyID) {
        try {
            if (this.search.func_146201_a(c, keyID) || (this.isValidInt(c, keyID) && this.stackSize.func_146201_a(c, keyID))) {
                this.setupMaxInt();
            }
            else {
                if (keyID == 28 && !this.selectedStack.func_190926_b()) {
                    this.func_146284_a(this.field_146292_n.get(26));
                }
                super.func_73869_a(c, keyID);
            }
        }
        catch (Exception ex) {}
    }
    
    protected void func_73864_a(final int mouseX, final int mouseY, final int mouseButton) {
        try {
            super.func_73864_a(mouseX, mouseY, mouseButton);
            this.search.func_146192_a(mouseX, mouseY, mouseButton);
            this.stackSize.func_146192_a(mouseX, mouseY, mouseButton);
        }
        catch (Exception ex) {}
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
    
    public void func_73866_w_() {
        this.field_146292_n.clear();
        super.func_73866_w_();
        Keyboard.enableRepeatEvents(true);
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.search = new GuiTextField(2934, this.field_146289_q, k + 4, l + 4, 248, 20);
        this.stackSize = new GuiTextField(2935, this.field_146289_q, k + 95, l + 156, 64, 12);
        this.setupMaxInt();
        for (int i = 0; i < this.btnActions.length; ++i) {
            final boolean neg = i % 2 == 1;
            if (i < 8) {
                final GuiButton btn = new GuiButton(i, neg ? (k - i / 2 * 16 + 103 - 32) : (k + i / 2 * 16 + 103 + 64), l + 154, 16, 16, neg ? String.valueOf(this.btnActions[i]) : ("+" + this.btnActions[i]));
                this.field_146292_n.add(btn);
            }
            else {
                final int xIndex = (i % 4 == 0) ? (k + 212) : ((i % 4 == 1) ? (k + 26) : ((i % 4 == 2) ? (k + 235) : (k + 4)));
                final int yIndex = l + 140 + i / 4 * 16;
                if (this.btnActions[i] != Integer.MAX_VALUE && this.btnActions[i] != -2147483647) {
                    final GuiButton btn2 = new GuiButton(i, xIndex, yIndex, 16, 16, neg ? ("" + this.btnActions[i]) : ("+" + this.btnActions[i]));
                    this.field_146292_n.add(btn2);
                }
                else {
                    final String s = neg ? "<<<" : ">>>";
                    final GuiButton btn3 = new GuiButton(i, neg ? (k + 4) : (k + 235), l + 154, 16, 16, s);
                    this.field_146292_n.add(btn3);
                }
            }
        }
        final GuiRequestButton request = new GuiRequestButton(26, k + 3, l + 46, 27, 10, "Request");
        this.field_146292_n.add(request);
    }
    
    protected void func_146284_a(final GuiButton button) {
        try {
            super.func_146284_a(button);
            if (button.field_146127_k < 26) {
                final int i = this.btnActions[button.field_146127_k];
                this.setupMaxInt();
                int currentInt = Integer.parseInt(this.stackSize.func_146179_b());
                if (i != Integer.MAX_VALUE && i != -2147483647) {
                    currentInt += i;
                    if (currentInt <= 0) {
                        currentInt = 1;
                    }
                    this.stackSize.func_146180_a(String.valueOf(currentInt));
                    this.setupMaxInt();
                }
                else {
                    currentInt = i;
                    if (currentInt < 0) {
                        this.stackSize.func_146180_a("1");
                        this.setupMaxInt();
                        return;
                    }
                    if (!this.selectedStack.func_190926_b() && currentInt > this.selectedStack.func_190916_E()) {
                        this.stackSize.func_146180_a(String.valueOf(this.selectedStack.func_190916_E()));
                        this.setupMaxInt();
                        return;
                    }
                    this.setupMaxInt();
                }
            }
            else if (button.field_146127_k == 26 && this.screen != null && this.screen.parent != null && !this.selectedStack.func_190926_b()) {
                this.setupMaxInt();
                final NBTTagCompound carriedToServer = new NBTTagCompound();
                final NBTTagCompound itemTag = new NBTTagCompound();
                this.selectedStack.func_77955_b(itemTag);
                carriedToServer.func_74768_a("x", this.screen.func_174877_v().func_177958_n());
                carriedToServer.func_74768_a("y", this.screen.func_174877_v().func_177956_o());
                carriedToServer.func_74768_a("z", this.screen.func_174877_v().func_177952_p());
                carriedToServer.func_74768_a("px", this.screen.parent.func_174877_v().func_177958_n());
                carriedToServer.func_74768_a("py", this.screen.parent.func_174877_v().func_177956_o());
                carriedToServer.func_74768_a("pz", this.screen.parent.func_174877_v().func_177952_p());
                carriedToServer.func_74778_a("requester", MiscUtils.getUUIDFromPlayer((EntityPlayer)Minecraft.func_71410_x().field_71439_g).toString());
                carriedToServer.func_74768_a("size", Integer.parseInt(this.stackSize.func_146179_b()));
                carriedToServer.func_74757_a("craft", this.recipeSelected > -1);
                carriedToServer.func_74782_a("requestedItem", (NBTBase)itemTag);
                final PacketNBT sent = new PacketNBT(carriedToServer).setID(5);
                EssentialCraftCore.network.sendToServer((IMessage)sent);
                GuiMIMScreen.packetArrived = false;
            }
        }
        catch (Exception ex) {}
    }
    
    public boolean func_73868_f() {
        return false;
    }
    
    protected void func_146976_a(final float partialTicks, final int mX, final int mY) {
        ItemStack ttis = ItemStack.field_190927_a;
        boolean ttib = false;
        final int k = (this.field_146294_l - this.field_146999_f) / 2;
        final int l = (this.field_146295_m - this.field_147000_g) / 2;
        Minecraft.func_71410_x().field_71446_o.func_110577_a(this.textures);
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        this.search.func_146194_f();
        this.stackSize.func_146194_f();
        this.field_146292_n.get(26).field_146124_l = (!this.selectedStack.func_190926_b() && GuiMIMScreen.packetArrived);
        for (final GuiElement element : this.elementList) {
            Minecraft.func_71410_x().field_71446_o.func_110577_a(element.getElementTexture());
            element.draw(k + element.getX(), l + element.getY(), mX, mY);
            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        }
        DrawUtils.bindTexture("essentialcraft", "textures/gui/mimScreenSlider.png");
        this.func_73729_b(k + 228, l + 25, 0, 0, 12, 126);
        if (Mouse.isButtonDown(0) && mX >= k + 228 && mX <= k + 228 + 12 && mY >= l + 25 && mY < l + 25 + 126) {
            final int yIndex = mY - (l + 25);
            final int percentage = MathHelper.func_76128_c(yIndex / 126.0 * 100.0);
            final double dIndex = percentage / 100.0 * this.maxScrollIndex;
            final int iIndex = (int)dIndex;
            final double lIndex = dIndex - iIndex;
            final int index = (lIndex >= 0.5) ? (iIndex + 1) : iIndex;
            this.scrollIndex = Math.min(index, this.maxScrollIndex);
        }
        this.func_73729_b(k + 229, l + 26 + ((this.maxScrollIndex == 0) ? 0 : MathUtils.pixelatedTextureSize(this.scrollIndex, this.maxScrollIndex, 113)), 12, 0, 10, 11);
        if (!Mouse.isButtonDown(0) && this.isLeftMouseButtonPressed) {
            this.isLeftMouseButtonPressed = false;
        }
        if (this.screen != null && this.screen.parent != null) {
            ArrayList<ItemStack> drawnItems;
            if (this.search.func_146179_b() != null && !this.search.func_146179_b().isEmpty()) {
                drawnItems = this.screen.parent.getItemsByName(this.search.func_146179_b());
            }
            else {
                drawnItems = this.screen.parent.getAllItems();
            }
            ArrayList<TileMIMCraftingManager.CraftingPattern> crafts;
            if (this.search.func_146179_b() != null && !this.search.func_146179_b().isEmpty()) {
                crafts = this.screen.parent.getCraftsByName(this.search.func_146179_b());
            }
            else {
                crafts = this.screen.parent.getAllCrafts();
            }
            this.craftsByItemStack.clear();
            final int regSize = drawnItems.size();
            for (final TileMIMCraftingManager.CraftingPattern p : crafts) {
                this.craftsByItemStack.put(p.result, p);
                drawnItems.add(p.result);
            }
            if (drawnItems == null || drawnItems.isEmpty()) {
                this.selectedStack = ItemStack.field_190927_a;
                this.secondPress = false;
                this.recipeSelected = -1;
            }
            if (!this.selectedStack.func_190926_b()) {
                boolean hasStack = false;
                if (this.recipeSelected > -1) {
                    for (final ItemStack is : this.craftsByItemStack.keySet()) {
                        if (!is.func_190926_b() && is.func_77969_a(this.selectedStack) && ItemStack.func_77970_a(is, this.selectedStack) && is.func_190916_E() == this.selectedStack.func_190916_E()) {
                            hasStack = true;
                            break;
                        }
                    }
                }
                else {
                    for (final ItemStack is : drawnItems) {
                        if (!is.func_190926_b() && is.func_77969_a(this.selectedStack) && ItemStack.func_77970_a(is, this.selectedStack)) {
                            hasStack = true;
                            break;
                        }
                    }
                }
                if (!hasStack) {
                    this.selectedStack = ItemStack.field_190927_a;
                    this.secondPress = false;
                    this.recipeSelected = -1;
                }
            }
            RenderHelper.func_74518_a();
            RenderHelper.func_74520_c();
            this.maxScrollIndex = Math.max(0, (drawnItems.size() <= 60) ? 0 : ((drawnItems.size() - 60) / 10 + 1));
            final int dWheel = Mouse.getDWheel();
            if (dWheel > 0) {
                final int n = 0;
                final int scrollIndex = this.scrollIndex - 1;
                this.scrollIndex = scrollIndex;
                this.scrollIndex = Math.max(n, scrollIndex);
            }
            if (dWheel < 0) {
                this.scrollIndex = Math.min(this.maxScrollIndex, ++this.scrollIndex);
            }
            if (this.scrollIndex > this.maxScrollIndex) {
                this.scrollIndex = 0;
            }
            for (int i = this.scrollIndex * 10; i < drawnItems.size() && i < 60 + this.scrollIndex * 10; ++i) {
                int x = k + 32 + i % 10 * 19;
                int y = l + 28 + i / 10 * 19 - this.scrollIndex * 19;
                if (!this.selectedStack.func_190926_b() && !drawnItems.get(i).func_190926_b() && drawnItems.get(i).func_77969_a(this.selectedStack) && ItemStack.func_77970_a((ItemStack)drawnItems.get(i), this.selectedStack) && ((this.recipeSelected == -1 && i < regSize) || (this.recipeSelected > -1 && i == this.recipeSelected))) {
                    x -= 2;
                    y -= 2;
                    this.func_73733_a(x, y, x + 18, y + 18, -1996510465, -2004326776);
                    this.func_73733_a(x, y, x + 1, y + 18, -10092442, -13434829);
                    this.func_73733_a(x, y + 17, x + 18, y + 18, -13434829, -15663087);
                    this.func_73733_a(x + 17, y, x + 18, y + 18, -6750055, -15663087);
                    this.func_73733_a(x, y, x + 18, y + 1, -10092442, -6750055);
                    ++y;
                    ++x;
                }
                this.field_146296_j.func_180450_b((ItemStack)drawnItems.get(i), x, y);
                int alterSize = drawnItems.get(i).func_190916_E();
                final boolean greaterThan1K = alterSize >= 1000;
                final boolean greaterThan1M = alterSize >= 1000000;
                if (alterSize >= 1000000) {
                    alterSize /= 1000000;
                }
                if (alterSize >= 1000) {
                    alterSize /= 1000;
                }
                String s = greaterThan1M ? (alterSize + "M") : (greaterThan1K ? (alterSize + "k") : (alterSize + ""));
                if (i >= regSize) {
                    s = "Craft";
                }
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                GlStateManager.func_179084_k();
                if (i >= regSize) {
                    final boolean unicode = Minecraft.func_71410_x().field_71474_y.field_151455_aw || Minecraft.func_71410_x().field_71466_p.func_82883_a();
                    if (!unicode) {
                        GlStateManager.func_179152_a(0.5f, 0.5f, 1.0f);
                        GlStateManager.func_179137_b(1.0, 1.0, 0.0);
                        this.field_146289_q.func_78276_b(s, x * 2, (y + 8) * 2 + 6, 0);
                        GlStateManager.func_179137_b(-1.0, -1.0, 0.0);
                        this.field_146289_q.func_78276_b(s, x * 2, (y + 8) * 2 + 6, 16777215);
                        GlStateManager.func_179152_a(2.0f, 2.0f, 1.0f);
                    }
                    else {
                        GlStateManager.func_179137_b(0.5, 0.5, 0.0);
                        this.field_146289_q.func_78276_b(s, x, y + 8, 0);
                        GlStateManager.func_179137_b(-0.5, -0.5, 0.0);
                        this.field_146289_q.func_78276_b(s, x, y + 8, 16777215);
                    }
                }
                else {
                    GlStateManager.func_179137_b(0.5, 0.5, 0.0);
                    this.field_146289_q.func_78276_b(s, x, y + 8, 0);
                    GlStateManager.func_179137_b(-0.5, -0.5, 0.0);
                    this.field_146289_q.func_78276_b(s, x, y + 8, 16777215);
                }
                GlStateManager.func_179145_e();
                GlStateManager.func_179126_j();
                GlStateManager.func_179147_l();
                if (mX >= x && mX <= x + 16 && mY >= y && mY <= y + 16) {
                    ttis = drawnItems.get(i);
                    if (i >= regSize) {
                        ttib = true;
                    }
                    if (Mouse.isButtonDown(0) && !this.isLeftMouseButtonPressed) {
                        this.isLeftMouseButtonPressed = true;
                        if (this.selectedStack.func_190926_b()) {
                            this.selectedStack = drawnItems.get(i).func_77946_l();
                            this.secondPress = true;
                            this.lastPressedTime = 20;
                            if (i >= regSize) {
                                this.recipeSelected = i;
                            }
                            else {
                                this.recipeSelected = -1;
                            }
                        }
                        else {
                            if (func_146272_n()) {
                                this.secondPress = true;
                                this.lastPressedTime = 20;
                            }
                            if (!drawnItems.get(i).func_190926_b() && (!drawnItems.get(i).func_77969_a(this.selectedStack) || !ItemStack.func_77970_a((ItemStack)drawnItems.get(i), this.selectedStack))) {
                                this.selectedStack = drawnItems.get(i).func_77946_l();
                                if (i >= regSize) {
                                    this.recipeSelected = i;
                                }
                                else {
                                    this.recipeSelected = -1;
                                }
                                if (func_146272_n()) {
                                    this.secondPress = false;
                                    this.func_146284_a(this.field_146292_n.get(26));
                                }
                                this.setupMaxInt();
                            }
                            else if (i >= regSize) {
                                if (i == this.recipeSelected) {
                                    if (!this.secondPress) {
                                        this.secondPress = true;
                                        this.lastPressedTime = 20;
                                    }
                                    else {
                                        this.secondPress = false;
                                        this.func_146284_a(this.field_146292_n.get(26));
                                    }
                                    this.setupMaxInt();
                                }
                                else {
                                    this.selectedStack = drawnItems.get(i).func_77946_l();
                                    this.recipeSelected = i;
                                }
                            }
                            else if (i < regSize) {
                                if (this.recipeSelected != -1) {
                                    this.recipeSelected = -1;
                                    this.selectedStack = drawnItems.get(i).func_77946_l();
                                }
                                else if (!this.secondPress) {
                                    this.secondPress = true;
                                    this.lastPressedTime = 20;
                                }
                                else {
                                    this.secondPress = false;
                                    this.func_146284_a(this.field_146292_n.get(26));
                                }
                                this.setupMaxInt();
                            }
                        }
                    }
                }
            }
            if (!ttis.func_190926_b()) {
                if (ttib) {
                    final int j2 = mX + 12;
                    final int k2 = mY + ttis.func_82840_a(this.player, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL).size() * 10 + 6;
                    final int i2 = 50;
                    final int sX = 50;
                    this.func_73733_a(j2 - 3, k2 - 4, j2 + sX + 3, k2 - 3, -16777216, -16777216);
                    this.func_73733_a(j2 - 3, k2 + i2 + 3, j2 + sX + 3, k2 + i2 + 4, -16777216, -16777216);
                    this.func_73733_a(j2 - 3, k2 - 3, j2 + sX + 3, k2 + i2 + 3, -14535834, -16775663);
                    this.func_73733_a(j2 - 4, k2 - 3, j2 - 3, k2 + i2 + 3, -16777216, -16777216);
                    this.func_73733_a(j2 + sX + 3, k2 - 3, j2 + sX + 4, k2 + i2 + 3, -16777216, -16777216);
                    if (this.craftsByItemStack.containsKey(ttis)) {
                        for (int m = 0; m < this.craftsByItemStack.get(ttis).input.length; ++m) {
                            final int pX = mX + m / 3 * 17 + 10 - 10;
                            final int pY = mY + m % 3 * 17 + 4 + 6;
                            this.func_73733_a(pX + 12, pY + 16, pX + 12 + 16, pY + 16 + 16, -1996510465, -2004326776);
                            this.func_73733_a(pX + 12, pY + 16, pX + 12 + 1, pY + 16 + 16, -10092442, -13434829);
                            this.func_73733_a(pX + 12, pY + 16 + 15, pX + 12 + 16, pY + 16 + 16, -13434829, -15663087);
                            this.func_73733_a(pX + 12 + 15, pY + 16, pX + 12 + 16, pY + 16 + 16, -6750055, -15663087);
                            this.func_73733_a(pX + 12, pY + 16, pX + 12 + 16, pY + 16 + 1, -10092442, -6750055);
                            if (!this.craftsByItemStack.get(ttis).input[m].func_190926_b()) {
                                GuiResearchBook.itemRender.func_180450_b(this.craftsByItemStack.get(ttis).input[m], mX + m / 3 * 17 + 12, mY + m % 3 * 17 + 26);
                            }
                        }
                    }
                }
                this.func_146285_a(ttis, mX, mY);
            }
            RenderHelper.func_74519_b();
            drawnItems.clear();
        }
    }
    
    public void setupMaxInt() {
        if (this.selectedStack.func_190926_b()) {
            if (!this.isCorrectInteger()) {
                this.stackSize.func_146180_a("0");
            }
            return;
        }
        if (!this.isCorrectInteger()) {
            this.stackSize.func_146180_a("1");
        }
        else {
            final int i = Integer.parseInt(this.stackSize.func_146179_b());
            if (i <= 0) {
                this.stackSize.func_146180_a("1");
            }
            if (i > this.selectedStack.func_190916_E() && this.recipeSelected == -1) {
                this.stackSize.func_146180_a(String.valueOf(this.selectedStack.func_190916_E()));
            }
        }
    }
    
    public boolean isCorrectInteger() {
        try {
            final int i = Integer.parseInt(this.stackSize.func_146179_b());
            return i >= 0;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }
    
    static {
        GuiMIMScreen.packetArrived = true;
    }
    
    public static class GuiRequestButton extends GuiButton
    {
        public GuiRequestButton(final int id, final int x, final int y, final int sizeX, final int sizeY, final String string) {
            super(id, x, y, sizeX, sizeY, string);
        }
        
        public void func_191745_a(final Minecraft mc, final int mouseX, final int mouseY, final float partial) {
            if (this.field_146125_m) {
                final FontRenderer fontrenderer = mc.field_71466_p;
                mc.func_110434_K().func_110577_a(GuiRequestButton.field_146122_a);
                GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
                this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
                final int k = this.func_146114_a(this.field_146123_n);
                GlStateManager.func_179147_l();
                OpenGlHelper.func_148821_a(770, 771, 1, 0);
                GlStateManager.func_179112_b(770, 771);
                this.func_73729_b(this.field_146128_h, this.field_146129_i, 0, 46 + k * 20, this.field_146120_f / 2, this.field_146121_g);
                this.func_73729_b(this.field_146128_h + this.field_146120_f / 2, this.field_146129_i, 200 - this.field_146120_f / 2, 46 + k * 20, this.field_146120_f / 2, this.field_146121_g);
                this.func_146119_b(mc, mouseX, mouseY);
                int l = 14737632;
                if (this.packedFGColour != 0) {
                    l = this.packedFGColour;
                }
                else if (!this.field_146124_l) {
                    l = 10526880;
                }
                else if (this.field_146123_n) {
                    l = 16777120;
                }
                final boolean unicode = Minecraft.func_71410_x().field_71474_y.field_151455_aw || Minecraft.func_71410_x().field_71466_p.func_82883_a();
                if (!unicode) {
                    GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
                }
                else {
                    GlStateManager.func_179152_a(0.95f, 0.95f, 0.95f);
                }
                this.func_73732_a(fontrenderer, this.field_146126_j, unicode ? MathHelper.func_76141_d((this.field_146128_h + this.field_146120_f / 2) / 0.95f) : ((this.field_146128_h + this.field_146120_f / 2) * 2), unicode ? MathHelper.func_76141_d((this.field_146129_i + (this.field_146121_g - 8) / 2) / 0.95f) : ((this.field_146129_i + (this.field_146121_g - 8) / 2) * 2 + 4), l);
                if (!unicode) {
                    GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
                }
                else {
                    GlStateManager.func_179152_a(1.0526316f, 1.0526316f, 1.0526316f);
                }
            }
        }
    }
}
