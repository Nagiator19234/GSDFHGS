package essentialcraft.client.gui;

import net.minecraft.client.gui.*;
import essentialcraft.utils.cfg.*;
import net.minecraftforge.fml.client.config.*;
import net.minecraftforge.common.config.*;
import java.util.*;

public class GuiModConfiguration extends GuiConfig
{
    public GuiModConfiguration(final GuiScreen parentScreen) {
        super(parentScreen, (List)getConfigElements(), "essentialcraft", false, false, GuiConfig.getAbridgedConfigPath(Config.config.toString()));
    }
    
    private static List<IConfigElement> getConfigElements() {
        final List<IConfigElement> list = new ArrayList<IConfigElement>();
        list.addAll(new ConfigElement(Config.config.getCategory("misc")).getChildElements());
        list.addAll(new ConfigElement(Config.config.getCategory("general")).getChildElements());
        list.addAll(new ConfigElement(Config.config.getCategory("worldgen")).getChildElements());
        list.addAll(new ConfigElement(Config.config.getCategory("difficulty")).getChildElements());
        list.addAll(new ConfigElement(Config.config.getCategory("tileentities")).getChildElements());
        return list;
    }
}
