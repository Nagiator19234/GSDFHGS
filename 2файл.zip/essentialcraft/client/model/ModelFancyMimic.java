package essentialcraft.client.model;

import net.minecraft.block.state.*;
import java.util.*;
import net.minecraft.client.*;
import com.google.common.collect.*;
import net.minecraftforge.client.*;
import essentialcraft.common.block.*;
import net.minecraftforge.common.property.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.init.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.*;

public class ModelFancyMimic implements IBakedModel
{
    private final String type;
    
    public ModelFancyMimic(final String type) {
        this.type = type;
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        if (!(state.func_177230_c() instanceof BlockFancyMimic)) {
            return (List<BakedQuad>)Minecraft.func_71410_x().func_175602_ab().func_175023_a().func_178126_b().func_174951_a().func_188616_a(state, side, rand);
        }
        final ImmutableList.Builder<BakedQuad> ret = (ImmutableList.Builder<BakedQuad>)ImmutableList.builder();
        final BlockRenderLayer layer = MinecraftForgeClient.getRenderLayer();
        final IBlockState heldState = (IBlockState)((IExtendedBlockState)state).getValue((IUnlistedProperty)BlockMimic.STATE);
        final IBlockAccess heldWorld = (IBlockAccess)((IExtendedBlockState)state).getValue((IUnlistedProperty)BlockMimic.WORLD);
        final BlockPos heldPos = (BlockPos)((IExtendedBlockState)state).getValue((IUnlistedProperty)BlockMimic.POS);
        if (heldWorld == null || heldPos == null) {
            return (List<BakedQuad>)ret.build();
        }
        final Minecraft mc = Minecraft.func_71410_x();
        if (heldState == null && layer == BlockRenderLayer.SOLID) {
            final ModelResourceLocation path = new ModelResourceLocation("essentialcraft:mimic", "inventory");
            ret.addAll((Iterable)mc.func_175602_ab().func_175023_a().func_178126_b().func_174953_a(path).func_188616_a(state, side, rand));
        }
        else if (heldState != null && heldState.func_177230_c().canRenderInLayer(heldState, layer)) {
            final IBlockState actual = heldState.func_177230_c().func_176221_a(heldState, (IBlockAccess)new FakeBlockAccess(heldWorld), heldPos);
            final IBakedModel model = mc.func_175602_ab().func_175023_a().func_178125_b(actual);
            final IBlockState extended = heldState.func_177230_c().getExtendedState(actual, (IBlockAccess)new FakeBlockAccess(heldWorld), heldPos);
            ret.addAll((Iterable)model.func_188616_a(extended, side, rand));
        }
        if (layer == BlockRenderLayer.CUTOUT_MIPPED) {
            final ModelResourceLocation path = new ModelResourceLocation("essentialcraft:fancyblock/mimic", "type=" + this.type);
            ret.addAll((Iterable)mc.func_175602_ab().func_175023_a().func_178126_b().func_174953_a(path).func_188616_a(state, side, rand));
        }
        return (List<BakedQuad>)ret.build();
    }
    
    public boolean func_177555_b() {
        return true;
    }
    
    public boolean func_177556_c() {
        return true;
    }
    
    public boolean func_188618_c() {
        return false;
    }
    
    public TextureAtlasSprite func_177554_e() {
        return Minecraft.func_71410_x().func_147117_R().func_110572_b("essentialcraft:blocks/mimic");
    }
    
    public ItemCameraTransforms func_177552_f() {
        return ItemCameraTransforms.field_178357_a;
    }
    
    public ItemOverrideList func_188617_f() {
        return ItemOverrideList.field_188022_a;
    }
    
    private static class FakeBlockAccess implements IBlockAccess
    {
        private final IBlockAccess compose;
        
        private FakeBlockAccess(final IBlockAccess compose) {
            this.compose = compose;
        }
        
        public TileEntity func_175625_s(final BlockPos pos) {
            return this.compose.func_175625_s(pos);
        }
        
        public int func_175626_b(final BlockPos pos, final int lightValue) {
            return 15728880;
        }
        
        public IBlockState func_180495_p(final BlockPos pos) {
            IBlockState state = this.compose.func_180495_p(pos);
            if (state.func_177230_c() instanceof BlockFancyMimic) {
                state = ((TileMimic)this.compose.func_175625_s(pos)).getState();
            }
            return (state == null) ? Blocks.field_150350_a.func_176223_P() : state;
        }
        
        public boolean func_175623_d(final BlockPos pos) {
            return this.compose.func_175623_d(pos);
        }
        
        public Biome func_180494_b(final BlockPos pos) {
            return this.compose.func_180494_b(pos);
        }
        
        public int func_175627_a(final BlockPos pos, final EnumFacing direction) {
            return this.compose.func_175627_a(pos, direction);
        }
        
        public WorldType func_175624_G() {
            return this.compose.func_175624_G();
        }
        
        public boolean isSideSolid(final BlockPos pos, final EnumFacing side, final boolean _default) {
            return this.compose.isSideSolid(pos, side, _default);
        }
    }
}
