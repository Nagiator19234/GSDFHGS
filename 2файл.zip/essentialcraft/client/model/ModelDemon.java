package essentialcraft.client.model;

import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;

public class ModelDemon extends ModelBiped
{
    public ModelRenderer bipedWings;
    public ModelRenderer bipedWingsBack;
    private static final ResourceLocation wingsTexture;
    
    public ModelDemon(final float scale, final float bodyPos, final int textureWidth, final int textureHeight) {
        (this.bipedWings = new ModelRenderer((ModelBase)this, 0, 0)).func_78790_a(-16.0f, -4.0f, 2.1f, 32, 16, 0, 0.0f);
        this.bipedWings.func_78793_a(0.0f, 0.0f + bodyPos, 0.0f);
    }
    
    public void func_78088_a(final Entity entity, final float limbSwing, final float limbSwingAmount, final float age, final float yaw, final float pitch, final float scale) {
        super.func_78088_a(entity, limbSwing, limbSwingAmount, age, yaw, pitch, scale);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ModelDemon.wingsTexture);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(770, 771);
        this.bipedWings.func_78785_a(scale);
    }
    
    public void func_78087_a(final float limbSwing, final float limbSwingAmount, final float age, final float yaw, final float pitch, final float scale, final Entity entity) {
        super.func_78087_a(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        this.bipedWings.field_78795_f = this.field_78115_e.field_78795_f;
        this.bipedWings.field_78796_g = this.field_78115_e.field_78796_g;
        this.bipedWings.field_78808_h = this.field_78115_e.field_78808_h;
    }
    
    static {
        wingsTexture = new ResourceLocation("essentialcraft", "textures/entities/demon_wings.png");
    }
}
