package essentialcraft.client.model;

import net.minecraft.block.state.*;
import net.minecraft.client.renderer.texture.*;
import org.apache.commons.lang3.tuple.*;
import javax.vecmath.*;
import net.minecraft.client.renderer.block.model.*;
import com.google.common.collect.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import essentialcraft.common.item.*;
import DummyCore.Utils.*;
import java.util.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;

public class ModelGunHandler implements IBakedModel
{
    public static IBakedModel blankItem;
    private final IBakedModel baseModel;
    
    public ModelGunHandler(final IBakedModel baseModel) {
        this.baseModel = baseModel;
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        return (List<BakedQuad>)this.baseModel.func_188616_a(state, side, rand);
    }
    
    public boolean func_177555_b() {
        return this.baseModel.func_177555_b();
    }
    
    public boolean func_177556_c() {
        return this.baseModel.func_177556_c();
    }
    
    public boolean func_188618_c() {
        return this.baseModel.func_188618_c();
    }
    
    public TextureAtlasSprite func_177554_e() {
        return this.baseModel.func_177554_e();
    }
    
    public ItemCameraTransforms func_177552_f() {
        return this.baseModel.func_177552_f();
    }
    
    public Pair<? extends IBakedModel, Matrix4f> handlePerspective(final ItemCameraTransforms.TransformType cameraTransformType) {
        final Matrix4f matrix4f = (Matrix4f)this.baseModel.handlePerspective(cameraTransformType).getRight();
        return (Pair<? extends IBakedModel, Matrix4f>)Pair.of((Object)this, (Object)matrix4f);
    }
    
    public ItemOverrideList func_188617_f() {
        return ModelGunOverrideHandler.INSTANCE;
    }
    
    public static class ModelGunOverrideHandler extends ItemOverrideList
    {
        public static final ModelGunOverrideHandler INSTANCE;
        
        public ModelGunOverrideHandler() {
            super((List)ImmutableList.of());
        }
        
        public IBakedModel handleItemState(final IBakedModel originalModel, final ItemStack stack, final World world, final EntityLivingBase entity) {
            if (!(stack.func_77973_b() instanceof ItemGun)) {
                return originalModel;
            }
            final NBTTagCompound tag = MiscUtils.getStackTag(stack);
            GunRegistry.GunMaterial base = null;
            GunRegistry.GunMaterial handle = null;
            GunRegistry.GunMaterial device = null;
            GunRegistry.ScopeMaterial scope = null;
            GunRegistry.LenseMaterial lense = null;
            final ItemGun iGun = (ItemGun)stack.func_77973_b();
            if (!stack.func_77942_o() || !stack.func_77978_p().func_74764_b("base")) {
                final Random rnd = new Random(System.currentTimeMillis() / 1000L);
                base = GunRegistry.GUN_MATERIALS.get(rnd.nextInt(GunRegistry.GUN_MATERIALS.size()));
                handle = GunRegistry.GUN_MATERIALS.get(rnd.nextInt(GunRegistry.GUN_MATERIALS.size()));
                device = GunRegistry.GUN_MATERIALS.get(rnd.nextInt(GunRegistry.GUN_MATERIALS.size()));
                if (iGun.gunType.equalsIgnoreCase("sniper")) {
                    scope = GunRegistry.SCOPE_MATERIALS_SNIPER.get(rnd.nextInt(GunRegistry.SCOPE_MATERIALS_SNIPER.size()));
                }
                else if (!iGun.gunType.equalsIgnoreCase("gatling")) {
                    scope = GunRegistry.SCOPE_MATERIALS.get(rnd.nextInt(GunRegistry.SCOPE_MATERIALS.size()));
                }
                lense = GunRegistry.LENSE_MATERIALS.get(rnd.nextInt(GunRegistry.LENSE_MATERIALS.size()));
            }
            else {
                base = GunRegistry.getGunFromID(tag.func_74779_i("base"));
                handle = GunRegistry.getGunFromID(tag.func_74779_i("handle"));
                device = GunRegistry.getGunFromID(tag.func_74779_i("device"));
                if (iGun.gunType.equalsIgnoreCase("sniper")) {
                    scope = GunRegistry.getScopeSniperFromID(tag.func_74779_i("scope"));
                }
                else {
                    scope = GunRegistry.getScopeFromID(tag.func_74779_i("scope"));
                }
                lense = GunRegistry.getLenseFromID(tag.func_74779_i("lense"));
            }
            if (entity != null && entity.func_70093_af() && tag.func_74764_b("scope") && iGun.gunType.equalsIgnoreCase("sniper")) {
                return (IBakedModel)new ModelGun(ModelGunHandler.blankItem);
            }
            return (IBakedModel)new ModelGun(originalModel, (base == null) ? null : new ResourceLocation((String)base.baseTextures.get(iGun.gunType)), (handle == null) ? null : new ResourceLocation((String)handle.handleTextures.get(iGun.gunType)), (device == null) ? null : new ResourceLocation((String)device.deviceTextures.get(iGun.gunType)), (scope == null) ? null : new ResourceLocation((String)scope.textures.get(iGun.gunType)), (lense == null) ? null : new ResourceLocation((String)lense.textures.get(iGun.gunType)));
        }
        
        static {
            INSTANCE = new ModelGunOverrideHandler();
        }
    }
}
