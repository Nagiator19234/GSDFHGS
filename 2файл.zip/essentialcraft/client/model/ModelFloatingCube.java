package essentialcraft.client.model;

import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.model.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.*;

@SideOnly(Side.CLIENT)
public class ModelFloatingCube extends ModelBase
{
    private ModelRenderer cube;
    private ModelRenderer glass;
    private ModelRenderer base;
    
    public ModelFloatingCube(final float f, final boolean hasBase) {
        this.glass = new ModelRenderer((ModelBase)this, "glass");
        this.glass.func_78784_a(0, 0).func_78789_a(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        this.cube = new ModelRenderer((ModelBase)this, "cube");
        this.cube.func_78784_a(32, 0).func_78789_a(-4.0f, -4.0f, -4.0f, 8, 8, 8);
        if (hasBase) {
            this.base = new ModelRenderer((ModelBase)this, "base");
            this.base.func_78784_a(0, 16).func_78789_a(-6.0f, 0.0f, -6.0f, 12, 4, 12);
        }
    }
    
    public void render(final TileEntity tile, final float limbSwing, final float limbSwingAmount, final float age, final float yaw, final float pitch, final float scale) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
        GlStateManager.func_179109_b(0.0f, -0.5f, 0.0f);
        GlStateManager.func_179114_b(limbSwingAmount, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179109_b(0.0f, 0.8f + age, 0.0f);
        GlStateManager.func_179114_b(60.0f, 0.7071f, 0.0f, 0.7071f);
        this.glass.func_78785_a(scale);
        final float s = 0.875f;
        GlStateManager.func_179152_a(s, s, s);
        GlStateManager.func_179114_b(60.0f, 0.7071f, 0.0f, 0.7071f);
        GlStateManager.func_179114_b(limbSwingAmount, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179152_a(s, s, s);
        GlStateManager.func_179114_b(60.0f, 0.7071f, 0.0f, 0.7071f);
        GlStateManager.func_179114_b(limbSwingAmount, 0.0f, 1.0f, 0.0f);
        this.cube.func_78785_a(scale);
        GlStateManager.func_179121_F();
    }
}
