package essentialcraft.client.model;

import net.minecraft.block.state.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.client.*;
import com.google.common.collect.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.renderer.block.model.*;
import org.apache.commons.lang3.tuple.*;
import javax.vecmath.*;
import java.awt.*;
import com.google.common.primitives.*;
import net.minecraft.client.renderer.vertex.*;

public class ModelGun implements IBakedModel
{
    static final float DISTANCE_BEHIND_ITEM_FACE = 0.46875f;
    static final float DELTA_FOR_OVERLAP = 6.25E-5f;
    private IBakedModel baseModel;
    private ResourceLocation base;
    private ResourceLocation handle;
    private ResourceLocation device;
    private ResourceLocation scope;
    private ResourceLocation lense;
    
    public ModelGun(final IBakedModel baseModel) {
        this(baseModel, null, null, null, null, null);
    }
    
    public ModelGun(final IBakedModel baseModel, final ResourceLocation base, final ResourceLocation handle, final ResourceLocation device, final ResourceLocation scope, final ResourceLocation lense) {
        this.baseModel = baseModel;
        this.base = base;
        this.handle = handle;
        this.device = device;
        this.scope = scope;
        this.lense = lense;
        if (this.base == null) {
            this.base = new ResourceLocation("essentialcraft:items/null");
        }
        if (this.handle == null) {
            this.handle = new ResourceLocation("essentialcraft:items/null");
        }
        if (this.device == null) {
            this.device = new ResourceLocation("essentialcraft:items/null");
        }
        if (this.scope == null) {
            this.scope = new ResourceLocation("essentialcraft:items/null");
        }
        if (this.lense == null) {
            this.lense = new ResourceLocation("essentialcraft:items/null");
        }
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        final BakedQuad baseNorth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4686875f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.base.toString()), EnumFacing.NORTH);
        final BakedQuad baseSouth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4686875f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.base.toString()), EnumFacing.SOUTH);
        final BakedQuad handleNorth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.468625f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.handle.toString()), EnumFacing.NORTH);
        final BakedQuad handleSouth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.468625f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.handle.toString()), EnumFacing.SOUTH);
        final BakedQuad deviceNorth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4685625f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.device.toString()), EnumFacing.NORTH);
        final BakedQuad deviceSouth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4685625f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.device.toString()), EnumFacing.SOUTH);
        final BakedQuad scopeNorth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4685f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.scope.toString()), EnumFacing.NORTH);
        final BakedQuad scopeSouth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4685f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.scope.toString()), EnumFacing.SOUTH);
        final BakedQuad lenseNorth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4684375f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.lense.toString()), EnumFacing.NORTH);
        final BakedQuad lenseSouth = this.createBakedQuadForFace(0.5f, 1.0f, 0.5f, 1.0f, -0.4684375f, 0, Minecraft.func_71410_x().func_147117_R().func_110572_b(this.lense.toString()), EnumFacing.SOUTH);
        final ImmutableList.Builder<BakedQuad> builder = (ImmutableList.Builder<BakedQuad>)ImmutableList.builder();
        builder.addAll((Iterable)this.baseModel.func_188616_a(state, side, rand));
        builder.add((Object[])new BakedQuad[] { baseNorth, baseSouth, handleNorth, handleSouth, deviceNorth, deviceSouth, scopeNorth, scopeSouth, lenseNorth, lenseSouth });
        return (List<BakedQuad>)builder.build();
    }
    
    public boolean func_177555_b() {
        return this.baseModel.func_177555_b();
    }
    
    public boolean func_177556_c() {
        return this.baseModel.func_177556_c();
    }
    
    public boolean func_188618_c() {
        return this.baseModel.func_188618_c();
    }
    
    public TextureAtlasSprite func_177554_e() {
        return Minecraft.func_71410_x().func_147117_R().func_110572_b(this.base.toString());
    }
    
    public ItemOverrideList func_188617_f() {
        return ItemOverrideList.field_188022_a;
    }
    
    public ItemCameraTransforms func_177552_f() {
        return this.baseModel.func_177552_f();
    }
    
    public Pair<? extends IBakedModel, Matrix4f> handlePerspective(final ItemCameraTransforms.TransformType cameraTransformType) {
        final Matrix4f matrix4f = (Matrix4f)this.baseModel.handlePerspective(cameraTransformType).getRight();
        return (Pair<? extends IBakedModel, Matrix4f>)Pair.of((Object)this, (Object)matrix4f);
    }
    
    private BakedQuad createBakedQuadForFace(final float centreLR, final float width, final float centreUD, final float height, final float forwardDisplacement, final int itemRenderLayer, final TextureAtlasSprite texture, final EnumFacing face) {
        float x3 = 0.0f;
        float x2 = 0.0f;
        float x5 = 0.0f;
        float x4 = 0.0f;
        float z5 = 0.0f;
        float z4 = 0.0f;
        float z7 = 0.0f;
        float z6 = 0.0f;
        float y5 = 0.0f;
        float y4 = 0.0f;
        float y3 = 0.0f;
        float y2 = 0.0f;
        switch (face) {
            case UP: {
                x2 = (x3 = centreLR + width / 2.0f);
                x4 = (x5 = centreLR - width / 2.0f);
                z4 = (z5 = centreUD + height / 2.0f);
                z6 = (z7 = centreUD - height / 2.0f);
                y2 = (y3 = (y4 = (y5 = 1.0f + forwardDisplacement)));
                break;
            }
            case DOWN: {
                x2 = (x3 = centreLR + width / 2.0f);
                x4 = (x5 = centreLR - width / 2.0f);
                z4 = (z5 = centreUD - height / 2.0f);
                z6 = (z7 = centreUD + height / 2.0f);
                y2 = (y3 = (y4 = (y5 = 0.0f - forwardDisplacement)));
                break;
            }
            case WEST: {
                z7 = (z5 = centreLR + width / 2.0f);
                z4 = (z6 = centreLR - width / 2.0f);
                y5 = (y3 = centreUD - height / 2.0f);
                y4 = (y2 = centreUD + height / 2.0f);
                x2 = (x3 = (x5 = (x4 = 0.0f - forwardDisplacement)));
                break;
            }
            case EAST: {
                z7 = (z5 = centreLR - width / 2.0f);
                z4 = (z6 = centreLR + width / 2.0f);
                y5 = (y3 = centreUD - height / 2.0f);
                y4 = (y2 = centreUD + height / 2.0f);
                x2 = (x3 = (x5 = (x4 = 1.0f + forwardDisplacement)));
                break;
            }
            case NORTH: {
                x2 = (x3 = centreLR + width / 2.0f);
                x4 = (x5 = centreLR - width / 2.0f);
                y5 = (y3 = centreUD - height / 2.0f);
                y4 = (y2 = centreUD + height / 2.0f);
                z7 = (z5 = (z6 = (z4 = 0.0f - forwardDisplacement)));
                break;
            }
            case SOUTH: {
                x2 = (x3 = centreLR + width / 2.0f);
                x4 = (x5 = centreLR - width / 2.0f);
                y5 = (y3 = centreUD - height / 2.0f);
                y4 = (y2 = centreUD + height / 2.0f);
                z7 = (z5 = (z6 = (z4 = 1.0f + forwardDisplacement)));
                break;
            }
            default: {
                return null;
            }
        }
        return new BakedQuad(Ints.concat(new int[][] { this.vertexToInts(x3, y3, z5, Color.WHITE.getRGB(), texture, 16.0f, 16.0f), this.vertexToInts(x2, y2, z7, Color.WHITE.getRGB(), texture, 16.0f, 0.0f), this.vertexToInts(x5, y4, z6, Color.WHITE.getRGB(), texture, 0.0f, 0.0f), this.vertexToInts(x4, y5, z4, Color.WHITE.getRGB(), texture, 0.0f, 16.0f) }), itemRenderLayer, face, texture, true, DefaultVertexFormats.field_176599_b);
    }
    
    private int[] vertexToInts(final float x, final float y, final float z, final int color, final TextureAtlasSprite texture, final float u, final float v) {
        return new int[] { Float.floatToRawIntBits(x), Float.floatToRawIntBits(y), Float.floatToRawIntBits(z), color, Float.floatToRawIntBits(texture.func_94214_a((double)u)), Float.floatToRawIntBits(texture.func_94207_b((double)v)), 0 };
    }
}
