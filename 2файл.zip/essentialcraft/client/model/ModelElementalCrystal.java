package essentialcraft.client.model;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelElementalCrystal extends ModelBase
{
    ModelRenderer Shape1;
    ModelRenderer Shape2;
    ModelRenderer Shape3;
    ModelRenderer Shape4;
    ModelRenderer Shape5;
    ModelRenderer Shape6;
    ModelRenderer Shape7;
    ModelRenderer Shape8;
    ModelRenderer Shape9;
    ModelRenderer Shape10;
    ModelRenderer Shape11;
    ModelRenderer Shape12;
    ModelRenderer Shape13;
    ModelRenderer Shape14;
    ModelRenderer Shape15;
    ModelRenderer Shape16;
    ModelRenderer Shape17;
    ModelRenderer Shape18;
    ModelRenderer Shape19;
    ModelRenderer Shape20;
    ModelRenderer Shape21;
    ModelRenderer Shape22;
    
    public ModelElementalCrystal() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        (this.Shape1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 4, 20, 5);
        this.Shape1.func_78793_a(1.0f, 10.0f, -7.0f);
        this.Shape1.func_78787_b(128, 128);
        this.Shape1.field_78809_i = true;
        this.setRotation(this.Shape1, 0.2094395f, 0.2094395f, 0.3316126f);
        (this.Shape2 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape2.func_78793_a(3.0f, 13.0f, -6.0f);
        this.Shape2.func_78787_b(128, 128);
        this.Shape2.field_78809_i = true;
        this.setRotation(this.Shape2, -0.5585054f, -0.8552113f, 0.418879f);
        (this.Shape3 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape3.func_78793_a(1.0f, 13.0f, -4.0f);
        this.Shape3.func_78787_b(128, 128);
        this.Shape3.field_78809_i = true;
        this.setRotation(this.Shape3, -3.141593f, -0.9599311f, -0.4014257f);
        (this.Shape4 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape4.func_78793_a(1.0f, 18.0f, -1.0f);
        this.Shape4.func_78787_b(128, 128);
        this.Shape4.field_78809_i = true;
        this.setRotation(this.Shape4, -3.141593f, -0.9599311f, -1.029744f);
        (this.Shape5 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape5.func_78793_a(1.0f, 21.0f, -3.0f);
        this.Shape5.func_78787_b(128, 128);
        this.Shape5.field_78809_i = true;
        this.setRotation(this.Shape5, -0.0523599f, -0.6632251f, -0.9424778f);
        (this.Shape6 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape6.func_78793_a(-1.0f, 20.0f, -6.0f);
        this.Shape6.func_78787_b(128, 128);
        this.Shape6.field_78809_i = true;
        this.setRotation(this.Shape6, 0.2268928f, -0.6632251f, -0.4712389f);
        (this.Shape7 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 4, 14, 5);
        this.Shape7.func_78793_a(-5.0f, 12.0f, 1.0f);
        this.Shape7.func_78787_b(128, 128);
        this.Shape7.field_78809_i = true;
        this.setRotation(this.Shape7, -0.0174533f, 0.2094395f, -0.2617994f);
        (this.Shape8 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 4, 7, 5);
        this.Shape8.func_78793_a(2.0f, 16.0f, -1.0f);
        this.Shape8.func_78787_b(128, 128);
        this.Shape8.field_78809_i = true;
        this.setRotation(this.Shape8, -0.2268928f, 0.2094395f, 0.2617994f);
        (this.Shape9 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 5, 5);
        this.Shape9.func_78793_a(-3.0f, 19.0f, -3.0f);
        this.Shape9.func_78787_b(128, 128);
        this.Shape9.field_78809_i = true;
        this.setRotation(this.Shape9, -0.0523599f, -0.7504916f, -0.1745329f);
        (this.Shape10 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 4, 8, 4);
        this.Shape10.func_78793_a(-5.0f, 18.0f, -9.0f);
        this.Shape10.func_78787_b(128, 128);
        this.Shape10.field_78809_i = true;
        this.setRotation(this.Shape10, 0.2443461f, -0.7330383f, -0.2617994f);
        (this.Shape11 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 4, 8, 4);
        this.Shape11.func_78793_a(6.0f, 15.0f, 4.0f);
        this.Shape11.func_78787_b(128, 128);
        this.Shape11.field_78809_i = true;
        this.setRotation(this.Shape11, -0.0872665f, -0.7330383f, 0.3839724f);
        (this.Shape12 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 7, 3);
        this.Shape12.func_78793_a(-4.0f, 19.0f, 4.0f);
        this.Shape12.func_78787_b(128, 128);
        this.Shape12.field_78809_i = true;
        this.setRotation(this.Shape12, -0.3316126f, -0.7330383f, 0.2268928f);
        (this.Shape13 = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 7, 3);
        this.Shape13.func_78793_a(5.0f, 18.0f, -7.0f);
        this.Shape13.func_78787_b(128, 128);
        this.Shape13.field_78809_i = true;
        this.setRotation(this.Shape13, 0.1396263f, -0.7330383f, 0.0349066f);
        (this.Shape14 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape14.func_78793_a(-4.0f, 14.0f, 4.0f);
        this.Shape14.func_78787_b(128, 128);
        this.Shape14.field_78809_i = true;
        this.setRotation(this.Shape14, -3.141593f, -0.9599311f, -0.7504916f);
        (this.Shape15 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape15.func_78793_a(4.0f, 23.0f, 6.0f);
        this.Shape15.func_78787_b(128, 128);
        this.Shape15.field_78809_i = true;
        this.setRotation(this.Shape15, -2.844887f, -1.099557f, -0.7853982f);
        (this.Shape16 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape16.func_78793_a(-3.0f, 19.0f, 4.0f);
        this.Shape16.func_78787_b(128, 128);
        this.Shape16.field_78809_i = true;
        this.setRotation(this.Shape16, -2.740167f, -0.9250245f, -0.2617994f);
        (this.Shape17 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape17.func_78793_a(-7.0f, 19.0f, -6.0f);
        this.Shape17.func_78787_b(128, 128);
        this.Shape17.field_78809_i = true;
        this.setRotation(this.Shape17, -2.408554f, -1.047198f, -0.5585054f);
        (this.Shape18 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape18.func_78793_a(-6.0f, 22.0f, 0.0f);
        this.Shape18.func_78787_b(128, 128);
        this.Shape18.field_78809_i = true;
        this.setRotation(this.Shape18, -2.722714f, -1.064651f, -0.7330383f);
        (this.Shape19 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape19.func_78793_a(4.0f, 17.0f, 0.0f);
        this.Shape19.func_78787_b(128, 128);
        this.Shape19.field_78809_i = true;
        this.setRotation(this.Shape19, -0.9250245f, -0.8552113f, 0.4886922f);
        (this.Shape20 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 3, 3, 3);
        this.Shape20.func_78793_a(6.0f, 15.0f, 7.0f);
        this.Shape20.func_78787_b(128, 128);
        this.Shape20.field_78809_i = true;
        this.setRotation(this.Shape20, -0.9250245f, -0.8726646f, 0.9773844f);
        (this.Shape21 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Shape21.func_78793_a(6.0f, 18.0f, -5.0f);
        this.Shape21.func_78787_b(128, 128);
        this.Shape21.field_78809_i = true;
        this.setRotation(this.Shape21, -0.715585f, -0.9599311f, 0.9250245f);
        (this.Shape22 = new ModelRenderer((ModelBase)this, 18, 0)).func_78789_a(0.0f, 0.0f, 0.0f, 2, 2, 2);
        this.Shape22.func_78793_a(-4.0f, 19.0f, 6.0f);
        this.Shape22.func_78787_b(128, 128);
        this.Shape22.field_78809_i = true;
        this.setRotation(this.Shape22, -0.715585f, -0.9599311f, 0.9250245f);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
        this.Shape1.func_78785_a(f5);
        this.Shape2.func_78785_a(f5);
        this.Shape3.func_78785_a(f5);
        this.Shape4.func_78785_a(f5);
        this.Shape5.func_78785_a(f5);
        this.Shape6.func_78785_a(f5);
        this.Shape7.func_78785_a(f5);
        this.Shape8.func_78785_a(f5);
        this.Shape9.func_78785_a(f5);
        this.Shape10.func_78785_a(f5);
        this.Shape11.func_78785_a(f5);
        this.Shape12.func_78785_a(f5);
        this.Shape13.func_78785_a(f5);
        this.Shape14.func_78785_a(f5);
        this.Shape15.func_78785_a(f5);
        this.Shape16.func_78785_a(f5);
        this.Shape17.func_78785_a(f5);
        this.Shape18.func_78785_a(f5);
        this.Shape19.func_78785_a(f5);
        this.Shape20.func_78785_a(f5);
        this.Shape21.func_78785_a(f5);
        this.Shape22.func_78785_a(f5);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float f, final float f1, final float f2, final float f3, final float f4, final float f5, final Entity par7Entity) {
        super.func_78087_a(f, f1, f2, f3, f4, f5, par7Entity);
    }
    
    public void renderModel(final float f5) {
        this.Shape1.func_78785_a(f5);
        this.Shape2.func_78785_a(f5);
        this.Shape3.func_78785_a(f5);
        this.Shape4.func_78785_a(f5);
        this.Shape5.func_78785_a(f5);
        this.Shape6.func_78785_a(f5);
        this.Shape7.func_78785_a(f5);
        this.Shape8.func_78785_a(f5);
        this.Shape9.func_78785_a(f5);
        this.Shape10.func_78785_a(f5);
        this.Shape11.func_78785_a(f5);
        this.Shape12.func_78785_a(f5);
        this.Shape13.func_78785_a(f5);
        this.Shape14.func_78785_a(f5);
        this.Shape15.func_78785_a(f5);
        this.Shape16.func_78785_a(f5);
        this.Shape17.func_78785_a(f5);
        this.Shape18.func_78785_a(f5);
        this.Shape19.func_78785_a(f5);
        this.Shape20.func_78785_a(f5);
        this.Shape21.func_78785_a(f5);
        this.Shape22.func_78785_a(f5);
    }
}
