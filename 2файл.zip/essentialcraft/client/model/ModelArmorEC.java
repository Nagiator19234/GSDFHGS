package essentialcraft.client.model;

import net.minecraft.client.model.*;
import net.minecraft.entity.*;

public class ModelArmorEC extends ModelBiped
{
    ModelRenderer bodyCross;
    ModelRenderer bodyPlate;
    ModelRenderer bodyPlateb;
    ModelRenderer bodyPlatel;
    ModelRenderer bodyPlater;
    ModelRenderer bodyCross1;
    ModelRenderer lal;
    ModelRenderer lap2;
    ModelRenderer lap1;
    ModelRenderer lap;
    ModelRenderer rap1;
    ModelRenderer rap2;
    ModelRenderer rap;
    ModelRenderer helml;
    ModelRenderer helmt;
    ModelRenderer helms;
    
    public ModelArmorEC(final float f) {
        super(f, 0.0f, 128, 64);
        this.field_78090_t = 128;
        this.field_78089_u = 64;
        (this.bodyCross = new ModelRenderer((ModelBase)this, 10, 32)).func_78789_a(-4.0f, 0.0f, -2.1f, 1, 11, 1);
        this.bodyCross.func_78793_a(0.0f, 0.0f, -1.0f);
        this.bodyCross.func_78787_b(128, 64);
        this.bodyCross.field_78809_i = true;
        this.field_78115_e.func_78792_a(this.bodyCross);
        this.setRotation(this.bodyCross, 0.0f, 0.0f, -0.6108652f);
        (this.bodyPlate = new ModelRenderer((ModelBase)this, 14, 39)).func_78789_a(-3.0f, 2.0f, 1.0f, 6, 3, 1);
        this.bodyPlate.func_78793_a(0.0f, 0.0f, 1.0f);
        this.bodyPlate.func_78787_b(128, 64);
        this.bodyPlate.field_78809_i = true;
        this.setRotation(this.bodyPlate, 0.1919862f, 0.0f, 0.0f);
        this.field_78115_e.func_78792_a(this.bodyPlate);
        (this.bodyPlateb = new ModelRenderer((ModelBase)this, 14, 39)).func_78789_a(-3.0f, 5.0f, 3.0f, 6, 3, 1);
        this.bodyPlateb.func_78793_a(0.0f, 0.0f, 1.0f);
        this.bodyPlateb.func_78787_b(128, 64);
        this.bodyPlateb.field_78809_i = true;
        this.setRotation(this.bodyPlateb, -0.1919862f, 0.0f, 0.0f);
        this.field_78115_e.func_78792_a(this.bodyPlateb);
        (this.bodyPlatel = new ModelRenderer((ModelBase)this, 14, 32)).func_78789_a(-3.0f, 2.0f, 2.0f, 3, 6, 1);
        this.bodyPlatel.func_78793_a(0.0f, 0.0f, 1.0f);
        this.bodyPlatel.func_78787_b(128, 64);
        this.bodyPlatel.field_78809_i = true;
        this.setRotation(this.bodyPlatel, 0.0f, -0.1919862f, 0.0f);
        this.field_78115_e.func_78792_a(this.bodyPlatel);
        (this.bodyPlater = new ModelRenderer((ModelBase)this, 14, 32)).func_78789_a(0.0f, 2.0f, 2.0f, 3, 6, 1);
        this.bodyPlater.func_78793_a(0.0f, 0.0f, 1.0f);
        this.bodyPlater.func_78787_b(128, 64);
        this.bodyPlater.field_78809_i = true;
        this.setRotation(this.bodyPlater, 0.0f, 0.1919862f, 0.0f);
        this.field_78115_e.func_78792_a(this.bodyPlater);
        (this.bodyCross1 = new ModelRenderer((ModelBase)this, 10, 32)).func_78789_a(3.0f, 0.0f, -2.1f, 1, 11, 1);
        this.bodyCross1.func_78793_a(0.0f, 0.0f, -1.0f);
        this.bodyCross1.func_78787_b(128, 64);
        this.bodyCross1.field_78809_i = true;
        this.setRotation(this.bodyCross1, 0.0f, 0.0f, 0.6108652f);
        this.field_78115_e.func_78792_a(this.bodyCross1);
        (this.lal = new ModelRenderer((ModelBase)this, 0, 40)).func_78789_a(-1.233333f, -0.8666667f, -2.633333f, 1, 10, 1);
        this.lal.func_78793_a(0.0f, 0.0f, -1.25f);
        this.lal.func_78787_b(128, 64);
        this.lal.field_78809_i = true;
        this.setRotation(this.lal, 0.1047198f, -0.7853982f, -0.1047198f);
        this.field_178724_i.func_78792_a(this.lal);
        (this.lap2 = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(-2.0f, 5.0f, -2.0f, 1, 4, 4);
        this.lap2.func_78793_a(5.0f, 0.0f, 0.0f);
        this.lap2.func_78787_b(128, 64);
        this.lap2.field_78809_i = true;
        this.setRotation(this.lap2, 0.0f, 0.0f, -0.0872665f);
        this.field_178724_i.func_78792_a(this.lap2);
        (this.lap1 = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(-3.5f, 1.0f, -2.0f, 1, 4, 4);
        this.lap1.func_78793_a(6.75f, 0.0f, 0.0f);
        this.lap1.func_78787_b(128, 64);
        this.lap1.field_78809_i = true;
        this.setRotation(this.lap1, 0.0f, 0.0f, -0.0872665f);
        this.field_178724_i.func_78792_a(this.lap1);
        (this.lap = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(-4.0f, -2.0f, -2.0f, 1, 4, 4);
        this.lap.func_78793_a(7.5f, 0.0f, 0.0f);
        this.lap.func_78787_b(128, 64);
        this.lap.field_78809_i = true;
        this.setRotation(this.lap, 0.0f, 0.0f, -0.0872665f);
        this.field_178724_i.func_78792_a(this.lap);
        (this.rap1 = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(2.5f, 1.0f, -2.0f, 1, 4, 4);
        this.rap1.func_78793_a(-6.75f, 0.0f, 0.0f);
        this.rap1.func_78787_b(128, 64);
        this.rap1.field_78809_i = true;
        this.setRotation(this.rap1, 0.0f, 0.0f, 0.0872665f);
        this.field_178723_h.func_78792_a(this.rap1);
        (this.rap2 = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(2.0f, 5.0f, -2.0f, 1, 4, 4);
        this.rap2.func_78793_a(-6.0f, 0.0f, 0.0f);
        this.rap2.func_78787_b(128, 64);
        this.rap2.field_78809_i = true;
        this.setRotation(this.rap2, 0.0f, 0.0f, 0.0872665f);
        this.field_178723_h.func_78792_a(this.rap2);
        (this.rap = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(3.0f, -2.0f, -2.0f, 1, 4, 4);
        this.rap.func_78793_a(-7.5f, 0.0f, 0.0f);
        this.rap.func_78787_b(128, 64);
        this.rap.field_78809_i = true;
        this.setRotation(this.rap, 0.0f, 0.0f, 0.0872665f);
        this.field_178723_h.func_78792_a(this.rap);
        (this.helml = new ModelRenderer((ModelBase)this, 0, 40)).func_78789_a(-2.5f, -1.0f, -1.5f, 1, 10, 1);
        this.helml.func_78793_a(0.0f, 0.0f, -1.25f);
        this.helml.func_78787_b(128, 64);
        this.helml.field_78809_i = true;
        this.setRotation(this.helml, 0.122173f, -0.7853982f, -0.1047198f);
        this.field_178723_h.func_78792_a(this.helml);
        (this.helmt = new ModelRenderer((ModelBase)this, 0, 52)).func_78789_a(-5.0f, -9.0f, -5.0f, 10, 1, 10);
        this.helmt.func_78793_a(0.0f, 0.0f, 0.0f);
        this.helmt.func_78787_b(128, 64);
        this.helmt.field_78809_i = true;
        this.setRotation(this.helmt, 0.0f, 0.0f, 0.0f);
        this.field_78116_c.func_78792_a(this.helmt);
        (this.helms = new ModelRenderer((ModelBase)this, 40, 52)).func_78789_a(-5.0f, -5.0f, -1.0f, 10, 1, 10);
        this.helms.func_78793_a(0.0f, 0.0f, 0.1f);
        this.helms.func_78787_b(128, 64);
        this.helms.field_78809_i = true;
        this.setRotation(this.helms, 1.570796f, 0.0f, 0.0f);
        this.field_78116_c.func_78792_a(this.helms);
    }
    
    public void render(final float f5) {
        this.bodyCross.func_78785_a(f5);
        this.bodyPlate.func_78785_a(f5);
        this.bodyPlateb.func_78785_a(f5);
        this.bodyPlatel.func_78785_a(f5);
        this.bodyPlater.func_78785_a(f5);
        this.bodyCross1.func_78785_a(f5);
        this.lal.func_78785_a(f5);
        this.lap2.func_78785_a(f5);
        this.lap1.func_78785_a(f5);
        this.lap.func_78785_a(f5);
        this.rap1.func_78785_a(f5);
        this.rap2.func_78785_a(f5);
        this.rap.func_78785_a(f5);
        this.helml.func_78785_a(f5);
        this.helmt.func_78785_a(f5);
        this.helms.func_78785_a(f5);
    }
    
    public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
        this.func_78087_a(f, f1, f2, f3, f4, f5, entity);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
}
