package essentialcraft.client.render.item;

import codechicken.lib.render.item.*;
import essentialcraft.client.model.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import net.minecraft.nbt.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import java.util.*;
import com.google.common.collect.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.common.model.*;
import codechicken.lib.util.*;

public class RenderElementalCrystalAsItem implements IItemRenderer
{
    public static final ResourceLocation textures;
    public static final ResourceLocation neutral;
    public static final ResourceLocation fire;
    public static final ResourceLocation water;
    public static final ResourceLocation earth;
    public static final ResourceLocation air;
    public static final ModelElementalCrystal crystal;
    
    public void renderItem(final ItemStack item, final ItemCameraTransforms.TransformType type) {
        final NBTTagCompound tag = MiscUtils.getStackTag(item);
        float size = 100.0f;
        float fireF = 0.0f;
        float waterF = 0.0f;
        float earthF = 0.0f;
        float airF = 0.0f;
        if (tag.func_74764_b("size")) {
            size = tag.func_74760_g("size");
        }
        if (tag.func_74764_b("fire")) {
            fireF = tag.func_74760_g("fire");
        }
        if (tag.func_74764_b("water")) {
            waterF = tag.func_74760_g("water");
        }
        if (tag.func_74764_b("earth")) {
            earthF = tag.func_74760_g("earth");
        }
        if (tag.func_74764_b("air")) {
            airF = tag.func_74760_g("air");
        }
        GlStateManager.func_179094_E();
        final float scale = MathUtils.getPercentage((int)size, 100) / 100.0f;
        GlStateManager.func_179109_b(0.5f, 1.7f - (1.0f - scale) * 1.4f, 0.5f);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderElementalCrystalAsItem.textures);
        GlStateManager.func_179140_f();
        GlStateManager.func_179129_p();
        GlStateManager.func_179084_k();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.5f);
        GlStateManager.func_179147_l();
        OpenGlHelper.func_148821_a(770, 771, 1, 0);
        RenderElementalCrystalAsItem.crystal.renderModel(0.0625f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderElementalCrystalAsItem.fire);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, fireF / 100.0f);
        RenderElementalCrystalAsItem.crystal.renderModel(0.0625f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderElementalCrystalAsItem.water);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, waterF / 100.0f);
        RenderElementalCrystalAsItem.crystal.renderModel(0.0625f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderElementalCrystalAsItem.earth);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, earthF / 100.0f);
        RenderElementalCrystalAsItem.crystal.renderModel(0.0625f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderElementalCrystalAsItem.air);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, airF / 100.0f);
        RenderElementalCrystalAsItem.crystal.renderModel(0.0625f);
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        return (List<BakedQuad>)ImmutableList.of();
    }
    
    public boolean func_177555_b() {
        return false;
    }
    
    public boolean func_177556_c() {
        return false;
    }
    
    public boolean func_188618_c() {
        return true;
    }
    
    public TextureAtlasSprite func_177554_e() {
        return Minecraft.func_71410_x().func_147117_R().func_110572_b("minecraft:blocks/glass");
    }
    
    public ItemCameraTransforms func_177552_f() {
        return ItemCameraTransforms.field_178357_a;
    }
    
    public ItemOverrideList func_188617_f() {
        return ItemOverrideList.field_188022_a;
    }
    
    public IModelState getTransforms() {
        return (IModelState)TransformUtils.DEFAULT_BLOCK;
    }
    
    static {
        textures = new ResourceLocation("essentialcraft:textures/models/MCrystalTex.png");
        neutral = new ResourceLocation("essentialcraft:textures/models/MCrystalTex.png");
        fire = new ResourceLocation("essentialcraft:textures/models/FCrystalTex.png");
        water = new ResourceLocation("essentialcraft:textures/models/WCrystalTex.png");
        earth = new ResourceLocation("essentialcraft:textures/models/ECrystalTex.png");
        air = new ResourceLocation("essentialcraft:textures/models/ACrystalTex.png");
        crystal = new ModelElementalCrystal();
    }
}
