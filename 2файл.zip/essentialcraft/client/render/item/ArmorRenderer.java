package essentialcraft.client.render.item;

import codechicken.lib.render.item.*;
import essentialcraft.client.model.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.inventory.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import net.minecraft.client.model.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import java.util.*;
import com.google.common.collect.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.common.model.*;
import codechicken.lib.util.*;

public class ArmorRenderer implements IItemRenderer
{
    public static final ModelArmorEC theModel;
    
    public void renderItem(final ItemStack item, final ItemCameraTransforms.TransformType type) {
        if (item.func_77973_b() instanceof ItemArmorEC) {
            final ItemArmorEC armor = (ItemArmorEC)item.func_77973_b();
            final EntityEquipmentSlot atype = armor.field_77881_a;
            final String texture = armor.getArmorTexture(item, null, atype, null);
            final int index = texture.indexOf(":");
            if (index != -1) {
                final String modName = texture.substring(0, index);
                final String tName = texture.substring(index + 1);
                DrawUtils.bindTexture(modName, tName);
                final ModelBiped modelbiped = ArmorRenderer.theModel;
                modelbiped.field_78116_c.field_78806_j = (atype == EntityEquipmentSlot.HEAD);
                modelbiped.field_178720_f.field_78806_j = (atype == EntityEquipmentSlot.HEAD);
                modelbiped.field_78115_e.field_78806_j = (atype == EntityEquipmentSlot.CHEST || atype == EntityEquipmentSlot.LEGS);
                modelbiped.field_178723_h.field_78806_j = (atype == EntityEquipmentSlot.CHEST);
                modelbiped.field_178724_i.field_78806_j = (atype == EntityEquipmentSlot.CHEST);
                modelbiped.field_178721_j.field_78806_j = (atype == EntityEquipmentSlot.LEGS || atype == EntityEquipmentSlot.FEET);
                modelbiped.field_178722_k.field_78806_j = (atype == EntityEquipmentSlot.LEGS || atype == EntityEquipmentSlot.FEET);
                if (atype == EntityEquipmentSlot.HEAD) {
                    GlStateManager.func_179109_b(0.5f, 1.7f, 0.5f);
                }
                if (atype == EntityEquipmentSlot.CHEST) {
                    GlStateManager.func_179109_b(0.5f, 2.5f, 0.5f);
                }
                if (atype == EntityEquipmentSlot.LEGS) {
                    GlStateManager.func_179109_b(0.5f, 3.2f, 0.5f);
                }
                if (atype == EntityEquipmentSlot.FEET) {
                    GlStateManager.func_179109_b(0.5f, 3.2f, 0.5f);
                }
                GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
                modelbiped.func_78088_a((Entity)Minecraft.func_71410_x().field_71439_g, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
            }
        }
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        return (List<BakedQuad>)ImmutableList.of();
    }
    
    public boolean func_177555_b() {
        return false;
    }
    
    public boolean func_177556_c() {
        return false;
    }
    
    public boolean func_188618_c() {
        return true;
    }
    
    public TextureAtlasSprite func_177554_e() {
        return null;
    }
    
    public ItemCameraTransforms func_177552_f() {
        return ItemCameraTransforms.field_178357_a;
    }
    
    public ItemOverrideList func_188617_f() {
        return ItemOverrideList.field_188022_a;
    }
    
    public IModelState getTransforms() {
        return (IModelState)TransformUtils.DEFAULT_BLOCK;
    }
    
    static {
        theModel = new ModelArmorEC(1.0f);
    }
}
