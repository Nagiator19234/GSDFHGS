package essentialcraft.client.render.item;

import codechicken.lib.render.item.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import essentialcraft.client.render.tile.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import java.util.*;
import com.google.common.collect.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.common.model.*;
import codechicken.lib.util.*;

public class RenderEnderGeneratorAsItem implements IItemRenderer
{
    public void renderItem(final ItemStack paramItemStack, final ItemCameraTransforms.TransformType type) {
        GlStateManager.func_179094_E();
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderEnderGenerator.textures);
        RenderEnderGenerator.model.renderAll();
        GlStateManager.func_179121_F();
    }
    
    public List<BakedQuad> func_188616_a(final IBlockState state, final EnumFacing side, final long rand) {
        return (List<BakedQuad>)ImmutableList.of();
    }
    
    public boolean func_177555_b() {
        return false;
    }
    
    public boolean func_177556_c() {
        return false;
    }
    
    public boolean func_188618_c() {
        return true;
    }
    
    public TextureAtlasSprite func_177554_e() {
        return Minecraft.func_71410_x().func_147117_R().func_110572_b("essentialcraft:blocks/magicplatingblock");
    }
    
    public ItemCameraTransforms func_177552_f() {
        return ItemCameraTransforms.field_178357_a;
    }
    
    public ItemOverrideList func_188617_f() {
        return ItemOverrideList.field_188022_a;
    }
    
    public IModelState getTransforms() {
        return (IModelState)TransformUtils.DEFAULT_BLOCK;
    }
}
