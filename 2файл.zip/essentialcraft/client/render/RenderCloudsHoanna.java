package essentialcraft.client.render;

import net.minecraftforge.client.*;
import net.minecraft.util.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.renderer.*;

public class RenderCloudsHoanna extends IRenderHandler
{
    private static final ResourceLocation locationCloudsPng;
    private int cloudTickCounter;
    
    public void render(final float partialTicks, final WorldClient world, final Minecraft mc) {
        if (world.field_73012_v.nextInt(10) == 0) {
            ++this.cloudTickCounter;
        }
        for (int layer = 0; layer < 3; ++layer) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179129_p();
            final float f1 = (float)(mc.func_175606_aa().field_70137_T + (mc.func_175606_aa().field_70163_u - mc.func_175606_aa().field_70137_T) * partialTicks);
            final Tessellator tessellator = Tessellator.func_178181_a();
            final BufferBuilder BufferBuilder = tessellator.func_178180_c();
            final float f2 = 12.0f;
            final float f3 = 4.0f;
            final double d0 = this.cloudTickCounter + partialTicks;
            double d2 = (mc.func_175606_aa().field_70169_q + (mc.func_175606_aa().field_70165_t - mc.func_175606_aa().field_70169_q) * partialTicks + d0 * layer * layer * 0.03) / f2;
            double d3 = (mc.func_175606_aa().field_70166_s + (mc.func_175606_aa().field_70161_v - mc.func_175606_aa().field_70166_s) * partialTicks) / f2 * layer * layer + 0.33;
            final float f4 = world.field_73011_w.func_76571_f() - f1 + 0.33f + layer * 36;
            final int i = MathHelper.func_76128_c(d2 / 2048.0);
            final int j = MathHelper.func_76128_c(d3 / 2048.0);
            d2 -= i * 2048;
            d3 -= j * 2048;
            mc.field_71446_o.func_110577_a(RenderCloudsHoanna.locationCloudsPng);
            GlStateManager.func_179147_l();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            Vec3d vec3d = new Vec3d((double)(1.0f * (layer + 1) / 3.0f), (double)(1.0f * (layer + 1) / 3.0f), (double)(1.0f * (layer + 1) / 3.0f));
            if (world.func_72896_J()) {
                vec3d = new Vec3d(0.3, 0.3, 0.3);
            }
            if (world.func_72896_J() && world.func_72911_I()) {
                vec3d = new Vec3d(0.1, 0.1, 0.1);
            }
            float f5 = (float)vec3d.field_72450_a;
            float f6 = (float)vec3d.field_72448_b;
            float f7 = (float)vec3d.field_72449_c;
            if (mc.field_71474_y.field_74337_g) {
                final float f8 = (f5 * 30.0f + f6 * 59.0f + f7 * 11.0f) / 100.0f;
                final float f9 = (f5 * 30.0f + f6 * 70.0f) / 100.0f;
                final float f10 = (f5 * 30.0f + f7 * 70.0f) / 100.0f;
                f5 = f8;
                f6 = f9;
                f7 = f10;
            }
            float f8 = (float)(d2 * 0.0);
            float f9 = (float)(d3 * 0.0);
            final float f10 = 0.00390625f;
            f8 = MathHelper.func_76128_c(d2) * f10;
            f9 = MathHelper.func_76128_c(d3) * f10;
            final float f11 = (float)(d2 - MathHelper.func_76128_c(d2));
            final float f12 = (float)(d3 - MathHelper.func_76128_c(d3));
            final byte b0 = 8;
            final byte b2 = 4;
            final float f13 = 9.765625E-4f;
            GlStateManager.func_179152_a(f2, 1.0f, f2);
            for (int k = 0; k < 2; ++k) {
                if (k == 0) {
                    GlStateManager.func_179135_a(false, false, false, false);
                }
                else if (mc.field_71474_y.field_74337_g) {
                    if (EntityRenderer.field_78515_b == 0) {
                        GlStateManager.func_179135_a(false, true, true, true);
                    }
                    else {
                        GlStateManager.func_179135_a(true, false, false, true);
                    }
                }
                else {
                    GlStateManager.func_179135_a(true, true, true, true);
                }
                for (int l = -b2 + 1; l <= b2; ++l) {
                    for (int i2 = -b2 + 1; i2 <= b2; ++i2) {
                        BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181712_l);
                        final float f14 = (float)(l * b0);
                        final float f15 = (float)(i2 * b0);
                        final float f16 = f14 - f11;
                        final float f17 = f15 - f12;
                        if (f4 > -f3 - 1.0f) {
                            BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + b0)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.7f, f6 * 0.7f, f7 * 0.7f, 0.8f).func_181663_c(0.0f, -1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + 0.0f), (double)(f17 + b0)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.7f, f6 * 0.7f, f7 * 0.7f, 0.8f).func_181663_c(0.0f, -1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + 0.0f), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.7f, f6 * 0.7f, f7 * 0.7f, 0.8f).func_181663_c(0.0f, -1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.7f, f6 * 0.7f, f7 * 0.7f, 0.8f).func_181663_c(0.0f, -1.0f, 0.0f).func_181675_d();
                        }
                        if (f4 <= f3 + 1.0f) {
                            BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + f3 - f13), (double)(f17 + b0)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5, f6, f7, 0.8f).func_181663_c(0.0f, 1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + f3 - f13), (double)(f17 + b0)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5, f6, f7, 0.8f).func_181663_c(0.0f, 1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + f3 - f13), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5, f6, f7, 0.8f).func_181663_c(0.0f, 1.0f, 0.0f).func_181675_d();
                            BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + f3 - f13), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5, f6, f7, 0.8f).func_181663_c(0.0f, 1.0f, 0.0f).func_181675_d();
                        }
                        if (l > -1) {
                            for (int j2 = 0; j2 < b0; ++j2) {
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + b0)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(-1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 0.0f), (double)(f4 + f3), (double)(f17 + b0)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(-1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 0.0f), (double)(f4 + f3), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(-1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(-1.0f, 0.0f, 0.0f).func_181675_d();
                            }
                        }
                        if (l <= 1) {
                            for (int j2 = 0; j2 < b0; ++j2) {
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 1.0f - f13), (double)(f4 + 0.0f), (double)(f17 + b0)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 1.0f - f13), (double)(f4 + f3), (double)(f17 + b0)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + b0) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 1.0f - f13), (double)(f4 + f3), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(1.0f, 0.0f, 0.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + j2 + 1.0f - f13), (double)(f4 + 0.0f), (double)(f17 + 0.0f)).func_187315_a((double)((f14 + j2 + 0.5f) * f10 + f8), (double)((f15 + 0.0f) * f10 + f9)).func_181666_a(f5 * 0.9f, f6 * 0.9f, f7 * 0.9f, 0.8f).func_181663_c(1.0f, 0.0f, 0.0f).func_181675_d();
                            }
                        }
                        if (i2 > -1) {
                            for (int j2 = 0; j2 < b0; ++j2) {
                                BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + f3), (double)(f17 + j2 + 0.0f)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, -1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + f3), (double)(f17 + j2 + 0.0f)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, -1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + 0.0f), (double)(f17 + j2 + 0.0f)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, -1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + j2 + 0.0f)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, -1.0f).func_181675_d();
                            }
                        }
                        if (i2 <= 1) {
                            for (int j2 = 0; j2 < b0; ++j2) {
                                BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + f3), (double)(f17 + j2 + 1.0f - f13)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, 1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + f3), (double)(f17 + j2 + 1.0f - f13)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, 1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + b0), (double)(f4 + 0.0f), (double)(f17 + j2 + 1.0f - f13)).func_187315_a((double)((f14 + b0) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, 1.0f).func_181675_d();
                                BufferBuilder.func_181662_b((double)(f16 + 0.0f), (double)(f4 + 0.0f), (double)(f17 + j2 + 1.0f - f13)).func_187315_a((double)((f14 + 0.0f) * f10 + f8), (double)((f15 + j2 + 0.5f) * f10 + f9)).func_181666_a(f5 * 0.8f, f6 * 0.8f, f7 * 0.8f, 0.8f).func_181663_c(0.0f, 0.0f, 1.0f).func_181675_d();
                            }
                        }
                        tessellator.func_78381_a();
                    }
                }
            }
            GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.func_179084_k();
            GlStateManager.func_179089_o();
            GlStateManager.func_179121_F();
        }
    }
    
    static {
        locationCloudsPng = new ResourceLocation("textures/environment/clouds.png");
    }
}
