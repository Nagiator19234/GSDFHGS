package essentialcraft.client.render;

import net.minecraftforge.client.*;
import net.minecraft.util.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.*;

public class RenderSkyParadox extends IRenderHandler
{
    private static final ResourceLocation locationMoonPhasesPng;
    private static final ResourceLocation locationSunPng;
    public float rotation;
    public float rotationSpeed;
    
    public RenderSkyParadox() {
        this.rotation = -90.0f;
        this.rotationSpeed = 0.01f;
    }
    
    public void render(final float partialTicks, final WorldClient world, final Minecraft mc) {
        this.rotationSpeed *= 1.007f;
        this.rotation += this.rotationSpeed;
        GlStateManager.func_179090_x();
        final Vec3d Vec3d = world.func_72833_a(mc.func_175606_aa(), partialTicks);
        final float f1 = (float)Vec3d.field_72450_a;
        final float f2 = (float)Vec3d.field_72448_b;
        final float f3 = (float)Vec3d.field_72449_c;
        GlStateManager.func_179124_c(f1, f2, f3);
        final Tessellator tessellator1 = Tessellator.func_178181_a();
        final BufferBuilder BufferBuilder = tessellator1.func_178180_c();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179127_m();
        GlStateManager.func_179124_c(f1, f2, f3);
        GlStateManager.func_179106_n();
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        OpenGlHelper.func_148821_a(770, 771, 1, 0);
        RenderHelper.func_74518_a();
        final float[] afloat = world.field_73011_w.func_76560_a(world.func_72826_c(partialTicks), partialTicks);
        if (afloat != null) {
            GlStateManager.func_179090_x();
            GlStateManager.func_179103_j(7425);
            GlStateManager.func_179094_E();
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(MathHelper.func_76126_a((float)Math.toRadians((double)System.currentTimeMillis())), 0.0f, 0.0f, 1.0f);
            GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
            final float f4 = afloat[0];
            final float f5 = afloat[1];
            final float f6 = afloat[2];
            BufferBuilder.func_181668_a(6, DefaultVertexFormats.field_181709_i);
            BufferBuilder.func_181662_b(0.0, 100.0, 0.0).func_181666_a(f4, f5, f6, afloat[3]).func_181675_d();
            for (int j = 0; j <= 16; ++j) {
                final float f7 = j * 3.1415927f * 2.0f / 16.0f;
                final float f8 = MathHelper.func_76126_a(f7);
                final float f9 = MathHelper.func_76134_b(f7);
                BufferBuilder.func_181662_b((double)(f8 * 120.0f), (double)(f9 * 120.0f), (double)(-f9 * 40.0f * afloat[3])).func_181666_a(afloat[0], afloat[1], afloat[2], 0.0f).func_181675_d();
            }
            tessellator1.func_78381_a();
            GlStateManager.func_179121_F();
            GlStateManager.func_179103_j(7424);
        }
        GlStateManager.func_179098_w();
        OpenGlHelper.func_148821_a(770, 1, 1, 0);
        GlStateManager.func_179094_E();
        final float f4 = 1.0f - world.func_72867_j(partialTicks);
        final float f5 = 0.0f;
        final float f6 = 0.0f;
        final float f10 = 0.0f;
        if (this.rotationSpeed == 0.0f) {
            this.rotationSpeed = 0.01f;
        }
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, f4);
        GlStateManager.func_179109_b(f5, f6, f10);
        GlStateManager.func_179114_b(-90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(this.rotation, 1.0f, 0.0f, 0.0f);
        float f11 = 30.0f;
        mc.field_71446_o.func_110577_a(RenderSkyParadox.locationSunPng);
        BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        BufferBuilder.func_181662_b((double)(-f11), 100.0, (double)(-f11)).func_187315_a(0.0, 0.0).func_181675_d();
        BufferBuilder.func_181662_b((double)f11, 100.0, (double)(-f11)).func_187315_a(1.0, 0.0).func_181675_d();
        BufferBuilder.func_181662_b((double)f11, 100.0, (double)f11).func_187315_a(1.0, 1.0).func_181675_d();
        BufferBuilder.func_181662_b((double)(-f11), 100.0, (double)f11).func_187315_a(0.0, 1.0).func_181675_d();
        tessellator1.func_78381_a();
        f11 = 20.0f;
        mc.field_71446_o.func_110577_a(RenderSkyParadox.locationMoonPhasesPng);
        final int k = world.func_72853_d();
        final int l = k % 4;
        final int i1 = k / 4 % 2;
        final float f12 = (l + 0) / 4.0f;
        final float f13 = (i1 + 0) / 2.0f;
        final float f14 = (l + 1) / 4.0f;
        final float f15 = (i1 + 1) / 2.0f;
        BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        BufferBuilder.func_181662_b((double)(-f11), -100.0, (double)f11).func_187315_a((double)f14, (double)f15).func_181675_d();
        BufferBuilder.func_181662_b((double)f11, -100.0, (double)f11).func_187315_a((double)f12, (double)f15).func_181675_d();
        BufferBuilder.func_181662_b((double)f11, -100.0, (double)(-f11)).func_187315_a((double)f12, (double)f13).func_181675_d();
        BufferBuilder.func_181662_b((double)(-f11), -100.0, (double)(-f11)).func_187315_a((double)f14, (double)f13).func_181675_d();
        tessellator1.func_78381_a();
        GlStateManager.func_179090_x();
        final float f16 = world.func_72880_h(partialTicks) * f4;
        if (f16 > 0.0f) {
            GlStateManager.func_179131_c(f16, f16, f16, f16);
        }
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179127_m();
        GlStateManager.func_179121_F();
        GlStateManager.func_179090_x();
        GlStateManager.func_179124_c(0.0f, 0.0f, 0.0f);
        final double d0 = mc.field_71439_g.func_174824_e(partialTicks).field_72448_b - world.func_72919_O();
        if (d0 < 0.0) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.0f, 12.0f, 0.0f);
            GlStateManager.func_179121_F();
            final float f17 = -(float)(d0 + 65.0);
            BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
            BufferBuilder.func_181662_b(-1.0, (double)f17, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f17, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f17, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f17, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f17, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f17, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f17, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f17, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            tessellator1.func_78381_a();
        }
        if (world.field_73011_w.func_76561_g()) {
            GlStateManager.func_179124_c(f1 * 0.2f + 0.04f, f2 * 0.2f + 0.04f, f3 * 0.6f + 0.1f);
        }
        else {
            GlStateManager.func_179124_c(f1, f2, f3);
        }
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(0.0f, -(float)(d0 - 16.0), 0.0f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179098_w();
        GlStateManager.func_179132_a(true);
    }
    
    static {
        locationMoonPhasesPng = new ResourceLocation("textures/environment/moon_phases.png");
        locationSunPng = new ResourceLocation("textures/environment/sun.png");
    }
}
