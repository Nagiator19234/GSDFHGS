package essentialcraft.client.render;

import net.minecraft.client.*;
import net.minecraftforge.client.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.player.*;
import baubles.api.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.item.*;
import org.lwjgl.opengl.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.common.gameevent.*;
import essentialcraft.common.mod.*;
import java.util.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import java.lang.reflect.*;
import essentialcraft.proxy.*;
import net.minecraft.client.audio.*;
import essentialcraft.common.registry.*;
import net.minecraft.potion.*;
import net.minecraft.init.*;
import essentialcraft.common.tile.*;
import essentialcraft.api.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraftforge.client.event.*;
import essentialcraft.common.block.*;
import net.minecraft.client.renderer.block.model.*;
import essentialcraft.client.model.*;
import net.minecraftforge.fml.common.*;
import essentialcraft.client.render.item.*;
import essentialcraft.common.item.*;
import org.apache.commons.lang3.tuple.*;
import DummyCore.Client.*;

public class RenderHandlerEC
{
    public static final ResourceLocation iconsEC;
    public static final ResourceLocation whitebox;
    public static final Minecraft mc;
    public static boolean isParadoxActive;
    public static int currentParadoxTicks;
    public static int paradoxID;
    public static Coord3D explosion;
    public static IRenderHandler skyRenderer;
    public static boolean isMouseInverted;
    public static boolean isSprintKeyDown;
    public static double renderPartialTicksCheck;
    public static boolean isNightVisionKeyDown;
    public static boolean isNightVisionActive;
    public static final IModelCustom board;
    public static final ResourceLocation boardTextures;
    public static HashMap<IInventory, HashMap<Integer, List<EnumFacing>>> slotsTable;
    ResourceLocation loc;
    
    public RenderHandlerEC() {
        this.loc = new ResourceLocation("essentialcraft", "textures/hud/sniper_scope.png");
    }
    
    public void renderParadox() {
        final Minecraft mc = Minecraft.func_71410_x();
        final ScaledResolution scaledresolution = new ScaledResolution(mc);
        final int k = scaledresolution.func_78326_a();
        final int l = scaledresolution.func_78328_b();
        if (RenderHandlerEC.currentParadoxTicks >= 190) {
            renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 0.0f, 0.0f, 0.0f);
        }
        if (RenderHandlerEC.paradoxID == 0) {
            if (RenderHandlerEC.currentParadoxTicks == 199) {
                mc.field_71439_g.func_130014_f_().func_184134_a(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v, SoundEvents.field_187674_a, SoundCategory.AMBIENT, 100.0f, 0.01f, false);
            }
            if (RenderHandlerEC.currentParadoxTicks == 199) {
                MiscUtils.setShaders(5);
            }
            if (RenderHandlerEC.currentParadoxTicks <= 10) {
                MiscUtils.setShaders(-1);
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 1.0f, 1.0f, 1.0f);
            }
            if (RenderHandlerEC.currentParadoxTicks >= 10) {
                for (int i = 0; i < 20; ++i) {
                    mc.field_71441_e.func_175688_a(EnumParticleTypes.REDSTONE, mc.field_71439_g.field_70165_t + MathUtils.randomDouble(mc.field_71441_e.field_73012_v) * 16.0, mc.field_71439_g.field_70163_u + MathUtils.randomDouble(mc.field_71441_e.field_73012_v) * 16.0, mc.field_71439_g.field_70161_v + MathUtils.randomDouble(mc.field_71441_e.field_73012_v) * 16.0, -1.0, 0.0, 0.0, new int[0]);
                }
            }
        }
        if (RenderHandlerEC.paradoxID == 1) {
            if (RenderHandlerEC.currentParadoxTicks >= 190) {
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 0.0f, 0.0f, 0.0f);
            }
            if (RenderHandlerEC.currentParadoxTicks == 190) {
                MiscUtils.setShaders(16);
                final World w = (World)mc.field_71441_e;
                final WorldProvider prov = w.field_73011_w;
                if (!(prov.getSkyRenderer() instanceof RenderSkyParadox)) {
                    RenderHandlerEC.skyRenderer = prov.getSkyRenderer();
                    prov.setSkyRenderer((IRenderHandler)new RenderSkyParadox());
                }
            }
            if (RenderHandlerEC.currentParadoxTicks <= 10) {
                MiscUtils.setShaders(-1);
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 1.0f, 1.0f, 1.0f);
                final World w = (World)mc.field_71441_e;
                final WorldProvider prov = w.field_73011_w;
                prov.setSkyRenderer(RenderHandlerEC.skyRenderer);
            }
        }
        if (RenderHandlerEC.paradoxID == 2) {
            if (RenderHandlerEC.currentParadoxTicks >= 190) {
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 0.0f, 0.0f, 0.0f);
            }
            if (RenderHandlerEC.currentParadoxTicks == 190) {
                MiscUtils.setShaders(12);
            }
            if (RenderHandlerEC.currentParadoxTicks < 190 && RenderHandlerEC.currentParadoxTicks > 10) {
                if (RenderHandlerEC.explosion == null) {
                    RenderHandlerEC.explosion = new Coord3D(mc.field_71439_g.field_70165_t + MathUtils.randomDouble(mc.field_71441_e.field_73012_v) * 32.0, mc.field_71439_g.field_70163_u + 32.0, mc.field_71439_g.field_70161_v + MathUtils.randomDouble(mc.field_71441_e.field_73012_v) * 32.0);
                }
                else {
                    mc.field_71441_e.func_184134_a((double)RenderHandlerEC.explosion.x, (double)RenderHandlerEC.explosion.y, (double)RenderHandlerEC.explosion.z, SoundEvents.field_187539_bB, SoundCategory.BLOCKS, 3.0f, 0.1f, true);
                    mc.field_71441_e.func_72876_a((Entity)null, (double)RenderHandlerEC.explosion.x, (double)RenderHandlerEC.explosion.y, (double)RenderHandlerEC.explosion.z, 5.0f, false);
                    final Coord3D explosion = RenderHandlerEC.explosion;
                    explosion.y -= 0.5f;
                    if (RenderHandlerEC.explosion.y < mc.field_71439_g.field_70163_u - 10.0) {
                        RenderHandlerEC.explosion = null;
                    }
                }
            }
            if (RenderHandlerEC.currentParadoxTicks <= 10) {
                MiscUtils.setShaders(-1);
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
        if (RenderHandlerEC.paradoxID == 3) {
            if (RenderHandlerEC.currentParadoxTicks >= 190) {
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 0.0f, 0.0f, 0.0f);
            }
            if (RenderHandlerEC.currentParadoxTicks == 190) {
                MiscUtils.setShaders(8);
            }
            final EntityPlayerSP field_71439_g = mc.field_71439_g;
            field_71439_g.field_70181_x += 0.03999999910593033;
            if (RenderHandlerEC.currentParadoxTicks <= 10) {
                MiscUtils.setShaders(-1);
                renderImage(RenderHandlerEC.whitebox, k, l, 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
    }
    
    public static IInventory getInventoryFromContainer(final GuiContainer gc) {
        for (final Slot slt : gc.field_147002_h.field_75151_b) {
            if (slt != null) {
                return slt.field_75224_c;
            }
        }
        return null;
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void renderLivingSpecials(final RenderLivingEvent.Specials.Post<?> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)event.getEntity();
            if (BaublesApi.getBaublesHandler(p) != null && !BaublesApi.getBaublesHandler(p).getStackInSlot(3).func_190926_b() && BaublesApi.getBaublesHandler(p).getStackInSlot(3).func_77973_b() instanceof ItemComputerBoard && p.field_71075_bZ.field_75100_b) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.func_179114_b(p.field_70177_z - 90.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.func_179109_b(0.0f, 0.0f, 0.0f);
                GlStateManager.func_179152_a(0.8f, 0.8f, 0.8f);
                Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderHandlerEC.boardTextures);
                RenderHandlerEC.board.renderAll();
                GlStateManager.func_179121_F();
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void renderFog(final EntityViewRenderEvent.RenderFogEvent evt) {
        if (evt.getFogMode() == 0) {
            final EntityPlayerSP p = RenderHandlerEC.mc.field_71439_g;
            final ItemStack is = p.func_184614_ca();
            if (!is.func_190926_b() && is.func_77973_b() instanceof ItemOrbitalRemote) {
                final float f = 1.0f;
                final double d0 = p.field_70169_q + (p.field_70165_t - p.field_70169_q) * f;
                final double d2 = p.field_70167_r + (p.field_70163_u - p.field_70167_r) * f + p.func_70047_e();
                final double d3 = p.field_70166_s + (p.field_70161_v - p.field_70166_s) * f;
                final Vec3d lookVec = new Vec3d(d0, d2, d3);
                final float f2 = p.field_70127_C + (p.field_70125_A - p.field_70127_C);
                final float f3 = p.field_70126_B + (p.field_70177_z - p.field_70126_B);
                final float f4 = MathHelper.func_76134_b(-f3 * 0.017453292f - 3.1415927f);
                final float f5 = MathHelper.func_76126_a(-f3 * 0.017453292f - 3.1415927f);
                final float f6 = -MathHelper.func_76134_b(-f2 * 0.017453292f);
                final float f7 = MathHelper.func_76126_a(-f2 * 0.017453292f);
                final float f8 = f5 * f6;
                final float f9 = f4 * f6;
                final double d4 = 32.0;
                final Vec3d distanced = lookVec.func_72441_c(f8 * d4, f7 * d4, f9 * d4);
                final RayTraceResult mop = p.func_130014_f_().func_147447_a(lookVec, distanced, true, false, false);
                if (mop != null && mop.field_72313_a == RayTraceResult.Type.BLOCK) {
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179092_a(516, 0.1f);
                    GlStateManager.func_179106_n();
                    DrawUtils.bindTexture("minecraft", "textures/entity/beacon_beam.png");
                    GlStateManager.func_179137_b(mop.func_178782_a().func_177958_n() - TileEntityRendererDispatcher.field_147554_b, mop.func_178782_a().func_177956_o() + 1 - TileEntityRendererDispatcher.field_147555_c, mop.func_178782_a().func_177952_p() - TileEntityRendererDispatcher.field_147552_d);
                    TileEntityBeaconRenderer.func_188205_a(0.0, 0.0, 0.0, evt.getRenderPartialTicks(), 1.0, (double)p.func_130014_f_().func_82737_E(), 0, 255 - mop.func_178782_a().func_177956_o(), new float[] { 1.0f, 0.0f, 1.0f }, 0.2, 0.499);
                    GlStateManager.func_179127_m();
                    GlStateManager.func_179089_o();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179092_a(516, 0.5f);
                    GlStateManager.func_179121_F();
                }
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void renderBlockOverlays(final RenderWorldLastEvent evt) {
        final EntityPlayerSP p = RenderHandlerEC.mc.field_71439_g;
        final double doubleX = p.field_70142_S + (p.field_70165_t - p.field_70142_S) * evt.getPartialTicks();
        final double doubleY = p.field_70137_T + (p.field_70163_u - p.field_70137_T) * evt.getPartialTicks();
        final double doubleZ = p.field_70136_U + (p.field_70161_v - p.field_70136_U) * evt.getPartialTicks();
        if (ItemInventoryGem.currentlyClicked != null) {
            final Coord3D c = ItemInventoryGem.currentlyClicked;
            final float mx = c.x;
            final float my = c.y;
            final float mz = c.z;
            final double dist = p.func_70011_f(mx + 0.5, my + 0.5, mz + 0.5);
            if (dist > 24.0) {
                return;
            }
            GlStateManager.func_179094_E();
            final boolean depth = GL11.glIsEnabled(2929);
            GlStateManager.func_179097_i();
            final boolean texture = GL11.glIsEnabled(3553);
            GlStateManager.func_179090_x();
            GlStateManager.func_179118_c();
            GlStateManager.func_179147_l();
            GlStateManager.func_179112_b(770, 771);
            GL11.glColor4d(1.0, 0.0, 1.0, ItemInventoryGem.clickTicks / 100.0);
            GlStateManager.func_187441_d(3.0f);
            GlStateManager.func_179137_b(-doubleX, -doubleY, -doubleZ);
            GlStateManager.func_187447_r(1);
            GlStateManager.func_187435_e(mx, my, mz);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz);
            GlStateManager.func_187435_e(mx, my, mz);
            GlStateManager.func_187435_e(mx, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz);
            GlStateManager.func_187435_e(mx, my, mz);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx, my, mz + 1.0f);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my, mz);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz + 1.0f);
            GlStateManager.func_187435_e(mx + 1.0f, my + 1.0f, mz);
            GlStateManager.func_187437_J();
            if (depth) {
                GlStateManager.func_179126_j();
            }
            if (texture) {
                GlStateManager.func_179098_w();
            }
            GlStateManager.func_179084_k();
            GlStateManager.func_179141_d();
            GlStateManager.func_179121_F();
        }
        final ItemStack is = p.func_184614_ca();
        if (!is.func_190926_b()) {
            if (is.func_77978_p() != null && is.func_77973_b() instanceof ItemBoundGem && is.func_77978_p().func_74764_b("pos") && is.func_77978_p().func_74762_e("dim") == p.field_71093_bK) {
                final int[] coords = ItemBoundGem.getCoords(is);
                final Coord3D c2 = new Coord3D((float)coords[0], (float)coords[1], (float)coords[2]);
                final float mx2 = c2.x;
                final float my2 = c2.y;
                final float mz2 = c2.z;
                final double dist2 = p.func_70011_f(mx2 + 0.5, my2 + 0.5, mz2 + 0.5);
                if (dist2 > 24.0 || !p.func_130014_f_().func_175667_e(new BlockPos((int)mx2, (int)my2, (int)mz2))) {
                    return;
                }
                final AxisAlignedBB aabb = p.func_130014_f_().func_180495_p(new BlockPos((int)mx2, (int)my2, (int)mz2)).func_177230_c().func_180640_a(p.func_130014_f_().func_180495_p(new BlockPos((int)mx2, (int)my2, (int)mz2)), p.func_130014_f_(), new BlockPos((int)mx2, (int)my2, (int)mz2));
                GlStateManager.func_179094_E();
                final boolean depth2 = GL11.glIsEnabled(2929);
                GlStateManager.func_179097_i();
                final boolean texture2 = GL11.glIsEnabled(3553);
                GlStateManager.func_179090_x();
                GlStateManager.func_179118_c();
                GlStateManager.func_179147_l();
                GlStateManager.func_179112_b(770, 771);
                GlStateManager.func_179124_c(0.8984375f, 0.7578125f, 0.58984375f);
                GlStateManager.func_187441_d(1.0f);
                GlStateManager.func_179137_b(-doubleX, -doubleY, -doubleZ);
                GlStateManager.func_187447_r(1);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72338_b, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72338_b, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72339_c);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72340_a, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72334_f);
                GL11.glVertex3d(aabb.field_72336_d, aabb.field_72337_e, aabb.field_72339_c);
                GlStateManager.func_187437_J();
                if (depth2) {
                    GlStateManager.func_179126_j();
                }
                if (texture2) {
                    GlStateManager.func_179098_w();
                }
                GlStateManager.func_179084_k();
                GlStateManager.func_179141_d();
                GlStateManager.func_179121_F();
            }
            if (is.func_77973_b() instanceof ItemMagicalBuilder) {
                final ItemMagicalBuilder builder = (ItemMagicalBuilder)is.func_77973_b();
                if (builder.hasFirstPoint(is) && !builder.hasSecondPoint(is)) {
                    final Coord3D c2 = builder.getFirstPoint(is);
                    final AxisAlignedBB aabb2 = new AxisAlignedBB((double)c2.x, (double)c2.y, (double)c2.z, (double)(c2.x + 1.0f), (double)(c2.y + 1.0f), (double)(c2.z + 1.0f));
                    GlStateManager.func_179094_E();
                    final boolean depth3 = GL11.glIsEnabled(2929);
                    GlStateManager.func_179097_i();
                    final boolean texture3 = GL11.glIsEnabled(3553);
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179118_c();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179124_c(1.0f, 0.0f, 1.0f);
                    GlStateManager.func_187441_d(2.0f);
                    GlStateManager.func_179137_b(-doubleX, -doubleY, -doubleZ);
                    GlStateManager.func_187447_r(1);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72338_b, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72338_b, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72339_c);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72340_a, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72334_f);
                    GL11.glVertex3d(aabb2.field_72336_d, aabb2.field_72337_e, aabb2.field_72339_c);
                    GlStateManager.func_187437_J();
                    if (depth3) {
                        GlStateManager.func_179126_j();
                    }
                    if (texture3) {
                        GlStateManager.func_179098_w();
                    }
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                    GlStateManager.func_179121_F();
                }
                else if (builder.hasFirstPoint(is) && builder.hasSecondPoint(is)) {
                    final Coord3D c2 = builder.getFirstPoint(is);
                    final Coord3D c3 = builder.getSecondPoint(is);
                    final AxisAlignedBB aabb3 = new AxisAlignedBB((c3.x < c2.x) ? ((double)(c2.x + 1.0f)) : ((double)c2.x), (c3.y < c2.y) ? ((double)(c2.y + 1.0f)) : ((double)c2.y), (c3.z < c2.z) ? ((double)(c2.z + 1.0f)) : ((double)c2.z), (c3.x < c2.x) ? ((double)c3.x) : ((double)(c3.x + 1.0f)), (c3.y < c2.y) ? ((double)c3.y) : ((double)(c3.y + 1.0f)), (c3.z < c2.z) ? ((double)c3.z) : ((double)(c3.z + 1.0f)));
                    GlStateManager.func_179094_E();
                    final boolean depth4 = GL11.glIsEnabled(2929);
                    GlStateManager.func_179097_i();
                    final boolean texture4 = GL11.glIsEnabled(3553);
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179118_c();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179124_c(1.0f, 0.0f, 1.0f);
                    GlStateManager.func_187441_d(2.0f);
                    GlStateManager.func_179137_b(-doubleX, -doubleY, -doubleZ);
                    GlStateManager.func_187447_r(1);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72338_b, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72338_b, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72339_c);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72340_a, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72334_f);
                    GL11.glVertex3d(aabb3.field_72336_d, aabb3.field_72337_e, aabb3.field_72339_c);
                    GlStateManager.func_187437_J();
                    if (depth4) {
                        GlStateManager.func_179126_j();
                    }
                    if (texture4) {
                        GlStateManager.func_179098_w();
                    }
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                    GlStateManager.func_179121_F();
                }
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void clientGUIRenderTickEvent(final TickEvent.RenderTickEvent event) {
        final EntityPlayer player = EssentialCraftCore.proxy.getClientPlayer();
        if (player != null) {
            final World w = player.func_130014_f_();
            if (w != null) {
                final GuiScreen currentScreen = Minecraft.func_71410_x().field_71462_r;
                if (currentScreen != null && currentScreen instanceof GuiContainer && GuiScreen.func_146271_m()) {
                    final GuiContainer gc = (GuiContainer)currentScreen;
                    try {
                        final Class<GuiContainer> gcClass = GuiContainer.class;
                        final Field FguiLeft = gcClass.getDeclaredFields()[4];
                        final Field FguiTop = gcClass.getDeclaredFields()[5];
                        FguiLeft.setAccessible(true);
                        FguiTop.setAccessible(true);
                        final int guiLeft = FguiLeft.getInt(gc);
                        final int guiTop = FguiTop.getInt(gc);
                        final int k = guiLeft;
                        final int l = guiTop;
                        final IInventory inv = getInventoryFromContainer(gc);
                        if (inv != null && inv instanceof ISidedInventory) {
                            final ISidedInventory sided = (ISidedInventory)inv;
                            if (RenderHandlerEC.slotsTable.isEmpty() || !RenderHandlerEC.slotsTable.containsKey(inv)) {
                                RenderHandlerEC.slotsTable.clear();
                                final HashMap<Integer, List<EnumFacing>> accessibleSlots = new HashMap<Integer, List<EnumFacing>>();
                                for (int j = 0; j < 6; ++j) {
                                    final EnumFacing d = EnumFacing.func_82600_a(j);
                                    final int[] slots = sided.func_180463_a(d);
                                    if (slots != null) {
                                        for (final int slotN : slots) {
                                            if (accessibleSlots.containsKey(slotN)) {
                                                final List<EnumFacing> lst = accessibleSlots.get(slotN);
                                                if (!lst.contains(d)) {
                                                    lst.add(d);
                                                }
                                                accessibleSlots.put(slotN, lst);
                                            }
                                            else {
                                                final List<EnumFacing> lst = new ArrayList<EnumFacing>();
                                                lst.add(d);
                                                accessibleSlots.put(slotN, lst);
                                            }
                                        }
                                    }
                                }
                                RenderHandlerEC.slotsTable.put(inv, accessibleSlots);
                            }
                        }
                        for (final Slot slt : gc.field_147002_h.field_75151_b) {
                            if (slt.field_75224_c instanceof TileEntity || slt.field_75224_c instanceof InventoryBasic) {
                                GlStateManager.func_179094_E();
                                GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
                                Minecraft.func_71410_x().field_71466_p.func_78276_b("" + slt.field_75222_d, (k + slt.field_75223_e) * 2, (l + slt.field_75221_f) * 2, 0);
                                GlStateManager.func_179121_F();
                                if (slt.field_75224_c instanceof ISidedInventory && RenderHandlerEC.slotsTable.containsKey(inv)) {
                                    final HashMap<Integer, List<EnumFacing>> accessibleSlots2 = RenderHandlerEC.slotsTable.get(inv);
                                    if (accessibleSlots2.containsKey(slt.field_75222_d)) {
                                        final List<EnumFacing> lst2 = accessibleSlots2.get(slt.field_75222_d);
                                        if (lst2 != null && !lst2.isEmpty()) {
                                            final EnumFacing d2 = lst2.get((int)(w.func_72820_D() / 20L % lst2.size()));
                                            GlStateManager.func_179094_E();
                                            GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
                                            Minecraft.func_71410_x().field_71466_p.func_78276_b("" + d2, (k + slt.field_75223_e) * 2, (l + slt.field_75221_f + 12) * 2, 0);
                                            GlStateManager.func_179121_F();
                                        }
                                    }
                                }
                            }
                            GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    
    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            if (ItemInventoryGem.clickTicks > 0) {
                --ItemInventoryGem.clickTicks;
            }
            if (ItemInventoryGem.clickTicks == 0) {
                ItemInventoryGem.currentlyClicked = null;
            }
        }
        ClientProxy.playingMusic.removeIf(pair -> !Minecraft.func_71410_x().func_147118_V().func_147692_c((ISound)pair.getRight()));
        if (event.player.func_130014_f_().field_72995_K && event.phase == TickEvent.Phase.START && event.player instanceof EntityPlayerSP) {
            final EntityPlayerSP player = (EntityPlayerSP)event.player;
            if (PotionRegistry.paradox != null && RenderHandlerEC.mc.field_71439_g.func_70660_b((Potion)PotionRegistry.paradox) != null) {
                final int duration = RenderHandlerEC.mc.field_71439_g.func_70660_b((Potion)PotionRegistry.paradox).func_76459_b();
                if (duration > 100) {
                    if (duration % 100 == 0) {
                        RenderHandlerEC.mc.field_71441_e.func_184134_a(RenderHandlerEC.mc.field_71439_g.field_70165_t, RenderHandlerEC.mc.field_71439_g.field_70163_u, RenderHandlerEC.mc.field_71439_g.field_70161_v, SoundRegistry.potionHeartbeat, SoundCategory.PLAYERS, 100.0f, 1.0f, true);
                    }
                    if (RenderHandlerEC.currentParadoxTicks > 0) {
                        --RenderHandlerEC.currentParadoxTicks;
                    }
                    if (RenderHandlerEC.currentParadoxTicks == 0 && duration < 1600) {
                        RenderHandlerEC.paradoxID = -1;
                        RenderHandlerEC.isParadoxActive = false;
                        MiscUtils.setShaders(-1);
                    }
                    if (duration < 1700 && !RenderHandlerEC.isParadoxActive && player.func_130014_f_().field_73012_v.nextFloat() < 0.005f) {
                        RenderHandlerEC.paradoxID = RenderHandlerEC.mc.field_71441_e.field_73012_v.nextInt(4);
                        RenderHandlerEC.currentParadoxTicks = 200;
                        RenderHandlerEC.isParadoxActive = true;
                    }
                }
                else {
                    RenderHandlerEC.currentParadoxTicks = 0;
                    RenderHandlerEC.paradoxID = -1;
                    RenderHandlerEC.isParadoxActive = false;
                }
            }
            if (RenderHandlerEC.renderPartialTicksCheck > 0.0) {
                --RenderHandlerEC.renderPartialTicksCheck;
                if (RenderHandlerEC.renderPartialTicksCheck <= 0.0) {
                    Minecraft.func_71410_x().field_71441_e.func_184134_a(player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187604_bf, SoundCategory.PLAYERS, 1.0f, 2.0f, false);
                }
            }
            if (!ClientProxy.kbArmorVision.func_151470_d() && RenderHandlerEC.isNightVisionKeyDown) {
                RenderHandlerEC.isNightVisionKeyDown = false;
            }
            if (RenderHandlerEC.isNightVisionActive && (((ItemStack)player.field_71071_by.field_70460_b.get(3)).func_190926_b() || !(((ItemStack)player.field_71071_by.field_70460_b.get(3)).func_77973_b() instanceof ItemComputerArmor))) {
                RenderHandlerEC.isNightVisionActive = false;
                Minecraft.func_71410_x().field_71439_g.func_184589_d(MobEffects.field_76439_r);
            }
            if (ClientProxy.kbArmorVision.func_151470_d() && !RenderHandlerEC.isNightVisionKeyDown && player.field_71071_by.field_70460_b.get(3) != null && ((ItemStack)player.field_71071_by.field_70460_b.get(3)).func_77973_b() instanceof ItemComputerArmor) {
                RenderHandlerEC.isNightVisionKeyDown = true;
                RenderHandlerEC.isNightVisionActive = !RenderHandlerEC.isNightVisionActive;
                if (RenderHandlerEC.isNightVisionActive) {
                    final PotionEffect effect = new PotionEffect(MobEffects.field_76439_r, Integer.MAX_VALUE, 0, false, false);
                    effect.func_100012_b(true);
                    Minecraft.func_71410_x().field_71439_g.func_70690_d(effect);
                }
                else {
                    Minecraft.func_71410_x().field_71439_g.func_184589_d(MobEffects.field_76439_r);
                }
            }
            if (!ClientProxy.kbArmorBoost.func_151470_d() && RenderHandlerEC.isSprintKeyDown) {
                RenderHandlerEC.isSprintKeyDown = false;
            }
            if (ClientProxy.kbArmorBoost.func_151470_d() && !RenderHandlerEC.isSprintKeyDown) {
                RenderHandlerEC.isSprintKeyDown = true;
                if (ItemComputerArmor.hasFullset((EntityPlayer)player) && RenderHandlerEC.renderPartialTicksCheck <= 0.0) {
                    final Vec3d lookVec = player.func_70040_Z();
                    final EntityPlayerSP entityPlayerSP = player;
                    entityPlayerSP.field_70159_w += lookVec.field_72450_a * 3.0;
                    final EntityPlayerSP entityPlayerSP2 = player;
                    entityPlayerSP2.field_70181_x += lookVec.field_72448_b * 3.0;
                    final EntityPlayerSP entityPlayerSP3 = player;
                    entityPlayerSP3.field_70179_y += lookVec.field_72449_c * 3.0;
                    for (int i = 0; i < 10; ++i) {
                        player.func_130014_f_().func_184134_a(player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187625_bm, SoundCategory.PLAYERS, 1.0f, 0.01f + player.func_130014_f_().field_73012_v.nextFloat(), false);
                    }
                    RenderHandlerEC.renderPartialTicksCheck = 20.0;
                }
            }
            if (!player.field_71075_bZ.field_75100_b && player.func_70090_H() && ItemComputerArmor.hasFullset((EntityPlayer)player) && Minecraft.func_71410_x().field_71474_y.field_74351_w.func_151470_d()) {
                final EntityPlayerSP entityPlayerSP4 = player;
                entityPlayerSP4.field_70159_w *= 1.2;
                if (player.field_70181_x > 0.0) {
                    final EntityPlayerSP entityPlayerSP5 = player;
                    entityPlayerSP5.field_70181_x *= 1.2;
                }
                final EntityPlayerSP entityPlayerSP6 = player;
                entityPlayerSP6.field_70179_y *= 1.2;
                final double d2 = Math.cos(player.field_70177_z * 3.141592653589793 / 180.0);
                final double d3 = Math.sin(player.field_70177_z * 3.141592653589793 / 180.0);
                final double d4 = player.func_130014_f_().field_73012_v.nextFloat() * 2.0f - 1.0f;
                final double d5 = (player.func_130014_f_().field_73012_v.nextInt(2) * 2 - 1) * 0.7;
                final double d6 = player.field_70165_t - d2 * d4 * 0.8 + d3 * d5;
                final double d7 = player.field_70161_v - d3 * d4 * 0.8 - d2 * d5;
                for (int j = 0; j < 10; ++j) {
                    player.func_130014_f_().func_175688_a(EnumParticleTypes.WATER_BUBBLE, d6, player.field_70163_u - 0.125, d7, player.field_70159_w, player.field_70181_x, player.field_70179_y, new int[0]);
                }
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void renderWindRuneOverlay(final DrawBlockHighlightEvent event) {
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void pre(final RenderGameOverlayEvent.Pre event) {
        try {
            if (event.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
                if (ItemComputerArmor.hasFullset((EntityPlayer)Minecraft.func_71410_x().field_71439_g)) {
                    final ScaledResolution res = new ScaledResolution(RenderHandlerEC.mc);
                    final float r = 10.0f;
                    final float k = (float)(res.func_78326_a() / 2 + 105);
                    final float h = 11.0f;
                    final int circle_points = 100;
                    float angle = 6.2832f / circle_points;
                    GlStateManager.func_179094_E();
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179090_x();
                    GlStateManager.func_179140_f();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179118_c();
                    GlStateManager.func_187447_r(6);
                    float renderTime = (float)(Minecraft.func_71410_x().field_71439_g.field_70173_aa % 40);
                    if (renderTime > 20.0f) {
                        renderTime = 40.0f - renderTime;
                    }
                    GlStateManager.func_179131_c(0.0f, 1.0f, 1.0f, MathHelper.func_76131_a(renderTime / 20.0f, 0.1f, 0.8f));
                    GL11.glVertex2f(k, h);
                    for (angle = 2.0f; angle < 8.300000190734863 - RenderHandlerEC.renderPartialTicksCheck / 20.0 * 8.300000190734863; angle += (float)0.01) {
                        final float x2 = (float)(k + Math.sin(angle) * r);
                        final float y2 = (float)(h + Math.cos(angle) * r);
                        GL11.glVertex2f(x2, y2);
                    }
                    GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                    GlStateManager.func_187437_J();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                    GlStateManager.func_179098_w();
                    GlStateManager.func_179121_F();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179118_c();
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, MathHelper.func_76131_a(renderTime / 20.0f, 0.1f, 0.8f));
                    DrawUtils.drawTexture_Items((int)k - 8, (int)h - 8, TextureUtils.fromItem(Items.field_151152_bP), 16, 16, 100.0f);
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                }
                if (!((ItemStack)Minecraft.func_71410_x().field_71439_g.field_71071_by.field_70460_b.get(3)).func_190926_b() && ((ItemStack)Minecraft.func_71410_x().field_71439_g.field_71071_by.field_70460_b.get(3)).func_77973_b() instanceof ItemComputerArmor) {
                    final ScaledResolution res = new ScaledResolution(RenderHandlerEC.mc);
                    final float r = 10.0f;
                    final float k = (float)(res.func_78326_a() / 2 - 108);
                    final float h = 11.0f;
                    final int circle_points = 100;
                    float angle = 6.2832f / circle_points;
                    GlStateManager.func_179094_E();
                    GL11.glEnable(2929);
                    GL11.glEnable(3042);
                    GlStateManager.func_179112_b(770, 771);
                    GL11.glDisable(3553);
                    GL11.glDisable(2896);
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179118_c();
                    GlStateManager.func_187447_r(6);
                    float renderTime = (float)(Minecraft.func_71410_x().field_71439_g.field_70173_aa % 40);
                    if (renderTime > 20.0f) {
                        renderTime = 40.0f - renderTime;
                    }
                    float cB = 0.2f;
                    if (RenderHandlerEC.isNightVisionActive) {
                        cB = 1.0f;
                    }
                    GlStateManager.func_179131_c(0.0f, 0.0f, cB, MathHelper.func_76131_a(renderTime / 20.0f, 0.1f, 0.8f));
                    GL11.glVertex2f(k, h);
                    for (angle = 2.0f; angle < 8.3f; angle += (float)0.01) {
                        final float x3 = (float)(k + Math.sin(angle) * r);
                        final float y3 = (float)(h + Math.cos(angle) * r);
                        GL11.glVertex2f(x3, y3);
                    }
                    GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                    GlStateManager.func_187437_J();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                    GL11.glEnable(3553);
                    GlStateManager.func_179121_F();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 771);
                    GlStateManager.func_179118_c();
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, MathHelper.func_76131_a(renderTime / 20.0f, 0.1f, 0.8f));
                    DrawUtils.drawTexture_Items((int)k - 8, (int)h - 8, TextureUtils.fromItem(ItemsCore.computer_helmet), 16, 16, 100.0f);
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179141_d();
                }
            }
            if (event.getType() == RenderGameOverlayEvent.ElementType.HEALTH && Minecraft.func_71410_x().field_71439_g.func_70660_b((Potion)PotionRegistry.mruCorruption) != null) {
                Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderHandlerEC.iconsEC);
            }
            if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
                final EntityPlayer p = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
                final RayTraceResult target = p.func_174822_a((double)RenderHandlerEC.mc.field_71442_b.func_78757_d(), event.getPartialTicks());
                if (target != null && target.field_72313_a == RayTraceResult.Type.BLOCK) {
                    target.func_178782_a().func_177958_n();
                    target.func_178782_a().func_177956_o();
                    target.func_178782_a().func_177952_p();
                    final Block b = p.func_130014_f_().func_180495_p(target.func_178782_a()).func_177230_c();
                    if (b != null && b instanceof BlockWindRune) {
                        final TileWindRune rune = (TileWindRune)p.func_130014_f_().func_175625_s(target.func_178782_a());
                        if (rune != null && !p.func_184614_ca().func_190926_b()) {
                            final WindImbueRecipe rec = WindImbueRecipe.getRecipeByInput(p.func_184614_ca());
                            if (rec != null) {
                                final int energyReq = rec.enderEnergy;
                                final int energy = rune.getEnderstarEnergy();
                                final boolean creative = p.field_71075_bZ.field_75098_d;
                                int color;
                                if (energy < energyReq && !creative) {
                                    color = 16711680;
                                }
                                else {
                                    color = 65382;
                                }
                                final ScaledResolution res2 = new ScaledResolution(RenderHandlerEC.mc);
                                String displayed = energyReq + " ESPE";
                                if (creative) {
                                    displayed += " [Creative]";
                                }
                                final String energyDisplay = energy + " ESPE";
                                Minecraft.func_71410_x().field_71466_p.func_78276_b(displayed, res2.func_78326_a() / 2 - displayed.length() * 3, res2.func_78328_b() / 2, color);
                                Minecraft.func_71410_x().field_71466_p.func_78276_b(energyDisplay, res2.func_78326_a() / 2 - energyDisplay.length() * 3, res2.func_78328_b() / 2 + 10, 16777215);
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e) {}
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void post(final RenderGameOverlayEvent.Post event) {
        try {
            if (event.getType() == RenderGameOverlayEvent.ElementType.ALL) {
                final Minecraft mc = Minecraft.func_71410_x();
                final ScaledResolution scaledresolution = new ScaledResolution(mc);
                final int k = scaledresolution.func_78326_a();
                final int l = scaledresolution.func_78328_b();
                if (mc.field_71439_g.func_70660_b((Potion)PotionRegistry.chaosInfluence) != null) {
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179132_a(false);
                    GlStateManager.func_179147_l();
                    OpenGlHelper.func_148821_a(770, 771, 1, 0);
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.3f);
                    final TextureAtlasSprite iicon = TextureUtils.fromBlock(BlocksCore.lightCorruption[0], 7);
                    mc.func_110434_K().func_110577_a(TextureMap.field_110575_b);
                    final float f1 = iicon.func_94209_e();
                    final float f2 = iicon.func_94206_g();
                    final float f3 = iicon.func_94212_f();
                    final float f4 = iicon.func_94210_h();
                    final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
                    tessellator.startDrawingQuads();
                    tessellator.addVertexWithUV(0.0, (double)l, -90.0, (double)f1, (double)f4);
                    tessellator.addVertexWithUV((double)k, (double)l, -90.0, (double)f3, (double)f4);
                    tessellator.addVertexWithUV((double)k, 0.0, -90.0, (double)f3, (double)f2);
                    tessellator.addVertexWithUV(0.0, 0.0, -90.0, (double)f1, (double)f2);
                    tessellator.draw();
                    GlStateManager.func_179132_a(true);
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
                }
                if (mc.field_71439_g.func_70660_b((Potion)PotionRegistry.frozenMind) != null) {
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179132_a(false);
                    GlStateManager.func_179147_l();
                    OpenGlHelper.func_148821_a(770, 771, 1, 0);
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.3f);
                    final TextureAtlasSprite iicon = TextureUtils.fromBlock(BlocksCore.lightCorruption[1], 7);
                    mc.func_110434_K().func_110577_a(TextureMap.field_110575_b);
                    final float f1 = iicon.func_94209_e();
                    final float f2 = iicon.func_94206_g();
                    final float f3 = iicon.func_94212_f();
                    final float f4 = iicon.func_94210_h();
                    final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
                    tessellator.startDrawingQuads();
                    tessellator.addVertexWithUV(0.0, (double)l, -90.0, (double)f1, (double)f4);
                    tessellator.addVertexWithUV((double)k, (double)l, -90.0, (double)f3, (double)f4);
                    tessellator.addVertexWithUV((double)k, 0.0, -90.0, (double)f3, (double)f2);
                    tessellator.addVertexWithUV(0.0, 0.0, -90.0, (double)f1, (double)f2);
                    tessellator.draw();
                    GlStateManager.func_179132_a(true);
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
                }
                if (mc.field_71439_g.func_70660_b((Potion)PotionRegistry.paradox) != null) {}
            }
            if (event.getType() == RenderGameOverlayEvent.ElementType.HEALTH && Minecraft.func_71410_x().field_71439_g.func_70660_b((Potion)PotionRegistry.mruCorruption) != null) {
                Minecraft.func_71410_x().field_71446_o.func_110577_a(Gui.field_110324_m);
            }
        }
        catch (Exception e) {}
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void onModelBake(final ModelBakeEvent event) {
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:rightclicker", "normal"), (Object)new ModelRightClicker());
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:mimic", "normal"), (Object)new ModelMimic());
        for (int i = 0; i < 16; ++i) {
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:fancyblock/mimic", "internal=" + BlockFancy.FancyBlockType.fromIndex(i).toString()), (Object)new ModelFancyMimic(BlockFancy.FancyBlockType.fromIndex(i).toString()));
        }
        ModelGunHandler.blankItem = (IBakedModel)event.getModelRegistry().func_82594_a((Object)new ModelResourceLocation("essentialcraft:item/blank", "inventory"));
        final IBakedModel pistolModel = (IBakedModel)event.getModelRegistry().func_82594_a((Object)new ModelResourceLocation("essentialcraft:item/gun.pistol", "inventory"));
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:item/gun.pistol", "internal"), (Object)new ModelGunHandler(pistolModel));
        final IBakedModel rifleModel = (IBakedModel)event.getModelRegistry().func_82594_a((Object)new ModelResourceLocation("essentialcraft:item/gun.rifle", "inventory"));
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:item/gun.rifle", "internal"), (Object)new ModelGunHandler(rifleModel));
        final IBakedModel sniperModel = (IBakedModel)event.getModelRegistry().func_82594_a((Object)new ModelResourceLocation("essentialcraft:item/gun.sniper", "inventory"));
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:item/gun.sniper", "internal"), (Object)new ModelGunHandler(sniperModel));
        final IBakedModel gatlingModel = (IBakedModel)event.getModelRegistry().func_82594_a((Object)new ModelResourceLocation("essentialcraft:item/gun.gatling", "inventory"));
        event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:item/gun.gatling", "internal"), (Object)new ModelGunHandler(gatlingModel));
        if (Loader.isModLoaded("codechickenlib")) {
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:elementalcrystal", "inventory"), (Object)new RenderElementalCrystalAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:mithrilinecrystal", "inventory"), (Object)new RenderMithrilineCrystalAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:armor", "inventory"), (Object)new ArmorRenderer());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:colddistillatortemp", "inventory"), (Object)new RenderColdDistillatorAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:crystalcontrollertemp", "inventory"), (Object)new RenderCrystalControllerAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:crystalextractortemp", "inventory"), (Object)new RenderCrystalExtractorAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:darknessobelisktemp", "inventory"), (Object)new RenderDarknessObeliskAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:endergeneratortemp", "inventory"), (Object)new RenderEnderGeneratorAsItem());
            event.getModelRegistry().func_82595_a((Object)new ModelResourceLocation("essentialcraft:magicalrepairertemp", "inventory"), (Object)new RenderMagicalRepairerAsItem());
        }
    }
    
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void onClientRenderTick(final RenderGameOverlayEvent.Pre event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            final EntityPlayer p = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
            if (!p.func_184614_ca().func_190926_b() && p.func_184614_ca().func_77973_b() instanceof ItemGun && p.func_70093_af() && p.func_184614_ca().func_77978_p() != null && p.func_184614_ca().func_77978_p().func_74764_b("scope") && ((ItemGun)p.func_184614_ca().func_77973_b()).gunType.equalsIgnoreCase("sniper")) {
                if (event.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
                    final Minecraft mc = Minecraft.func_71410_x();
                    final ScaledResolution scaledresolution = new ScaledResolution(mc);
                    int k = scaledresolution.func_78326_a();
                    final int l = scaledresolution.func_78328_b();
                    if (k < l) {
                        k = l;
                    }
                    if (k > l) {
                        k = l;
                    }
                    Minecraft.func_71410_x().func_110434_K().func_110577_a(this.loc);
                    GlStateManager.func_179132_a(false);
                    final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
                    tessellator.startDrawingQuads();
                    tessellator.addVertexWithUV((double)(scaledresolution.func_78326_a() / 2 - scaledresolution.func_78326_a() / 4), (double)l, -90.0, 0.0, 1.0);
                    tessellator.addVertexWithUV(k + (double)(scaledresolution.func_78326_a() / 2) - scaledresolution.func_78326_a() / 4, (double)l, -90.0, 1.0, 1.0);
                    tessellator.addVertexWithUV(k + (double)(scaledresolution.func_78326_a() / 2) - scaledresolution.func_78326_a() / 4, 0.0, -90.0, 1.0, 0.0);
                    tessellator.addVertexWithUV((double)(scaledresolution.func_78326_a() / 2 - scaledresolution.func_78326_a() / 4), 0.0, -90.0, 0.0, 0.0);
                    tessellator.draw();
                    Minecraft.func_71410_x().func_110434_K().func_110577_a(RenderHandlerEC.whitebox);
                    GlStateManager.func_179124_c(0.0f, 0.0f, 0.0f);
                    tessellator.startDrawingQuads();
                    tessellator.addVertexWithUV(0.0, (double)l, -90.0, 0.0, 1.0);
                    tessellator.addVertexWithUV((double)(scaledresolution.func_78326_a() / 2 - scaledresolution.func_78326_a() / 4), (double)l, -90.0, 1.0, 1.0);
                    tessellator.addVertexWithUV((double)(scaledresolution.func_78326_a() / 2 - scaledresolution.func_78326_a() / 4), 0.0, -90.0, 1.0, 0.0);
                    tessellator.addVertexWithUV(0.0, 0.0, -90.0, 0.0, 0.0);
                    tessellator.draw();
                    tessellator.startDrawingQuads();
                    tessellator.addVertexWithUV(k + (double)(scaledresolution.func_78326_a() / 2) - scaledresolution.func_78326_a() / 4, (double)l, -90.0, 0.0, 1.0);
                    tessellator.addVertexWithUV((double)scaledresolution.func_78326_a(), (double)l, -90.0, 1.0, 1.0);
                    tessellator.addVertexWithUV((double)scaledresolution.func_78326_a(), 0.0, -90.0, 1.0, 0.0);
                    tessellator.addVertexWithUV(k + (double)(scaledresolution.func_78326_a() / 2) - scaledresolution.func_78326_a() / 4, 0.0, -90.0, 0.0, 0.0);
                    tessellator.draw();
                    GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
                    GlStateManager.func_179132_a(true);
                }
                event.setCanceled(true);
            }
        }
    }
    
    public static void renderImage(final ResourceLocation image, final int scaledResX, final int scaledResY, final float opacity, final float r, final float g, final float b) {
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a(false);
        OpenGlHelper.func_148821_a(770, 771, 1, 0);
        GlStateManager.func_179131_c(r, g, b, opacity);
        GlStateManager.func_179118_c();
        RenderHandlerEC.mc.func_110434_K().func_110577_a(image);
        final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(0.0, (double)scaledResY, -90.0, 0.0, 1.0);
        tessellator.addVertexWithUV((double)scaledResX, (double)scaledResY, -90.0, 1.0, 1.0);
        tessellator.addVertexWithUV((double)scaledResX, 0.0, -90.0, 1.0, 0.0);
        tessellator.addVertexWithUV(0.0, 0.0, -90.0, 0.0, 0.0);
        tessellator.draw();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179141_d();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    static {
        iconsEC = new ResourceLocation("essentialcraft", "textures/special/icons.png");
        whitebox = new ResourceLocation("essentialcraft", "textures/special/whitebox.png");
        mc = Minecraft.func_71410_x();
        RenderHandlerEC.renderPartialTicksCheck = 0.0;
        board = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft", "models/item/board.obj"));
        boardTextures = new ResourceLocation("essentialcraft", "textures/models/board.png");
        RenderHandlerEC.slotsTable = new HashMap<IInventory, HashMap<Integer, List<EnumFacing>>>();
    }
}
