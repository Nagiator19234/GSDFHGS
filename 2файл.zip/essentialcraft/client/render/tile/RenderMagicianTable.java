package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import essentialcraft.api.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMagicianTable extends TileEntitySpecialRenderer<TileMagicianTable>
{
    public static final IModelCustom cube;
    
    public void doRender(final TileMagicianTable table, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y, (float)z + 0.5f);
        if (table.upgrade != -1) {
            this.func_147499_a((ResourceLocation)MagicianTableUpgrades.UPGRADE_TEXTURES.get(table.upgrade));
            final float scale = 0.99f;
            GlStateManager.func_179109_b(0.0f, 0.005f, 0.0f);
            GlStateManager.func_179152_a(scale, scale, scale);
            RenderMagicianTable.cube.renderAll();
        }
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMagicianTable tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    static {
        cube = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/cube.obj"));
    }
}
