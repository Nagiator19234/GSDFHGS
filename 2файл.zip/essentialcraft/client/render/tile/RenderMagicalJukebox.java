package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import essentialcraft.common.item.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalJukebox extends TileEntitySpecialRenderer<TileMagicalJukebox>
{
    public void doRender(final TileMagicalJukebox tile, final double x, final double y, final double z, final float partialTicks) {
        final float[][] coloring = { { 1.0f, 0.0f, 0.0f }, { 1.0f, 0.0f, 1.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 1.0f, 1.0f }, { 0.0f, 1.0f, 0.0f }, { 1.0f, 1.0f, 0.0f }, { 1.0f, 1.0f, 1.0f } };
        final float rotation = 90.0f;
        int currentSupposedTimingColor = (int)(tile.func_145831_w().func_72820_D() % 210L);
        currentSupposedTimingColor /= 30;
        final ItemStack is = tile.func_70301_a(1);
        float upperIndex = (tile.func_145831_w().func_72820_D() + partialTicks) % 40.0f;
        if (upperIndex < 20.0f) {
            upperIndex = 20.0f - upperIndex;
        }
        else {
            upperIndex -= 20.0f;
        }
        float upperIndex2 = (tile.func_145831_w().func_72820_D() + partialTicks) % 30.0f;
        if (upperIndex2 < 15.0f) {
            upperIndex2 = 15.0f - upperIndex2;
        }
        else {
            upperIndex2 -= 15.0f;
        }
        if (is.func_77973_b() == ItemsCore.record_secret && tile.recordCooldownTime > 0) {
            GlStateManager.func_179124_c(coloring[currentSupposedTimingColor][0], coloring[currentSupposedTimingColor][1], coloring[currentSupposedTimingColor][2]);
        }
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y, (float)z + 0.5f);
        if (is.func_77973_b() == ItemsCore.record_secret && tile.recordCooldownTime > 0) {
            GlStateManager.func_179152_a(1.0f - upperIndex / 60.0f, 1.0f - upperIndex2 / 40.0f, 1.0f - (20.0f - upperIndex) / 60.0f);
        }
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        if (is.func_77973_b() == ItemsCore.record_secret && tile.recordCooldownTime > 0) {
            DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.65f - upperIndex2 / 40.0f, 0.5f);
        }
        else {
            DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.65f, 0.5f);
        }
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMagicalJukebox tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
}
