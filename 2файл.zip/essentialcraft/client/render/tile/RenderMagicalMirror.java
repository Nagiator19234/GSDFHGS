package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalMirror extends TileEntitySpecialRenderer<TileMagicalMirror>
{
    public static final ResourceLocation textures;
    public static final ResourceLocation glass;
    public static final IModelCustom model;
    
    public void doRender(final TileMagicalMirror tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y - 0.25f, (float)z + 0.5f);
        float timeIndex = (tile.func_145831_w().func_72820_D() + partialTicks) % 120.0f;
        float yIndex = 1.0f;
        if (timeIndex <= 60.0f) {
            yIndex = timeIndex / 240.0f;
        }
        else {
            yIndex = 0.5f - timeIndex / 240.0f;
        }
        GlStateManager.func_179109_b(0.0f, yIndex - 0.25f, 0.0f);
        if (tile.inventoryPos != null) {
            final double d0 = tile.inventoryPos.func_177958_n() - tile.func_174877_v().func_177958_n();
            final double d2 = tile.inventoryPos.func_177956_o() - tile.func_174877_v().func_177956_o() - yIndex;
            final double d3 = tile.inventoryPos.func_177952_p() - tile.func_174877_v().func_177952_p();
            final double d4 = MathHelper.func_76133_a(d0 * d0 + d3 * d3);
            final float f = -(float)(Math.atan2(d3, d0) * 180.0 / 3.141592653589793) - 90.0f;
            final float f2 = -(float)(-(Math.atan2(d2, d4) * 180.0 / 3.141592653589793));
            GlStateManager.func_179114_b(f, 0.0f, 1.0f, 0.0f);
            GlStateManager.func_179114_b(f2, 1.0f, 0.0f, 0.0f);
        }
        this.func_147499_a(RenderMagicalMirror.textures);
        RenderMagicalMirror.model.renderPart("pCube2");
        this.func_147499_a(RenderMagicalMirror.glass);
        if (tile.pulsing) {
            timeIndex = (float)(Minecraft.func_71410_x().field_71441_e.func_72820_D() % 20L);
            float colorIndex = 1.0f;
            if (timeIndex <= 10.0f) {
                colorIndex = 1.0f - timeIndex / 10.0f;
            }
            else {
                colorIndex = (timeIndex - 10.0f) / 10.0f;
            }
            GlStateManager.func_179124_c(1.0f, colorIndex, 1.0f);
        }
        RenderMagicalMirror.model.renderPart("pPlane1");
        GlStateManager.func_179114_b(180.0f, 0.0f, 1.0f, 0.0f);
        RenderMagicalMirror.model.renderPart("pPlane1");
        GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
        if (!tile.transferingStack.func_190926_b()) {
            if (tile.transferTime < 20) {
                DrawUtils.renderItemStack_Full(tile.transferingStack, x, y, z, (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, -0.3f + tile.transferTime / 20.0f, 0.5f);
            }
            else {
                final Vec3d vec = new Vec3d((double)(tile.inventoryPos.func_177958_n() - tile.func_174877_v().func_177958_n()), (double)(tile.inventoryPos.func_177956_o() - tile.func_174877_v().func_177956_o()), (double)(tile.inventoryPos.func_177952_p() - tile.func_174877_v().func_177952_p()));
                DrawUtils.renderItemStack_Full(tile.transferingStack, x, y, z, (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f + (float)vec.field_72450_a * (tile.transferTime - 20.0f) / 40.0f, 0.5f + (float)vec.field_72448_b * (tile.transferTime - 20.0f) / 40.0f, 0.5f + (float)vec.field_72449_c * (tile.transferTime - 20.0f) / 40.0f);
            }
        }
    }
    
    protected ResourceLocation getEntityTexture(final TileEntity entity) {
        return RenderMagicalMirror.textures;
    }
    
    public void render(final TileMagicalMirror tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    public boolean isGlobalRenderer(final TileMagicalMirror te) {
        return true;
    }
    
    static {
        textures = new ResourceLocation("essentialcraft:textures/models/armtextures.png");
        glass = new ResourceLocation("essentialcraft:textures/models/mirror.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/mirror.obj"));
    }
}
