package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderRadiatingChamber extends TileEntitySpecialRenderer<TileRadiatingChamber>
{
    public void doRender(final TileRadiatingChamber tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, 0.0f, 90.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.875f, 0.5f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileRadiatingChamber tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
}
