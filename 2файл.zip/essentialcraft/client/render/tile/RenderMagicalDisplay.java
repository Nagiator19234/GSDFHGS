package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.client.*;
import net.minecraft.client.util.*;
import net.minecraft.world.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.*;
import java.util.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalDisplay extends TileEntitySpecialRenderer<TileMagicalDisplay>
{
    public void doRender(final TileMagicalDisplay display, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        final int metadata = display.func_145832_p();
        final ItemStack displayed = display.func_70301_a(0);
        final float rotationX = (metadata == 3) ? 0.0f : ((metadata == 2) ? 180.0f : ((metadata == 4) ? 90.0f : 270.0f));
        float offsetX = (metadata == 1 || metadata == 0) ? 0.7f : ((metadata == 3 || metadata == 2) ? 0.5f : ((metadata == 4) ? 0.96f : 0.04f));
        float offsetY = (metadata == 1) ? 0.04f : ((metadata == 0) ? 0.96f : 0.4f);
        float offsetZ = (metadata == 1 || metadata == 0) ? 0.5f : ((metadata == 4 || metadata == 5) ? 0.5f : ((metadata == 2) ? 0.96f : 0.04f));
        final float rotationZ = (metadata == 1 || metadata == 0) ? 90.0f : 0.0f;
        final float scaleIndex = (display.type == 0) ? 1.0f : ((display.type == 1) ? 0.5f : 0.375f);
        if (!displayed.func_190926_b()) {
            GlStateManager.func_179152_a(scaleIndex, scaleIndex, scaleIndex);
            if (display.type == 0 || metadata == 0 || metadata == 1) {
                DrawUtils.renderItemStack_Full(displayed, x / scaleIndex, y / scaleIndex, z / scaleIndex, rotationX, rotationZ, 1.0f, 1.0f, 1.0f, offsetX / scaleIndex, offsetY / scaleIndex, offsetZ / scaleIndex);
            }
            if (display.type == 1 && metadata != 0 && metadata != 1) {
                offsetX = ((metadata == 3) ? 0.25f : ((metadata == 2) ? 0.75f : ((metadata == 4) ? 0.95f : 0.05f)));
                offsetY = ((metadata == 1) ? 0.04f : ((metadata == 0) ? 0.96f : 0.6f));
                offsetZ = ((metadata == 4) ? 0.25f : ((metadata == 5) ? 0.75f : ((metadata == 2) ? 0.95f : 0.05f)));
                DrawUtils.renderItemStack_Full(displayed, x / scaleIndex, y / scaleIndex, z / scaleIndex, rotationX, rotationZ, 1.0f, 1.0f, 1.0f, offsetX / scaleIndex, offsetY / scaleIndex, offsetZ / scaleIndex);
                GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
                final FontRenderer renderer = Minecraft.func_71410_x().field_71466_p;
                GlStateManager.func_179137_b(x, y, z);
                final String drawedName = displayed.func_82833_r();
                GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
                switch (metadata) {
                    case 2: {
                        GlStateManager.func_179109_b(1.0f - drawedName.length() / 160.0f, -0.4f, -0.949f);
                        break;
                    }
                    case 3: {
                        GlStateManager.func_179109_b(drawedName.length() / 160.0f, -0.4f, -0.051f);
                        break;
                    }
                    case 4: {
                        GlStateManager.func_179109_b(0.949f, -0.4f, -(drawedName.length() / 160.0f));
                        break;
                    }
                    case 5: {
                        GlStateManager.func_179109_b(0.051f, -0.4f, -1.0f + drawedName.length() / 160.0f);
                        break;
                    }
                }
                GlStateManager.func_179114_b(rotationX, 0.0f, 1.0f, 0.0f);
                final float s = 0.06f / (drawedName.length() / 2);
                GlStateManager.func_179152_a(s, s, s);
                renderer.func_78276_b(drawedName, 0, 0, 16777215);
                GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
            }
            if (display.type == 2 && metadata != 0 && metadata != 1) {
                offsetX = ((metadata == 3) ? 0.25f : ((metadata == 2) ? 0.75f : ((metadata == 4) ? 0.95f : 0.05f)));
                offsetY = 0.7f;
                offsetZ = ((metadata == 4) ? 0.25f : ((metadata == 5) ? 0.75f : ((metadata == 2) ? 0.95f : 0.05f)));
                DrawUtils.renderItemStack_Full(displayed, x / scaleIndex, y / scaleIndex, z / scaleIndex, rotationX, rotationZ, 1.0f, 1.0f, 1.0f, offsetX / scaleIndex, offsetY / scaleIndex, offsetZ / scaleIndex);
                GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
                final FontRenderer renderer = Minecraft.func_71410_x().field_71466_p;
                GlStateManager.func_179137_b(x, y, z);
                final String drawedName = displayed.func_82833_r();
                GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
                switch (metadata) {
                    case 2: {
                        GlStateManager.func_179109_b(0.6f - drawedName.length() / 160.0f, -0.8f, -0.949f);
                        break;
                    }
                    case 3: {
                        GlStateManager.func_179109_b(0.4f + drawedName.length() / 160.0f, -0.8f, -0.051f);
                        break;
                    }
                    case 4: {
                        GlStateManager.func_179109_b(0.949f, -0.8f, -0.4f - drawedName.length() / 160.0f);
                        break;
                    }
                    case 5: {
                        GlStateManager.func_179109_b(0.051f, -0.8f, -0.6f + drawedName.length() / 160.0f);
                        break;
                    }
                }
                GlStateManager.func_179114_b(rotationX, 0.0f, 1.0f, 0.0f);
                float s = 0.03f / (drawedName.length() / 2);
                GlStateManager.func_179094_E();
                GlStateManager.func_179152_a(s, s, s);
                renderer.func_78276_b(drawedName, 0, 0, 16777215);
                GlStateManager.func_179121_F();
                final List<String> displaySt = new ArrayList<String>();
                displayed.func_77973_b().func_77624_a(displayed, (World)Minecraft.func_71410_x().field_71441_e, (List)displaySt, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
                int longestStr = 1;
                for (final String st : displaySt) {
                    if (longestStr < st.length()) {
                        longestStr = st.length();
                    }
                }
                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b(-0.4f, 0.15f, 0.0f);
                s = 0.08f / (longestStr / 2.0f);
                GlStateManager.func_179152_a(s, s, s);
                for (final String element : displaySt) {
                    GlStateManager.func_179109_b(0.0f, 10.0f, 0.0f);
                    renderer.func_78276_b(element, 0, 0, 16777215);
                }
                GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
                GlStateManager.func_179121_F();
            }
        }
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMagicalDisplay tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
}
