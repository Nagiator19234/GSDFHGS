package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

public class RenderColdDistillator extends TileEntitySpecialRenderer<TileColdDistillator>
{
    public static final IModelCustom model;
    public static final ResourceLocation textures;
    
    public void render(final TileColdDistillator te, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderColdDistillator.textures);
        RenderColdDistillator.model.renderAll();
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    static {
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/colddistillator.obj"));
        textures = new ResourceLocation("essentialcraft:textures/models/colddistillator.png");
    }
}
