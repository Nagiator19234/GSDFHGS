package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMRULink extends TileEntitySpecialRenderer<TileMRUCUECAcceptor>
{
    private static final ResourceLocation enderDragonCrystalBeamTextures;
    
    public void doRender(final TileMRUCUECAcceptor tile, final double x, final double y, final double z, final float partialTicks) {
    }
    
    public void render(final TileMRUCUECAcceptor tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    static {
        enderDragonCrystalBeamTextures = new ResourceLocation("textures/entity/endercrystal/endercrystal_beam.png");
    }
}
