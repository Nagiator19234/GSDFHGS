package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import essentialcraft.utils.common.*;
import java.util.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMonsterHolder extends TileEntitySpecialRenderer<TileMonsterHolder>
{
    public void doRender(final TileMonsterHolder tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        final List<EntityLivingBase> lst = (List<EntityLivingBase>)tile.func_145831_w().func_72872_a((Class)EntityLivingBase.class, new AxisAlignedBB((double)(tile.func_174877_v().func_177958_n() - 32), (double)(tile.func_174877_v().func_177956_o() - 32), (double)(tile.func_174877_v().func_177952_p() - 32), (double)(tile.func_174877_v().func_177958_n() + 33), (double)(tile.func_174877_v().func_177956_o() + 33), (double)(tile.func_174877_v().func_177952_p() + 33)));
        if (!lst.isEmpty() && tile.getCapability(CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, null).getMRU() > lst.size()) {
            for (final EntityLivingBase e : lst) {
                if (!(e instanceof EntityPlayer)) {
                    final Coord3D tilePos = new Coord3D(tile.func_174877_v().func_177958_n() + 0.5, tile.func_174877_v().func_177956_o() + 0.5, tile.func_174877_v().func_177952_p() + 0.5);
                    final Coord3D mobPosition = new Coord3D(e.field_70165_t, e.field_70163_u, e.field_70161_v);
                    final DummyDistance dist = new DummyDistance(tilePos, mobPosition);
                    if (dist.getDistance() >= 10.0f) {
                        continue;
                    }
                    GlStateManager.func_179094_E();
                    final double[] o = { e.field_70165_t - 0.5, e.field_70163_u + e.func_70047_e() + 0.5, e.field_70161_v - 0.5 };
                    final float f21 = 0.0f + partialTicks;
                    float f22 = MathHelper.func_76126_a(f21 * 0.2f) / 2.0f + 0.5f;
                    f22 = (f22 * f22 + f22) * 0.2f;
                    final float f23 = (float)(o[0] - tile.func_174877_v().func_177958_n());
                    final float f24 = (float)(o[1] - (f22 + tile.func_174877_v().func_177956_o() + 1.3f));
                    final float f25 = (float)(o[2] - tile.func_174877_v().func_177952_p());
                    GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 0.6f, (float)z + 0.5f);
                    final float f26 = MathHelper.func_76129_c(f23 * f23 + f25 * f25);
                    final float f27 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25);
                    GlStateManager.func_179114_b((float)(-Math.atan2(f25, f23)) * 180.0f / 3.1415927f - 90.0f, 0.0f, 1.0f, 0.0f);
                    GlStateManager.func_179114_b((float)(-Math.atan2(f26, f24)) * 180.0f / 3.1415927f - 90.0f, 1.0f, 0.0f, 0.0f);
                    final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
                    RenderHelper.func_74518_a();
                    GlStateManager.func_179092_a(516, 0.1f);
                    GlStateManager.func_179129_p();
                    DrawUtils.bindTexture("essentialcraft", "textures/special/mru_beam.png");
                    GlStateManager.func_179103_j(7425);
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179112_b(770, 1);
                    GlStateManager.func_179118_c();
                    final float f28 = 1.0f;
                    final float f29 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25) / 32.0f - (PlayerTickHandler.tickAmount + partialTicks) * 0.1f;
                    tessellator.startDrawingWithColor(5);
                    final byte b0 = 8;
                    for (int i1 = 0; i1 <= b0; ++i1) {
                        final float f30 = MathHelper.func_76126_a(i1 % b0 * 3.1415927f * 2.0f / b0) * 0.75f * 0.1f;
                        final float f31 = MathHelper.func_76134_b(i1 % b0 * 3.1415927f * 2.0f / b0) * 0.75f * 0.1f;
                        final float f32 = i1 % b0 * 1.0f / b0;
                        tessellator.setColorRGBA_F(0.0f, 1.0f, 1.0f, 10.0f);
                        tessellator.addVertexWithUV((double)f30, (double)f31, 0.0, (double)f32, (double)f29);
                        tessellator.setColorRGBA_F(1.0f, 0.0f, 1.0f, 10.0f);
                        tessellator.addVertexWithUV((double)f30, (double)f31, (double)f27, (double)f32, (double)f28);
                    }
                    tessellator.draw();
                    GlStateManager.func_179089_o();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179103_j(7424);
                    GlStateManager.func_179141_d();
                    RenderHelper.func_74519_b();
                    GlStateManager.func_179121_F();
                }
            }
        }
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMonsterHolder tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    public boolean isGlobalRenderer(final TileMonsterHolder te) {
        return true;
    }
}
