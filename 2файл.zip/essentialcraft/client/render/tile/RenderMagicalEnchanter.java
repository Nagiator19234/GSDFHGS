package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalEnchanter extends TileEntitySpecialRenderer<TileMagicalEnchanter>
{
    private static final ResourceLocation TEXTURE_BOOK;
    private final ModelBook modelBook;
    
    public RenderMagicalEnchanter() {
        this.modelBook = new ModelBook();
    }
    
    public void render(final TileMagicalEnchanter te, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x + 0.5, y + 0.75, z + 0.5);
        final float f = te.tickCount + partialTicks;
        GlStateManager.func_179109_b(0.0f, 0.1f + MathHelper.func_76126_a(f * 0.1f) * 0.01f, 0.0f);
        float f2;
        for (f2 = te.bookRotation - te.bookRotationPrev; f2 >= 3.141592653589793; f2 -= (float)6.283185307179586) {}
        while (f2 < -3.141592653589793) {
            f2 += (float)6.283185307179586;
        }
        final float f3 = te.bookRotationPrev + f2 * partialTicks;
        GlStateManager.func_179114_b((float)(-f3 * 57.29577951308232), 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(80.0f, 0.0f, 0.0f, 1.0f);
        this.func_147499_a(RenderMagicalEnchanter.TEXTURE_BOOK);
        float f4 = te.pageFlipPrev + (te.pageFlip - te.pageFlipPrev) * partialTicks + 0.25f;
        float f5 = te.pageFlipPrev + (te.pageFlip - te.pageFlipPrev) * partialTicks + 0.75f;
        f4 = (f4 - MathHelper.func_76140_b((double)f4)) * 1.6f - 0.3f;
        f5 = (f5 - MathHelper.func_76140_b((double)f5)) * 1.6f - 0.3f;
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        }
        if (f4 > 1.0f) {
            f4 = 1.0f;
        }
        if (f5 > 1.0f) {
            f5 = 1.0f;
        }
        final float f6 = te.bookSpreadPrev + (te.bookSpread - te.bookSpreadPrev) * partialTicks;
        GlStateManager.func_179089_o();
        this.modelBook.func_78088_a((Entity)null, f, f4, f5, f6, 0.0f, 0.0625f);
        GlStateManager.func_179121_F();
    }
    
    static {
        TEXTURE_BOOK = new ResourceLocation("textures/entity/enchanting_table_book.png");
    }
}
