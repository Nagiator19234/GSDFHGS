package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMonsterHarvester extends TileEntitySpecialRenderer<TileMonsterHarvester>
{
    public void doRender(final TileMonsterHarvester tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        final float rotation = (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f;
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(2), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.95f, 0.5f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.3f, 1.15f, 0.3f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(3), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.7f, 1.15f, 0.3f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(4), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.3f, 1.15f, 0.7f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(5), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.7f, 1.15f, 0.7f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMonsterHarvester tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
}
