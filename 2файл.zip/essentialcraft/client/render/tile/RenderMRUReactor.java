package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import java.util.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMRUReactor extends TileEntitySpecialRenderer<TileMRUReactor>
{
    public static final ResourceLocation textures;
    public static final IModelCustom model;
    public static final ResourceLocation stextures;
    public static final IModelCustom smodel;
    
    public void doRender(final TileMRUReactor tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y, (float)z + 0.5f);
        this.func_147499_a(RenderMRUReactor.stextures);
        if (!tile.isStructureCorrect) {
            GlStateManager.func_179124_c(0.4f, 0.4f, 0.4f);
            GlStateManager.func_179152_a(0.55f, 0.55f, 0.55f);
            RenderMRUReactor.smodel.renderAll();
        }
        else {
            final float wTime = 0.0f;
            GlStateManager.func_179109_b(0.0f, 0.5f + wTime, 0.0f);
            GlStateManager.func_179152_a(0.55f, 0.55f, 0.55f);
            RenderMRUReactor.smodel.renderAll();
        }
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        if (tile.isStructureCorrect()) {
            for (final Lightning l : tile.lightnings) {
                l.render(x, y, z, partialTicks);
            }
        }
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMRUReactor tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        textures = new ResourceLocation("essentialcraft:textures/models/flowerburner.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/mrureactor_btm.obj"));
        stextures = new ResourceLocation("essentialcraft:textures/models/sphere.png");
        smodel = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/sphere.obj"));
    }
}
