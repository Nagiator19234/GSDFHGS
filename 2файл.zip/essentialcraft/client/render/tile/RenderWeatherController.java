package essentialcraft.client.render.tile;

import essentialcraft.common.tile.*;
import essentialcraft.common.item.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.tileentity.*;

public class RenderWeatherController extends TileEntitySpecialRenderer<TileWeatherController>
{
    public void render(final TileWeatherController te, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        final int id = (te.func_70301_a(1).func_77973_b() == ItemsCore.clearing_catalyst) ? 0 : ((te.func_70301_a(1).func_77973_b() == ItemsCore.raining_catalyst) ? 1 : ((te.func_70301_a(1).func_77973_b() == ItemsCore.thundering_catalyst) ? 2 : -1));
        if (id != -1) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179092_a(516, 0.1f);
            GlStateManager.func_179106_n();
            GlStateManager.func_179140_f();
            OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
            DrawUtils.bindTexture("minecraft", "textures/entity/beacon_beam.png");
            GlStateManager.func_179109_b(-0.5f, 0.0f, -0.5f);
            final float[] colors = (id == 0) ? new float[] { 0.49803922f, 0.6666667f, 1.0f } : ((id == 1) ? new float[] { 0.4f, 0.44313726f, 0.5372549f } : ((id == 2) ? new float[] { 0.16862746f, 0.18039216f, 0.20392157f } : new float[3]));
            final double beamRad = te.progressLevel / (double)TileWeatherController.requiredTicks / 5.0;
            final double glowRad = te.progressLevel / (double)TileWeatherController.requiredTicks / 2.0;
            TileEntityBeaconRenderer.func_188205_a(x + 0.5, y, z + 0.5, 0.0, 1.0, (double)te.func_145831_w().func_82737_E(), 0, 255 - te.func_174877_v().func_177956_o(), colors, beamRad, glowRad);
            GlStateManager.func_179145_e();
            GlStateManager.func_179127_m();
            GlStateManager.func_179121_F();
        }
    }
    
    public boolean isGlobalRenderer(final TileWeatherController te) {
        return true;
    }
}
