package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMithrilineCrystal extends TileEntitySpecialRenderer<TileMithrilineCrystal>
{
    public static final ResourceLocation textures_mithriline;
    public static final ResourceLocation textures_pale;
    public static final ResourceLocation textures_void;
    public static final ResourceLocation textures_demonic;
    public static final ResourceLocation textures_shade;
    public static final IModelCustom model;
    
    public void doRender(final TileMithrilineCrystal tile, final double x, final double y, final double z, final float partialTicks) {
        final int meta = tile.func_145832_p();
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179140_f();
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(1, 771);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.9f);
        final float time = (tile.func_145831_w().func_72820_D() + partialTicks) % 45.0f * 8.0f;
        float movement = (tile.func_145831_w().func_72820_D() + partialTicks) % 60.0f;
        if (movement > 30.0f) {
            movement = 30.0f - movement + 30.0f;
        }
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y + movement / 30.0f, (float)z + 0.5f);
        GlStateManager.func_179114_b(time, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
        this.func_147499_a((meta == 0) ? RenderMithrilineCrystal.textures_mithriline : ((meta == 3) ? RenderMithrilineCrystal.textures_pale : ((meta == 6) ? RenderMithrilineCrystal.textures_void : ((meta == 9) ? RenderMithrilineCrystal.textures_demonic : RenderMithrilineCrystal.textures_shade))));
        RenderMithrilineCrystal.model.renderAll();
        GlStateManager.func_179145_e();
        GlStateManager.func_179141_d();
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMithrilineCrystal tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() % 3 == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    static {
        textures_mithriline = new ResourceLocation("essentialcraft:textures/models/mithrilinecrystal.png");
        textures_pale = new ResourceLocation("essentialcraft:textures/models/palecrystal.png");
        textures_void = new ResourceLocation("essentialcraft:textures/models/voidcrystal.png");
        textures_demonic = new ResourceLocation("essentialcraft:textures/models/demoniccrystal.png");
        textures_shade = new ResourceLocation("essentialcraft:textures/models/shadecrystal.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/mithrilinecrystal.obj"));
    }
}
