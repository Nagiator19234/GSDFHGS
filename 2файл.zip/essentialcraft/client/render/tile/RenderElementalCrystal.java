package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import essentialcraft.client.model.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderElementalCrystal extends TileEntitySpecialRenderer<TileElementalCrystal>
{
    public static final ResourceLocation textures;
    public static final ResourceLocation neutral;
    public static final ResourceLocation fire;
    public static final ResourceLocation water;
    public static final ResourceLocation earth;
    public static final ResourceLocation air;
    public static final ModelElementalCrystal crystal;
    
    public void doRender(final TileElementalCrystal crystal_tile, final double x, final double y, final double z, final float partialTicks) {
        final int metadata = crystal_tile.func_145832_p();
        GlStateManager.func_179094_E();
        final float scale = MathUtils.getPercentage((int)crystal_tile.size, 100) / 100.0f;
        if (metadata == 1) {
            GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 1.4f - (1.0f - scale) * 1.4f, (float)z + 0.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        }
        if (metadata == 0) {
            GlStateManager.func_179109_b((float)x + 0.5f, (float)y - 0.4f + (1.0f - scale) * 1.4f, (float)z + 0.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(0.0f, 1.0f, 0.0f, 0.0f);
        }
        if (metadata == 2) {
            GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 0.5f, (float)z - 0.5f + (1.0f - scale) * 1.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
        }
        if (metadata == 4) {
            GlStateManager.func_179109_b((float)x - 0.5f + (1.0f - scale) * 1.5f, (float)y + 0.5f, (float)z + 0.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(270.0f, 0.0f, 0.0f, 1.0f);
        }
        if (metadata == 3) {
            GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 0.5f, (float)z + 1.5f - (1.0f - scale) * 1.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(-90.0f, 1.0f, 0.0f, 0.0f);
        }
        if (metadata == 5) {
            GlStateManager.func_179109_b((float)x + 1.5f - (1.0f - scale) * 1.5f, (float)y + 0.5f, (float)z + 0.5f);
            GlStateManager.func_179152_a(scale, scale, scale);
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
        }
        this.func_147499_a(RenderElementalCrystal.textures);
        RenderHelper.func_74518_a();
        GlStateManager.func_179140_f();
        GlStateManager.func_179129_p();
        GlStateManager.func_179084_k();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.5f);
        GlStateManager.func_179147_l();
        OpenGlHelper.func_148821_a(770, 771, 1, 0);
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        this.func_147499_a(RenderElementalCrystal.fire);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, (float)(crystal_tile.fire / 100.0));
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        this.func_147499_a(RenderElementalCrystal.water);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, (float)(crystal_tile.water / 100.0));
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        this.func_147499_a(RenderElementalCrystal.earth);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, (float)(crystal_tile.earth / 100.0));
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        this.func_147499_a(RenderElementalCrystal.air);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, (float)(crystal_tile.air / 100.0));
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileElementalCrystal tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        textures = new ResourceLocation("essentialcraft:textures/models/mcrystaltex.png");
        neutral = new ResourceLocation("essentialcraft:textures/models/mcrystaltex.png");
        fire = new ResourceLocation("essentialcraft:textures/models/fcrystaltex.png");
        water = new ResourceLocation("essentialcraft:textures/models/wcrystaltex.png");
        earth = new ResourceLocation("essentialcraft:textures/models/ecrystaltex.png");
        air = new ResourceLocation("essentialcraft:textures/models/acrystaltex.png");
        crystal = new ModelElementalCrystal();
    }
}
