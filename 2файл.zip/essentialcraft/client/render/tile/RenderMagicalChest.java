package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalChest extends TileEntitySpecialRenderer<TileMagicalChest>
{
    public static final ResourceLocation magicalTextures;
    public static final ResourceLocation voidTextures;
    public static final ModelChest chest;
    public static final ModelChest inventoryChest;
    
    public void doRender(final TileMagicalChest tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179091_B();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179109_b((float)x, (float)y + 1.0f, (float)z + 1.0f);
        GlStateManager.func_179152_a(1.0f, -1.0f, -1.0f);
        GlStateManager.func_179109_b(0.5f, 0.5f, 0.5f);
        GlStateManager.func_179114_b(tile.rotation * 90.0f + 180.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179109_b(-0.5f, -0.5f, -0.5f);
        final float f1 = tile.prevLidAngle + (tile.lidAngle - tile.prevLidAngle) * partialTicks;
        RenderMagicalChest.chest.field_78234_a.field_78795_f = -(f1 * 3.1415927f / 2.0f);
        this.func_147499_a((tile.func_145832_p() == 0) ? RenderMagicalChest.magicalTextures : RenderMagicalChest.voidTextures);
        RenderMagicalChest.chest.func_78231_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179121_F();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public void render(final TileMagicalChest tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        magicalTextures = new ResourceLocation("essentialcraft:textures/blocks/chests/magical.png");
        voidTextures = new ResourceLocation("essentialcraft:textures/blocks/chests/void.png");
        chest = new ModelChest();
        inventoryChest = new ModelChest();
    }
}
