package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import essentialcraft.utils.common.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderCorruptionCleaner extends TileEntitySpecialRenderer<TileCorruptionCleaner>
{
    public void doRender(final TileCorruptionCleaner tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        if (tile.cleared != null) {
            GlStateManager.func_179094_E();
            final float[] o = { (float)tile.cleared.func_177958_n(), tile.cleared.func_177956_o() + 1.45f, (float)tile.cleared.func_177952_p() };
            GlStateManager.func_179121_F();
            final float f21 = 0.0f + partialTicks;
            float f22 = MathHelper.func_76126_a(f21 * 0.2f) / 2.0f + 0.5f;
            f22 = (f22 * f22 + f22) * 0.2f;
            GlStateManager.func_179094_E();
            final float f23 = o[0] - tile.func_174877_v().func_177958_n();
            final float f24 = (float)(o[1] - (double)(f22 + tile.func_174877_v().func_177956_o() + 1.3f));
            final float f25 = o[2] - tile.func_174877_v().func_177952_p();
            GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 0.5f, (float)z + 0.5f);
            final float f26 = MathHelper.func_76129_c(f23 * f23 + f25 * f25);
            final float f27 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25);
            GlStateManager.func_179114_b((float)(-Math.atan2(f25, f23)) * 180.0f / 3.1415927f - 90.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.func_179114_b((float)(-Math.atan2(f26, f24)) * 180.0f / 3.1415927f - 90.0f, 1.0f, 0.0f, 0.0f);
            final TessellatorWrapper tessellator = TessellatorWrapper.getInstance();
            RenderHelper.func_74518_a();
            GlStateManager.func_179092_a(516, 0.1f);
            GlStateManager.func_179129_p();
            DrawUtils.bindTexture("essentialcraft", "textures/special/mru_beam.png");
            GlStateManager.func_179103_j(7425);
            GlStateManager.func_179147_l();
            GlStateManager.func_179112_b(770, 1);
            GlStateManager.func_179118_c();
            final float f28 = 1.0f;
            final float f29 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25) / 32.0f - (PlayerTickHandler.tickAmount + partialTicks) * 0.1f;
            GlStateManager.func_179131_c(0.0f, 1.0f, 1.0f, 1.0f);
            tessellator.startDrawing(5);
            final byte b0 = 8;
            for (int i = 0; i <= b0; ++i) {
                final float f30 = MathHelper.func_76126_a(i % b0 * 3.1415927f * 2.0f / b0) * 0.75f * 0.1f;
                final float f31 = MathHelper.func_76134_b(i % b0 * 3.1415927f * 2.0f / b0) * 0.75f * 0.1f;
                final float f32 = i % b0 * 1.0f / b0;
                tessellator.addVertexWithUV((double)f30, (double)f31, 0.0, (double)f32, (double)f29);
                tessellator.addVertexWithUV((double)f30, (double)f31, (double)f27, (double)f32, (double)f28);
            }
            tessellator.draw();
            GlStateManager.func_179089_o();
            GlStateManager.func_179084_k();
            GlStateManager.func_179103_j(7424);
            GlStateManager.func_179141_d();
            RenderHelper.func_74519_b();
            GlStateManager.func_179121_F();
        }
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileCorruptionCleaner tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    public boolean isGlobalRenderer(final TileCorruptionCleaner te) {
        return true;
    }
}
