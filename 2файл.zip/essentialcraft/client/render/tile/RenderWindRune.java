package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderWindRune extends TileEntitySpecialRenderer<TileWindRune>
{
    public static final ResourceLocation rune;
    public static final IModelCustom model;
    
    public void doRender(final TileWindRune p, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderWindRune.rune);
        GlStateManager.func_179137_b(x + 0.5, y - 0.20000000298023224, z + 0.5);
        if (p.tier == -1) {
            GlStateManager.func_179121_F();
            return;
        }
        float movement = (p.func_145831_w().func_72820_D() + partialTicks) % 60.0f + partialTicks;
        if (movement > 30.0f) {
            movement = 60.0f - movement;
        }
        float c = movement / 30.0f;
        if (c < 0.2f) {
            c = 0.2f;
        }
        if (p.tier == 0) {
            GlStateManager.func_179124_c(c, c, c);
        }
        GlStateManager.func_179114_b(45.0f, 0.0f, 1.0f, 0.0f);
        RenderWindRune.model.renderPart("pPlane1");
        GlStateManager.func_179121_F();
    }
    
    public void render(final TileWindRune tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    public boolean isGlobalRenderer(final TileWindRune te) {
        return true;
    }
    
    static {
        rune = new ResourceLocation("essentialcraft:textures/models/windrune.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/rune.obj"));
    }
}
