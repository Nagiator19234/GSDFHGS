package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderChargingChamber extends TileEntitySpecialRenderer<TileChargingChamber>
{
    public void doRender(final TileChargingChamber tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        float rotation = (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f;
        float upperIndex = (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f;
        if (upperIndex < 180.0f) {
            upperIndex = 180.0f - upperIndex;
        }
        else {
            upperIndex -= 180.0f;
        }
        rotation += 360.0f / (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f;
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.65f + upperIndex / 500.0f, 0.5f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileChargingChamber tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
}
