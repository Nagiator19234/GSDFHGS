package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMIM extends TileEntitySpecialRenderer<TileMIM>
{
    public static final ResourceLocation textures;
    public static final ResourceLocation vtextures;
    public static final IModelCustom model;
    
    public void doRender(final TileMIM t, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y, (float)z + 0.5f);
        GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
        this.func_147499_a(RenderMIM.vtextures);
        RenderMIM.model.renderPart("Cube.001_Cube.002");
        RenderMIM.model.renderPart("Cube_Cube.001");
        GlStateManager.func_179114_b(t.innerRotation + partialTicks, 0.0f, 1.0f, 0.0f);
        this.func_147499_a(RenderMIM.textures);
        RenderMIM.model.renderPart("Cube.002_Cube.003");
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMIM tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        textures = new ResourceLocation("essentialcraft:textures/blocks/mimcube.png");
        vtextures = new ResourceLocation("essentialcraft:textures/blocks/voidstone.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/mim.obj"));
    }
}
