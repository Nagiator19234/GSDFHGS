package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderDarknessObelisk extends TileEntitySpecialRenderer<TileDarknessObelisk>
{
    public static final ResourceLocation rune;
    public static final IModelCustom model;
    public static final ResourceLocation obelisk;
    public static final IModelCustom modelObelisk;
    
    public void doRender(final TileEntity tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        final float lightLevel = tile.func_145831_w().func_175724_o(tile.func_174877_v());
        GlStateManager.func_179147_l();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f - lightLevel / 15.0f);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderDarknessObelisk.rune);
        GlStateManager.func_179137_b(x + 0.5, y, z + 0.5);
        float upperRotationIndex = (tile.func_145831_w().func_72820_D() + partialTicks) % 100.0f;
        if (upperRotationIndex > 50.0f) {
            upperRotationIndex = 50.0f - upperRotationIndex + 50.0f;
        }
        GlStateManager.func_179109_b(0.0f, upperRotationIndex / 200.0f - 0.1f, 0.0f);
        GlStateManager.func_179114_b(System.currentTimeMillis() / 50.0f % 360.0f, 0.0f, 1.0f, 0.0f);
        RenderDarknessObelisk.model.renderPart("pPlane1");
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileDarknessObelisk tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        rune = new ResourceLocation("essentialcraft:textures/models/darknessrune.png");
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/rune.obj"));
        obelisk = new ResourceLocation("essentialcraft:textures/models/darknessobelisk.png");
        modelObelisk = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/darknessobelisk.obj"));
    }
}
