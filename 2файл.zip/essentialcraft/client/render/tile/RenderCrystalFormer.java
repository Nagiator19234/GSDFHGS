package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderCrystalFormer extends TileEntitySpecialRenderer<TileCrystalFormer>
{
    public void doRender(final TileCrystalFormer tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        final float scale = 0.5f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.8f, (float)y + 1.1f, (float)z + 0.5f);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        this.func_147499_a(RenderElementalCrystal.neutral);
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.2f, (float)y + 1.1f, (float)z + 0.5f);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        this.func_147499_a(RenderElementalCrystal.neutral);
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 1.1f, (float)z + 0.8f);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        this.func_147499_a(RenderElementalCrystal.neutral);
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 1.1f, (float)z + 0.2f);
        GlStateManager.func_179152_a(scale, scale, scale);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        this.func_147499_a(RenderElementalCrystal.neutral);
        RenderElementalCrystal.crystal.renderModel(0.0625f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileCrystalFormer tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
}
