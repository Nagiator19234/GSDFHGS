package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import essentialcraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderRayTower extends TileEntitySpecialRenderer<TileRayTower>
{
    private static final ResourceLocation enderCrystalTextures;
    private ModelFloatingCube model;
    
    public RenderRayTower() {
        this.model = new ModelFloatingCube(0.0f, true);
    }
    
    public void doRender(final TileRayTower tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        final float f2 = tile.innerRotation + partialTicks;
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 1.6f, (float)z + 0.5f);
        this.func_147499_a(RenderRayTower.enderCrystalTextures);
        float f3 = MathHelper.func_76126_a(f2 * 0.2f) / 2.0f + 0.5f;
        f3 += f3 * f3;
        GlStateManager.func_179152_a(0.4f, 0.4f, 0.4f);
        this.model.render(tile, 0.0f, f2 * 3.0f, 0.35f, 0.0f, 0.0f, 0.0625f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileRayTower tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        if (tile.func_145832_p() == 0) {
            this.doRender(tile, x, y, z, partialTicks);
        }
    }
    
    static {
        enderCrystalTextures = new ResourceLocation("essentialcraft:textures/entities/raycrystal.png");
    }
}
