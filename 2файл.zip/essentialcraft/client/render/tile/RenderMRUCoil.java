package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import essentialcraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;
import net.minecraft.tileentity.*;

@SideOnly(Side.CLIENT)
public class RenderMRUCoil extends TileEntitySpecialRenderer<TileMRUCoil>
{
    private static final ResourceLocation enderCrystalTextures;
    private ModelFloatingCube model;
    
    public RenderMRUCoil() {
        this.model = new ModelFloatingCube(0.0f, true);
    }
    
    public void doRender(final TileMRUCoil tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        final float f2 = tile.innerRotation + partialTicks;
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x + 0.5f, (float)y + 0.6f, (float)z + 0.5f);
        this.func_147499_a(RenderMRUCoil.enderCrystalTextures);
        float f3 = MathHelper.func_76126_a(f2 * 0.2f) / 2.0f + 0.5f;
        f3 += f3 * f3;
        GlStateManager.func_179152_a(0.2f, 0.2f, 0.2f);
        this.model.render(tile, 0.0f, f2 * 3.0f, 0.35f, 0.0f, 0.0f, 0.0625f);
        if (tile.localLightning != null) {
            tile.localLightning.render(x, y, z, partialTicks);
        }
        GlStateManager.func_179121_F();
        GlStateManager.func_179094_E();
        if (tile.monsterLightning != null) {
            tile.monsterLightning.render(x, y, z, partialTicks);
        }
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMRUCoil tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    public boolean isGlobalRenderer(final TileMRUCoil te) {
        return true;
    }
    
    static {
        enderCrystalTextures = new ResourceLocation("essentialcraft:textures/entities/raycrystal.png");
    }
}
