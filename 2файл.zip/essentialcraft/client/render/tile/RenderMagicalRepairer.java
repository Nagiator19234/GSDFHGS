package essentialcraft.client.render.tile;

import net.minecraft.client.renderer.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;
import DummyCore.Utils.*;
import net.minecraft.tileentity.*;
import DummyCore.Client.*;

@SideOnly(Side.CLIENT)
public class RenderMagicalRepairer extends TileEntitySpecialRenderer<TileMagicalRepairer>
{
    public static final IModelCustom model;
    public static final ResourceLocation textures;
    
    public void doRender(final TileMagicalRepairer tile, final double x, final double y, final double z, final float partialTicks) {
        RenderHelper.func_74518_a();
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderMagicalRepairer.textures);
        RenderMagicalRepairer.model.renderAll();
        GlStateManager.func_179121_F();
        final float rotation = (tile.func_145831_w().func_72820_D() + partialTicks) % 360.0f;
        GlStateManager.func_179094_E();
        DrawUtils.renderItemStack_Full(tile.func_70301_a(1), x, y, z, rotation, 0.0f, 1.0f, 1.0f, 1.0f, 0.5f, 0.65f, 0.5f);
        GlStateManager.func_179121_F();
        RenderHelper.func_74519_b();
    }
    
    public void render(final TileMagicalRepairer tile, final double x, final double y, final double z, final float partialTicks, final int destroyStage, final float alpha) {
        this.doRender(tile, x, y, z, partialTicks);
    }
    
    static {
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft:models/block/magicalrepairer.obj"));
        textures = new ResourceLocation("essentialcraft:textures/models/magicalrepairer.png");
    }
}
