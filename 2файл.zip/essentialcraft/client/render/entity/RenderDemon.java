package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import essentialcraft.client.model.*;
import net.minecraft.client.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.client.renderer.entity.*;

@SideOnly(Side.CLIENT)
public class RenderDemon extends RenderLiving<EntityDemon>
{
    private static final ResourceLocation endermanEyesTexture;
    private static final ResourceLocation endermanTextures;
    private ModelDemon endermanModel;
    
    public RenderDemon() {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)new ModelDemon(1.0f, 0.0f, 64, 32), 0.5f);
        this.endermanModel = (ModelDemon)super.field_77045_g;
    }
    
    public RenderDemon(final RenderManager rm) {
        super(rm, (ModelBase)new ModelDemon(1.0f, 0.0f, 64, 32), 0.5f);
        this.endermanModel = (ModelDemon)super.field_77045_g;
    }
    
    protected void preRenderCallback(final EntityDemon entity, final float partialTicks) {
        final float s = 1.4f;
        GlStateManager.func_179152_a(s, s, s);
    }
    
    public void doRender(final EntityDemon entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        super.func_76986_a((EntityLiving)entity, x, y, z, entityYaw, partialTicks);
    }
    
    protected ResourceLocation getEntityTexture(final EntityDemon entity) {
        return RenderDemon.endermanTextures;
    }
    
    protected int shouldRenderPass(final EntityDemon entity, final int pass, final float partialTicks) {
        if (pass != 0) {
            return -1;
        }
        this.func_110776_a(RenderDemon.endermanEyesTexture);
        final float f1 = 1.0f;
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179112_b(1, 1);
        GlStateManager.func_179140_f();
        if (entity.func_82150_aj()) {
            GlStateManager.func_179132_a(false);
        }
        else {
            GlStateManager.func_179132_a(true);
        }
        final char c0 = '\uf0f0';
        final int j = c0 % 65536;
        final int k = c0 / 65536;
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, j / 1.0f, k / 1.0f);
        GlStateManager.func_179145_e();
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, f1);
        return 1;
    }
    
    static {
        endermanEyesTexture = new ResourceLocation("essentialcraft", "textures/entities/demon_eyes.png");
        endermanTextures = new ResourceLocation("essentialcraft", "textures/entities/demon.png");
    }
    
    public static class Factory implements IRenderFactory<EntityDemon>
    {
        public Render<? super EntityDemon> createRenderFor(final RenderManager manager) {
            return (Render<? super EntityDemon>)new RenderDemon(manager);
        }
    }
}
