package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;

public class RenderMRURay extends Render<EntityMRURay>
{
    private static final ResourceLocation field_147523_b;
    
    public RenderMRURay(final RenderManager renderManager) {
        super(renderManager);
    }
    
    public void doRender(final EntityMRURay entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        final EntityMRURay ray = entity;
        if (ray.pX == 0.0 && ray.pY == 0.0 && ray.pZ == 0.0) {
            return;
        }
        float r = 0.0f;
        float g = 1.0f;
        float b = 1.0f;
        if (ray.balance == 1.0f) {
            r = 1.0f;
            g = 0.0f;
            b = 0.0f;
        }
        if (ray.balance == 2.0f) {
            r = 0.0f;
            g = 0.0f;
            b = 1.0f;
        }
        if (ray.balance == 3.0f) {
            r = 1.0f;
            g = 0.0f;
            b = 1.0f;
        }
        if (ray.balance == 4.0f) {
            r = 0.3f;
            g = 0.3f;
            b = 0.3f;
        }
        renderBeam(partialTicks, x, y, z, 1.0 - ray.field_70173_aa / 60.0, 0.0, 0.0, ray.pX - ray.field_70165_t, ray.pY - ray.field_70163_u, ray.pZ - ray.field_70161_v, r, g, b, r, g, b, (float)(0.10000000149011612 * (1.0 + ray.field_70173_aa / 60.0)));
    }
    
    protected ResourceLocation getEntityTexture(final EntityMRURay entity) {
        return RenderMRURay.field_147523_b;
    }
    
    public static void renderBeam(final float partialTicks, final double x, final double y, final double z, final double posX, final double posY, final double posZ, final double offsetX, final double offsetY, final double offsetZ, final float colorR, final float colorG, final float colorB, final float colorRB, final float colorGB, final float colorBB, final float size) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179140_f();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(770, 1);
        final float f21 = 0.0f + partialTicks;
        float f22 = MathHelper.func_76126_a(f21 * 0.2f) / 2.0f + 0.5f;
        f22 = (f22 * f22 + f22) * 0.2f;
        final float f23 = (float)offsetX;
        final float f24 = (float)offsetY;
        final float f25 = (float)offsetZ;
        GlStateManager.func_179137_b(x, y + posY, z + posZ);
        final float f26 = MathHelper.func_76129_c(f23 * f23 + f25 * f25);
        final float f27 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25);
        GlStateManager.func_179114_b((float)(-Math.atan2(f25, f23)) * 180.0f / 3.1415927f - 90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b((float)(-Math.atan2(f26, f24)) * 180.0f / 3.1415927f - 90.0f, 1.0f, 0.0f, 0.0f);
        final Tessellator tessellator = Tessellator.func_178181_a();
        RenderHelper.func_74518_a();
        DrawUtils.bindTexture("essentialcraft", "textures/special/mru_beam.png");
        GlStateManager.func_179103_j(7425);
        final float f28 = 1.0f;
        final float f29 = MathHelper.func_76129_c(f23 * f23 + f24 * f24 + f25 * f25) / 32.0f - 1.0E-4f;
        tessellator.func_178180_c().func_181668_a(5, DefaultVertexFormats.field_181709_i);
        final byte b0 = 8;
        for (int i1 = 0; i1 <= b0; ++i1) {
            final float f30 = MathHelper.func_76126_a(i1 % b0 * 3.1415927f * 2.0f / b0) * 0.75f * size;
            final float f31 = MathHelper.func_76134_b(i1 % b0 * 3.1415927f * 2.0f / b0) * 0.75f * size;
            final float f32 = i1 % b0 * 1.0f / b0;
            tessellator.func_178180_c().func_181662_b((double)f30, (double)f31, 0.0).func_187315_a((double)f32, (double)f29).func_181666_a(colorRB, colorGB, colorBB, (float)posX).func_181675_d();
            tessellator.func_178180_c().func_181662_b((double)f30, (double)f31, (double)f27).func_187315_a((double)f32, (double)f28).func_181666_a(colorR, colorG, colorB, (float)posX).func_181675_d();
        }
        tessellator.func_78381_a();
        GlStateManager.func_179112_b(770, 771);
        GlStateManager.func_179084_k();
        GlStateManager.func_179103_j(7424);
        RenderHelper.func_74519_b();
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
    }
    
    static {
        field_147523_b = new ResourceLocation("textures/entity/beacon_beam.png");
    }
    
    public static class Factory implements IRenderFactory<EntityMRURay>
    {
        public Render<? super EntityMRURay> createRenderFor(final RenderManager manager) {
            return new RenderMRURay(manager);
        }
    }
}
