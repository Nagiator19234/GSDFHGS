package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.client.renderer.entity.*;

@SideOnly(Side.CLIENT)
public class RenderPoisonFume extends RenderLiving<EntityPoisonFume>
{
    private static final ResourceLocation villagerTextures;
    
    public RenderPoisonFume() {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)new ModelBiped(0.0f), 0.5f);
    }
    
    public RenderPoisonFume(final RenderManager rm) {
        super(rm, (ModelBase)new ModelBiped(0.0f), 0.5f);
    }
    
    public void doRender(final EntityPoisonFume entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
    }
    
    protected ResourceLocation getEntityTexture(final EntityPoisonFume entity) {
        return RenderPoisonFume.villagerTextures;
    }
    
    protected void preRenderCallback(final EntityPoisonFume entity, final float partialTicks) {
        final float f1 = 0.9375f;
        GlStateManager.func_179152_a(f1, f1, f1);
    }
    
    static {
        villagerTextures = new ResourceLocation("essentialcraft", "textures/entities/windMage_apprentice.png");
    }
    
    public static class Factory implements IRenderFactory<EntityPoisonFume>
    {
        public Render<? super EntityPoisonFume> createRenderFor(final RenderManager manager) {
            return (Render<? super EntityPoisonFume>)new RenderPoisonFume(manager);
        }
    }
}
