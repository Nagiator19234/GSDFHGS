package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.*;
import essentialcraft.utils.common.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.client.renderer.*;
import essentialcraft.client.render.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;

public class RenderMRUPresence extends Render<EntityMRUPresence>
{
    static final float HALF_SQRT_3 = 0.8660254f;
    
    public RenderMRUPresence(final RenderManager renderManager) {
        super(renderManager);
    }
    
    public void doRender(final EntityMRUPresence entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (ECUtils.canPlayerSeeMRU((EntityPlayer)Minecraft.func_71410_x().field_71439_g)) {
            final float index = entity.renderIndex;
            final float stability = entity.mruStorage.getBalance();
            float colorRRender = 0.0f;
            float colorGRender = 1.0f;
            float colorBRender = 1.0f;
            final float colorRNormal = 0.0f;
            final float colorGNormal = 1.0f;
            final float colorBNormal = 1.0f;
            final float colorRChaos = 1.0f;
            final float colorGChaos = 0.0f;
            final float colorBChaos = 0.0f;
            final float colorRFrozen = 0.0f;
            final float colorGFrozen = 0.0f;
            final float colorBFrozen = 1.0f;
            final int mru = entity.mruStorage.getMRU();
            if (stability != 1.0f) {
                if (stability < 1.0f) {
                    float diff = stability;
                    if (diff < 0.01f) {
                        diff = 0.0f;
                    }
                    colorRRender = colorRNormal * diff + colorRFrozen * (1.0f - diff);
                    colorGRender = colorGNormal * diff + colorGFrozen * (1.0f - diff);
                    colorBRender = colorBNormal * diff + colorBFrozen * (1.0f - diff);
                }
                if (stability > 1.0f) {
                    float diff = 2.0f - stability;
                    if (diff < 0.01f) {
                        diff = 0.0f;
                    }
                    colorRRender = colorRNormal * diff + colorRChaos * (1.0f - diff);
                    colorGRender = colorGNormal * diff + colorGChaos * (1.0f - diff);
                    colorBRender = colorBNormal * diff + colorBChaos * (1.0f - diff);
                }
            }
            final Random rand = new Random(432L);
            GlStateManager.func_179094_E();
            GlStateManager.func_179143_c(519);
            GlStateManager.func_179147_l();
            GlStateManager.func_179118_c();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.func_179103_j(7425);
            GlStateManager.func_179131_c(colorRRender, colorGRender, colorBRender, 0.5f);
            GlStateManager.func_179137_b(x, y, z);
            Minecraft.func_71410_x().field_71446_o.func_110577_a(RenderHandlerEC.whitebox);
            GlStateManager.func_179152_a(7.5E-6f * mru, 7.5E-6f * mru, 7.5E-6f * mru);
            for (int i = 0; i < entity.mruStorage.getMRU() / 25; ++i) {
                GlStateManager.func_179114_b(rand.nextFloat() * 360.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.func_179114_b(rand.nextFloat() * 360.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.func_179114_b(rand.nextFloat() * 360.0f + index * 90.0f, 0.0f, 0.0f, 1.0f);
                final float f0 = rand.nextFloat() * 20.0f + 5.0f;
                final float f2 = rand.nextFloat() * 2.0f + 1.0f;
                GlStateManager.func_187447_r(6);
                GlStateManager.func_187435_e(0.0f, 0.0f, 0.0f);
                GlStateManager.func_187435_e(-0.8660254f * f2, f0, -f2 / 2.0f);
                GlStateManager.func_187435_e(0.8660254f * f2, f0, -f2 / 2.0f);
                GlStateManager.func_187435_e(0.0f, f0, f2);
                GlStateManager.func_187435_e(-0.8660254f * f2, f0, -f2 / 2.0f);
                GlStateManager.func_187437_J();
            }
            GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.func_179103_j(7424);
            GlStateManager.func_179084_k();
            GlStateManager.func_179141_d();
            GlStateManager.func_179143_c(515);
            GlStateManager.func_179121_F();
        }
    }
    
    protected ResourceLocation getEntityTexture(final EntityMRUPresence entity) {
        return RenderHandlerEC.whitebox;
    }
    
    public static class Factory implements IRenderFactory<EntityMRUPresence>
    {
        public Render<? super EntityMRUPresence> createRenderFor(final RenderManager manager) {
            return new RenderMRUPresence(manager);
        }
    }
}
