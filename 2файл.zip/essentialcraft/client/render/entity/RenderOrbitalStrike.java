package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.tileentity.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;

public class RenderOrbitalStrike extends Render<EntityOrbitalStrike>
{
    public RenderOrbitalStrike(final RenderManager renderManager) {
        super(renderManager);
    }
    
    public void doRender(final EntityOrbitalStrike e, final double screenX, final double screenY, final double screenZ, final float rotationYaw, final float rotationPitch) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179092_a(516, 0.1f);
        GlStateManager.func_179106_n();
        GlStateManager.func_179140_f();
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0f, 240.0f);
        DrawUtils.bindTexture("minecraft", "textures/entity/beacon_beam.png");
        GlStateManager.func_179109_b(-0.5f, 0.0f, -0.5f);
        TileEntityBeaconRenderer.func_188205_a(screenX, screenY, screenZ, 0.0, 1.0, (double)e.func_130014_f_().func_82737_E(), 0, (int)(255.0 - e.field_70163_u), new float[] { 1.0f, 0.0f, 1.0f }, e.delay / 15.0, e.delay / 6.0);
        GlStateManager.func_179145_e();
        GlStateManager.func_179127_m();
        GlStateManager.func_179121_F();
    }
    
    protected ResourceLocation getEntityTexture(final EntityOrbitalStrike e) {
        return new ResourceLocation("textures/entity/beacon_beam.png");
    }
    
    public static class Factory implements IRenderFactory<EntityOrbitalStrike>
    {
        public Render<? super EntityOrbitalStrike> createRenderFor(final RenderManager manager) {
            return new RenderOrbitalStrike(manager);
        }
    }
}
