package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.*;
import DummyCore.Utils.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import DummyCore.Client.*;
import net.minecraftforge.fml.client.registry.*;

public class RenderDivider extends Render<EntityDivider>
{
    public static final IModelCustom model;
    
    public RenderDivider(final RenderManager renderManager) {
        super(renderManager);
    }
    
    public void doRender(final EntityDivider e, final double x, final double y, final double z, final float partial, final float zero) {
        GlStateManager.func_179094_E();
        RenderHelper.func_74518_a();
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(1, 771);
        DrawUtils.bindTexture("minecraft", "textures/entity/beacon_beam.png");
        GlStateManager.func_179137_b(x, y - 3.0, z);
        GlStateManager.func_179152_a(3.0f, 3.0f, 3.0f);
        GlStateManager.func_179131_c(1.0f, 0.0f, 1.0f, 0.2f);
        RenderDivider.model.renderAll();
        GlStateManager.func_179109_b(0.0f, 2.0f, 0.0f);
        GlStateManager.func_179152_a(-1.0f, -1.0f, -1.0f);
        RenderDivider.model.renderAll();
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        RenderHelper.func_74519_b();
        GlStateManager.func_179121_F();
    }
    
    protected ResourceLocation getEntityTexture(final EntityDivider e) {
        return null;
    }
    
    static {
        model = AdvancedModelLoader.loadModel(new ResourceLocation("essentialcraft", "models/block/sphere.obj"));
    }
    
    public static class Factory implements IRenderFactory<EntityDivider>
    {
        public Render<? super EntityDivider> createRenderFor(final RenderManager manager) {
            return new RenderDivider(manager);
        }
    }
}
