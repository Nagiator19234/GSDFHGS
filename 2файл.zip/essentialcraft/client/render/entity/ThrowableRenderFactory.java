package essentialcraft.client.render.entity;

import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.item.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.entity.*;

public class ThrowableRenderFactory<T extends Entity> implements IRenderFactory<T>
{
    public Item itemToRender;
    
    public ThrowableRenderFactory(final Item i) {
        this.itemToRender = i;
    }
    
    public Render<? super T> createRenderFor(final RenderManager manager) {
        return (Render<? super T>)new RenderSnowball(manager, this.itemToRender, Minecraft.func_71410_x().func_175599_af());
    }
}
