package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.entity.layers.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.client.renderer.entity.*;

@SideOnly(Side.CLIENT)
public class RenderWindMage extends RenderLiving<EntityWindMage>
{
    private static final ResourceLocation APPRENTICE_TEXTURES;
    private static final ResourceLocation NORMAL_TEXTURES;
    private static final ResourceLocation ARCHMAGE_TEXTURES;
    protected ModelBiped villagerModel;
    
    public RenderWindMage() {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)new ModelBiped(0.0f), 0.5f);
        this.villagerModel = (ModelBiped)this.field_77045_g;
        this.func_177094_a((LayerRenderer)new LayerBipedArmor((RenderLivingBase)this));
    }
    
    public RenderWindMage(final RenderManager rm) {
        super(rm, (ModelBase)new ModelBiped(0.0f), 0.5f);
        this.villagerModel = (ModelBiped)this.field_77045_g;
    }
    
    protected ResourceLocation getEntityTexture(final EntityWindMage entity) {
        switch (entity.getType()) {
            default: {
                return RenderWindMage.APPRENTICE_TEXTURES;
            }
            case 1: {
                return RenderWindMage.NORMAL_TEXTURES;
            }
            case 2: {
                return RenderWindMage.ARCHMAGE_TEXTURES;
            }
        }
    }
    
    protected void preRenderCallback(final EntityWindMage entity, final float partialTicks) {
        final float f1 = 0.9375f;
        GlStateManager.func_179152_a(f1, f1, f1);
    }
    
    static {
        APPRENTICE_TEXTURES = new ResourceLocation("essentialcraft", "textures/entities/windMage_apprentice.png");
        NORMAL_TEXTURES = new ResourceLocation("essentialcraft", "textures/entities/windMage.png");
        ARCHMAGE_TEXTURES = new ResourceLocation("essentialcraft", "textures/entities/windMage_archmage.png");
    }
    
    public static class Factory implements IRenderFactory<EntityWindMage>
    {
        public Render<? super EntityWindMage> createRenderFor(final RenderManager manager) {
            return (Render<? super EntityWindMage>)new RenderWindMage(manager);
        }
    }
}
