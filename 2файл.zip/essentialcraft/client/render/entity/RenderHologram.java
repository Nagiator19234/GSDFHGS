package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.client.renderer.entity.*;

@SideOnly(Side.CLIENT)
public class RenderHologram extends RenderBiped<EntityHologram>
{
    private static final ResourceLocation textures;
    private ModelBiped model;
    
    public RenderHologram() {
        super(Minecraft.func_71410_x().func_175598_ae(), new ModelBiped(1.0f, 0.0f, 64, 32), 0.5f);
        this.model = (ModelBiped)super.field_77045_g;
    }
    
    public RenderHologram(final RenderManager rm) {
        super(rm, new ModelBiped(0.0f, 0.0f, 64, 32), 0.5f);
        this.model = (ModelBiped)super.field_77045_g;
    }
    
    protected void preRenderCallback(final EntityHologram entity, final float partialTicks) {
        final float s = 1.0f;
        GlStateManager.func_179152_a(s, s, s);
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(1, 771);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.2f);
    }
    
    protected ResourceLocation getEntityTexture(final EntityHologram entity) {
        return RenderHologram.textures;
    }
    
    public void doRender(final EntityHologram h, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        super.func_76986_a((EntityLiving)h, x, y, z, entityYaw, partialTicks);
        int meta = 76;
        if (h.attackID == -1) {
            meta = 76;
        }
        if (h.attackID == 0) {
            meta = 70;
        }
        if (h.attackID == 1) {
            meta = 73;
        }
        if (h.attackID == 2) {
            meta = 72;
        }
        if (h.attackID == 3) {
            meta = 71;
        }
        DrawUtils.renderItemStack_Full(new ItemStack(ItemsCore.genericItem, 1, meta), x, y, z, (h.field_70173_aa + partialTicks) % 360.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 2.4f, 0.0f);
    }
    
    static {
        textures = new ResourceLocation("essentialcraft", "textures/entities/boss.png");
    }
    
    public static class Factory implements IRenderFactory<EntityHologram>
    {
        public Render<? super EntityHologram> createRenderFor(final RenderManager manager) {
            return (Render<? super EntityHologram>)new RenderHologram(manager);
        }
    }
}
