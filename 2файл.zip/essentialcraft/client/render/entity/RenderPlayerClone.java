package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.model.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.entity.layers.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.resources.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.client.registry.*;
import net.minecraft.client.renderer.entity.*;

@SideOnly(Side.CLIENT)
public class RenderPlayerClone extends RenderBiped<EntityPlayerClone>
{
    private static ResourceLocation textures;
    private ModelBiped model;
    
    public RenderPlayerClone() {
        this(Minecraft.func_71410_x().func_175598_ae());
    }
    
    public RenderPlayerClone(final RenderManager rm) {
        super(rm, new ModelBiped(0.0f, 0.0f, 64, 64), 0.5f);
        this.model = (ModelBiped)super.field_77045_g;
        this.func_177094_a((LayerRenderer)new LayerBipedArmor((RenderLivingBase)this));
    }
    
    protected void preRenderCallback(final EntityPlayerClone entity, final float partialTicks) {
        final float s = 1.0f;
        GlStateManager.func_179152_a(s, s, s);
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(1, 771);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 0.2f);
    }
    
    protected ResourceLocation getEntityTexture(final EntityPlayerClone entity) {
        return RenderPlayerClone.textures;
    }
    
    public void doRender(final EntityPlayerClone entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        RenderPlayerClone.textures = DefaultPlayerSkin.func_177335_a();
        final UUID playerId = entity.getClonedPlayer();
        if (playerId != null) {
            RenderPlayerClone.textures = Minecraft.func_71410_x().func_147114_u().func_175102_a(playerId).func_178837_g();
        }
        super.func_76986_a((EntityLiving)entity, x, y, z, entityYaw, partialTicks);
    }
    
    public static class Factory implements IRenderFactory<EntityPlayerClone>
    {
        public Render<? super EntityPlayerClone> createRenderFor(final RenderManager manager) {
            return (Render<? super EntityPlayerClone>)new RenderPlayerClone(manager);
        }
    }
}
