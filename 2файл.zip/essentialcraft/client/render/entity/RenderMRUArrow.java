package essentialcraft.client.render.entity;

import essentialcraft.common.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.renderer.*;
import net.minecraftforge.fml.client.registry.*;

public class RenderMRUArrow extends Render<EntityMRUArrow>
{
    private static final ResourceLocation arrowTextures;
    
    public RenderMRUArrow(final RenderManager renderManager) {
        super(renderManager);
    }
    
    public void doRender(final EntityMRUArrow entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        this.func_180548_c((Entity)entity);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179094_E();
        GlStateManager.func_179140_f();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks - 90.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks, 0.0f, 0.0f, 1.0f);
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder bufferbuilder = tessellator.func_178180_c();
        GlStateManager.func_179091_B();
        final float f9 = entity.field_70249_b - partialTicks;
        if (f9 > 0.0f) {
            final float f10 = -MathHelper.func_76126_a(f9 * 3.0f) * f9;
            GlStateManager.func_179114_b(f10, 0.0f, 0.0f, 1.0f);
        }
        GlStateManager.func_179114_b(45.0f, 1.0f, 0.0f, 0.0f);
        GlStateManager.func_179152_a(0.05625f, 0.05625f, 0.05625f);
        GlStateManager.func_179109_b(-4.0f, 0.0f, 0.0f);
        if (this.field_188301_f) {
            GlStateManager.func_179142_g();
            GlStateManager.func_187431_e(this.func_188298_c((Entity)entity));
        }
        GlStateManager.func_187432_a(0.05625f, 0.0f, 0.0f);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(-7.0, -2.0, -2.0).func_187315_a(0.0, 0.15625).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, -2.0, 2.0).func_187315_a(0.15625, 0.15625).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, 2.0, 2.0).func_187315_a(0.15625, 0.3125).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, 2.0, -2.0).func_187315_a(0.0, 0.3125).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_187432_a(-0.05625f, 0.0f, 0.0f);
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(-7.0, 2.0, -2.0).func_187315_a(0.0, 0.15625).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, 2.0, 2.0).func_187315_a(0.15625, 0.15625).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, -2.0, 2.0).func_187315_a(0.15625, 0.3125).func_181675_d();
        bufferbuilder.func_181662_b(-7.0, -2.0, -2.0).func_187315_a(0.0, 0.3125).func_181675_d();
        tessellator.func_78381_a();
        for (int j = 0; j < 4; ++j) {
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_187432_a(0.0f, 0.0f, 0.05625f);
            bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
            bufferbuilder.func_181662_b(-8.0, -2.0, 0.0).func_187315_a(0.0, 0.0).func_181675_d();
            bufferbuilder.func_181662_b(8.0, -2.0, 0.0).func_187315_a(0.5, 0.0).func_181675_d();
            bufferbuilder.func_181662_b(8.0, 2.0, 0.0).func_187315_a(0.5, 0.15625).func_181675_d();
            bufferbuilder.func_181662_b(-8.0, 2.0, 0.0).func_187315_a(0.0, 0.15625).func_181675_d();
            tessellator.func_78381_a();
        }
        if (this.field_188301_f) {
            GlStateManager.func_187417_n();
            GlStateManager.func_179119_h();
        }
        GlStateManager.func_179101_C();
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
        super.func_76986_a((Entity)entity, x, y, z, entityYaw, partialTicks);
    }
    
    protected ResourceLocation getEntityTexture(final EntityMRUArrow entity) {
        return RenderMRUArrow.arrowTextures;
    }
    
    static {
        arrowTextures = new ResourceLocation("textures/entity/arrow.png");
    }
    
    public static class Factory implements IRenderFactory<EntityMRUArrow>
    {
        public Render<? super EntityMRUArrow> createRenderFor(final RenderManager manager) {
            return new RenderMRUArrow(manager);
        }
    }
}
