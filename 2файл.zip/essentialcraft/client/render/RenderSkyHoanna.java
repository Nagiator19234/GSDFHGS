package essentialcraft.client.render;

import net.minecraftforge.client.*;
import net.minecraft.util.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.*;
import essentialcraft.utils.common.*;
import net.minecraft.client.renderer.vertex.*;
import java.util.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.*;

public class RenderSkyHoanna extends IRenderHandler
{
    private static final ResourceLocation locationMoonPhasesPng;
    private static final ResourceLocation locationSunPng;
    private static final ResourceLocation locationEndSkyPng;
    
    public void render(final float partialTicks, final WorldClient world, final Minecraft mc) {
        int colorDay = 2175297;
        if (ECUtils.isEventActive("essentialcraft.event.darkness")) {
            colorDay = 0;
        }
        GlStateManager.func_179106_n();
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        RenderHelper.func_74518_a();
        GlStateManager.func_179132_a(false);
        mc.field_71446_o.func_110577_a(RenderSkyHoanna.locationEndSkyPng);
        final Tessellator tessellator = Tessellator.func_178181_a();
        final BufferBuilder BufferBuilder = tessellator.func_178180_c();
        for (int i = 0; i < 6; ++i) {
            GlStateManager.func_179094_E();
            if (i == 1) {
                GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            }
            if (i == 2) {
                GlStateManager.func_179114_b(-90.0f, 1.0f, 0.0f, 0.0f);
            }
            if (i == 3) {
                GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
            }
            if (i == 4) {
                GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
            }
            if (i == 5) {
                GlStateManager.func_179114_b(-90.0f, 0.0f, 0.0f, 1.0f);
            }
            BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
            BufferBuilder.func_181662_b(-100.0, -100.0, -100.0).func_187315_a(0.0, 0.0).func_181669_b((colorDay & 0xFF0000) >> 16, (colorDay & 0xFF00) >> 8, colorDay & 0xFF, 255).func_181675_d();
            BufferBuilder.func_181662_b(-100.0, -100.0, 100.0).func_187315_a(0.0, 16.0).func_181669_b((colorDay & 0xFF0000) >> 16, (colorDay & 0xFF00) >> 8, colorDay & 0xFF, 255).func_181675_d();
            BufferBuilder.func_181662_b(100.0, -100.0, 100.0).func_187315_a(16.0, 16.0).func_181669_b((colorDay & 0xFF0000) >> 16, (colorDay & 0xFF00) >> 8, colorDay & 0xFF, 255).func_181675_d();
            BufferBuilder.func_181662_b(100.0, -100.0, -100.0).func_187315_a(16.0, 0.0).func_181669_b((colorDay & 0xFF0000) >> 16, (colorDay & 0xFF00) >> 8, colorDay & 0xFF, 255).func_181675_d();
            tessellator.func_78381_a();
            GlStateManager.func_179121_F();
        }
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179141_d();
        GlStateManager.func_179090_x();
        final Vec3d Vec3d = world.func_72833_a(mc.func_175606_aa(), partialTicks);
        float f1 = (float)Vec3d.field_72450_a;
        float f2 = (float)Vec3d.field_72448_b;
        float f3 = (float)Vec3d.field_72449_c;
        if (mc.field_71474_y.field_74337_g) {
            final float f4 = (f1 * 30.0f + f2 * 59.0f + f3 * 11.0f) / 100.0f;
            final float f5 = (f1 * 30.0f + f2 * 70.0f) / 100.0f;
            final float f6 = (f1 * 30.0f + f3 * 70.0f) / 100.0f;
            f1 = f4;
            f2 = f5;
            f3 = f6;
        }
        GlStateManager.func_179124_c(f1, f2, f3);
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179127_m();
        GlStateManager.func_179124_c(f1, f2, f3);
        GlStateManager.func_179106_n();
        GlStateManager.func_179118_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        RenderHelper.func_74518_a();
        final float[] afloat = world.field_73011_w.func_76560_a(world.func_72826_c(partialTicks), partialTicks);
        if (afloat != null) {
            GlStateManager.func_179090_x();
            GlStateManager.func_179103_j(7425);
            GlStateManager.func_179094_E();
            GlStateManager.func_179114_b(90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b((MathHelper.func_76126_a(world.func_72929_e(partialTicks)) < 0.0f) ? 180.0f : 0.0f, 0.0f, 0.0f, 1.0f);
            GlStateManager.func_179114_b(90.0f, 0.0f, 0.0f, 1.0f);
            float f6 = afloat[0];
            float f7 = afloat[1];
            float f8 = afloat[2];
            if (mc.field_71474_y.field_74337_g) {
                final float f9 = (f6 * 30.0f + f7 * 59.0f + f8 * 11.0f) / 100.0f;
                final float f10 = (f6 * 30.0f + f7 * 70.0f) / 100.0f;
                final float f11 = (f6 * 30.0f + f8 * 70.0f) / 100.0f;
                f6 = f9;
                f7 = f10;
                f8 = f11;
            }
            BufferBuilder.func_181668_a(6, DefaultVertexFormats.field_181709_i);
            BufferBuilder.func_181662_b(0.0, 100.0, 0.0).func_181666_a(f6, f7, f8, afloat[3]).func_181675_d();
            for (int j = 0; j <= 16; ++j) {
                final float f11 = j * 3.1415927f * 2.0f / 16.0f;
                final float f12 = MathHelper.func_76126_a(f11);
                final float f13 = MathHelper.func_76134_b(f11);
                BufferBuilder.func_181662_b((double)(f12 * 120.0f), (double)(f13 * 120.0f), (double)(-f13 * 40.0f * afloat[3])).func_181666_a(afloat[0], afloat[1], afloat[2], 0.0f).func_181675_d();
            }
            tessellator.func_78381_a();
            GlStateManager.func_179121_F();
            GlStateManager.func_179103_j(7424);
        }
        GlStateManager.func_179098_w();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179094_E();
        float f6 = 1.0f - world.func_72867_j(partialTicks);
        float f7 = 0.0f;
        float f8 = 0.0f;
        final float f9 = 0.0f;
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, f6);
        GlStateManager.func_179109_b(f7, f8, f9);
        final Random sunRnd = new Random(54263524L);
        final boolean b = ECUtils.isEventActive("essentialcraft.event.sunArray");
        int mod = 1;
        if (b) {
            mod = 3;
        }
        if (!ECUtils.isEventActive("essentialcraft.event.darkness")) {
            for (int k = 0; k < 10 * mod; ++k) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179114_b(-90.0f + k * 30.0f, 0.0f + k * k, k - 1.0f / k / k, 1.0f * k * k);
                GlStateManager.func_179114_b(world.func_72826_c(partialTicks) * 360.0f * k, 1.0f, 0.0f, 0.0f);
                final float f10 = sunRnd.nextFloat() * 20.0f;
                mc.field_71446_o.func_110577_a(RenderSkyHoanna.locationSunPng);
                for (int x = 0; x < k + 5; ++x) {
                    BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                    final float fR = sunRnd.nextFloat();
                    final float fG = sunRnd.nextFloat();
                    final float fB = sunRnd.nextFloat();
                    final float fA = sunRnd.nextFloat();
                    BufferBuilder.func_181662_b((double)(-f10), 100.0, (double)(-f10)).func_187315_a(0.0, 0.0).func_181666_a(fR, fG, fB, fA).func_181675_d();
                    BufferBuilder.func_181662_b((double)f10, 100.0, (double)(-f10)).func_187315_a(1.0, 0.0).func_181666_a(fR, fG, fB, fA).func_181675_d();
                    BufferBuilder.func_181662_b((double)f10, 100.0, (double)f10).func_187315_a(1.0, 1.0).func_181666_a(fR, fG, fB, fA).func_181675_d();
                    BufferBuilder.func_181662_b((double)(-f10), 100.0, (double)f10).func_187315_a(0.0, 1.0).func_181666_a(fR, fG, fB, fA).func_181675_d();
                    tessellator.func_78381_a();
                }
                GlStateManager.func_179121_F();
            }
        }
        final Random moonRnd = new Random(23564637563453L);
        if (!ECUtils.isEventActive("essentialcraft.event.darkness")) {
            for (int l = 0; l < 6; ++l) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179114_b(-90.0f + l * 30.0f, 0.0f + l * l, l - 1.0f / l / l, 1.0f * l * l);
                GlStateManager.func_179114_b(world.func_72826_c(partialTicks) * 360.0f * l, 1.0f, 0.0f, 0.0f);
                final float f10 = moonRnd.nextFloat() * 30.0f;
                mc.field_71446_o.func_110577_a(RenderSkyHoanna.locationMoonPhasesPng);
                for (int x2 = 0; x2 < 2 * l; ++x2) {
                    final int m = moonRnd.nextInt(8);
                    final int l2 = m % 4;
                    final int i2 = m / 4 % 2;
                    final float f14 = (l2 + 0) / 4.0f;
                    final float f15 = (i2 + 0) / 2.0f;
                    final float f16 = (l2 + 1) / 4.0f;
                    final float f17 = (i2 + 1) / 2.0f;
                    BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181709_i);
                    final float fR2 = moonRnd.nextFloat();
                    final float fG2 = moonRnd.nextFloat();
                    final float fB2 = moonRnd.nextFloat();
                    final float fA2 = moonRnd.nextFloat();
                    BufferBuilder.func_181662_b((double)(-f10), -100.0, (double)f10).func_187315_a((double)f16, (double)f17).func_181666_a(fR2, fG2, fB2, fA2).func_181675_d();
                    BufferBuilder.func_181662_b((double)f10, -100.0, (double)f10).func_187315_a((double)f14, (double)f17).func_181666_a(fR2, fG2, fB2, fA2).func_181675_d();
                    BufferBuilder.func_181662_b((double)f10, -100.0, (double)(-f10)).func_187315_a((double)f14, (double)f15).func_181666_a(fR2, fG2, fB2, fA2).func_181675_d();
                    BufferBuilder.func_181662_b((double)(-f10), -100.0, (double)(-f10)).func_187315_a((double)f16, (double)f15).func_181666_a(fR2, fG2, fB2, fA2).func_181675_d();
                    tessellator.func_78381_a();
                }
                GlStateManager.func_179121_F();
            }
        }
        GlStateManager.func_179090_x();
        final float f18 = world.func_72880_h(partialTicks) * f6;
        if (f18 > 0.0f) {
            GlStateManager.func_179131_c(f18, f18, f18, f18);
        }
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179127_m();
        GlStateManager.func_179121_F();
        GlStateManager.func_179090_x();
        GlStateManager.func_179124_c(0.0f, 0.0f, 0.0f);
        final double d0 = mc.field_71439_g.func_174824_e(partialTicks).field_72448_b - world.func_72919_O();
        if (d0 < 0.0) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.0f, 12.0f, 0.0f);
            GlStateManager.func_179121_F();
            final float f19 = -(float)(d0 + 65.0);
            BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
            BufferBuilder.func_181662_b(-1.0, (double)f19, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f19, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f19, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f19, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f19, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, (double)f19, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f19, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, (double)f19, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(-1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, 1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            BufferBuilder.func_181662_b(1.0, -1.0, -1.0).func_181669_b(0, 0, 0, 255).func_181675_d();
            tessellator.func_78381_a();
        }
        if (world.field_73011_w.func_76561_g()) {
            GlStateManager.func_179124_c(f1 * 0.2f + 0.04f, f2 * 0.2f + 0.04f, f3 * 0.6f + 0.1f);
        }
        else {
            GlStateManager.func_179124_c(f1, f2, f3);
        }
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(0.0f, -(float)(d0 - 16.0), 0.0f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179098_w();
        GlStateManager.func_179132_a(true);
    }
    
    static {
        locationMoonPhasesPng = new ResourceLocation("textures/environment/moon_phases.png");
        locationSunPng = new ResourceLocation("textures/environment/sun.png");
        locationEndSkyPng = new ResourceLocation("textures/environment/end_sky.png");
    }
}
