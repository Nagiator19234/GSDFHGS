package essentialcraft.client.particle;

import net.minecraft.client.particle.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import essentialcraft.utils.common.*;
import net.minecraft.entity.player.*;

public class ParticleMRU extends Particle
{
    private double mruPosX;
    private double mruPosY;
    private double mruPosZ;
    public float tickPos;
    private static final ResourceLocation particleTextures;
    private static final ResourceLocation ecparticleTextures;
    
    public ParticleMRU(final World w, final double x, final double y, final double z, final double i, final double j, final double k) {
        super(w, x, y, z, i, j, k);
        this.field_187129_i = i;
        this.field_187130_j = j;
        this.field_187131_k = k;
        this.field_187126_f = x;
        this.mruPosX = x;
        this.field_187127_g = y;
        this.mruPosY = y;
        this.field_187128_h = z;
        this.mruPosZ = z;
        this.field_187136_p.nextFloat();
        this.field_70544_f = 0.5f;
        this.field_70552_h = 0.0f;
        this.field_70553_i = 0.0f;
        this.field_70551_j = 0.8f;
        this.field_82339_as = 0.99f;
        this.field_70547_e = (int)(Math.random() * 10.0) + 40;
        this.field_190017_n = true;
        this.func_70536_a((int)(Math.random() * 8.0));
    }
    
    public ParticleMRU(final World w, final double x, final double y, final double z, final double i, final double j, final double k, final double cR, final double cG, final double cB) {
        this(w, x, y, z, i, j, k);
        this.field_70552_h = (float)cR;
        this.field_70553_i = (float)cG;
        this.field_70551_j = (float)cB;
    }
    
    public boolean func_187111_c() {
        return true;
    }
    
    public void func_180434_a(final BufferBuilder var1, final Entity var2, final float par2, final float par3, final float par4, final float par5, final float par6, final float par7) {
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleMRU.ecparticleTextures);
        final boolean enabled = GL11.glIsEnabled(3042);
        GlStateManager.func_179147_l();
        if (ECUtils.canPlayerSeeMRU((EntityPlayer)Minecraft.func_71410_x().field_71439_g)) {
            final float sc = this.field_70544_f;
            final float cR = this.field_70552_h;
            final float cG = this.field_70553_i;
            final float cB = this.field_70551_j;
            final float cA = this.field_82339_as;
            this.field_70544_f *= 1.5f;
            this.field_70552_h = 1.0f;
            this.field_70553_i = 0.0f;
            this.field_70551_j = 1.0f;
            this.field_82339_as = 0.99f;
            super.func_180434_a(var1, var2, par2, par3, par4, par5, par6, par7);
            this.field_70544_f = sc;
            this.field_70552_h = cR;
            this.field_70553_i = cG;
            this.field_70551_j = cB;
            this.field_82339_as = cA;
            super.func_180434_a(var1, var2, par2, par3, par4, par5, par6, par7);
        }
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleMRU.particleTextures);
        if (!enabled) {
            GlStateManager.func_179084_k();
        }
    }
    
    public int func_189214_a(final float partialTick) {
        return 255;
    }
    
    public float getBrightness(final float partialTick) {
        final float f1 = (float)super.func_189214_a(partialTick);
        float f2 = this.field_70546_d / (float)this.field_70547_e;
        f2 *= f2 * f2 * f2;
        return f1 * (1.0f - f2) + f2;
    }
    
    public void func_189213_a() {
        this.tickPos += 15.0f + this.field_187122_b.field_73012_v.nextFloat() * 15.0f;
        if (this.field_70546_d < this.field_70547_e / 2) {
            this.func_70536_a(7 - this.field_70546_d * 8 / (this.field_70547_e / 2));
        }
        else {
            this.func_70536_a((this.field_70546_d - this.field_70547_e / 2) * 8 / (this.field_70547_e / 2));
        }
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        final float f = this.field_70546_d / (float)this.field_70547_e;
        this.field_187126_f = this.mruPosX + this.field_187129_i * f + Math.sin(Math.toRadians(this.tickPos + this.field_187122_b.func_72820_D() * 10L)) / 10.0;
        this.field_187127_g = this.mruPosY + this.field_187130_j * f + Math.cos(Math.toRadians(this.tickPos + this.field_187122_b.func_72820_D() * 10L)) / 10.0;
        this.field_187128_h = this.mruPosZ + this.field_187131_k * f - Math.sin(Math.toRadians(this.tickPos + this.field_187122_b.func_72820_D() * 10L)) / 10.0;
        if (this.field_70546_d++ >= this.field_70547_e) {
            this.func_187112_i();
        }
    }
    
    static {
        particleTextures = new ResourceLocation("textures/particle/particles.png");
        ecparticleTextures = new ResourceLocation("essentialcraft", "textures/special/particles.png");
    }
}
