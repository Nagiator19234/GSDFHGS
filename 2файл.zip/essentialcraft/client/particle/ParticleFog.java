package essentialcraft.client.particle;

import net.minecraft.client.particle.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;

public class ParticleFog extends Particle
{
    private double mruPosX;
    private double mruPosY;
    private double mruPosZ;
    public double red;
    public double green;
    public double blue;
    public static final ResourceLocation rec;
    private static final ResourceLocation particleTextures;
    
    public ParticleFog(final World w, final double x, final double y, final double z, final double i, final double j, final double k) {
        super(w, x, y, z, i, j, k);
        if (w != null && w.field_73012_v != null) {
            this.field_187129_i = MathUtils.randomDouble(w.field_73012_v);
            this.field_187130_j = MathUtils.randomDouble(w.field_73012_v);
            this.field_187131_k = MathUtils.randomDouble(w.field_73012_v);
            this.red = i;
            this.green = j;
            this.blue = k;
            this.field_187126_f = x;
            this.mruPosX = x;
            this.field_187127_g = y;
            this.mruPosY = y;
            this.field_187128_h = z;
            this.mruPosZ = z;
            this.field_187136_p.nextFloat();
            this.field_70544_f = 10.0f;
            this.field_70552_h = (float)this.red;
            this.field_70553_i = (float)this.green;
            this.field_70551_j = (float)this.blue;
            this.field_82339_as = 0.99f;
            this.field_70547_e = (int)(Math.random() * 10.0) + 100;
            this.field_190017_n = true;
            this.func_70536_a((int)(Math.random() * 8.0));
        }
    }
    
    public void func_180434_a(final BufferBuilder var1, final Entity var2, final float partialTicks, final float rotationX, final float rotationZ, final float rotationYZ, final float rotationXY, final float rotationXZ) {
        final TessellatorWrapper var3 = TessellatorWrapper.getInstance();
        var3.draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleFog.rec);
        final boolean enabled = GL11.glIsEnabled(3042);
        GlStateManager.func_179147_l();
        super.func_180434_a(var1, var2, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
        var3.draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleFog.particleTextures);
        if (!enabled) {
            GlStateManager.func_179084_k();
        }
    }
    
    public int func_189214_a(final float partialTick) {
        final int i = super.func_189214_a(partialTick);
        float f1 = this.field_70546_d / (float)this.field_70547_e;
        f1 *= f1;
        f1 *= f1;
        final int j = i & 0xFF;
        int k = i >> 16 & 0xFF;
        k += (int)(f1 * 15.0f * 16.0f);
        if (k > 240) {
            k = 240;
        }
        return j | k << 16;
    }
    
    public float getBrightness(final float partialTick) {
        final float f1 = (float)super.func_189214_a(partialTick);
        float f2 = this.field_70546_d / (float)this.field_70547_e;
        f2 *= f2 * f2 * f2;
        return f1 * (1.0f - f2) + f2;
    }
    
    public void func_189213_a() {
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        final float f = this.field_70546_d / (float)this.field_70547_e;
        this.field_187126_f = this.mruPosX + this.field_187129_i * f;
        this.field_187127_g = this.mruPosY + this.field_187130_j * f;
        this.field_187128_h = this.mruPosZ + this.field_187131_k * f;
        this.field_70544_f *= 1.01f;
        if (this.field_70546_d++ >= this.field_70547_e) {
            this.func_187112_i();
        }
    }
    
    static {
        rec = new ResourceLocation("essentialcraft", "textures/items/particles/fog.png");
        particleTextures = new ResourceLocation("textures/particle/particles.png");
    }
}
