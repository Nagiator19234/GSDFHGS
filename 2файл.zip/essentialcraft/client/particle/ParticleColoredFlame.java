package essentialcraft.client.particle;

import net.minecraft.client.particle.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.*;

public class ParticleColoredFlame extends Particle
{
    private float flameScale;
    private static final ResourceLocation particleTextures;
    private static final ResourceLocation ecparticleTextures;
    
    public ParticleColoredFlame(final World w, final double x, final double y, final double z, final double mX, final double mY, final double mZ) {
        super(w, x, y, z, mX, mY, mZ);
        this.field_187129_i = this.field_187129_i * 0.01 + mX;
        this.field_187130_j = this.field_187130_j * 0.01 + mY;
        this.field_187131_k = this.field_187131_k * 0.01 + mZ;
        this.flameScale = this.field_70544_f;
        final float field_70552_h = 1.0f;
        this.field_70551_j = field_70552_h;
        this.field_70553_i = field_70552_h;
        this.field_70552_h = field_70552_h;
        this.field_82339_as = 0.99f;
        this.field_70547_e = (int)(8.0 / (Math.random() * 0.8 + 0.2)) + 4;
        this.field_190017_n = true;
        this.func_70536_a(48);
    }
    
    public boolean func_187111_c() {
        return true;
    }
    
    public ParticleColoredFlame(final World w, final double x, final double y, final double z, final double mX, final double mY, final double mZ, final double r, final double g, final double b, final double scale) {
        super(w, x, y, z, mX, mY, mZ);
        this.field_187129_i = this.field_187129_i * 0.01 + mX;
        this.field_187130_j = this.field_187130_j * 0.01 + mY;
        this.field_187131_k = this.field_187131_k * 0.01 + mZ;
        this.flameScale = (float)scale;
        this.field_70552_h = (float)r;
        this.field_70553_i = (float)g;
        this.field_70551_j = (float)b;
        this.field_82339_as = 0.99f;
        this.field_70547_e = (int)(8.0 / (Math.random() * 0.8 + 0.2)) + 4;
        this.field_190017_n = true;
        this.func_70536_a(48);
    }
    
    public void func_180434_a(final BufferBuilder buffer, final Entity entity, final float partialTicks, final float rotationX, final float rotationZ, final float rotationYZ, final float rotationXY, final float rotationXZ) {
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleColoredFlame.ecparticleTextures);
        final float f6 = (this.field_70546_d + partialTicks) / this.field_70547_e;
        this.field_70544_f = this.flameScale * (1.0f - f6 * f6 * 0.5f);
        super.func_180434_a(buffer, entity, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleColoredFlame.particleTextures);
    }
    
    public int func_189214_a(final float partialTick) {
        float f1 = (this.field_70546_d + partialTick) / this.field_70547_e;
        if (f1 < 0.0f) {
            f1 = 0.0f;
        }
        if (f1 > 1.0f) {
            f1 = 1.0f;
        }
        final int i = super.func_189214_a(partialTick);
        int j = i & 0xFF;
        final int k = i >> 16 & 0xFF;
        j += (int)(f1 * 15.0f * 16.0f);
        if (j > 240) {
            j = 240;
        }
        return j | k << 16;
    }
    
    public float getBrightness(final float partialTick) {
        float f1 = (this.field_70546_d + partialTick) / this.field_70547_e;
        if (f1 < 0.0f) {
            f1 = 0.0f;
        }
        if (f1 > 1.0f) {
            f1 = 1.0f;
        }
        final float f2 = (float)super.func_189214_a(partialTick);
        return f2 * f1 + (1.0f - f1);
    }
    
    public void func_189213_a() {
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        if (this.field_70546_d++ >= this.field_70547_e) {
            this.func_187112_i();
        }
        this.func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
        this.field_187129_i *= 0.96;
        this.field_187130_j *= 0.96;
        this.field_187131_k *= 0.96;
        if (this.field_187132_l) {
            this.field_187129_i *= 0.7;
            this.field_187131_k *= 0.7;
        }
    }
    
    static {
        particleTextures = new ResourceLocation("textures/particle/particles.png");
        ecparticleTextures = new ResourceLocation("essentialcraft", "textures/special/particles.png");
    }
}
