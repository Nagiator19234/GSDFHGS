package essentialcraft.client.particle;

import net.minecraft.client.particle.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.*;
import net.minecraft.client.renderer.*;
import org.lwjgl.opengl.*;

public class ParticleSmokeEC extends ParticleSmokeNormal
{
    private static final ResourceLocation particleTextures;
    private static final ResourceLocation ecparticleTextures;
    
    public ParticleSmokeEC(final World w, final double x, final double y, final double z, final double mX, final double mY, final double mZ, final float scale) {
        super(w, x, y, z, mX, mY, mZ, scale);
        this.field_82339_as = 0.99f;
    }
    
    public ParticleSmokeEC(final World w, final double x, final double y, final double z, final double mX, final double mY, final double mZ, final float scale, final double r, final double g, final double b) {
        this(w, x, y, z, mX, mY, mZ, scale);
        this.field_70552_h = (float)r;
        this.field_70553_i = (float)g;
        this.field_70551_j = (float)b;
    }
    
    public boolean func_187111_c() {
        return true;
    }
    
    public void func_180434_a(final BufferBuilder var1, final Entity var2, final float par2, final float par3, final float par4, final float par5, final float par6, final float par7) {
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleSmokeEC.ecparticleTextures);
        GlStateManager.func_179094_E();
        final boolean enabled = GL11.glIsEnabled(3042);
        GlStateManager.func_179147_l();
        super.func_180434_a(var1, var2, par2, par3, par4, par5, par6, par7);
        TessellatorWrapper.getInstance().draw().begin(7, DefaultVertexFormats.field_181704_d);
        Minecraft.func_71410_x().field_71446_o.func_110577_a(ParticleSmokeEC.particleTextures);
        if (!enabled) {
            GlStateManager.func_179084_k();
        }
        GlStateManager.func_179121_F();
    }
    
    static {
        particleTextures = new ResourceLocation("textures/particle/particles.png");
        ecparticleTextures = new ResourceLocation("essentialcraft", "textures/special/particles.png");
    }
}
