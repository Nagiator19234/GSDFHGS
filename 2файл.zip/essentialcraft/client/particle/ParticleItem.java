package essentialcraft.client.particle;

import net.minecraft.client.particle.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import java.util.*;
import net.minecraft.client.renderer.*;

public class ParticleItem extends Particle
{
    static final float HALF_SQRT_3 = 0.8660254f;
    public double red;
    public double green;
    public double blue;
    
    public ParticleItem(final World w, final double x, final double y, final double z, final double r, final double g, final double b, final double mX, final double mY, final double mZ) {
        super(w, x, y, z, 0.0, 0.0, 0.0);
        this.red = r;
        this.green = g;
        this.blue = b;
        this.field_187129_i = mX / 20.0;
        this.field_187130_j = mY / 20.0;
        this.field_187131_k = mZ / 20.0;
        this.field_70547_e = 25;
    }
    
    public void func_180434_a(final BufferBuilder var1, final Entity var2, final float x, final float y, final float z, final float u1, final float u2, final float u3) {
        this.field_190017_n = true;
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        final float f11 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * x - ParticleItem.field_70556_an);
        final float f12 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * x - ParticleItem.field_70554_ao);
        final float f13 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * x - ParticleItem.field_70555_ap);
        final Random var3 = new Random((long)(this.field_187126_f * 100.0 + this.field_187127_g * 100.0 + this.field_187128_h * 100.0));
        GlStateManager.func_179103_j(7425);
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(f11, f12, f13);
        final int mru = 200;
        GlStateManager.func_179152_a(7.5E-6f * mru, 7.5E-6f * mru, 7.5E-6f * mru);
        GlStateManager.func_179131_c((float)this.red, (float)this.green, (float)this.blue, 1.0f);
        for (int var4 = 0; var4 < 100; ++var4) {
            GlStateManager.func_179114_b(var3.nextFloat() * 360.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(var3.nextFloat() * 360.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.func_179114_b(var3.nextFloat() * 360.0f + 90.0f, 0.0f, 0.0f, 1.0f);
            final float var5 = var3.nextFloat() * 20.0f + 15.0f;
            final float var6 = var3.nextFloat() * 2.0f + 3.0f;
            GlStateManager.func_187447_r(6);
            GlStateManager.func_187435_e(0.0f, 0.0f, 0.0f);
            GlStateManager.func_187435_e(-0.8660254f * var6, var5, -var6 / 2.0f);
            GlStateManager.func_187435_e(0.8660254f * var6, var5, -var6 / 2.0f);
            GlStateManager.func_187435_e(0.0f, var5, var6);
            GlStateManager.func_187435_e(-0.8660254f * var6, var5, -var6 / 2.0f);
            GlStateManager.func_187437_J();
        }
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.func_179121_F();
        GlStateManager.func_179103_j(7424);
    }
}
