package essentialcraft.common.capabilities.espe;

import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import java.util.concurrent.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;

public class CapabilityESPEHandler
{
    @CapabilityInject(IESPEHandler.class)
    public static Capability<IESPEHandler> ESPE_HANDLER_CAPABILITY;
    @CapabilityInject(IESPEHandlerItem.class)
    public static Capability<IESPEHandlerItem> ESPE_HANDLER_ITEM_CAPABILITY;
    
    public static void register() {
        CapabilityManager.INSTANCE.register((Class)IESPEHandler.class, (Capability.IStorage)new DefaultESPEHandlerStorage(), (Callable)ESPEStorage::new);
        CapabilityManager.INSTANCE.register((Class)IESPEHandlerItem.class, (Capability.IStorage)new DefaultESPEHandlerStorage(), (Callable)ESPEItemStorage::new);
    }
    
    static {
        CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY = null;
        CapabilityESPEHandler.ESPE_HANDLER_ITEM_CAPABILITY = null;
    }
    
    private static class DefaultESPEHandlerStorage<T extends IESPEHandler> implements Capability.IStorage<T>
    {
        public NBTBase writeNBT(final Capability<T> capability, final T instance, final EnumFacing side) {
            final NBTTagCompound nbt = new NBTTagCompound();
            return (NBTBase)instance.writeToNBT(nbt);
        }
        
        public void readNBT(final Capability<T> capability, final T instance, final EnumFacing side, final NBTBase base) {
            instance.readFromNBT((NBTTagCompound)base);
        }
    }
}
