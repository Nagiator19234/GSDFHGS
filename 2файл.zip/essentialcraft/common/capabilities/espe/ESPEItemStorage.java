package essentialcraft.common.capabilities.espe;

import essentialcraft.api.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.common.capabilities.mru.*;

public class ESPEItemStorage extends ESPEStorage implements IESPEHandlerItem, ICapabilityProvider
{
    protected boolean storage;
    protected ItemStack storageStack;
    protected final boolean storageSettable;
    protected NBTTagCompound prevNBT;
    
    protected ESPEItemStorage() {
        this.storage = false;
        this.prevNBT = null;
        this.storageSettable = true;
    }
    
    public ESPEItemStorage(final ItemStack storageStack) {
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final double maxESPE) {
        super(maxESPE);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final int tier) {
        super(tier);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final double maxESPE, final int tier) {
        super(maxESPE, tier);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final boolean storage) {
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final double maxESPE, final boolean storage) {
        super(maxESPE);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final int tier, final boolean storage) {
        super(tier);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public ESPEItemStorage(final ItemStack storageStack, final double maxESPE, final int tier, final boolean storage) {
        super(maxESPE, tier);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    @Override
    public double getMaxESPE() {
        this.readIfChanged();
        return super.getMaxESPE();
    }
    
    @Override
    public void setMaxESPE(final double amount) {
        this.readIfChanged();
        super.setMaxESPE(amount);
        this.writeIfChanged();
    }
    
    @Override
    public double getESPE() {
        this.readIfChanged();
        return super.getESPE();
    }
    
    @Override
    public void setESPE(final double amount) {
        this.readIfChanged();
        super.setESPE(amount);
        this.writeIfChanged();
    }
    
    @Override
    public double addESPE(final double amount, final boolean doAdd) {
        this.readIfChanged();
        final double ret = super.addESPE(amount, doAdd);
        this.writeIfChanged();
        return ret;
    }
    
    @Override
    public double extractESPE(final double amount, final boolean doExtract) {
        this.readIfChanged();
        final double ret = super.extractESPE(amount, doExtract);
        this.writeIfChanged();
        return ret;
    }
    
    @Override
    public int getTier() {
        this.readIfChanged();
        return super.getTier();
    }
    
    @Override
    public void setTier(final int tier) {
        this.readIfChanged();
        super.setTier(tier);
        this.writeIfChanged();
    }
    
    @Override
    public boolean getStorage() {
        this.readIfChanged();
        return this.storage;
    }
    
    @Override
    public void setStorage(final boolean storage) {
        this.readIfChanged();
        if (this.storageSettable) {
            this.storage = storage;
        }
        this.writeIfChanged();
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        if (this.storageSettable) {
            this.storage = nbt.func_74767_n("storage");
        }
    }
    
    protected void writeIfChanged() {
        final NBTTagCompound nbt = this.writeToNBT(this.storageStack.func_77978_p().func_74737_b());
        if (!nbt.equals((Object)this.prevNBT)) {
            this.storageStack.func_77982_d(nbt);
            this.prevNBT = nbt.func_74737_b();
        }
    }
    
    protected void readIfChanged() {
        final NBTTagCompound nbt = this.storageStack.func_77978_p();
        if (!nbt.equals((Object)this.prevNBT)) {
            this.readFromNBT(nbt);
            this.prevNBT = nbt.func_74737_b();
        }
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY) ? this : null);
    }
}
