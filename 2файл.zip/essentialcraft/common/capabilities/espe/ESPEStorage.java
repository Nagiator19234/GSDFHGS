package essentialcraft.common.capabilities.espe;

import essentialcraft.api.*;
import net.minecraft.nbt.*;

public class ESPEStorage implements IESPEHandler
{
    protected double maxESPE;
    protected double espe;
    protected int tier;
    protected final boolean maxESPESettable;
    protected final boolean tierSettable;
    
    public ESPEStorage() {
        this.maxESPE = 10000.0;
        this.espe = 0.0;
        this.tier = 0;
        this.maxESPESettable = true;
        this.tierSettable = true;
    }
    
    public ESPEStorage(final double maxESPE) {
        this.maxESPE = 10000.0;
        this.espe = 0.0;
        this.tier = 0;
        this.maxESPE = maxESPE;
        this.maxESPESettable = false;
        this.tierSettable = true;
    }
    
    public ESPEStorage(final int tier) {
        this.maxESPE = 10000.0;
        this.espe = 0.0;
        this.tier = 0;
        this.tier = tier;
        this.maxESPESettable = true;
        this.tierSettable = false;
    }
    
    public ESPEStorage(final double maxESPE, final int tier) {
        this.maxESPE = 10000.0;
        this.espe = 0.0;
        this.tier = 0;
        this.maxESPE = maxESPE;
        this.tier = tier;
        this.maxESPESettable = false;
        this.tierSettable = false;
    }
    
    @Override
    public double getMaxESPE() {
        return this.maxESPE;
    }
    
    @Override
    public void setMaxESPE(final double amount) {
        if (this.maxESPESettable) {
            this.maxESPE = amount;
        }
    }
    
    @Override
    public double getESPE() {
        return this.espe;
    }
    
    @Override
    public void setESPE(final double amount) {
        this.espe = amount;
    }
    
    @Override
    public double addESPE(final double amount, final boolean doAdd) {
        if (amount <= 0.0) {
            return amount;
        }
        if (this.espe + amount >= this.maxESPE) {
            final double ret = this.espe + amount - this.maxESPE;
            if (doAdd) {
                this.espe = this.maxESPE;
            }
            return ret;
        }
        if (doAdd) {
            this.espe += amount;
        }
        return 0.0;
    }
    
    @Override
    public double extractESPE(final double amount, final boolean doExtract) {
        if (amount <= 0.0) {
            return 0.0;
        }
        if (this.espe - amount <= 0.0) {
            final double ret = this.espe;
            if (doExtract) {
                this.espe = 0.0;
            }
            return ret;
        }
        if (doExtract) {
            this.espe -= amount;
        }
        return amount;
    }
    
    @Override
    public int getTier() {
        return this.tier;
    }
    
    @Override
    public void setTier(final int tier) {
        if (this.tierSettable) {
            this.tier = tier;
        }
    }
    
    @Override
    public NBTTagCompound writeToNBT(final NBTTagCompound nbt) {
        if (this.maxESPESettable) {
            nbt.func_74780_a("maxESPE", this.maxESPE);
        }
        nbt.func_74780_a("espe", this.espe);
        if (this.tierSettable) {
            nbt.func_74768_a("tier", this.tier);
        }
        return nbt;
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbt) {
        if (this.maxESPESettable) {
            this.maxESPE = nbt.func_74769_h("maxESPE");
        }
        this.espe = nbt.func_74769_h("espe");
        if (this.tierSettable) {
            this.tier = nbt.func_74762_e("tier");
        }
        if (nbt.func_74764_b("energy")) {
            this.espe = nbt.func_74760_g("energy");
        }
    }
}
