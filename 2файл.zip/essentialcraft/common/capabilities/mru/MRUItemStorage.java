package essentialcraft.common.capabilities.mru;

import essentialcraft.api.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;

public class MRUItemStorage extends MRUStorage implements IMRUHandlerItem, ICapabilityProvider
{
    protected boolean storage;
    protected ItemStack storageStack;
    protected final boolean storageSettable;
    protected NBTTagCompound prevNBT;
    
    protected MRUItemStorage() {
        this.storage = false;
        this.prevNBT = null;
        this.storageSettable = true;
    }
    
    public MRUItemStorage(final ItemStack storageStack) {
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public MRUItemStorage(final ItemStack storageStack, final int maxMRU) {
        super(maxMRU);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storageSettable = true;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public MRUItemStorage(final ItemStack storageStack, final boolean storage) {
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    public MRUItemStorage(final ItemStack storageStack, final int maxMRU, final boolean storage) {
        super(maxMRU);
        this.storage = false;
        this.prevNBT = null;
        this.storageStack = storageStack;
        this.storage = storage;
        this.storageSettable = false;
        MiscUtils.createNBTTag(this.storageStack);
    }
    
    @Override
    public int getMaxMRU() {
        this.readIfChanged();
        return super.getMaxMRU();
    }
    
    @Override
    public void setMaxMRU(final int amount) {
        this.readIfChanged();
        super.setMaxMRU(amount);
        this.writeIfChanged();
    }
    
    @Override
    public int getMRU() {
        this.readIfChanged();
        return super.getMRU();
    }
    
    @Override
    public void setMRU(final int amount) {
        this.readIfChanged();
        super.setMRU(amount);
        this.writeIfChanged();
    }
    
    @Override
    public int addMRU(final int amount, final boolean doAdd) {
        this.readIfChanged();
        final int ret = super.addMRU(amount, doAdd);
        this.writeIfChanged();
        return ret;
    }
    
    @Override
    public int extractMRU(final int amount, final boolean doExtract) {
        this.readIfChanged();
        final int ret = super.extractMRU(amount, doExtract);
        this.writeIfChanged();
        return ret;
    }
    
    @Override
    public float getBalance() {
        this.readIfChanged();
        return super.getBalance();
    }
    
    @Override
    public void setBalance(final float balance) {
        this.readIfChanged();
        super.setBalance(balance);
        this.writeIfChanged();
    }
    
    @Override
    public boolean getShade() {
        this.readIfChanged();
        return super.getShade();
    }
    
    @Override
    public void setShade(final boolean shade) {
        this.readIfChanged();
        super.setShade(shade);
        this.writeIfChanged();
    }
    
    @Override
    public boolean getStorage() {
        this.readIfChanged();
        return this.storage;
    }
    
    @Override
    public void setStorage(final boolean storage) {
        this.readIfChanged();
        if (this.storageSettable) {
            this.storage = storage;
        }
        this.writeIfChanged();
    }
    
    @Override
    public NBTTagCompound writeToNBT(final NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        if (this.storageSettable) {
            nbt.func_74757_a("storage", this.storage);
        }
        return nbt;
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        if (this.storageSettable) {
            this.storage = nbt.func_74767_n("storage");
        }
    }
    
    protected void writeIfChanged() {
        final NBTTagCompound nbt = this.writeToNBT(this.storageStack.func_77978_p().func_74737_b());
        if (!nbt.equals((Object)this.prevNBT)) {
            this.storageStack.func_77982_d(nbt);
            this.prevNBT = nbt.func_74737_b();
        }
    }
    
    protected void readIfChanged() {
        final NBTTagCompound nbt = this.storageStack.func_77978_p();
        if (!nbt.equals((Object)this.prevNBT)) {
            this.readFromNBT(nbt);
            this.prevNBT = nbt.func_74737_b();
        }
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY) ? this : null);
    }
}
