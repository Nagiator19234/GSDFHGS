package essentialcraft.common.capabilities.mru;

import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import java.util.concurrent.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;

public class CapabilityMRUHandler
{
    @CapabilityInject(IMRUHandler.class)
    public static Capability<IMRUHandler> MRU_HANDLER_CAPABILITY;
    @CapabilityInject(IMRUHandlerItem.class)
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    @CapabilityInject(IMRUHandlerEntity.class)
    public static Capability<IMRUHandlerEntity> MRU_HANDLER_ENTITY_CAPABILITY;
    
    public static void register() {
        CapabilityManager.INSTANCE.register((Class)IMRUHandler.class, (Capability.IStorage)new DefaultMRUHandlerStorage(), (Callable)MRUStorage::new);
        CapabilityManager.INSTANCE.register((Class)IMRUHandlerItem.class, (Capability.IStorage)new DefaultMRUHandlerStorage(), (Callable)MRUItemStorage::new);
        CapabilityManager.INSTANCE.register((Class)IMRUHandlerEntity.class, (Capability.IStorage)new DefaultMRUHandlerStorage(), (Callable)MRUEntityStorage::new);
    }
    
    static {
        CapabilityMRUHandler.MRU_HANDLER_CAPABILITY = null;
        CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY = null;
        CapabilityMRUHandler.MRU_HANDLER_ENTITY_CAPABILITY = null;
    }
    
    private static class DefaultMRUHandlerStorage<T extends IMRUHandler> implements Capability.IStorage<T>
    {
        public NBTBase writeNBT(final Capability<T> capability, final T instance, final EnumFacing side) {
            final NBTTagCompound nbt = new NBTTagCompound();
            return (NBTBase)instance.writeToNBT(nbt);
        }
        
        public void readNBT(final Capability<T> capability, final T instance, final EnumFacing side, final NBTBase base) {
            instance.readFromNBT((NBTTagCompound)base);
        }
    }
}
