package essentialcraft.common.capabilities.mru;

import essentialcraft.api.*;
import net.minecraft.nbt.*;

public class MRUEntityStorage extends MRUStorage implements IMRUHandlerEntity
{
    protected boolean flag;
    protected boolean stay;
    
    public MRUEntityStorage() {
        this.flag = false;
        this.stay = true;
    }
    
    public MRUEntityStorage(final int maxMRU) {
        super(maxMRU);
        this.flag = false;
        this.stay = true;
    }
    
    @Override
    public boolean getFlag() {
        return this.flag;
    }
    
    @Override
    public void setFlag(final boolean flag) {
        this.flag = flag;
    }
    
    @Override
    public boolean canAlwaysStay() {
        return this.stay;
    }
    
    @Override
    public void setAlwaysStay(final boolean stay) {
        this.stay = stay;
    }
    
    @Override
    public NBTTagCompound writeToNBT(final NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        nbt.func_74757_a("flag", this.getFlag());
        nbt.func_74757_a("stay", this.canAlwaysStay());
        return nbt;
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        this.setFlag(nbt.func_74767_n("flag"));
        this.setAlwaysStay(nbt.func_74767_n("stay"));
        if (nbt.func_74764_b("Balance")) {
            this.balance = nbt.func_74760_g("Balance");
        }
    }
}
