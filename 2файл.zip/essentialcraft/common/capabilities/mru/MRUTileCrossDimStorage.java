package essentialcraft.common.capabilities.mru;

import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.api.*;
import DummyCore.Utils.*;

public class MRUTileCrossDimStorage extends MRUTileStorage
{
    public MRUTileCrossDimStorage() {
    }
    
    public MRUTileCrossDimStorage(final int maxMRU) {
        super(maxMRU);
    }
    
    @Override
    public void mruIn(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            final BlockPos o2 = new BlockPos(o[0], o[1], o[2]);
            if (getDimension(boundGem) == world.field_73011_w.getDimension()) {
                if (!pos.equals((Object)o2) && world.func_175625_s(o2) != null && world.func_175625_s(o2).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IMRUHandler other = (IMRUHandler)world.func_175625_s(o2).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
                    if (this.getMRU() < this.getMaxMRU()) {
                        final int req = this.getMaxMRU() - this.getMRU();
                        final int extracted = other.extractMRU(req, true);
                        this.setBalance((other.getBalance() * extracted + this.getBalance() * this.getMRU()) / (extracted + this.getMRU()));
                        this.addMRU(extracted, true);
                    }
                }
            }
            else if (!world.field_72995_K) {
                final World worldOther = (World)world.func_73046_m().func_71218_a(getDimension(boundGem));
                if (worldOther != null && worldOther.func_175625_s(o2) != null && worldOther.func_175625_s(o2).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IMRUHandler other2 = (IMRUHandler)worldOther.func_175625_s(o2).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
                    if (this.getMRU() < this.getMaxMRU()) {
                        final int req2 = this.getMaxMRU() - this.getMRU();
                        final int extracted2 = other2.extractMRU(req2, true);
                        this.setBalance((other2.getBalance() * extracted2 + this.getBalance() * this.getMRU()) / (extracted2 + this.getMRU()));
                        this.addMRU(extracted2, true);
                    }
                }
            }
        }
    }
    
    @Override
    public void spawnMRUParticles(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (world.field_72995_K && boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null && getDimension(boundGem) == world.field_73011_w.getDimension()) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            final BlockPos pos2 = new BlockPos(o[0], o[1], o[2]);
            this.doSpawnMRUParticles(pos, pos2, world);
        }
    }
    
    static int getDimension(final ItemStack stack) {
        return MiscUtils.getStackTag(stack).func_74762_e("dim");
    }
}
