package essentialcraft.common.capabilities.mru;

import essentialcraft.api.*;
import net.minecraft.nbt.*;

public class MRUStorage implements IMRUHandler
{
    protected int maxMRU;
    protected int mru;
    protected float balance;
    protected boolean shade;
    protected final boolean maxMRUSettable;
    
    public MRUStorage() {
        this.maxMRU = 5000;
        this.mru = 0;
        this.balance = 1.0f;
        this.shade = false;
        this.maxMRUSettable = true;
    }
    
    public MRUStorage(final int maxMRU) {
        this.maxMRU = 5000;
        this.mru = 0;
        this.balance = 1.0f;
        this.shade = false;
        this.maxMRU = maxMRU;
        this.maxMRUSettable = false;
    }
    
    @Override
    public int getMaxMRU() {
        return this.maxMRU;
    }
    
    @Override
    public void setMaxMRU(final int amount) {
        if (this.maxMRUSettable && amount >= 0) {
            this.maxMRU = amount;
        }
    }
    
    @Override
    public int getMRU() {
        return this.mru;
    }
    
    @Override
    public void setMRU(final int amount) {
        if (amount <= 0) {
            this.mru = 0;
        }
        else if (amount >= this.maxMRU) {
            this.mru = this.maxMRU;
        }
        else {
            this.mru = amount;
        }
    }
    
    @Override
    public int addMRU(final int amount, final boolean doAdd) {
        if (amount <= 0) {
            return amount;
        }
        if (this.mru + amount >= this.maxMRU) {
            final int ret = this.mru + amount - this.maxMRU;
            if (doAdd) {
                this.mru = this.maxMRU;
            }
            return ret;
        }
        if (doAdd) {
            this.mru += amount;
        }
        return 0;
    }
    
    @Override
    public int extractMRU(final int amount, final boolean doExtract) {
        if (amount <= 0) {
            return 0;
        }
        if (this.mru - amount <= 0) {
            final int ret = this.mru;
            if (doExtract) {
                this.mru = 0;
            }
            return ret;
        }
        if (doExtract) {
            this.mru -= amount;
        }
        return amount;
    }
    
    @Override
    public float getBalance() {
        return this.balance;
    }
    
    @Override
    public void setBalance(final float balance) {
        if (balance <= 0.0f) {
            this.balance = 0.0f;
        }
        else if (balance >= 2.0f) {
            this.balance = 2.0f;
        }
        else {
            this.balance = balance;
        }
    }
    
    @Override
    public boolean getShade() {
        return this.shade;
    }
    
    @Override
    public void setShade(final boolean shade) {
        this.shade = shade;
    }
    
    @Override
    public NBTTagCompound writeToNBT(final NBTTagCompound nbt) {
        if (this.maxMRUSettable) {
            nbt.func_74768_a("maxMRU", this.maxMRU);
        }
        nbt.func_74768_a("mru", this.mru);
        nbt.func_74776_a("balance", this.balance);
        nbt.func_74757_a("shade", this.shade);
        return nbt;
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbt) {
        if (this.maxMRUSettable) {
            this.maxMRU = nbt.func_74762_e("maxMRU");
        }
        this.mru = nbt.func_74762_e("mru");
        this.balance = nbt.func_74760_g("balance");
        this.shade = nbt.func_74767_n("shade");
    }
}
