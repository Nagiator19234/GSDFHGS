package essentialcraft.common.capabilities.mru;

import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.api.*;

public class MRUTileRangelessStorage extends MRUTileStorage
{
    public MRUTileRangelessStorage() {
        this.setRange(Integer.MAX_VALUE);
    }
    
    public MRUTileRangelessStorage(final int maxMRU) {
        super(maxMRU);
        this.setRange(Integer.MAX_VALUE);
    }
    
    @Override
    public void mruIn(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            final BlockPos o2 = new BlockPos(o[0], o[1], o[2]);
            if (!pos.equals((Object)o2) && world.func_175625_s(o2) != null && world.func_175625_s(o2).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                final IMRUHandler other = (IMRUHandler)world.func_175625_s(o2).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
                if (this.getMRU() < this.getMaxMRU()) {
                    final int req = this.getMaxMRU() - this.getMRU();
                    final int extracted = other.extractMRU(req, true);
                    if (extracted + this.getMRU() > 0) {
                        this.setBalance((other.getBalance() * extracted + this.getBalance() * this.getMRU()) / (extracted + this.getMRU()));
                    }
                    this.addMRU(extracted, true);
                }
            }
        }
    }
    
    @Override
    public void spawnMRUParticles(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (world.field_72995_K && boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            new BlockPos(o[0], o[1], o[2]);
            final BlockPos pos2 = new BlockPos(o[0], o[1], o[2]);
            this.doSpawnMRUParticles(pos, pos2, world);
        }
    }
}
