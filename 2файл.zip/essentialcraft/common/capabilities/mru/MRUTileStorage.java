package essentialcraft.common.capabilities.mru;

import net.minecraft.item.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import essentialcraft.common.item.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.api.*;
import essentialcraft.common.mod.*;
import essentialcraft.common.tile.*;

public class MRUTileStorage extends MRUStorage implements IWorldUpdatable<ItemStack>
{
    protected int range;
    
    public MRUTileStorage() {
        this.range = 16;
    }
    
    public MRUTileStorage(final int maxMRU) {
        super(maxMRU);
        this.range = 16;
    }
    
    public int getRange() {
        return this.range;
    }
    
    public MRUTileStorage setRange(final int range) {
        this.range = range;
        return this;
    }
    
    @Override
    public void update(final BlockPos pos, final World world, final ItemStack boundGem) {
        this.spawnMRUParticles(pos, world, boundGem);
        this.mruIn(pos, world, boundGem);
    }
    
    public void mruIn(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (!world.field_72995_K && boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            if (MathUtils.getDifference((float)pos.func_177958_n(), (float)o[0]) <= this.range && MathUtils.getDifference((float)pos.func_177956_o(), (float)o[1]) <= this.range && MathUtils.getDifference((float)pos.func_177952_p(), (float)o[2]) <= this.range) {
                final BlockPos o2 = new BlockPos(o[0], o[1], o[2]);
                if (!pos.equals((Object)o2) && world.func_175625_s(o2) != null && world.func_175625_s(o2).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IMRUHandler other = (IMRUHandler)world.func_175625_s(o2).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
                    if (this.getMRU() < this.getMaxMRU()) {
                        final int req = this.getMaxMRU() - this.getMRU();
                        final int extracted = other.extractMRU(req, true);
                        if (extracted + this.getMRU() > 0) {
                            this.setBalance((other.getBalance() * extracted + this.getBalance() * this.getMRU()) / (extracted + this.getMRU()));
                        }
                        this.addMRU(extracted, true);
                    }
                }
            }
        }
    }
    
    public void spawnMRUParticles(final BlockPos pos, final World world, final ItemStack boundGem) {
        if (world.field_72995_K && boundGem.func_77973_b() instanceof ItemBoundGem && boundGem.func_77978_p() != null) {
            final int[] o = ItemBoundGem.getCoords(boundGem);
            if (MathUtils.getDifference((float)pos.func_177958_n(), (float)o[0]) <= this.range && MathUtils.getDifference((float)pos.func_177956_o(), (float)o[1]) <= this.range && MathUtils.getDifference((float)pos.func_177952_p(), (float)o[2]) <= this.range) {
                final BlockPos pos2 = new BlockPos(o[0], o[1], o[2]);
                this.doSpawnMRUParticles(pos, pos2, world);
            }
        }
    }
    
    public void doSpawnMRUParticles(final BlockPos posThis, final BlockPos posOther, final World world) {
        if (world.func_175625_s(posOther) != null && world.func_175625_s(posOther).hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
            final IMRUHandler other = (IMRUHandler)world.func_175625_s(posOther).getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
            final float balance = other.getBalance();
            float colorRRender = 0.0f;
            float colorGRender = 1.0f;
            float colorBRender = 1.0f;
            final float colorRNormal = 0.0f;
            final float colorGNormal = 1.0f;
            final float colorBNormal = 1.0f;
            final float colorRChaos = 1.0f;
            final float colorGChaos = 0.0f;
            final float colorBChaos = 0.0f;
            final float colorRFrozen = 0.0f;
            final float colorGFrozen = 0.0f;
            final float colorBFrozen = 1.0f;
            if (balance != 1.0f) {
                if (balance < 1.0f) {
                    float diff = balance;
                    if (diff < 0.01f) {
                        diff = 0.0f;
                    }
                    colorRRender = colorRNormal * diff + colorRFrozen * (1.0f - diff);
                    colorGRender = colorGNormal * diff + colorGFrozen * (1.0f - diff);
                    colorBRender = colorBNormal * diff + colorBFrozen * (1.0f - diff);
                }
                if (balance > 1.0f) {
                    float diff = 2.0f - balance;
                    if (diff < 0.01f) {
                        diff = 0.0f;
                    }
                    colorRRender = colorRNormal * diff + colorRChaos * (1.0f - diff);
                    colorGRender = colorGNormal * diff + colorGChaos * (1.0f - diff);
                    colorBRender = colorBNormal * diff + colorBChaos * (1.0f - diff);
                }
            }
            if (world.func_175625_s(posThis) instanceof TileRayTower) {
                if (world.func_175625_s(posOther) instanceof TileRayTower) {
                    EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 1.85, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o() + 0.25, posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
                }
                else if (world.func_175625_s(posOther) instanceof TileMRUReactor) {
                    EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 1.1, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o() + 0.8, posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
                }
                else {
                    EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 0.5, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o() + 1.5, posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
                }
            }
            else if (world.func_175625_s(posOther) instanceof TileRayTower) {
                EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 1.85, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o() - 1.5, posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
            }
            else if (world.func_175625_s(posOther) instanceof TileMRUReactor) {
                EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 1.1, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o() - 0.6, posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
            }
            else {
                EssentialCraftCore.proxy.MRUFX(posOther.func_177958_n() + 0.5, posOther.func_177956_o() + 0.5, posOther.func_177952_p() + 0.5, posThis.func_177958_n() - posOther.func_177958_n(), posThis.func_177956_o() - posOther.func_177956_o(), posThis.func_177952_p() - posOther.func_177952_p(), colorRRender, colorGRender, colorBRender);
            }
        }
    }
}
