package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.block.state.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import java.util.*;

public class BlockMithrilineOre extends Block implements IModelRegisterer
{
    public static final PropertyEnum<BlockDropsOre.OreDimensionType> DIMENSION;
    
    public BlockMithrilineOre() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockMithrilineOre.DIMENSION, (Comparable)BlockDropsOre.OreDimensionType.OVERWORLD));
    }
    
    public int getExpDrop(final IBlockState state, final IBlockAccess world, final BlockPos pos, final int fortune) {
        return MathHelper.func_76136_a(BlockMithrilineOre.RANDOM, 0, 2);
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((BlockDropsOre.OreDimensionType)state.func_177229_b((IProperty)BlockMithrilineOre.DIMENSION)).getIndex());
    }
    
    public boolean canSilkHarvest(final World world, final BlockPos pos, final IBlockState state, final EntityPlayer player) {
        return true;
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 3; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public int func_180651_a(final IBlockState state) {
        return 51;
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return ItemsCore.genericItem;
    }
    
    public ArrayList<ItemStack> getDrops(final IBlockAccess world, final BlockPos pos, final IBlockState state, final int fortune) {
        final ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        for (int count = BlockMithrilineOre.RANDOM.nextInt(8 * (fortune + 1)) + 3, i = 0; i < count; ++i) {
            final Item item = this.func_180660_a(state, BlockMithrilineOre.RANDOM, fortune);
            if (item != null) {
                ret.add(new ItemStack(item, 1, this.func_180651_a(state)));
            }
        }
        return ret;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMithrilineOre.DIMENSION, (Comparable)BlockDropsOre.OreDimensionType.fromIndex(meta % 3));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((BlockDropsOre.OreDimensionType)state.func_177229_b((IProperty)BlockMithrilineOre.DIMENSION)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMithrilineOre.DIMENSION });
    }
    
    public void registerModels() {
        for (int i = 0; i < BlockDropsOre.OreDimensionType.values().length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:oremithriline", "dimension=" + BlockDropsOre.OreDimensionType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        DIMENSION = PropertyEnum.func_177709_a("dimension", (Class)BlockDropsOre.OreDimensionType.class);
    }
}
