package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.world.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.state.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import java.util.*;

public class BlockDrops extends Block implements IModelRegisterer
{
    public static final PropertyEnum<EnumDropType> TYPE;
    public static final AxisAlignedBB BLOCK_AABB;
    
    protected BlockDrops() {
        super(Material.field_151580_n, MapColor.field_151660_b);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockDrops.TYPE, (Comparable)EnumDropType.AIR));
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return Block.field_185506_k;
    }
    
    public AxisAlignedBB func_180640_a(final IBlockState state, final World worldIn, final BlockPos pos) {
        return BlockDrops.BLOCK_AABB.func_186670_a(pos);
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 4; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public int func_180651_a(final IBlockState state) {
        return ((EnumDropType)state.func_177229_b((IProperty)BlockDrops.TYPE)).getIndex();
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return ItemsCore.drops;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((EnumDropType)state.func_177229_b((IProperty)BlockDrops.TYPE)).getIndex());
    }
    
    public int func_149745_a(final Random rand) {
        return 1 + rand.nextInt(6);
    }
    
    public ArrayList<ItemStack> getDrops(final IBlockAccess world, final BlockPos pos, final IBlockState state, final int fortune) {
        final ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        for (int count = this.quantityDropped(state, fortune, (world instanceof World) ? ((World)world).field_73012_v : BlockDrops.RANDOM), i = 0; i < count; ++i) {
            final Item item = this.func_180660_a(state, (world instanceof World) ? ((World)world).field_73012_v : BlockDrops.RANDOM, fortune);
            if (item != null) {
                ret.add(new ItemStack(item, 1, this.func_180651_a(state)));
            }
        }
        return ret;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockDrops.TYPE, (Comparable)EnumDropType.fromIndex(meta % 4));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumDropType)state.func_177229_b((IProperty)BlockDrops.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockDrops.TYPE });
    }
    
    public void registerModels() {
        for (int i = 0; i < EnumDropType.CAN_BE_FARMED.length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:drops", "type=" + EnumDropType.CAN_BE_FARMED[i].func_176610_l()));
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177706_a("type", (Class)EnumDropType.class, (Enum[])EnumDropType.CAN_BE_FARMED);
        BLOCK_AABB = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.10000000149011612, 1.0);
    }
}
