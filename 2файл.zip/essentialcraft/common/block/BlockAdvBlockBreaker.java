package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockAdvBlockBreaker extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockAdvBlockBreaker() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockAdvBlockBreaker.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public boolean func_149744_f(final IBlockState s) {
        return true;
    }
    
    public void func_189540_a(final IBlockState s, final World w, final BlockPos p, final Block n, final BlockPos fp) {
        if (w instanceof World && w.func_175687_A(p) > 0) {
            ((TileAdvancedBlockBreaker)w.func_175625_s(p)).breakBlocks();
        }
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public IBlockState func_180642_a(final World worldIn, final BlockPos pos, final EnumFacing facing, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockAdvBlockBreaker.FACING, (Comparable)facing);
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileAdvancedBlockBreaker();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockAdvBlockBreaker.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockAdvBlockBreaker.FACING)).func_176745_a();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockAdvBlockBreaker.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockAdvBlockBreaker.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockAdvBlockBreaker.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockAdvBlockBreaker.FACING });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:advbreaker", "inventory"));
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
}
