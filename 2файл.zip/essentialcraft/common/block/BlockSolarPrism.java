package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockSolarPrism extends BlockContainer implements IModelRegisterer
{
    public static final AxisAlignedBB BLOCK_AABB;
    
    protected BlockSolarPrism() {
        super(Material.field_151576_e, MapColor.field_151647_F);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.TRANSLUCENT;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        return BlockSolarPrism.BLOCK_AABB;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileSolarPrism();
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:solarprism", "inventory"));
    }
    
    static {
        BLOCK_AABB = new AxisAlignedBB(-1.0, 0.4, -1.0, 2.0, 0.6, 2.0);
    }
}
