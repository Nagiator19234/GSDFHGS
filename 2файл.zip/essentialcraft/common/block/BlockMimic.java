package essentialcraft.common.block;

import DummyCore.Client.*;
import DummyCore.Utils.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.block.state.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.*;
import net.minecraftforge.common.property.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.block.material.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.init.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.*;

public class BlockMimic extends BlockContainer implements IModelRegisterer
{
    public static final UnlistedPropertyObject<IBlockState> STATE;
    public static final UnlistedPropertyObject<IBlockAccess> WORLD;
    public static final UnlistedPropertyObject<BlockPos> POS;
    
    public BlockMimic() {
        super(Material.field_151576_e);
    }
    
    public TileEntity func_149915_a(final World worldIn, final int meta) {
        return new TileMimic();
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }
    
    public int func_176201_c(final IBlockState state) {
        return 0;
    }
    
    protected BlockStateContainer func_180661_e() {
        return (BlockStateContainer)new ExtendedBlockState((Block)this, new IProperty[0], new IUnlistedProperty[] { (IUnlistedProperty)BlockMimic.STATE, (IUnlistedProperty)BlockMimic.WORLD, (IUnlistedProperty)BlockMimic.POS });
    }
    
    public IBlockState getExtendedState(IBlockState state, final IBlockAccess world, final BlockPos pos) {
        state = (IBlockState)((IExtendedBlockState)state).withProperty((IUnlistedProperty)BlockMimic.WORLD, (Object)world).withProperty((IUnlistedProperty)BlockMimic.POS, (Object)pos);
        final TileEntity tile = world.func_175625_s(pos);
        if (tile != null && tile instanceof TileMimic) {
            return (IBlockState)((IExtendedBlockState)state).withProperty((IUnlistedProperty)BlockMimic.STATE, (Object)((TileMimic)tile).getState());
        }
        return state;
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean canRenderInLayer(final IBlockState state, final BlockRenderLayer layer) {
        return true;
    }
    
    public boolean func_180639_a(final World worldIn, final BlockPos pos, final IBlockState state, final EntityPlayer playerIn, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final TileEntity tile = worldIn.func_175625_s(pos);
        final ItemStack heldItem = playerIn.func_184586_b(hand);
        if (tile instanceof TileMimic) {
            if (!playerIn.func_70093_af()) {
                if (!heldItem.func_190926_b() && heldItem.func_77973_b() instanceof ItemBlock) {
                    final TileMimic mimic = (TileMimic)tile;
                    final IBlockState changeState = ((ItemBlock)heldItem.func_77973_b()).func_179223_d().func_180642_a(worldIn, pos, side, hitX, hitY, hitZ, heldItem.func_77952_i(), (EntityLivingBase)playerIn);
                    if (isValidBlock(changeState) && changeState.func_177230_c() != this) {
                        mimic.setState(changeState);
                        worldIn.func_175704_b(pos, pos.func_177982_a(1, 1, 1));
                        return true;
                    }
                }
            }
            else {
                final TileMimic mimic = (TileMimic)tile;
                if (mimic.getState() != null) {
                    mimic.setState(null);
                    worldIn.func_175704_b(pos, pos.func_177982_a(1, 1, 1));
                    return true;
                }
            }
        }
        return false;
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        try {
            final TileEntity te = worldIn.func_175625_s(pos);
            if (te instanceof TileMimic && ((TileMimic)te).getState() != null) {
                return ((TileMimic)te).getState().func_185900_c((IBlockAccess)new FakeBlockAccess(worldIn), pos);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return super.func_185496_a(state, worldIn, pos);
    }
    
    public MapColor func_180659_g(final IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        try {
            final TileEntity te = worldIn.func_175625_s(pos);
            if (te instanceof TileMimic && ((TileMimic)te).getState() != null) {
                return ((TileMimic)te).getState().func_185909_g((IBlockAccess)new FakeBlockAccess(worldIn), pos);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return super.func_180659_g(state, worldIn, pos);
    }
    
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return BlockMimic.field_185506_k;
    }
    
    public boolean func_149686_d(final IBlockState state) {
        return false;
    }
    
    public static boolean isValidBlock(final IBlockState state) {
        return state.func_185901_i() == EnumBlockRenderType.MODEL && state.func_185904_a() != Material.field_151579_a;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:mimic", "inventory"));
    }
    
    static {
        STATE = new UnlistedPropertyObject("state", (Class)IBlockState.class);
        WORLD = new UnlistedPropertyObject("world", (Class)IBlockAccess.class);
        POS = new UnlistedPropertyObject("pos", (Class)BlockPos.class);
    }
    
    private static class FakeBlockAccess implements IBlockAccess
    {
        private final IBlockAccess compose;
        
        private FakeBlockAccess(final IBlockAccess compose) {
            this.compose = compose;
        }
        
        public TileEntity func_175625_s(final BlockPos pos) {
            return this.compose.func_175625_s(pos);
        }
        
        public int func_175626_b(final BlockPos pos, final int lightValue) {
            return 15728880;
        }
        
        public IBlockState func_180495_p(final BlockPos pos) {
            IBlockState state = this.compose.func_180495_p(pos);
            if (state.func_177230_c() instanceof BlockMimic) {
                state = ((TileMimic)this.compose.func_175625_s(pos)).getState();
            }
            return (state == null) ? Blocks.field_150350_a.func_176223_P() : state;
        }
        
        public boolean func_175623_d(final BlockPos pos) {
            return this.compose.func_175623_d(pos);
        }
        
        public Biome func_180494_b(final BlockPos pos) {
            return this.compose.func_180494_b(pos);
        }
        
        public int func_175627_a(final BlockPos pos, final EnumFacing direction) {
            return this.compose.func_175627_a(pos, direction);
        }
        
        public WorldType func_175624_G() {
            return this.compose.func_175624_G();
        }
        
        public boolean isSideSolid(final BlockPos pos, final EnumFacing side, final boolean _default) {
            return this.compose.isSideSolid(pos, side, _default);
        }
    }
}
