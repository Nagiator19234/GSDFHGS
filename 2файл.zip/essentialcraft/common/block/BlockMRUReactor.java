package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMRUReactor extends BlockContainer implements IModelRegisterer
{
    public BlockMRUReactor() {
        super(Material.field_151576_e, MapColor.field_151678_z);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World var1, final int var2) {
        return new TileMRUReactor();
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:reactor", "inventory"));
    }
}
