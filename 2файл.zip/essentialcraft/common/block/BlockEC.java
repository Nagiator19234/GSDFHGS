package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.util.*;
import net.minecraft.block.material.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockEC extends Block implements IModelRegisterer
{
    public BlockRenderLayer layer;
    
    public BlockEC(final Material material) {
        super(material);
        this.layer = BlockRenderLayer.SOLID;
    }
    
    public BlockEC(final Material material, final MapColor color) {
        super(material, color);
        this.layer = BlockRenderLayer.SOLID;
    }
    
    public BlockEC(final Material material, final BlockRenderLayer layer) {
        super(material);
        this.layer = BlockRenderLayer.SOLID;
        this.layer = layer;
    }
    
    public BlockEC(final Material material, final MapColor color, final BlockRenderLayer layer) {
        super(material, color);
        this.layer = BlockRenderLayer.SOLID;
        this.layer = layer;
    }
    
    public BlockRenderLayer func_180664_k() {
        return this.layer;
    }
    
    public Block func_149672_a(final SoundType s) {
        return super.func_149672_a(s);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
