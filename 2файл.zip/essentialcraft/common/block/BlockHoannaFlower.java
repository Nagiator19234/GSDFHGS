package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockHoannaFlower extends BlockBush implements IModelRegisterer
{
    public BlockHoannaFlower() {
        this.func_149672_a(SoundType.field_185850_c);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:flowergreen", "inventory"));
    }
}
