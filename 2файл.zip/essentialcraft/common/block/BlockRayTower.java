package essentialcraft.common.block;

import DummyCore.Client.*;
import DummyCore.Utils.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockRayTower extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<EnumLayer> LAYER;
    
    protected BlockRayTower() {
        super(Material.field_151573_f);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockRayTower.LAYER, (Comparable)EnumLayer.BOTTOM));
    }
    
    public void func_176213_c(final World w, final BlockPos p, final IBlockState s) {
        super.func_176213_c(w, p, s);
        if (w.func_175623_d(p.func_177984_a()) && s.func_177229_b((IProperty)BlockRayTower.LAYER) == EnumLayer.BOTTOM) {
            w.func_180501_a(p.func_177984_a(), this.func_176223_P().func_177226_a((IProperty)BlockRayTower.LAYER, (Comparable)EnumLayer.TOP), 3);
        }
    }
    
    public boolean func_176196_c(final World world, final BlockPos pos) {
        return world.func_180495_p(pos).func_177230_c().func_176200_f((IBlockAccess)world, pos) && world.func_175623_d(pos.func_177984_a());
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            if (par3.func_177229_b((IProperty)BlockRayTower.LAYER) == EnumLayer.BOTTOM) {
                player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            }
            else {
                player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o() - 1, par2.func_177952_p());
            }
            return true;
        }
        return true;
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        if (world.func_180495_p(pos.func_177977_b()).func_177230_c() == this) {
            world.func_175698_g(pos.func_177977_b());
        }
        if (world.func_180495_p(pos.func_177984_a()).func_177230_c() == this) {
            world.func_175698_g(pos.func_177984_a());
        }
        super.func_180663_b(world, pos, blockstate);
        world.func_175713_t(pos);
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileRayTower();
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockRayTower.LAYER, (Comparable)EnumLayer.fromIndexTwo(meta % 2));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumLayer)state.func_177229_b((IProperty)BlockRayTower.LAYER)).getIndexTwo();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockRayTower.LAYER });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:raytower", "inventory"));
    }
    
    static {
        LAYER = PropertyEnum.func_177706_a("layer", (Class)EnumLayer.class, (Enum[])EnumLayer.LAYERTWO);
    }
}
