package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMIMScreen extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockMIMScreen() {
        super(Material.field_151576_e, MapColor.field_151678_z);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockMIMScreen.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public boolean func_149744_f(final IBlockState s) {
        return true;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public IBlockState func_180642_a(final World w, final BlockPos p, final EnumFacing side, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMIMScreen.FACING, (Comparable)side);
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileMIMScreen();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMIMScreen.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockMIMScreen.FACING)).func_176745_a();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockMIMScreen.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockMIMScreen.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockMIMScreen.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMIMScreen.FACING });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:mimscreen", "inventory"));
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
}
