package essentialcraft.common.block;

import net.minecraft.block.*;
import essentialcraft.api.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockColdStone extends Block implements IColdBlock, IModelRegisterer
{
    public BlockColdStone() {
        super(Material.field_151588_w);
    }
    
    public float getColdModifier(final IBlockAccess w, final BlockPos pos) {
        return 0.5f;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:coldstone", "inventory"));
    }
}
