package essentialcraft.common.block;

import essentialcraft.api.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.creativetab.*;
import net.minecraft.world.*;
import net.minecraft.block.state.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.statemap.*;

public class BlockFancy extends Block implements IColdBlock, IModelRegisterer
{
    public static final String[] overlays;
    public static final PropertyEnum<FancyBlockType> TYPE;
    
    public BlockFancy(final Material material) {
        super(material);
        if (material == Material.field_151576_e) {
            this.func_149672_a(SoundType.field_185851_d);
        }
        if (material == Material.field_151574_g) {
            this.func_149672_a(SoundType.field_185858_k);
        }
        if (material == Material.field_151571_B || material == Material.field_151578_c) {
            this.func_149672_a(SoundType.field_185849_b);
        }
        if (material == Material.field_151580_n) {
            this.func_149672_a(SoundType.field_185854_g);
        }
        if (material == Material.field_151596_z) {
            this.func_149672_a(SoundType.field_185856_i);
        }
        if (material == Material.field_151575_d) {
            this.func_149672_a(SoundType.field_185848_a);
        }
        if (material == Material.field_151592_s) {
            this.func_149672_a(SoundType.field_185853_f);
        }
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockFancy.TYPE, (Comparable)FancyBlockType.ANCIENT_TILE));
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((FancyBlockType)state.func_177229_b((IProperty)BlockFancy.TYPE)).getIndex());
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 16; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public float getColdModifier(final IBlockAccess w, final BlockPos pos) {
        return (this == BlocksCore.fancyBlocks.get(3)) ? 0.5f : 0.0f;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockFancy.TYPE, (Comparable)FancyBlockType.fromIndex(meta));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((FancyBlockType)state.func_177229_b((IProperty)BlockFancy.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockFancy.TYPE });
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new FancyBlockStateMapper());
        for (int i = 0; i < 16; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:" + this.getRegistryName().func_110623_a().replace('.', '/'), "type=" + FancyBlockType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        overlays = new String[] { "ancientTile", "bigTile", "brick", "fancyTile", "pressuredTile", "smallTiles", "temple", "tiles", "futuristicTile", "machine", "runic", "netherStar", "plate", "packedPlate", "doublePlate", "gem" };
        TYPE = PropertyEnum.func_177709_a("type", (Class)FancyBlockType.class);
    }
    
    public enum FancyBlockType implements IStringSerializable
    {
        ANCIENT_TILE("ancient_tile"), 
        BIG_TILE("big_tile"), 
        BRICK("brick"), 
        FANCY_TILE("fancy_tile"), 
        PRESSURED_TILE("pressured_tile"), 
        SMALL_TILES("small_tiles"), 
        TEMPLE("temple"), 
        TILES("tiles"), 
        FUTURISTIC_TILE("futuristic_tile"), 
        MACHINE("machine"), 
        RUNIC("runic"), 
        NETHER_STAR("nether_star"), 
        PLATE("plate"), 
        PACKED_PLATE("packed_plate"), 
        DOUBLE_PLATE("double_plate"), 
        GEM("gem");
        
        private int index;
        private String name;
        
        private FancyBlockType(final String s) {
            this.index = this.ordinal();
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static FancyBlockType fromIndex(final int i) {
            return values()[i % 16];
        }
    }
    
    public static class FancyBlockStateMapper extends StateMapperBase
    {
        protected ModelResourceLocation func_178132_a(final IBlockState state) {
            return new ModelResourceLocation("essentialcraft:" + state.func_177230_c().getRegistryName().func_110623_a().replace('.', '/'), "type=" + ((FancyBlockType)state.func_177229_b((IProperty)BlockFancy.TYPE)).func_176610_l());
        }
    }
}
