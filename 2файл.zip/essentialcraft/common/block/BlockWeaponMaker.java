package essentialcraft.common.block;

import essentialcraft.api.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.creativetab.*;
import java.util.*;
import net.minecraft.client.util.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.block.state.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraft.item.*;
import DummyCore.Client.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;

public class BlockWeaponMaker extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<GunRegistry.GunType> TYPE;
    
    public BlockWeaponMaker() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockWeaponMaker.TYPE, (Comparable)GunRegistry.GunType.PISTOL));
    }
    
    public int func_180651_a(final IBlockState state) {
        return ((GunRegistry.GunType)state.func_177229_b((IProperty)BlockWeaponMaker.TYPE)).getIndex();
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((GunRegistry.GunType)state.func_177229_b((IProperty)BlockWeaponMaker.TYPE)).getIndex());
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int metadata) {
        return new TileWeaponMaker();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 4; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_190948_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        switch (stack.func_77952_i()) {
            case 0: {
                list.add(new ItemStack(ItemsCore.pistol).func_82833_r());
                break;
            }
            case 1: {
                list.add(new ItemStack(ItemsCore.rifle).func_82833_r());
                break;
            }
            case 2: {
                list.add(new ItemStack(ItemsCore.sniper).func_82833_r());
                break;
            }
            case 3: {
                list.add(new ItemStack(ItemsCore.gatling).func_82833_r());
                break;
            }
        }
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockWeaponMaker.TYPE, (Comparable)GunRegistry.GunType.fromIndex(meta % 4));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((GunRegistry.GunType)state.func_177229_b((IProperty)BlockWeaponMaker.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockWeaponMaker.TYPE });
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockWeaponMaker.TYPE }).func_178441_a());
        ModelLoader.setCustomMeshDefinition(Item.func_150898_a((Block)this), (ItemMeshDefinition)new ModelUtils.MeshDefinitionSingleIcon(new String[] { "essentialcraft:weaponmaker" }));
        ModelBakery.registerItemVariants(Item.func_150898_a((Block)this), new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:weaponmaker", "inventory") });
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)GunRegistry.GunType.class);
    }
}
