package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.properties.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;
import net.minecraft.block.material.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.creativetab.*;
import net.minecraft.entity.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import com.google.common.base.*;
import net.minecraft.util.*;

public class BlockFurnaceMagic extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    public static final PropertyEnum<FurnaceType> TYPE;
    
    public BlockFurnaceMagic() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockFurnaceMagic.FACING, (Comparable)EnumFacing.NORTH).func_177226_a((IProperty)BlockFurnaceMagic.TYPE, (Comparable)FurnaceType.FORTIFIED));
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public MapColor func_180659_g(final IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        return ((FurnaceType)state.func_177229_b((IProperty)BlockFurnaceMagic.TYPE)).getMapColor();
    }
    
    public int func_180651_a(final IBlockState s) {
        return ((FurnaceType)s.func_177229_b((IProperty)BlockFurnaceMagic.TYPE)).getIndex() * 4;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((FurnaceType)state.func_177229_b((IProperty)BlockFurnaceMagic.TYPE)).getIndex() * 4);
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        items.add((Object)new ItemStack((Block)this, 1, 0));
        items.add((Object)new ItemStack((Block)this, 1, 4));
        items.add((Object)new ItemStack((Block)this, 1, 8));
        items.add((Object)new ItemStack((Block)this, 1, 12));
    }
    
    public void func_176213_c(final World w, final BlockPos p, final IBlockState s) {
        super.func_176213_c(w, p, s);
        this.setBlockRotation(w, p, s);
    }
    
    private void setBlockRotation(final World w, final BlockPos p, final IBlockState s) {
        if (!w.field_72995_K) {
            final IBlockState block = w.func_180495_p(p.func_177978_c());
            final IBlockState block2 = w.func_180495_p(p.func_177968_d());
            final IBlockState block3 = w.func_180495_p(p.func_177976_e());
            final IBlockState block4 = w.func_180495_p(p.func_177974_f());
            int b0 = ((FurnaceType)s.func_177229_b((IProperty)BlockFurnaceMagic.TYPE)).getIndex();
            if (block.func_185914_p() && !block2.func_185914_p()) {
                ++b0;
                w.func_180501_a(p, this.func_176203_a(b0), 3);
                return;
            }
            if (block2.func_185914_p() && !block.func_185914_p()) {
                b0 += 0;
                w.func_180501_a(p, this.func_176203_a(b0), 3);
                return;
            }
            if (block3.func_185914_p() && !block4.func_185914_p()) {
                b0 += 3;
                w.func_180501_a(p, this.func_176203_a(b0), 3);
                return;
            }
            if (block4.func_185914_p() && !block3.func_185914_p()) {
                b0 += 2;
                w.func_180501_a(p, this.func_176203_a(b0), 3);
            }
        }
    }
    
    public IBlockState func_180642_a(final World worldIn, final BlockPos pos, final EnumFacing facing, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockFurnaceMagic.TYPE, (Comparable)FurnaceType.fromIndex(meta / 4)).func_177226_a((IProperty)BlockFurnaceMagic.FACING, (Comparable)placer.func_174811_aO().func_176734_d());
    }
    
    public void func_180633_a(final World w, final BlockPos p, final IBlockState s, final EntityLivingBase pl, final ItemStack is) {
        w.func_180501_a(p, this.func_176223_P().func_177226_a((IProperty)BlockFurnaceMagic.TYPE, (Comparable)FurnaceType.fromIndex(is.func_77952_i() / 4)).func_177226_a((IProperty)BlockFurnaceMagic.FACING, (Comparable)pl.func_174811_aO().func_176734_d()), 2);
    }
    
    public TileEntity func_149915_a(final World w, final int meta) {
        return new TileFurnaceMagic();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockFurnaceMagic.TYPE, (Comparable)FurnaceType.fromIndex(meta / 4)).func_177226_a((IProperty)BlockFurnaceMagic.FACING, (Comparable)EnumFacing.func_176731_b(meta % 4));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((FurnaceType)state.func_177229_b((IProperty)BlockFurnaceMagic.TYPE)).getIndex() * 4 + ((EnumFacing)state.func_177229_b((IProperty)BlockFurnaceMagic.FACING)).func_176736_b();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockFurnaceMagic.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockFurnaceMagic.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockFurnaceMagic.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockFurnaceMagic.FACING, (IProperty)BlockFurnaceMagic.TYPE });
    }
    
    public void registerModels() {
        for (int i = 0; i < FurnaceType.values().length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i * 4, new ModelResourceLocation("essentialcraft:furnacemagic", "facing=north,type=" + FurnaceType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        FACING = PropertyDirection.func_177712_a("facing", (Predicate)EnumFacing.Plane.HORIZONTAL);
        TYPE = PropertyEnum.func_177709_a("type", (Class)FurnaceType.class);
    }
    
    public enum FurnaceType implements IStringSerializable
    {
        FORTIFIED(0, "fortified", MapColor.field_151665_m), 
        MAGIC(1, "magic", MapColor.field_151678_z), 
        PALE(2, "pale", MapColor.field_151652_H), 
        VOID(3, "void", MapColor.field_151646_E);
        
        private final int index;
        private final String name;
        private final MapColor mapColor;
        
        private FurnaceType(final int index, final String name, final MapColor mapColor) {
            this.index = index;
            this.name = name;
            this.mapColor = mapColor;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public MapColor getMapColor() {
            return this.mapColor;
        }
        
        public static FurnaceType fromIndex(final int i) {
            return values()[i % 4];
        }
    }
}
