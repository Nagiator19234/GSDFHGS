package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import essentialcraft.common.tile.*;
import net.minecraft.inventory.*;
import essentialcraft.api.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMagicianTable extends BlockContainer implements IModelRegisterer
{
    public BlockMagicianTable() {
        super(Material.field_151576_e, MapColor.field_151678_z);
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final TileMagicianTable table = (TileMagicianTable)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, (IInventory)table);
        if (table.upgrade != -1) {
            final ItemStack dropped = MagicianTableUpgrades.createStackByUpgradeID(table.upgrade);
            InventoryHelper.func_180173_a(world, (double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), dropped);
        }
        super.func_180663_b(world, pos, blockstate);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileMagicianTable();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        final ItemStack currentItem = player.func_184586_b(par5);
        if (currentItem.func_190926_b() || !MagicianTableUpgrades.isItemUpgrade(currentItem)) {
            final TileMagicianTable table = (TileMagicianTable)world.func_175625_s(par2);
            if (player.func_70093_af()) {
                if (table.upgrade != -1) {
                    final ItemStack dropped = MagicianTableUpgrades.createStackByUpgradeID(table.upgrade);
                    if (!dropped.func_190926_b()) {
                        if (!world.field_72995_K) {
                            final EntityItem itm = new EntityItem(world, par2.func_177958_n() + 0.5, par2.func_177956_o() + 1.5, par2.func_177952_p() + 0.5, dropped);
                            itm.func_174867_a(30);
                            table.upgrade = -1;
                            table.syncTick = 0;
                            world.func_72838_d((Entity)itm);
                        }
                        return true;
                    }
                }
                return false;
            }
            if (!world.field_72995_K) {
                player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
                return true;
            }
            return true;
        }
        else {
            if (!player.func_70093_af()) {
                final TileMagicianTable table = (TileMagicianTable)world.func_175625_s(par2);
                if (table.upgrade == -1) {
                    table.upgrade = MagicianTableUpgrades.getUpgradeIDByItemStack(currentItem);
                    table.syncTick = 0;
                    player.field_71071_by.func_70298_a(player.field_71071_by.field_70461_c, 1);
                }
                return true;
            }
            return false;
        }
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:magiciantable", "inventory"));
    }
}
