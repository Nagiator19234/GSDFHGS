package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMIMImporter extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockMIMImporter() {
        super(Material.field_151576_e, MapColor.field_151660_b);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockMIMImporter.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState s, final IBlockAccess world, final BlockPos pos) {
        final int metadata = ((EnumFacing)s.func_177229_b((IProperty)BlockMIMImporter.FACING)).func_176745_a();
        if (metadata == 0) {
            return new AxisAlignedBB(0.3499999940395355, 0.0, 0.3499999940395355, 0.6499999761581421, 0.20000000298023224, 0.6499999761581421);
        }
        if (metadata == 1) {
            return new AxisAlignedBB(0.3499999940395355, 0.800000011920929, 0.3499999940395355, 0.6499999761581421, 1.0, 0.6499999761581421);
        }
        if (metadata == 2) {
            return new AxisAlignedBB(0.3499999940395355, 0.3499999940395355, 0.0, 0.6499999761581421, 0.6499999761581421, 0.20000000298023224);
        }
        if (metadata == 3) {
            return new AxisAlignedBB(0.3499999940395355, 0.3499999940395355, 0.800000011920929, 0.6499999761581421, 0.6499999761581421, 1.0);
        }
        if (metadata == 4) {
            return new AxisAlignedBB(0.0, 0.3499999940395355, 0.3499999940395355, 0.20000000298023224, 0.6499999761581421, 0.6499999761581421);
        }
        if (metadata == 5) {
            return new AxisAlignedBB(0.800000011920929, 0.3499999940395355, 0.3499999940395355, 1.0, 0.6499999761581421, 0.6499999761581421);
        }
        return super.func_185496_a(s, world, pos);
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149721_r(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int metadata) {
        return new TileMIMImportNode();
    }
    
    public IBlockState func_180642_a(final World w, final BlockPos p, final EnumFacing side, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMIMImporter.FACING, (Comparable)side.func_176734_d());
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMIMImporter.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockMIMImporter.FACING)).func_176745_a();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockMIMImporter.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockMIMImporter.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockMIMImporter.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMIMImporter.FACING });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:miminjector", "inventory"));
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
}
