package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockBlockBreaker extends Block implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockBlockBreaker() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockBlockBreaker.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public boolean func_149744_f(final IBlockState state) {
        return true;
    }
    
    public void func_189540_a(final IBlockState state, final World world, final BlockPos pos, final Block block, final BlockPos fromPos) {
        if (!world.field_72995_K && world.func_175687_A(pos) > 0) {
            final EnumFacing d = (EnumFacing)world.func_180495_p(pos).func_177229_b((IProperty)BlockBlockBreaker.FACING);
            final Block broken = world.func_180495_p(pos.func_177972_a(d)).func_177230_c();
            if (!broken.isAir(world.func_180495_p(pos.func_177972_a(d)), (IBlockAccess)world, pos.func_177972_a(d))) {
                final float hardness = broken.func_176195_g(world.func_180495_p(pos.func_177972_a(d)), world, pos.func_177972_a(d));
                if (hardness >= 0.0f && hardness <= 10.0f) {
                    for (int i = 1; i < 13; ++i) {
                        final BlockPos dP = pos.func_177967_a(d, i);
                        final Block b = world.func_180495_p(dP).func_177230_c();
                        if (b.func_176195_g(world.func_180495_p(dP), world, dP) != hardness) {
                            break;
                        }
                        b.func_180663_b(world, dP, world.func_180495_p(dP));
                        b.func_176206_d(world, dP, world.func_180495_p(dP));
                        b.func_176226_b(world, dP, world.func_180495_p(dP), 0);
                        world.func_175698_g(dP);
                    }
                }
            }
        }
    }
    
    public IBlockState func_180642_a(final World w, final BlockPos p, final EnumFacing side, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockBlockBreaker.FACING, (Comparable)side);
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockBlockBreaker.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockBlockBreaker.FACING)).func_176745_a();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockBlockBreaker.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockBlockBreaker.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockBlockBreaker.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockBlockBreaker.FACING });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:blockbreaker", "inventory"));
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
}
