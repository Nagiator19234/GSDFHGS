package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.*;
import net.minecraft.block.state.*;
import java.util.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMagicalFruit extends Block implements IModelRegisterer
{
    public BlockMagicalFruit() {
        super(Material.field_151570_A);
        this.func_149672_a(SoundType.field_185850_c);
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return ItemsCore.fruit;
    }
    
    public int func_149745_a(final Random rand) {
        return 3 + rand.nextInt(5);
    }
    
    public int func_149679_a(final int fortune, final Random rand) {
        int j = this.func_149745_a(rand) + rand.nextInt(1 + fortune);
        if (j > 9) {
            j = 9;
        }
        return j;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:fruit", "inventory"));
    }
}
