package essentialcraft.common.block;

import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import essentialcraft.common.tile.*;
import net.minecraft.nbt.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.*;
import net.minecraft.stats.*;
import com.google.common.collect.*;
import net.minecraftforge.event.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.block.state.*;
import net.minecraft.creativetab.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import DummyCore.Client.*;
import net.minecraftforge.fml.relauncher.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;

public class BlockElementalCrystal extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockElementalCrystal() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockElementalCrystal.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        final ItemStack is = new ItemStack((Block)this, 1);
        final TileEntity te = world.func_175625_s(pos);
        if (te instanceof TileElementalCrystal) {
            final TileElementalCrystal crystal = (TileElementalCrystal)te;
            final NBTTagCompound nbt = new NBTTagCompound();
            nbt.func_74780_a("size", crystal.size);
            nbt.func_74780_a("fire", crystal.fire);
            nbt.func_74780_a("water", crystal.water);
            nbt.func_74780_a("earth", crystal.earth);
            nbt.func_74780_a("air", crystal.air);
            is.func_77982_d(nbt);
        }
        return is;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileElementalCrystal();
    }
    
    public IBlockState func_180642_a(final World w, final BlockPos p, final EnumFacing side, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase placer) {
        return this.func_176223_P().func_177226_a((IProperty)BlockElementalCrystal.FACING, (Comparable)side);
    }
    
    public void func_180633_a(final World world, final BlockPos pos, final IBlockState state, final EntityLivingBase placer, final ItemStack stack) {
        final TileEntity te = world.func_175625_s(pos);
        if (te instanceof TileElementalCrystal) {
            double size = 0.0;
            double fire = 0.0;
            double water = 0.0;
            double earth = 0.0;
            double air = 0.0;
            final NBTTagCompound nbt = stack.func_77978_p();
            if (nbt != null) {
                size = nbt.func_74769_h("size");
                fire = nbt.func_74769_h("fire");
                water = nbt.func_74769_h("water");
                earth = nbt.func_74769_h("earth");
                air = nbt.func_74769_h("air");
            }
            final TileElementalCrystal crystal = (TileElementalCrystal)te;
            crystal.size = size;
            crystal.fire = fire;
            crystal.water = water;
            crystal.earth = earth;
            crystal.air = air;
        }
    }
    
    public void func_180657_a(final World world, final EntityPlayer player, final BlockPos pos, final IBlockState state, final TileEntity te, final ItemStack stack) {
        player.func_71029_a(StatList.func_188055_a((Block)this));
        player.func_71020_j(0.005f);
        if (world.field_72995_K) {
            return;
        }
        final ArrayList<ItemStack> items = (ArrayList<ItemStack>)Lists.newArrayList();
        final ItemStack is = new ItemStack((Block)this, 1);
        if (te instanceof TileElementalCrystal) {
            final TileElementalCrystal crystal = (TileElementalCrystal)te;
            final NBTTagCompound nbt = new NBTTagCompound();
            nbt.func_74780_a("size", crystal.size);
            nbt.func_74780_a("fire", crystal.fire);
            nbt.func_74780_a("water", crystal.water);
            nbt.func_74780_a("earth", crystal.earth);
            nbt.func_74780_a("air", crystal.air);
            is.func_77982_d(nbt);
        }
        items.add(is);
        ForgeEventFactory.fireBlockHarvesting((List)items, world, pos, state, 0, 1.0f, true, player);
        for (final ItemStack item : items) {
            func_180635_a(world, pos, item);
        }
    }
    
    public int getLightValue(final IBlockState s, final IBlockAccess world, final BlockPos pos) {
        final TileEntity te = world.func_175625_s(pos);
        if (te instanceof TileElementalCrystal) {
            final TileElementalCrystal crystal = (TileElementalCrystal)te;
            final double size = crystal.size;
            final double floatSize = size / 100.0;
            final int light = (int)(floatSize * 15.0);
            return light;
        }
        return this.func_149750_m(s);
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockElementalCrystal.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockElementalCrystal.FACING)).func_176745_a();
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockElementalCrystal.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockElementalCrystal.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockElementalCrystal.FACING)));
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockElementalCrystal.FACING });
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        items.add((Object)new ItemStack((Block)this, 1));
        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 4; ++j) {
                final ItemStack crystalStack = new ItemStack((Block)this, 1);
                final NBTTagCompound tag = new NBTTagCompound();
                tag.func_74780_a("size", (double)(i * 25));
                final double[] elements = { 0.0, 0.0, 0.0, 0.0 };
                elements[j] = 100.0;
                tag.func_74780_a("fire", elements[0]);
                tag.func_74780_a("water", elements[1]);
                tag.func_74780_a("earth", elements[2]);
                tag.func_74780_a("air", elements[3]);
                crystalStack.func_77982_d(tag);
                items.add((Object)crystalStack);
            }
            ItemStack crystalStack2 = new ItemStack((Block)this, 1);
            NBTTagCompound tag2 = new NBTTagCompound();
            tag2.func_74780_a("size", (double)(i * 25));
            double[] elements2 = { 100.0, 100.0, 100.0, 100.0 };
            tag2.func_74780_a("fire", elements2[0]);
            tag2.func_74780_a("water", elements2[1]);
            tag2.func_74780_a("earth", elements2[2]);
            tag2.func_74780_a("air", elements2[3]);
            crystalStack2.func_77982_d(tag2);
            items.add((Object)crystalStack2);
            crystalStack2 = new ItemStack((Block)this, 1);
            tag2 = new NBTTagCompound();
            tag2.func_74780_a("size", (double)(i * 25));
            elements2 = new double[] { 0.0, 0.0, 0.0, 0.0 };
            tag2.func_74780_a("fire", elements2[0]);
            tag2.func_74780_a("water", elements2[1]);
            tag2.func_74780_a("earth", elements2[2]);
            tag2.func_74780_a("air", elements2[3]);
            crystalStack2.func_77982_d(tag2);
            items.add((Object)crystalStack2);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockElementalCrystal.FACING }).func_178441_a());
        if (!Loader.isModLoaded("codechickenlib")) {
            ModelLoader.setCustomMeshDefinition(Item.func_150898_a((Block)this), (ItemMeshDefinition)new MeshDefinitionElementalCrystal());
            for (int i = 0; i <= 20; ++i) {
                ModelBakery.registerItemVariants(Item.func_150898_a((Block)this), new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:elementalcrystalinv", "size=" + i) });
            }
        }
        else {
            ModelUtils.setItemModelSingleIcon(Item.func_150898_a((Block)this), new String[] { "essentialcraft:elementalcrystal" });
        }
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
    
    public static class MeshDefinitionElementalCrystal implements ItemMeshDefinition
    {
        public ModelResourceLocation func_178113_a(final ItemStack stack) {
            float size = 0.0f;
            if (MiscUtils.getStackTag(stack) != null) {
                size = MiscUtils.getStackTag(stack).func_74760_g("size");
            }
            return new ModelResourceLocation("essentialcraft:elementalcrystalinv", "size=" + MathHelper.func_76141_d(size) / 5);
        }
    }
}
