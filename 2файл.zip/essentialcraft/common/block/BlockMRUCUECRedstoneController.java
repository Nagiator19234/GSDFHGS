package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.util.text.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMRUCUECRedstoneController extends BlockContainer implements IModelRegisterer
{
    protected BlockMRUCUECRedstoneController() {
        super(Material.field_151576_e, MapColor.field_151678_z);
    }
    
    public TileEntity func_149915_a(final World var1, final int var2) {
        return new TileMRUCUECRedstoneController();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            final TileMRUCUECRedstoneController tileMRUCUECRedstoneController;
            final TileMRUCUECRedstoneController rc = tileMRUCUECRedstoneController = (TileMRUCUECRedstoneController)world.func_175625_s(par2);
            ++tileMRUCUECRedstoneController.setting;
            if (rc.setting >= 11) {
                rc.setting = 0;
            }
            if (player.func_130014_f_().field_72995_K) {
                player.func_145747_a((ITextComponent)new TextComponentString(I18n.func_74838_a("essentialcraft.txt.redstone_" + rc.setting)));
            }
        }
        else {
            final TileMRUCUECRedstoneController rc = (TileMRUCUECRedstoneController)world.func_175625_s(par2);
            if (player.func_130014_f_().field_72995_K) {
                player.func_145747_a((ITextComponent)new TextComponentString(I18n.func_74838_a("essentialcraft.txt.redstone_" + rc.setting)));
            }
        }
        return true;
    }
    
    public boolean func_149744_f(final IBlockState s) {
        return true;
    }
    
    public int func_180656_a(final IBlockState s, final IBlockAccess w, final BlockPos p, final EnumFacing f) {
        final TileMRUCUECRedstoneController rc = (TileMRUCUECRedstoneController)w.func_175625_s(p);
        return rc.outputRedstone() ? 15 : 0;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:ecredstonecontroller", "inventory"));
    }
}
