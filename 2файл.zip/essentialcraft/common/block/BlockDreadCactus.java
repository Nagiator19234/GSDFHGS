package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.block.properties.*;
import net.minecraftforge.client.model.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.fml.relauncher.*;

public class BlockDreadCactus extends BlockCactus implements IModelRegisterer
{
    public BlockDreadCactus() {
        this.func_149672_a(SoundType.field_185850_c);
    }
    
    public void func_180634_a(final World world, final BlockPos pos, final IBlockState state, final Entity entity) {
        super.func_180634_a(world, pos, state, entity);
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase base = (EntityLivingBase)entity;
            base.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 100, 0));
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockDreadCactus.field_176587_a }).func_178441_a());
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:cacti", "inventory"));
    }
}
