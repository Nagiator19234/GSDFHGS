package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.material.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.block.state.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import java.util.*;
import net.minecraft.util.*;

public class BlockDropsOre extends Block implements IModelRegisterer
{
    public static final PropertyEnum<EnumDropType> TYPE;
    public static final PropertyEnum<OreDimensionType> DIMENSION;
    
    public int getExpDrop(final IBlockState state, final IBlockAccess world, final BlockPos pos, final int fortune) {
        return MathHelper.func_76136_a(BlockDropsOre.RANDOM, 0, 2);
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((OreDimensionType)state.func_177229_b((IProperty)BlockDropsOre.DIMENSION)).getIndex() * 5 + ((EnumDropType)state.func_177229_b((IProperty)BlockDropsOre.TYPE)).getIndexOre());
    }
    
    public boolean canSilkHarvest(final World world, final BlockPos pos, final IBlockState state, final EntityPlayer player) {
        return true;
    }
    
    public BlockDropsOre() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockDropsOre.TYPE, (Comparable)EnumDropType.ELEMENTAL).func_177226_a((IProperty)BlockDropsOre.DIMENSION, (Comparable)OreDimensionType.OVERWORLD));
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 15; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public int func_180651_a(final IBlockState state) {
        final int value = ((EnumDropType)state.func_177229_b((IProperty)BlockDropsOre.TYPE)).getIndexOre();
        return (value == 0) ? 4 : (value - 1);
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return ItemsCore.drops;
    }
    
    public ArrayList<ItemStack> getDrops(final IBlockAccess world, final BlockPos pos, final IBlockState state, final int fortune) {
        final ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        for (int count = BlockDropsOre.RANDOM.nextInt(2 * (fortune + 1)) + 1, i = 0; i < count; ++i) {
            final Item item = this.func_180660_a(state, BlockDropsOre.RANDOM, fortune);
            if (item != null) {
                ret.add(new ItemStack(item, 1, this.func_180651_a(state)));
            }
        }
        return ret;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockDropsOre.DIMENSION, (Comparable)OreDimensionType.fromIndex(meta % 15 / 5)).func_177226_a((IProperty)BlockDropsOre.TYPE, (Comparable)EnumDropType.fromIndexOre(meta % 5));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((OreDimensionType)state.func_177229_b((IProperty)BlockDropsOre.DIMENSION)).getIndex() * 5 + ((EnumDropType)state.func_177229_b((IProperty)BlockDropsOre.TYPE)).getIndexOre();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockDropsOre.TYPE, (IProperty)BlockDropsOre.DIMENSION });
    }
    
    public void registerModels() {
        for (int i = 0; i < OreDimensionType.values().length; ++i) {
            for (int j = 0; j < EnumDropType.values().length - 1; ++j) {
                ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i * (EnumDropType.values().length - 1) + j, new ModelResourceLocation("essentialcraft:oredrops", "dimension=" + OreDimensionType.fromIndex(i).func_176610_l() + ",type=" + EnumDropType.fromIndexOre(j).func_176610_l()));
            }
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177706_a("type", (Class)EnumDropType.class, (Enum[])EnumDropType.NORMAL);
        DIMENSION = PropertyEnum.func_177709_a("dimension", (Class)OreDimensionType.class);
    }
    
    public enum OreDimensionType implements IStringSerializable
    {
        OVERWORLD(0, "overworld"), 
        NETHER(1, "nether"), 
        END(2, "end");
        
        private int index;
        private String name;
        
        private OreDimensionType(final int i, final String s) {
            this.index = i;
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static OreDimensionType fromIndex(final int i) {
            return values()[i % 3];
        }
    }
}
