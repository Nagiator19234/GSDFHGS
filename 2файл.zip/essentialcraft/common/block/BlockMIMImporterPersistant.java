package essentialcraft.common.block;

import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMIMImporterPersistant extends BlockMIMImporter
{
    @Override
    public TileEntity func_149915_a(final World world, final int metadata) {
        return new TileMIMImportNodePersistant();
    }
    
    @Override
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:miminjectorp", "inventory"));
    }
}
