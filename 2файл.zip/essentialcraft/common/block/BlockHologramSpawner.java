package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.utils.cfg.*;
import essentialcraft.common.entity.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockHologramSpawner extends Block implements IModelRegisterer
{
    public static final AxisAlignedBB BLOCK_AABB;
    
    public BlockHologramSpawner() {
        super(Material.field_151576_e, MapColor.field_151677_p);
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        return BlockHologramSpawner.BLOCK_AABB;
    }
    
    public boolean func_180639_a(final World w, final BlockPos p, final IBlockState s, final EntityPlayer ep, final EnumHand h, final EnumFacing f, final float hx, final float hy, final float hz) {
        if (!w.field_72995_K && w.field_73011_w != null && (w.field_73011_w.getDimension() == Config.dimensionID || Config.allowHologramInOtherDimensions)) {
            w.func_175698_g(p);
            final EntityHologram hg = new EntityHologram(w);
            hg.func_70080_a(p.func_177958_n() + 0.5, (double)(p.func_177956_o() + 5), p.func_177952_p() + 0.5, 0.0f, 0.0f);
            w.func_72838_d((Entity)hg);
        }
        return true;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:holopad", "inventory"));
    }
    
    static {
        BLOCK_AABB = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.5, 1.0);
    }
}
