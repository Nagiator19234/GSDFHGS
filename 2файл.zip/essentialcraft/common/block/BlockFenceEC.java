package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockFenceEC extends BlockFence implements IModelRegisterer
{
    public BlockFenceEC(final Material material, final MapColor mapColor) {
        super(material, mapColor);
    }
    
    public BlockFenceEC(final Material material) {
        super(material, material.func_151565_r());
    }
    
    public BlockFenceEC() {
        super(Material.field_151576_e, Material.field_151576_e.func_151565_r());
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
