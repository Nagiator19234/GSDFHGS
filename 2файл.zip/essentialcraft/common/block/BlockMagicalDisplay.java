package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import java.util.*;
import essentialcraft.common.item.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMagicalDisplay extends BlockContainer implements IModelRegisterer
{
    public static final PropertyDirection FACING;
    
    public BlockMagicalDisplay() {
        super(Material.field_151576_e, MapColor.field_151660_b);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockMagicalDisplay.FACING, (Comparable)EnumFacing.DOWN));
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return ItemsCore.genericItem;
    }
    
    public int func_180651_a(final IBlockState state) {
        return 27;
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack(ItemsCore.genericItem, 1, 27);
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileMagicalDisplay();
    }
    
    public boolean func_180639_a(final World w, final BlockPos pos, final IBlockState par3, final EntityPlayer p, final EnumHand par5, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack is = p.func_184586_b(par5);
        final TileMagicalDisplay display = (TileMagicalDisplay)w.func_175625_s(pos);
        if (!is.func_190926_b()) {
            if (display.func_70301_a(0).func_190926_b()) {
                final ItemStack sett = is.func_77946_l();
                sett.func_190920_e(1);
                display.func_70299_a(0, sett);
                p.field_71071_by.func_70298_a(p.field_71071_by.field_70461_c, 1);
            }
            else {
                final ItemStack dropped = display.func_70301_a(0);
                if (!dropped.func_190926_b() && !w.field_72995_K) {
                    if (dropped.func_190916_E() == 0) {
                        dropped.func_190920_e(1);
                    }
                    final EntityItem itm = new EntityItem(w, pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, dropped);
                    itm.func_174867_a(30);
                    display.func_70299_a(0, ItemStack.field_190927_a);
                    w.func_72838_d((Entity)itm);
                }
            }
            display.syncTick = 0;
        }
        else if (p.func_70093_af()) {
            final ItemStack dropped = display.func_70301_a(0);
            if (!dropped.func_190926_b() && !w.field_72995_K) {
                if (dropped.func_190916_E() == 0) {
                    dropped.func_190920_e(1);
                }
                final EntityItem itm = new EntityItem(w, pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, dropped);
                itm.func_174867_a(30);
                display.func_70299_a(0, ItemStack.field_190927_a);
                w.func_72838_d((Entity)itm);
                display.syncTick = 1;
            }
        }
        else {
            final TileMagicalDisplay tileMagicalDisplay = display;
            ++tileMagicalDisplay.type;
            if (display.type >= 3) {
                display.type = 0;
            }
            display.syncTick = 1;
        }
        return true;
    }
    
    public IBlockState func_180642_a(final World w, final BlockPos pos, final EnumFacing side, final float hitX, final float hitY, final float hitZ, final int meta, final EntityLivingBase p) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMagicalDisplay.FACING, (Comparable)side);
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        final int metadata = ((EnumFacing)state.func_177229_b((IProperty)BlockMagicalDisplay.FACING)).func_176745_a();
        if (metadata == 0) {
            return new AxisAlignedBB(0.0, 0.949999988079071, 0.0, 1.0, 1.0, 1.0);
        }
        if (metadata == 1) {
            return new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.05000000074505806, 1.0);
        }
        if (metadata == 2) {
            return new AxisAlignedBB(0.0, 0.0, 0.949999988079071, 1.0, 1.0, 1.0);
        }
        if (metadata == 3) {
            return new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 0.05000000074505806);
        }
        if (metadata == 4) {
            return new AxisAlignedBB(0.949999988079071, 0.0, 0.0, 1.0, 1.0, 1.0);
        }
        if (metadata == 5) {
            return new AxisAlignedBB(0.0, 0.0, 0.0, 0.05000000074505806, 1.0, 1.0);
        }
        return super.func_185496_a(state, source, pos);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        return state.func_177226_a((IProperty)BlockMagicalDisplay.FACING, (Comparable)rot.func_185831_a((EnumFacing)state.func_177229_b((IProperty)BlockMagicalDisplay.FACING)));
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        return state.func_185907_a(mirrorIn.func_185800_a((EnumFacing)state.func_177229_b((IProperty)BlockMagicalDisplay.FACING)));
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMagicalDisplay.FACING, (Comparable)EnumFacing.func_82600_a(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumFacing)state.func_177229_b((IProperty)BlockMagicalDisplay.FACING)).func_176745_a();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMagicalDisplay.FACING });
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:magicaldisplay", "inventory"));
    }
    
    static {
        FACING = PropertyDirection.func_177714_a("facing");
    }
}
