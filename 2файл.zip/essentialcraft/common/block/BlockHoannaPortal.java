package essentialcraft.common.block;

import net.minecraft.world.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import net.minecraft.block.properties.*;
import net.minecraft.init.*;
import net.minecraft.block.state.pattern.*;
import com.google.common.cache.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import DummyCore.Client.*;

public class BlockHoannaPortal extends BlockPortal implements IModelRegisterer
{
    public BlockHoannaPortal() {
        this.func_149672_a(SoundType.field_185853_f);
    }
    
    public void func_180650_b(final World worldIn, final BlockPos pos, final IBlockState state, final Random rand) {
    }
    
    public void func_180634_a(final World world, final BlockPos pos, final IBlockState s, final Entity entity) {
        if (!world.field_72995_K) {
            DummyPortalHandler.transferEntityToDimension(entity);
        }
    }
    
    public void func_180655_c(final IBlockState state, final World worldIn, final BlockPos pos, final Random rand) {
        if (rand.nextInt(100) == 0) {
            worldIn.func_184134_a(pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, SoundEvents.field_187810_eg, SoundCategory.BLOCKS, 0.5f, rand.nextFloat() * 0.4f + 0.8f, false);
        }
    }
    
    public void func_189540_a(final IBlockState state, final World worldIn, final BlockPos pos, final Block blockIn, final BlockPos fromPos) {
        final EnumFacing.Axis enumfacing$axis = (EnumFacing.Axis)state.func_177229_b((IProperty)BlockHoannaPortal.field_176550_a);
        if (enumfacing$axis == EnumFacing.Axis.X) {
            final Size blockportal$size = new Size(worldIn, pos, EnumFacing.Axis.X);
            if (!blockportal$size.isValid() || blockportal$size.portalBlockCount < blockportal$size.width * blockportal$size.height) {
                worldIn.func_175656_a(pos, Blocks.field_150350_a.func_176223_P());
            }
        }
        else if (enumfacing$axis == EnumFacing.Axis.Z) {
            final Size blockportal$size2 = new Size(worldIn, pos, EnumFacing.Axis.Z);
            if (!blockportal$size2.isValid() || blockportal$size2.portalBlockCount < blockportal$size2.width * blockportal$size2.height) {
                worldIn.func_175656_a(pos, Blocks.field_150350_a.func_176223_P());
            }
        }
    }
    
    public BlockPattern.PatternHelper func_181089_f(final World world, final BlockPos pos) {
        EnumFacing.Axis axis = EnumFacing.Axis.Z;
        Size size = new Size(world, pos, EnumFacing.Axis.X);
        final LoadingCache<BlockPos, BlockWorldState> loadingcache = (LoadingCache<BlockPos, BlockWorldState>)BlockPattern.func_181627_a(world, true);
        if (!size.isValid()) {
            axis = EnumFacing.Axis.X;
            size = new Size(world, pos, EnumFacing.Axis.Z);
        }
        if (!size.isValid()) {
            return new BlockPattern.PatternHelper(pos, EnumFacing.NORTH, EnumFacing.UP, (LoadingCache)loadingcache, 1, 1, 1);
        }
        final int[] aint = new int[EnumFacing.AxisDirection.values().length];
        final EnumFacing enumfacing = size.rightDir.func_176735_f();
        final BlockPos blockpos = size.bottomLeft.func_177981_b(size.getHeight() - 1);
        for (final EnumFacing.AxisDirection dir : EnumFacing.AxisDirection.values()) {
            final BlockPattern.PatternHelper patternHelper = new BlockPattern.PatternHelper((enumfacing.func_176743_c() == dir) ? blockpos : blockpos.func_177967_a(size.rightDir, size.getWidth() - 1), EnumFacing.func_181076_a(dir, axis), EnumFacing.UP, (LoadingCache)loadingcache, size.getWidth(), size.getHeight(), 1);
            for (int i = 0; i < size.getWidth(); ++i) {
                for (int j = 0; j < size.getHeight(); ++j) {
                    final BlockWorldState blockworldstate = patternHelper.func_177670_a(i, j, 1);
                    if (blockworldstate.func_177509_a() != null && blockworldstate.func_177509_a().func_185904_a() != Material.field_151579_a) {
                        final int[] array = aint;
                        final int ordinal = dir.ordinal();
                        ++array[ordinal];
                    }
                }
            }
        }
        EnumFacing.AxisDirection axisDir = EnumFacing.AxisDirection.POSITIVE;
        for (final EnumFacing.AxisDirection dir2 : EnumFacing.AxisDirection.values()) {
            if (aint[dir2.ordinal()] < aint[axisDir.ordinal()]) {
                axisDir = dir2;
            }
        }
        return new BlockPattern.PatternHelper((enumfacing.func_176743_c() == axisDir) ? blockpos : blockpos.func_177967_a(size.rightDir, size.getWidth() - 1), EnumFacing.func_181076_a(axisDir, axis), EnumFacing.UP, (LoadingCache)loadingcache, size.getWidth(), size.getHeight(), 1);
    }
    
    public boolean func_176548_d(final World world, final BlockPos pos) {
        Size size = new Size(world, pos, EnumFacing.Axis.X);
        if (size.isValid() && size.portalBlockCount == 0) {
            size.placePortalBlocks();
            return true;
        }
        size = new Size(world, pos, EnumFacing.Axis.Z);
        if (size.isValid() && size.portalBlockCount == 0) {
            size.placePortalBlocks();
            return true;
        }
        return false;
    }
    
    public void registerModels() {
        ModelUtils.setItemModelSingleIcon(Item.func_150898_a((Block)this), new String[] { "essentialcraft:portal" });
    }
    
    public static class Size
    {
        private final World world;
        private final EnumFacing.Axis axis;
        private final EnumFacing rightDir;
        private final EnumFacing leftDir;
        private int portalBlockCount;
        private BlockPos bottomLeft;
        private int height;
        private int width;
        
        public Size(final World world, BlockPos pos, final EnumFacing.Axis axis) {
            this.world = world;
            this.axis = axis;
            if (axis == EnumFacing.Axis.X) {
                this.leftDir = EnumFacing.EAST;
                this.rightDir = EnumFacing.WEST;
            }
            else {
                this.leftDir = EnumFacing.NORTH;
                this.rightDir = EnumFacing.SOUTH;
            }
            for (BlockPos blockpos = pos; pos.func_177956_o() > blockpos.func_177956_o() - 21 && pos.func_177956_o() > 0 && this.isEmptyBlock(world.func_180495_p(pos.func_177977_b()).func_177230_c()); pos = pos.func_177977_b()) {}
            final int i = this.getDistanceUntilEdge(pos, this.leftDir) - 1;
            if (i >= 0) {
                this.bottomLeft = pos.func_177967_a(this.leftDir, i);
                this.width = this.getDistanceUntilEdge(this.bottomLeft, this.rightDir);
                if (this.width < 2 || this.width > 21) {
                    this.bottomLeft = null;
                    this.width = 0;
                }
            }
            if (this.bottomLeft != null) {
                this.height = this.calculatePortalHeight();
            }
        }
        
        protected int getDistanceUntilEdge(final BlockPos pos, final EnumFacing side) {
            int i;
            for (i = 0; i < 22; ++i) {
                final BlockPos blockpos = pos.func_177967_a(side, i);
                if (!this.isEmptyBlock(this.world.func_180495_p(blockpos).func_177230_c())) {
                    break;
                }
                if (this.world.func_180495_p(blockpos.func_177977_b()).func_177230_c() != Blocks.field_150343_Z) {
                    break;
                }
            }
            final Block block = this.world.func_180495_p(pos.func_177967_a(side, i)).func_177230_c();
            return (block == Blocks.field_150343_Z) ? i : 0;
        }
        
        public int getHeight() {
            return this.height;
        }
        
        public int getWidth() {
            return this.width;
        }
        
        protected int calculatePortalHeight() {
            this.height = 0;
        Label_0181:
            while (this.height < 21) {
                for (int i = 0; i < this.width; ++i) {
                    final BlockPos blockpos = this.bottomLeft.func_177967_a(this.rightDir, i).func_177981_b(this.height);
                    Block block = this.world.func_180495_p(blockpos).func_177230_c();
                    if (!this.isEmptyBlock(block)) {
                        break Label_0181;
                    }
                    if (block == BlocksCore.portal) {
                        ++this.portalBlockCount;
                    }
                    if (i == 0) {
                        block = this.world.func_180495_p(blockpos.func_177972_a(this.leftDir)).func_177230_c();
                        if (block != Blocks.field_150343_Z) {
                            break Label_0181;
                        }
                    }
                    else if (i == this.width - 1) {
                        block = this.world.func_180495_p(blockpos.func_177972_a(this.rightDir)).func_177230_c();
                        if (block != Blocks.field_150343_Z) {
                            break Label_0181;
                        }
                    }
                }
                ++this.height;
            }
            for (int j = 0; j < this.width; ++j) {
                if (this.world.func_180495_p(this.bottomLeft.func_177967_a(this.rightDir, j).func_177981_b(this.height)).func_177230_c() != Blocks.field_150343_Z) {
                    this.height = 0;
                    break;
                }
            }
            if (this.height <= 21 && this.height >= 3) {
                return this.height;
            }
            this.bottomLeft = null;
            this.width = 0;
            return this.height = 0;
        }
        
        protected boolean isEmptyBlock(final Block blockIn) {
            return blockIn.func_149688_o(blockIn.func_176223_P()) == Material.field_151579_a || blockIn == BlocksCore.portal;
        }
        
        public boolean isValid() {
            return this.bottomLeft != null && this.width >= 2 && this.width <= 21 && this.height >= 3 && this.height <= 21;
        }
        
        public void placePortalBlocks() {
            for (int i = 0; i < this.width; ++i) {
                final BlockPos blockpos = this.bottomLeft.func_177967_a(this.rightDir, i);
                for (int j = 0; j < this.height; ++j) {
                    this.world.func_180501_a(blockpos.func_177981_b(j), BlocksCore.portal.func_176223_P().func_177226_a((IProperty)BlockPortal.field_176550_a, (Comparable)this.axis), 2);
                }
            }
        }
    }
}
