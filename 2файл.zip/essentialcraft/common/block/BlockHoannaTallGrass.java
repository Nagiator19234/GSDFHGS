package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import net.minecraft.world.biome.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraftforge.common.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import java.util.*;

public class BlockHoannaTallGrass extends BlockBush implements IGrowable, IShearable, IBlockColor, IItemColor, IModelRegisterer
{
    public BlockHoannaTallGrass() {
        super(Material.field_151582_l);
        this.func_149672_a(SoundType.field_185850_c);
    }
    
    public AxisAlignedBB func_180640_a(final IBlockState state, final World worldIn, final BlockPos pos) {
        final float f = 0.4f;
        return new AxisAlignedBB((double)(0.5f - f), 0.0, (double)(0.5f - f), (double)(0.5f + f), 0.800000011920929, (double)(0.5f + f)).func_186670_a(pos);
    }
    
    public boolean canSustainPlant(final IBlockState state, final IBlockAccess world, final BlockPos pos, final EnumFacing direction, final IPlantable plantable) {
        final Block b = state.func_177230_c();
        return b != null && b instanceof BlockHoannaTallGrass;
    }
    
    public int colorMultiplier(final IBlockState s, final IBlockAccess world, final BlockPos pos, final int tint) {
        return BiomeColorHelper.func_180286_a(world, pos);
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int tintIndex) {
        return ColorizerGrass.func_77480_a(0.5, 1.0);
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, 0);
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return null;
    }
    
    public int func_149679_a(final int fortune, final Random rand) {
        return 1 + rand.nextInt(fortune * 2 + 1);
    }
    
    public ArrayList<ItemStack> getDrops(final IBlockAccess world, final BlockPos pos, final IBlockState meta, final int fortune) {
        final ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        Label_0048: {
            if (world instanceof World) {
                if (((World)world).field_73012_v.nextInt(8) == 0) {
                    break Label_0048;
                }
            }
            else if (BlockHoannaTallGrass.RANDOM.nextInt(8) == 0) {
                break Label_0048;
            }
            return ret;
        }
        final ItemStack seed = ForgeHooks.getGrassSeed((world instanceof World) ? ((World)world).field_73012_v : BlockHoannaTallGrass.RANDOM, fortune);
        if (!seed.func_190926_b()) {
            ret.add(seed);
        }
        return ret;
    }
    
    public boolean isShearable(final ItemStack item, final IBlockAccess world, final BlockPos pos) {
        return true;
    }
    
    public ArrayList<ItemStack> onSheared(final ItemStack item, final IBlockAccess world, final BlockPos pos, final int fortune) {
        final ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        ret.add(new ItemStack((Block)this, 1, this.func_176201_c(world.func_180495_p(pos))));
        return ret;
    }
    
    public boolean func_176473_a(final World world, final BlockPos pos, final IBlockState state, final boolean isClient) {
        return true;
    }
    
    public boolean func_180670_a(final World world, final Random rand, final BlockPos pos, final IBlockState state) {
        return true;
    }
    
    public void func_176474_b(final World world, final Random rand, final BlockPos pos, final IBlockState state) {
        final int l = this.func_176201_c(state);
        byte b0 = 2;
        if (l == 2) {
            b0 = 3;
        }
        if (Blocks.field_150398_cm.func_176196_c(world, pos)) {
            Blocks.field_150398_cm.func_176491_a(world, pos, BlockDoublePlant.EnumPlantType.func_176938_a((int)b0), 2);
        }
    }
    
    protected boolean func_185514_i(final IBlockState state) {
        return state.func_177230_c() == Blocks.field_150349_c || state.func_177230_c() == Blocks.field_150346_d || state.func_177230_c() == Blocks.field_150458_ak || state.func_177230_c() instanceof BlockHoannaTallGrass;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:tallgrass", "inventory"));
    }
}
