package essentialcraft.common.block;

import net.minecraft.block.*;
import net.minecraft.block.material.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import essentialcraft.common.mod.*;
import net.minecraft.world.*;
import net.minecraft.block.state.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import DummyCore.Client.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;

public class BlockMagicLight extends Block implements IModelRegisterer
{
    public static final PropertyEnum<LightType> TYPE;
    public static final AxisAlignedBB BLOCK_AABB;
    
    public BlockMagicLight() {
        super(Material.field_151594_q);
        this.func_149675_a(true);
        this.func_149715_a(1.0f);
    }
    
    public int func_149745_a(final Random rand) {
        return 0;
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return null;
    }
    
    public void func_180650_b(final World world, final BlockPos pos, final IBlockState state, final Random rand) {
        final int meta = ((LightType)state.func_177229_b((IProperty)BlockMagicLight.TYPE)).getIndex();
        if (meta == 1) {
            world.func_175698_g(pos);
        }
    }
    
    public void func_180655_c(final IBlockState state, final World world, final BlockPos pos, final Random rand) {
        final int meta = ((LightType)state.func_177229_b((IProperty)BlockMagicLight.TYPE)).getIndex();
        if (meta == 0) {
            for (int i = 0; i < 5; ++i) {
                Vec3d rotateVec = new Vec3d(1.0, 1.0, 1.0);
                rotateVec = rotateVec.func_178789_a(rand.nextFloat() * 360.0f);
                rotateVec = rotateVec.func_178785_b(rand.nextFloat() * 360.0f);
                EssentialCraftCore.proxy.spawnParticle("mruFX", pos.func_177958_n() + 0.5f, pos.func_177956_o() + 0.5f, pos.func_177952_p() + 0.5f, rotateVec.field_72450_a / 5.0, rotateVec.field_72448_b / 5.0, rotateVec.field_72449_c / 5.0);
                rotateVec = null;
            }
        }
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return Block.field_185506_k;
    }
    
    public AxisAlignedBB func_180640_a(final IBlockState state, final World worldIn, final BlockPos pos) {
        return BlockMagicLight.BLOCK_AABB.func_186670_a(pos);
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMagicLight.TYPE });
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMagicLight.TYPE, (Comparable)LightType.fromIndex(meta % 2));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((LightType)state.func_177229_b((IProperty)BlockMagicLight.TYPE)).getIndex();
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockMagicLight.TYPE }).func_178441_a());
        ModelUtils.setItemModelSingleIcon(Item.func_150898_a((Block)this), new String[] { "essentialcraft:torch" });
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)LightType.class);
        BLOCK_AABB = new AxisAlignedBB(0.20000000298023224, 0.20000000298023224, 0.20000000298023224, 0.800000011920929, 0.800000011920929, 0.800000011920929);
    }
    
    public enum LightType implements IStringSerializable
    {
        PLACED(0, "placed"), 
        SPAWNED(1, "spawned");
        
        private int index;
        private String name;
        
        private LightType(final int i, final String s) {
            this.index = i;
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static LightType fromIndex(final int i) {
            return values()[i % 2];
        }
    }
}
