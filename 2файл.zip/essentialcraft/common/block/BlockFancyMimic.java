package essentialcraft.common.block;

import net.minecraft.block.properties.*;
import net.minecraft.creativetab.*;
import net.minecraft.block.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.state.*;
import net.minecraftforge.common.property.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import net.minecraftforge.client.model.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.block.statemap.*;

public class BlockFancyMimic extends BlockMimic
{
    public static final PropertyEnum<BlockFancy.FancyBlockType> TYPE;
    
    public BlockFancyMimic() {
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockFancyMimic.TYPE, (Comparable)BlockFancy.FancyBlockType.ANCIENT_TILE));
    }
    
    @Override
    public int func_176201_c(final IBlockState state) {
        return ((BlockFancy.FancyBlockType)state.func_177229_b((IProperty)BlockFancyMimic.TYPE)).getIndex();
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockFancyMimic.TYPE, (Comparable)BlockFancy.FancyBlockType.fromIndex(meta));
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 16; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((BlockFancy.FancyBlockType)state.func_177229_b((IProperty)BlockFancyMimic.TYPE)).getIndex());
    }
    
    @Override
    protected BlockStateContainer func_180661_e() {
        return (BlockStateContainer)new ExtendedBlockState((Block)this, new IProperty[] { (IProperty)BlockFancyMimic.TYPE }, new IUnlistedProperty[] { (IUnlistedProperty)BlockFancyMimic.STATE, (IUnlistedProperty)BlockFancyMimic.WORLD, (IUnlistedProperty)BlockFancyMimic.POS });
    }
    
    @Override
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return this.func_185496_a(blockState, worldIn, pos);
    }
    
    @SideOnly(Side.CLIENT)
    @Override
    public void registerModels() {
        for (int i = 0; i < 16; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:fancyblock/mimicInv", "type=" + BlockFancy.FancyBlockType.fromIndex(i).func_176610_l()));
            ModelBakery.registerItemVariants(Item.func_150898_a((Block)this), new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:fancyblock/mimic", "type=" + BlockFancy.FancyBlockType.fromIndex(i).func_176610_l()), (ResourceLocation)new ModelResourceLocation("essentialcraft:fancyblock/mimic", "internal=" + BlockFancy.FancyBlockType.fromIndex(i).func_176610_l()) });
        }
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new FancyMimicStateMapper());
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)BlockFancy.FancyBlockType.class);
    }
    
    public static class FancyMimicStateMapper extends StateMapperBase
    {
        protected ModelResourceLocation func_178132_a(final IBlockState state) {
            return new ModelResourceLocation("essentialcraft:fancyblock/mimic", "internal=" + ((BlockFancy.FancyBlockType)state.func_177229_b((IProperty)BlockFancyMimic.TYPE)).func_176610_l());
        }
    }
}
