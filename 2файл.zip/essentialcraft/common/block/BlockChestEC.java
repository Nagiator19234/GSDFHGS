package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.creativetab.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.util.*;

public class BlockChestEC extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<ChestType> TYPE;
    
    public BlockChestEC() {
        super(Material.field_151576_e);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.INVISIBLE;
    }
    
    public MapColor func_180659_g(final IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        return ((ChestType)state.func_177229_b((IProperty)BlockChestEC.TYPE)).getMapColor();
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((ChestType)state.func_177229_b((IProperty)BlockChestEC.TYPE)).getIndex());
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        items.add((Object)new ItemStack((Block)this, 1, 0));
        items.add((Object)new ItemStack((Block)this, 1, 1));
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public TileEntity func_149915_a(final World world, final int metadata) {
        return new TileMagicalChest(metadata);
    }
    
    public void func_180633_a(final World worldIn, final BlockPos pos, final IBlockState state, final EntityLivingBase placer, final ItemStack stack) {
        final int l = placer.func_174811_aO().func_176736_b();
        final TileMagicalChest tile = (TileMagicalChest)worldIn.func_175625_s(pos);
        tile.rotation = l;
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public int func_180651_a(final IBlockState s) {
        return ((ChestType)s.func_177229_b((IProperty)BlockChestEC.TYPE)).getIndex();
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockChestEC.TYPE, (Comparable)ChestType.fromIndex(meta % 2));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((ChestType)state.func_177229_b((IProperty)BlockChestEC.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockChestEC.TYPE });
    }
    
    public void registerModels() {
        for (int i = 0; i < ChestType.values().length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:chestinv", "type=" + ChestType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)ChestType.class);
    }
    
    public enum ChestType implements IStringSerializable
    {
        MAGICAL(0, "magical", MapColor.field_151678_z), 
        VOID(1, "void", MapColor.field_151646_E);
        
        private final int index;
        private final String name;
        private final MapColor mapColor;
        
        private ChestType(final int index, final String name, final MapColor mapColor) {
            this.index = index;
            this.name = name;
            this.mapColor = mapColor;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public MapColor getMapColor() {
            return this.mapColor;
        }
        
        public static ChestType fromIndex(final int i) {
            return values()[i % 2];
        }
    }
}
