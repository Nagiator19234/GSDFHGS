package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.util.math.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraftforge.oredict.*;
import java.util.*;
import net.minecraft.block.state.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.fml.relauncher.*;

public class BlockDyeable extends Block implements IBlockColor, IModelRegisterer
{
    public static final String[] COLOR_NAMES;
    public static final int[] COLOR_VALUES;
    public static final PropertyEnum<EnumDyeColor> COLOR;
    
    public int colorMultiplier(final IBlockState state, final IBlockAccess world, final BlockPos pos, final int tint) {
        int metadata = ((EnumDyeColor)state.func_177229_b((IProperty)BlockDyeable.COLOR)).func_176767_b();
        if (metadata == 0) {
            metadata = 15;
        }
        else if (metadata == 15) {
            metadata = 0;
        }
        if (metadata == 32767) {
            metadata = 0;
        }
        return BlockDyeable.COLOR_VALUES[metadata];
    }
    
    public BlockDyeable(final Material material, final MapColor mapColor) {
        super(material, mapColor);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockDyeable.COLOR, (Comparable)EnumDyeColor.WHITE));
    }
    
    public BlockDyeable(final Material material) {
        this(material, material.func_151565_r());
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return this.field_149764_J != Material.field_151592_s;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return this.field_149764_J != Material.field_151592_s;
    }
    
    public BlockRenderLayer func_180664_k() {
        return (this.field_149764_J == Material.field_151592_s) ? BlockRenderLayer.TRANSLUCENT : BlockRenderLayer.SOLID;
    }
    
    public boolean func_176225_a(final IBlockState blockState, final IBlockAccess blockAccess, final BlockPos pos, final EnumFacing side) {
        return blockAccess.func_180495_p(pos.func_177972_a(side)).func_177230_c() != this && super.func_176225_a(blockState, blockAccess, pos, side);
    }
    
    public boolean func_180639_a(final World world, final BlockPos pos, final IBlockState state, final EntityPlayer player, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack is = player.func_184586_b(hand);
        if (!is.func_190926_b() && OreDictionary.getOreIDs(is).length > 0 && !(is.func_77973_b() instanceof ItemBlock)) {
            for (int i = 0; i < OreDictionary.getOreIDs(is).length; ++i) {
                final String oreDictName = OreDictionary.getOreName(OreDictionary.getOreIDs(is)[i]);
                if (oreDictName != null && !oreDictName.isEmpty() && !oreDictName.equalsIgnoreCase("unknown")) {
                    int color = -1;
                    for (int i2 = 0; i2 < BlockDyeable.COLOR_NAMES.length; ++i2) {
                        final String dyeName = "dye" + BlockDyeable.COLOR_NAMES[i2];
                        if (oreDictName.equalsIgnoreCase(dyeName)) {
                            color = i2;
                            break;
                        }
                    }
                    if (color != -1) {
                        if (color == 0) {
                            color = 15;
                        }
                        else if (color == 15) {
                            color = 0;
                        }
                        if (player.func_70093_af()) {
                            for (final BlockPos blockPos : BlockPos.func_177975_b(pos.func_177982_a(2, 2, 2), pos.func_177982_a(-2, -2, -2))) {
                                final Block b = world.func_180495_p(blockPos).func_177230_c();
                                if (b == this) {
                                    b.recolorBlock(world, blockPos, side, EnumDyeColor.func_176766_a(color));
                                    world.func_72975_g(blockPos.func_177958_n(), blockPos.func_177952_p(), blockPos.func_177956_o() - 2, blockPos.func_177956_o() + 2);
                                }
                            }
                        }
                        else {
                            this.recolorBlock(world, pos, side, EnumDyeColor.func_176766_a(color));
                            world.func_72975_g(pos.func_177958_n(), pos.func_177952_p(), pos.func_177956_o() - 2, pos.func_177956_o() + 2);
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean recolorBlock(final World world, final BlockPos pos, final EnumFacing side, final EnumDyeColor color) {
        int meta = this.func_176201_c(world.func_180495_p(pos));
        if (meta == 0) {
            meta = 15;
        }
        else if (meta == 15) {
            meta = 0;
        }
        if (meta != color.func_176767_b()) {
            meta = color.func_176767_b();
            if (meta == 0) {
                meta = 15;
            }
            else if (meta == 15) {
                meta = 0;
            }
            world.func_180501_a(pos, this.func_176203_a(meta), 2);
            return true;
        }
        return false;
    }
    
    public IBlockState func_176203_a(final int meta) {
        int color = meta;
        if (color == 0) {
            color = 15;
        }
        else if (color == 15) {
            color = 0;
        }
        return this.func_176223_P().func_177226_a((IProperty)BlockDyeable.COLOR, (Comparable)EnumDyeColor.func_176766_a(color));
    }
    
    public int func_176201_c(final IBlockState state) {
        int color = ((EnumDyeColor)state.func_177229_b((IProperty)BlockDyeable.COLOR)).func_176767_b();
        if (color == 0) {
            color = 15;
        }
        else if (color == 15) {
            color = 0;
        }
        return color;
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockDyeable.COLOR });
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockDyeable.COLOR }).func_178441_a());
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:" + this.getRegistryName().func_110623_a(), "inventory"));
    }
    
    static {
        COLOR_NAMES = new String[] { "white", "red", "green", "brown", "blue", "purple", "cyan", "lightgray", "gray", "pink", "lime", "yellow", "lightblue", "magenta", "orange", "black" };
        COLOR_VALUES = new int[] { 15790320, 11743532, 3887386, 5320730, 2437522, 8073150, 2651799, 11250603, 4408131, 14188952, 4312372, 14602026, 6719955, 12801229, 15435844, 1973019 };
        COLOR = PropertyEnum.func_177709_a("color", (Class)EnumDyeColor.class);
    }
}
