package essentialcraft.common.block;

import DummyCore.Client.*;
import com.mojang.authlib.*;
import net.minecraft.block.material.*;
import net.minecraft.creativetab.*;
import net.minecraft.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.passive.*;
import net.minecraftforge.common.util.*;
import net.minecraft.entity.player.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.block.state.*;
import net.minecraft.inventory.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import java.util.*;
import net.minecraft.util.*;

public class BlockRedstoneDeviceNotSided extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<DeviceType> TYPE;
    public static final String[] NAMES;
    public static GameProfile planterFakePlayerProfile;
    public static GameProfile breederFakePlayerProfile;
    
    public BlockRedstoneDeviceNotSided() {
        super(Material.field_151576_e);
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 9; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public int func_180651_a(final IBlockState meta) {
        return ((DeviceType)meta.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex();
    }
    
    public void shear(final Entity en, final IShearable e) {
        if (e.isShearable(new ItemStack((Item)Items.field_151097_aZ), (IBlockAccess)en.func_130014_f_(), en.func_180425_c())) {
            final List<ItemStack> items = (List<ItemStack>)e.onSheared(new ItemStack((Item)Items.field_151097_aZ), (IBlockAccess)en.func_130014_f_(), en.func_180425_c(), 2);
            for (final ItemStack is : items) {
                if (!is.func_190926_b()) {
                    final EntityItem itm = new EntityItem(en.func_130014_f_(), en.field_70165_t, en.field_70163_u, en.field_70161_v, is);
                    if (en.func_130014_f_().field_72995_K) {
                        continue;
                    }
                    en.func_130014_f_().func_72838_d((Entity)itm);
                }
            }
        }
    }
    
    public void breed(final EntityItem e) {
        if (!e.func_92059_d().func_190926_b()) {
            final AxisAlignedBB aabb = new AxisAlignedBB(e.field_70165_t - 0.5, e.field_70163_u - 0.5, e.field_70161_v - 0.5, e.field_70165_t + 0.5, e.field_70163_u + 0.5, e.field_70161_v + 0.5).func_72321_a(3.0, 3.0, 3.0);
            final List<EntityAnimal> animals = (List<EntityAnimal>)e.func_130014_f_().func_72872_a((Class)EntityAnimal.class, aabb);
            for (final EntityAnimal animal : animals) {
                if (animal.func_70877_b(e.func_92059_d()) && animal.func_70874_b() == 0 && !animal.func_70880_s()) {
                    final FakePlayer fake = new FakePlayer((WorldServer)e.func_130014_f_(), BlockRedstoneDeviceNotSided.breederFakePlayerProfile);
                    animal.func_146082_f((EntityPlayer)fake);
                    e.func_92059_d().func_190918_g(1);
                    if (this.invalidate(e)) {
                        break;
                    }
                    continue;
                }
            }
        }
    }
    
    public void shuffle(final EntityItem e) {
        if (!e.func_130014_f_().field_72995_K) {
            e.func_70080_a(e.field_70165_t + MathUtils.randomDouble(e.func_130014_f_().field_73012_v), e.field_70163_u, e.field_70161_v + MathUtils.randomDouble(e.func_130014_f_().field_73012_v), 0.0f, 0.0f);
        }
    }
    
    public void plant(final EntityItem e) {
        final BlockPos p = e.func_180425_c();
        if (e.func_92059_d() != null && !e.func_130014_f_().field_72995_K) {
            final ItemStack stk = e.func_92059_d();
            if (stk.func_77973_b() instanceof ItemBlock) {
                final Block b = Block.func_149634_a(stk.func_77973_b());
                if (b instanceof IPlantable && e.func_130014_f_().func_175623_d(p) && e.func_130014_f_().func_180495_p(p.func_177977_b()).func_177230_c().canSustainPlant(e.func_130014_f_().func_180495_p(p.func_177977_b()), (IBlockAccess)e.func_130014_f_(), p.func_177977_b(), EnumFacing.UP, (IPlantable)b)) {
                    final FakePlayer user = new FakePlayer((WorldServer)e.func_130014_f_(), BlockRedstoneDeviceNotSided.planterFakePlayerProfile);
                    stk.func_77973_b().func_180614_a((EntityPlayer)user, e.func_130014_f_(), p.func_177977_b(), EnumHand.MAIN_HAND, EnumFacing.UP, 0.0f, 0.0f, 0.0f);
                    this.invalidate(e);
                }
            }
            else if (stk.func_77973_b() instanceof IPlantable) {
                if (e.func_130014_f_().func_175623_d(p) && e.func_130014_f_().func_180495_p(p.func_177977_b()).func_177230_c().canSustainPlant(e.func_130014_f_().func_180495_p(p.func_177977_b()), (IBlockAccess)e.func_130014_f_(), p.func_177977_b(), EnumFacing.UP, (IPlantable)stk.func_77973_b())) {
                    final FakePlayer user2 = new FakePlayer((WorldServer)e.func_130014_f_(), BlockRedstoneDeviceNotSided.planterFakePlayerProfile);
                    stk.func_77973_b().func_180614_a((EntityPlayer)user2, e.func_130014_f_(), p.func_177977_b(), EnumHand.MAIN_HAND, EnumFacing.UP, 0.0f, 0.0f, 0.0f);
                    this.invalidate(e);
                }
            }
            else if (stk.func_77973_b() instanceof ItemBlockSpecial) {
                final Block b = ((ItemBlockSpecial)stk.func_77973_b()).getBlock();
                if (b instanceof IPlantable && e.func_130014_f_().func_175623_d(p) && e.func_130014_f_().func_180495_p(p.func_177977_b()).func_177230_c().canSustainPlant(e.func_130014_f_().func_180495_p(p.func_177977_b()), (IBlockAccess)e.func_130014_f_(), p.func_177977_b(), EnumFacing.UP, (IPlantable)b)) {
                    final FakePlayer user = new FakePlayer((WorldServer)e.func_130014_f_(), BlockRedstoneDeviceNotSided.planterFakePlayerProfile);
                    stk.func_77973_b().func_180614_a((EntityPlayer)user, e.func_130014_f_(), p.func_177977_b(), EnumHand.MAIN_HAND, EnumFacing.UP, 0.0f, 0.0f, 0.0f);
                    this.invalidate(e);
                }
            }
        }
    }
    
    public boolean invalidate(final EntityItem e) {
        if (e.func_92059_d().func_190926_b() || e.func_92059_d().func_190916_E() <= 0) {
            e.func_70106_y();
            return true;
        }
        return false;
    }
    
    public boolean func_149744_f(final IBlockState s) {
        return true;
    }
    
    public void func_189540_a(final IBlockState s, final World w, final BlockPos p, final Block n, final BlockPos fp) {
        if (((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 0 && (w.func_175687_A(p) > 0 || w.func_175676_y(p) > 0)) {
            final AxisAlignedBB aabb = new AxisAlignedBB(p).func_72314_b(12.0, 12.0, 12.0);
            final List<EntityItem> items = (List<EntityItem>)w.func_72872_a((Class)EntityItem.class, aabb);
            for (final EntityItem itm : items) {
                if (!itm.field_70128_L) {
                    this.plant(itm);
                }
            }
        }
        if (((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 1 && (w.func_175687_A(p) > 0 || w.func_175676_y(p) > 0)) {
            final AxisAlignedBB aabb = new AxisAlignedBB(p).func_72314_b(12.0, 12.0, 12.0);
            final List<EntityItem> items = (List<EntityItem>)w.func_72872_a((Class)EntityItem.class, aabb);
            for (final EntityItem itm : items) {
                if (!itm.field_70128_L) {
                    this.shuffle(itm);
                }
            }
        }
        if (((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 3 && (w.func_175687_A(p) > 0 || w.func_175676_y(p) > 0)) {
            final AxisAlignedBB aabb = new AxisAlignedBB(p).func_72314_b(12.0, 12.0, 12.0);
            final List<EntityItem> items = (List<EntityItem>)w.func_72872_a((Class)EntityItem.class, aabb);
            for (final EntityItem itm : items) {
                if (!itm.field_70128_L) {
                    this.breed(itm);
                }
            }
        }
        if (((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 5 && (w.func_175687_A(p) > 0 || w.func_175676_y(p) > 0)) {
            final AxisAlignedBB aabb = new AxisAlignedBB(p).func_72314_b(12.0, 12.0, 12.0);
            final List<Entity> entities = (List<Entity>)w.func_72872_a((Class)Entity.class, aabb);
            final List<IShearable> sheep = new ArrayList<IShearable>();
            for (final Entity e : entities) {
                if (e instanceof IShearable) {
                    sheep.add((IShearable)e);
                }
            }
            for (final IShearable sh : sheep) {
                this.shear((Entity)sh, sh);
            }
        }
        if ((((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 6 || ((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 7) && (w.func_175687_A(p) > 0 || w.func_175676_y(p) > 0)) {
            ((TileAnimalSeparator)w.func_175625_s(p)).separate(((DeviceType)s.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 6);
        }
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        switch (meta) {
            case 2: {
                return new TileCrafter();
            }
            case 4: {
                return new TileCreativeMRUSource();
            }
            case 6:
            case 7: {
                return new TileAnimalSeparator();
            }
            case 8: {
                return new TileCreativeESPESource();
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (world.func_175625_s(par2) == null || ((DeviceType)par3.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 4 || ((DeviceType)par3.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex() == 8 || player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockRedstoneDeviceNotSided.TYPE, (Comparable)DeviceType.fromIndex(meta % 9));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((DeviceType)state.func_177229_b((IProperty)BlockRedstoneDeviceNotSided.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockRedstoneDeviceNotSided.TYPE });
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        if (world.func_175625_s(pos) != null) {
            final TileEntity tile = world.func_175625_s(pos);
            if (tile instanceof IInventory) {
                final IInventory inv = (IInventory)tile;
                InventoryHelper.func_180175_a(world, pos, inv);
            }
        }
        super.func_180663_b(world, pos, blockstate);
    }
    
    public void registerModels() {
        for (int i = 0; i < DeviceType.values().length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:device", "type=" + DeviceType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)DeviceType.class);
        NAMES = new String[] { "replanter", "itemShuffler", "crafter", "breeder", "creativeMRUStorage", "shearingStation", "childSeparator", "adultSeparator", "creativeESPEStorage" };
        BlockRedstoneDeviceNotSided.planterFakePlayerProfile = new GameProfile(UUID.fromString("5cd89d0b-e9ba-0000-89f4-badbb05964ac"), "[EC3]Planter");
        BlockRedstoneDeviceNotSided.breederFakePlayerProfile = new GameProfile(UUID.fromString("5cd89d0b-e9ba-0000-89f4-badbb05964ad"), "[EC3]Breeder");
    }
    
    public enum DeviceType implements IStringSerializable
    {
        REPLANTER("replanter"), 
        ITEM_SHUFFLER("item_shuffler"), 
        CRAFTER("crafter"), 
        BREEDER("breeder"), 
        CREATIVE_MRU_STORAGE("creative_mru_storage"), 
        SHEARING_STATION("shearing_station"), 
        CHILD_SEPARATOR("child_separator"), 
        ADULT_SEPARATOR("adult_separator"), 
        CREATIVE_ESPE_STORAGE("creative_espe_storage");
        
        private int index;
        private String name;
        
        private DeviceType(final String s) {
            this.index = this.ordinal();
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static DeviceType fromIndex(final int i) {
            return values()[i];
        }
    }
}
