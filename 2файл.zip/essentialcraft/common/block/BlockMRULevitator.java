package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.world.*;
import java.util.*;
import essentialcraft.common.mod.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMRULevitator extends Block implements IModelRegisterer
{
    public BlockMRULevitator() {
        super(Material.field_151576_e);
        this.func_149675_a(true);
    }
    
    public void func_180655_c(final IBlockState s, final World state, final BlockPos world, final Random rand) {
        for (int i = 0; i < 12; ++i) {
            EssentialCraftCore.proxy.spawnParticle("mruFX", world.func_177958_n() + 0.5f + MathUtils.randomFloat(rand) / 5.0f, world.func_177956_o() + 0.5f, world.func_177952_p() + 0.5f + MathUtils.randomFloat(rand) / 5.0f, 0.0, -5.0f - MathUtils.randomFloat(rand) * 5.0f, 0.0);
            Vec3d rotateVec = new Vec3d(1.0, 0.0, 1.0);
            rotateVec = rotateVec.func_178785_b((float)(i * 30));
            for (int i2 = 0; i2 < 3; ++i2) {
                EssentialCraftCore.proxy.spawnParticle("mruFX", world.func_177958_n() + 0.5f + MathUtils.randomFloat(rand) / 5.0f, world.func_177956_o() + 0.25f, world.func_177952_p() + 0.5f + MathUtils.randomFloat(rand) / 5.0f, rotateVec.field_72450_a, 0.0, rotateVec.field_72449_c);
            }
        }
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:levitator", "inventory"));
    }
}
