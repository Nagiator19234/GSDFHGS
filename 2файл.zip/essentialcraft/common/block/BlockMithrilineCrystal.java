package essentialcraft.common.block;

import DummyCore.Utils.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.world.*;
import net.minecraft.block.material.*;
import net.minecraft.creativetab.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.block.state.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import DummyCore.Client.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;

public class BlockMithrilineCrystal extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<CrystalType> TYPE;
    public static final PropertyEnum<EnumLayer> LAYER;
    public static final AxisAlignedBB BLOCK_AABB;
    
    public BlockMithrilineCrystal() {
        super(Material.field_151576_e);
        this.func_149672_a(SoundType.field_185853_f);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockMithrilineCrystal.TYPE, (Comparable)CrystalType.MITHRILINE).func_177226_a((IProperty)BlockMithrilineCrystal.LAYER, (Comparable)EnumLayer.BOTTOM));
    }
    
    public int func_180651_a(final IBlockState s) {
        return ((CrystalType)s.func_177229_b((IProperty)BlockMithrilineCrystal.TYPE)).getIndex() * 3;
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((CrystalType)state.func_177229_b((IProperty)BlockMithrilineCrystal.TYPE)).getIndex() * 3);
    }
    
    public MapColor func_180659_g(final IBlockState state, final IBlockAccess worldIn, final BlockPos pos) {
        return ((CrystalType)state.func_177229_b((IProperty)BlockMithrilineCrystal.TYPE)).getMapColor();
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        items.add((Object)new ItemStack((Block)this, 1, 0));
        items.add((Object)new ItemStack((Block)this, 1, 3));
        items.add((Object)new ItemStack((Block)this, 1, 6));
        items.add((Object)new ItemStack((Block)this, 1, 9));
        items.add((Object)new ItemStack((Block)this, 1, 12));
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        super.func_180663_b(world, pos, blockstate);
        final int par6 = ((EnumLayer)blockstate.func_177229_b((IProperty)BlockMithrilineCrystal.LAYER)).getIndexThree();
        if (par6 == 0) {
            world.func_175698_g(pos.func_177984_a());
            world.func_175698_g(pos.func_177981_b(2));
        }
        if (par6 == 1) {
            world.func_175698_g(pos.func_177977_b());
            world.func_175698_g(pos.func_177984_a());
        }
        if (par6 == 2) {
            world.func_175698_g(pos.func_177977_b());
            world.func_175698_g(pos.func_177979_c(2));
        }
    }
    
    public void func_176213_c(final World w, final BlockPos p, final IBlockState s) {
        super.func_176213_c(w, p, s);
        final int meta = this.func_176201_c(s);
        if (meta % 3 == 0) {
            w.func_180501_a(p.func_177984_a(), this.func_176203_a(meta + 1), 3);
            w.func_180501_a(p.func_177981_b(2), this.func_176203_a(meta + 1), 3);
        }
    }
    
    public boolean func_176196_c(final World world, final BlockPos pos) {
        return world.func_180495_p(pos).func_177230_c().func_176200_f((IBlockAccess)world, pos) && world.func_180495_p(pos.func_177984_a()).func_177230_c().func_176200_f((IBlockAccess)world, pos.func_177984_a()) && world.func_180495_p(pos.func_177981_b(2)).func_177230_c().func_176200_f((IBlockAccess)world, pos.func_177981_b(2));
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return (meta % 3 == 0) ? new TileMithrilineCrystal(meta / 3) : null;
    }
    
    public float getEnchantPowerBonus(final World world, final BlockPos pos) {
        if (world.func_180495_p(pos).func_177229_b((IProperty)BlockMithrilineCrystal.LAYER) == EnumLayer.BOTTOM) {
            final int meta = ((CrystalType)world.func_180495_p(pos).func_177229_b((IProperty)BlockMithrilineCrystal.TYPE)).getIndex();
            return (meta == 0) ? 7.5f : ((meta == 1) ? 15.0f : ((meta == 2) ? 30.0f : ((meta == 3) ? 60.0f : ((meta == 4) ? 120.0f : 0.0f))));
        }
        return 0.0f;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockMithrilineCrystal.TYPE, (Comparable)CrystalType.fromIndex(meta % 15 / 3)).func_177226_a((IProperty)BlockMithrilineCrystal.LAYER, (Comparable)EnumLayer.fromIndexThree(meta % 3));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((CrystalType)state.func_177229_b((IProperty)BlockMithrilineCrystal.TYPE)).getIndex() * 3 + ((EnumLayer)state.func_177229_b((IProperty)BlockMithrilineCrystal.LAYER)).getIndexThree();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockMithrilineCrystal.TYPE, (IProperty)BlockMithrilineCrystal.LAYER });
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        return BlockMithrilineCrystal.BLOCK_AABB;
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockMithrilineCrystal.LAYER }).func_178441_a());
        if (!Loader.isModLoaded("codechickenlib")) {
            for (int i = 0; i < 5; ++i) {
                ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i * 3, new ModelResourceLocation("essentialcraft:mithrilinecrystalinv", "type=" + CrystalType.fromIndex(i).func_176610_l()));
            }
        }
        else {
            ModelUtils.setItemModelSingleIcon(Item.func_150898_a((Block)this), new String[] { "essentialcraft:mithrilinecrystal" });
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)CrystalType.class);
        LAYER = PropertyEnum.func_177706_a("layer", (Class)EnumLayer.class, (Enum[])EnumLayer.LAYERTHREE);
        BLOCK_AABB = new AxisAlignedBB(0.25, 0.0, 0.25, 0.75, 1.0, 0.75);
    }
    
    public enum CrystalType implements IStringSerializable
    {
        MITHRILINE(0, "mithriline", MapColor.field_151651_C), 
        PALE(1, "pale", MapColor.field_151652_H), 
        VOID(2, "void", MapColor.field_151646_E), 
        DEMONIC(3, "demonic", MapColor.field_151645_D), 
        SHADE(4, "shade", MapColor.field_151670_w);
        
        private final int index;
        private final String name;
        private final MapColor mapColor;
        
        private CrystalType(final int index, final String name, final MapColor mapColor) {
            this.index = index;
            this.name = name;
            this.mapColor = mapColor;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public MapColor getMapColor() {
            return this.mapColor;
        }
        
        public static CrystalType fromIndex(final int i) {
            return values()[i];
        }
    }
}
