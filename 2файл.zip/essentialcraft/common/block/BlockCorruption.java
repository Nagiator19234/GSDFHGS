package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.block.state.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockCorruption extends BlockContainer implements IModelRegisterer
{
    public static final PropertyInteger LEVEL;
    public static final PropertyBool DOWN;
    public static final PropertyBool UP;
    public static final PropertyBool SOUTH;
    public static final PropertyBool NORTH;
    public static final PropertyBool EAST;
    public static final PropertyBool WEST;
    public String textureName;
    
    protected BlockCorruption() {
        super(Material.field_151594_q);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockCorruption.LEVEL, (Comparable)0).func_177226_a((IProperty)BlockCorruption.DOWN, (Comparable)false).func_177226_a((IProperty)BlockCorruption.UP, (Comparable)false).func_177226_a((IProperty)BlockCorruption.SOUTH, (Comparable)false).func_177226_a((IProperty)BlockCorruption.NORTH, (Comparable)false).func_177226_a((IProperty)BlockCorruption.EAST, (Comparable)false).func_177226_a((IProperty)BlockCorruption.WEST, (Comparable)false));
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public BlockRenderLayer func_180664_k() {
        return BlockRenderLayer.TRANSLUCENT;
    }
    
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return Block.field_185506_k;
    }
    
    public boolean func_149686_d(final IBlockState state) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 8; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, (int)state.func_177229_b((IProperty)BlockCorruption.LEVEL));
    }
    
    public int func_180651_a(final IBlockState state) {
        return (int)state.func_177229_b((IProperty)BlockCorruption.LEVEL);
    }
    
    public Item func_180660_a(final IBlockState state, final Random rand, final int fortune) {
        return null;
    }
    
    public int func_149745_a(final Random rand) {
        return 0;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileCorruption();
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockCorruption.LEVEL, (Comparable)meta);
    }
    
    public int func_176201_c(final IBlockState state) {
        return (int)state.func_177229_b((IProperty)BlockCorruption.LEVEL);
    }
    
    public BlockCorruption setBlockTextureName(final String string) {
        this.textureName = string;
        return this;
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockCorruption.LEVEL, (IProperty)BlockCorruption.DOWN, (IProperty)BlockCorruption.UP, (IProperty)BlockCorruption.SOUTH, (IProperty)BlockCorruption.NORTH, (IProperty)BlockCorruption.EAST, (IProperty)BlockCorruption.WEST });
    }
    
    public IBlockState func_176221_a(final IBlockState state, final IBlockAccess world, final BlockPos pos) {
        return state.func_177226_a((IProperty)BlockCorruption.DOWN, (Comparable)world.func_180495_p(pos.func_177977_b()).func_185898_k()).func_177226_a((IProperty)BlockCorruption.UP, (Comparable)world.func_180495_p(pos.func_177984_a()).func_185898_k()).func_177226_a((IProperty)BlockCorruption.SOUTH, (Comparable)world.func_180495_p(pos.func_177968_d()).func_185898_k()).func_177226_a((IProperty)BlockCorruption.NORTH, (Comparable)world.func_180495_p(pos.func_177978_c()).func_185898_k()).func_177226_a((IProperty)BlockCorruption.EAST, (Comparable)world.func_180495_p(pos.func_177974_f()).func_185898_k()).func_177226_a((IProperty)BlockCorruption.WEST, (Comparable)world.func_180495_p(pos.func_177976_e()).func_185898_k());
    }
    
    public void registerModels() {
        for (int i = 0; i < 8; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:" + this.getRegistryName().func_110623_a() + "Inv", "level=" + i));
        }
    }
    
    static {
        LEVEL = PropertyInteger.func_177719_a("level", 0, 7);
        DOWN = PropertyBool.func_177716_a("down");
        UP = PropertyBool.func_177716_a("up");
        SOUTH = PropertyBool.func_177716_a("south");
        NORTH = PropertyBool.func_177716_a("north");
        EAST = PropertyBool.func_177716_a("east");
        WEST = PropertyBool.func_177716_a("west");
    }
}
