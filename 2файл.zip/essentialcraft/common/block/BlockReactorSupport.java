package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import DummyCore.Utils.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.state.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.world.chunk.*;
import essentialcraft.common.tile.*;
import net.minecraft.tileentity.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockReactorSupport extends Block implements IModelRegisterer
{
    public static final PropertyEnum<EnumLayer> LAYER;
    public static final PropertyBool SOUTH;
    public static final PropertyBool EAST;
    public static final PropertyBool NORTH;
    public static final PropertyBool WEST;
    
    public BlockReactorSupport() {
        super(Material.field_151576_e, MapColor.field_151678_z);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockReactorSupport.SOUTH, (Comparable)false).func_177226_a((IProperty)BlockReactorSupport.EAST, (Comparable)false).func_177226_a((IProperty)BlockReactorSupport.NORTH, (Comparable)false).func_177226_a((IProperty)BlockReactorSupport.WEST, (Comparable)false).func_177226_a((IProperty)BlockReactorSupport.LAYER, (Comparable)EnumLayer.BOTTOM));
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockReactorSupport.LAYER, (IProperty)BlockReactorSupport.SOUTH, (IProperty)BlockReactorSupport.EAST, (IProperty)BlockReactorSupport.NORTH, (IProperty)BlockReactorSupport.WEST });
    }
    
    public IBlockState func_176221_a(final IBlockState state, final IBlockAccess world, final BlockPos pos) {
        final Block b0 = world.func_180495_p(pos.func_177977_b()).func_177230_c();
        final Block b2 = world.func_180495_p(pos.func_177979_c(2)).func_177230_c();
        final TileEntity ste = (world instanceof ChunkCache) ? ((ChunkCache)world).func_190300_a(pos.func_177968_d(), Chunk.EnumCreateEntityType.CHECK) : world.func_175625_s(pos.func_177968_d());
        final TileEntity ete = (world instanceof ChunkCache) ? ((ChunkCache)world).func_190300_a(pos.func_177974_f(), Chunk.EnumCreateEntityType.CHECK) : world.func_175625_s(pos.func_177974_f());
        final TileEntity nte = (world instanceof ChunkCache) ? ((ChunkCache)world).func_190300_a(pos.func_177978_c(), Chunk.EnumCreateEntityType.CHECK) : world.func_175625_s(pos.func_177978_c());
        final TileEntity wte = (world instanceof ChunkCache) ? ((ChunkCache)world).func_190300_a(pos.func_177976_e(), Chunk.EnumCreateEntityType.CHECK) : world.func_175625_s(pos.func_177976_e());
        final boolean s = ste != null && ste instanceof TileMRUReactor && ((TileMRUReactor)ste).isStructureCorrect;
        final boolean e = ete != null && ete instanceof TileMRUReactor && ((TileMRUReactor)ete).isStructureCorrect;
        final boolean n = nte != null && nte instanceof TileMRUReactor && ((TileMRUReactor)nte).isStructureCorrect;
        final boolean w = wte != null && wte instanceof TileMRUReactor && ((TileMRUReactor)wte).isStructureCorrect;
        return state.func_177226_a((IProperty)BlockReactorSupport.LAYER, (Comparable)((b0 == this) ? ((b2 == this) ? EnumLayer.fromIndexThree(2) : EnumLayer.fromIndexThree(1)) : EnumLayer.fromIndexThree(0))).func_177226_a((IProperty)BlockReactorSupport.SOUTH, (Comparable)s).func_177226_a((IProperty)BlockReactorSupport.EAST, (Comparable)e).func_177226_a((IProperty)BlockReactorSupport.NORTH, (Comparable)n).func_177226_a((IProperty)BlockReactorSupport.WEST, (Comparable)w);
    }
    
    public IBlockState func_185499_a(final IBlockState state, final Rotation rot) {
        switch (rot) {
            case CLOCKWISE_180: {
                return state.func_177226_a((IProperty)BlockReactorSupport.NORTH, state.func_177229_b((IProperty)BlockReactorSupport.SOUTH)).func_177226_a((IProperty)BlockReactorSupport.EAST, state.func_177229_b((IProperty)BlockReactorSupport.WEST)).func_177226_a((IProperty)BlockReactorSupport.SOUTH, state.func_177229_b((IProperty)BlockReactorSupport.NORTH)).func_177226_a((IProperty)BlockReactorSupport.WEST, state.func_177229_b((IProperty)BlockReactorSupport.EAST));
            }
            case COUNTERCLOCKWISE_90: {
                return state.func_177226_a((IProperty)BlockReactorSupport.NORTH, state.func_177229_b((IProperty)BlockReactorSupport.EAST)).func_177226_a((IProperty)BlockReactorSupport.EAST, state.func_177229_b((IProperty)BlockReactorSupport.SOUTH)).func_177226_a((IProperty)BlockReactorSupport.SOUTH, state.func_177229_b((IProperty)BlockReactorSupport.WEST)).func_177226_a((IProperty)BlockReactorSupport.WEST, state.func_177229_b((IProperty)BlockReactorSupport.NORTH));
            }
            case CLOCKWISE_90: {
                return state.func_177226_a((IProperty)BlockReactorSupport.NORTH, state.func_177229_b((IProperty)BlockReactorSupport.WEST)).func_177226_a((IProperty)BlockReactorSupport.EAST, state.func_177229_b((IProperty)BlockReactorSupport.NORTH)).func_177226_a((IProperty)BlockReactorSupport.SOUTH, state.func_177229_b((IProperty)BlockReactorSupport.EAST)).func_177226_a((IProperty)BlockReactorSupport.WEST, state.func_177229_b((IProperty)BlockReactorSupport.SOUTH));
            }
            default: {
                return state;
            }
        }
    }
    
    public IBlockState func_185471_a(final IBlockState state, final Mirror mirrorIn) {
        switch (mirrorIn) {
            case LEFT_RIGHT: {
                return state.func_177226_a((IProperty)BlockReactorSupport.NORTH, state.func_177229_b((IProperty)BlockReactorSupport.SOUTH)).func_177226_a((IProperty)BlockReactorSupport.SOUTH, state.func_177229_b((IProperty)BlockReactorSupport.NORTH));
            }
            case FRONT_BACK: {
                return state.func_177226_a((IProperty)BlockReactorSupport.EAST, state.func_177229_b((IProperty)BlockReactorSupport.WEST)).func_177226_a((IProperty)BlockReactorSupport.WEST, state.func_177229_b((IProperty)BlockReactorSupport.EAST));
            }
            default: {
                return super.func_185471_a(state, mirrorIn);
            }
        }
    }
    
    public int func_176201_c(final IBlockState state) {
        return 0;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:reactorsupport", "inventory"));
    }
    
    static {
        LAYER = PropertyEnum.func_177706_a("layer", (Class)EnumLayer.class, (Enum[])EnumLayer.LAYERTHREE);
        SOUTH = PropertyBool.func_177716_a("south");
        EAST = PropertyBool.func_177716_a("east");
        NORTH = PropertyBool.func_177716_a("north");
        WEST = PropertyBool.func_177716_a("west");
    }
}
