package essentialcraft.common.block;

import net.minecraft.block.material.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import essentialcraft.common.mod.*;
import DummyCore.Registries.*;
import essentialcraft.common.item.*;
import essentialcraft.common.registry.*;
import java.util.*;

public class BlocksCore
{
    public static Block drops;
    public static Block magicPlating;
    public static Block fortifiedGlass;
    public static Block ecController;
    public static Block ecAcceptor;
    public static Block ecBalancer;
    public static Block ecEjector;
    public static Block ecHoldingChamber;
    public static Block ecStateChecker;
    public static Block ecRedstoneController;
    public static Block rayTower;
    public static Block moonWell;
    public static Block solarPrism;
    public static Block sunRayAbsorber;
    public static Block coldStone;
    public static Block coldDistillator;
    public static Block naturalFurnace;
    public static Block heatGenerator;
    public static Block enderGenerator;
    public static Block magicianTable;
    public static Block fortifiedStone;
    public static Block magicalQuarry;
    public static Block monsterClinger;
    public static Block potionSpreader;
    public static Block magicalEnchanter;
    public static Block monsterHarvester;
    public static Block magicalRepairer;
    public static Block matrixAbsorber;
    public static Block radiatingChamber;
    public static Block magmaticSmeltery;
    public static Block magicalJukebox;
    public static Block elementalCrystal;
    public static Block crystalFormer;
    public static Block crystalController;
    public static Block crystalExtractor;
    public static Block chargingChamber;
    public static Block voidStone;
    public static Block voidGlass;
    public static Block concrete;
    public static BlockDreadCactus cacti;
    public static Block dreadDirt;
    public static Block flowerGreen;
    public static Block fruit;
    public static Block root;
    public static Block tallGrass;
    public static Block thorns;
    public static Block magicalTeleporter;
    public static Block magicalFurnace;
    public static Block emberForge;
    public static Block levitator;
    public static Block spreader;
    public static Block[] fence;
    public static Block torch;
    public static Block blockPale;
    public static Block platingPale;
    public static Block mruCoilHardener;
    public static Block mruCoil;
    public static Block corruptionCleaner;
    public static Block reactorSupport;
    public static Block reactor;
    public static Block air;
    public static Block darknessObelisk;
    public static Block ultraHeatGen;
    public static Block ultraFlowerBurner;
    public static Block magicalMirror;
    public static Block magicalDisplay;
    public static BlockHoannaPortal portal;
    public static Block oreDrops;
    public static Block invertedBlock;
    public static Block mithrilineCrystal;
    public static Block mithrilineFurnace;
    public static Block demonicPlating;
    public static Block playerPentacle;
    public static Block windRune;
    public static Block rightClicker;
    public static Block redstoneTransmitter;
    public static Block magicalHopper;
    public static Block metadataManager;
    public static Block blockBreaker;
    public static Block compressed;
    public static Block demonicPentacle;
    public static Block weaponMaker;
    public static Block furnaceMagic;
    public static Block holopad;
    public static Block chest;
    public static Block mimInvStorage;
    public static Block newMim;
    public static Block mimScreen;
    public static Block mimCrafter;
    public static Block mimEjector;
    public static Block mimInjector;
    public static Block device;
    public static Block advBreaker;
    public static Block mimEjectorP;
    public static Block mimInjectorP;
    public static Block oreMithriline;
    public static Block crystalLamp;
    public static Block mimic;
    public static Block chunkLoader;
    public static Block dimTransciever;
    public static Block intersector;
    public static Block weatherController;
    public static Block water;
    public static Block lava;
    public static Block fire;
    public static List<Block> fancyBlocks;
    public static Block[] lightCorruption;
    
    public static void loadBlocks() {
        BlocksCore.drops = new BlockDrops().func_149663_c("essentialcraft.drops");
        registerBlockSimple(new ItemBlockMeta(BlocksCore.drops), "Drops");
        registerBlockSimple(BlocksCore.magicPlating = new BlockDyeable(Material.field_151576_e, MapColor.field_151678_z).func_149711_c(3.0f).func_149752_b(15.0f).func_149663_c("essentialcraft.magicPlatingBlock"), "magicPlating");
        registerBlockSimple(BlocksCore.fortifiedGlass = new BlockDyeable(Material.field_151592_s).func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.fortifiedGlass"), "fortifiedGlass");
        registerBlockSimple(BlocksCore.ecController = new BlockMRUCUECController().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecController"), "ecController");
        registerBlockSimple(BlocksCore.ecAcceptor = new BlockMRUCUECAcceptor().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecAcceptor"), "ecAcceptor");
        registerBlockSimple(BlocksCore.ecBalancer = new BlockMRUCUECBalancer().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecBalancer"), "ecBalancer");
        registerBlockSimple(BlocksCore.ecEjector = new BlockMRUCUECEjector().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecEjector"), "ecEjector");
        registerBlockSimple(BlocksCore.ecHoldingChamber = new BlockMRUCUECHoldingChamber().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecHoldingChamber"), "ecHoldingChamber");
        registerBlockSimple(BlocksCore.ecStateChecker = new BlockMRUCUECStateChecker().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecStateChecker"), "ecStateChecker");
        registerBlockSimple(BlocksCore.ecRedstoneController = new BlockMRUCUECRedstoneController().func_149711_c(3.0f).func_149752_b(15.0f).func_149713_g(0).func_149663_c("essentialcraft.ecRedstoneController"), "ecRedstoneController");
        registerBlockSimple(BlocksCore.rayTower = new BlockRayTower().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.rayTower"), "rayTower");
        registerBlockSimple(BlocksCore.solarPrism = new BlockSolarPrism().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.solarPrism"), "solarPrism");
        registerBlockSimple(BlocksCore.sunRayAbsorber = new BlockSunRayAbsorber().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.sunRayAbsorber"), "sunRayAbsorber");
        registerBlockSimple(BlocksCore.coldStone = new BlockColdStone().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.coldStone"), "coldStone");
        registerBlockSimple(BlocksCore.coldDistillator = new BlockColdDistillator().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.coldDistillator"), "coldDistillator");
        registerBlockSimple(BlocksCore.naturalFurnace = new BlockFlowerBurner().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.naturalFurnace"), "naturalFurnace");
        registerBlockSimple(BlocksCore.heatGenerator = new BlockHeatGenerator().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.heatGenerator"), "heatGenerator");
        registerBlockSimple(BlocksCore.enderGenerator = new BlockEnderGenerator().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.enderGenerator"), "enderGenerator");
        final String[] corruptionNames = { "chaos", "frozen", "magic", "shade" };
        for (int i = 0; i < 4; ++i) {
            registerBlockSimple(BlocksCore.lightCorruption[i] = new BlockCorruption().setBlockTextureName("essentialcraft:" + corruptionNames[i]).func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.corruption." + corruptionNames[i]), corruptionNames[i]);
        }
        registerBlockSimple(BlocksCore.moonWell = new BlockMoonWell().func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(0).func_149663_c("essentialcraft.moonWell"), "moonWell");
        BlocksCore.magicianTable = registerBlockSimple((Block)new BlockMagicianTable(), "magicianTable", 1.0f, 1.0f, 0);
        registerBlockSimple(BlocksCore.fortifiedStone = new BlockDyeable(Material.field_151576_e).func_149711_c(3.0f).func_149752_b(15.0f).func_149663_c("essentialcraft.fortifiedStone"), "fortifiedStone");
        BlocksCore.magicalQuarry = registerBlockSimple((Block)new BlockMagicalQuarry(), "magicalQuarry", 1.0f, 1.0f, 0);
        BlocksCore.monsterClinger = registerBlockSimple((Block)new BlockMonsterHolder(), "monsterClinger", 1.0f, 1.0f, 0);
        BlocksCore.potionSpreader = registerBlockSimple((Block)new BlockPotionSpreader(), "potionSpreader", 1.0f, 1.0f, 0);
        BlocksCore.magicalEnchanter = registerBlockSimple((Block)new BlockMagicalEnchanter(), "magicalEnchanter", 1.0f, 1.0f, 0);
        BlocksCore.monsterHarvester = registerBlockSimple((Block)new BlockMonsterHarvester(), "monsterHarvester", 1.0f, 1.0f, 0);
        BlocksCore.magicalRepairer = registerBlockSimple((Block)new BlockMagicalRepairer(), "magicalRepairer", 1.0f, 1.0f, 0);
        BlocksCore.matrixAbsorber = registerBlockSimple((Block)new BlockMatrixAbsorber(), "matrixAbsorber", 1.0f, 1.0f, 0);
        BlocksCore.radiatingChamber = registerBlockSimple((Block)new BlockRadiatingChamber(), "radiatingChamber", 1.0f, 1.0f, 0);
        BlocksCore.magmaticSmeltery = registerBlockSimple((Block)new BlockMagmaticSmeltery(), "magmaticSmeltery", 1.0f, 1.0f, 0);
        BlocksCore.magicalJukebox = registerBlockSimple((Block)new BlockMagicalJukebox(), "magicalJukebox", 1.0f, 1.0f, 0);
        registerBlockSimple(BlocksCore.elementalCrystal = new BlockElementalCrystal().func_149711_c(3.0f).func_149752_b(15.0f).func_149663_c("essentialcraft.elementalCrystal"), "elementalCrystal", ItemBlockElementalCrystal.class);
        BlocksCore.crystalFormer = registerBlockSimple((Block)new BlockCrystalFormer(), "crystalFormer", 1.0f, 1.0f, 0);
        BlocksCore.crystalController = registerBlockSimple((Block)new BlockCrystalController(), "crystalController", 1.0f, 1.0f, 0);
        BlocksCore.crystalExtractor = registerBlockSimple((Block)new BlockCrystalExtractor(), "crystalExtractor", 1.0f, 1.0f, 0);
        BlocksCore.chargingChamber = registerBlockSimple((Block)new BlockChargingChamber(), "chargingChamber", 1.0f, 1.0f, 0);
        registerBlockSimple(BlocksCore.voidStone = new BlockDyeable(Material.field_151576_e, MapColor.field_151646_E).func_149711_c(8.0f).func_149752_b(150.0f).func_149663_c("essentialcraft.voidStone"), "voidStone");
        registerBlockSimple(BlocksCore.voidGlass = new BlockDyeable(Material.field_151592_s, MapColor.field_151646_E).func_149711_c(8.0f).func_149752_b(150.0f).func_149663_c("essentialcraft.voidGlass"), "voidGlass");
        BlocksCore.concrete = registerBlockSimple(new BlockEC(Material.field_151576_e), "concrete", 1.0f, 1.0f, 0);
        BlocksCore.cacti = registerBlockSimple(new BlockDreadCactus(), "cacti", 1.0f, 1.0f, 0);
        BlocksCore.dreadDirt = registerBlockSimple(new BlockEC(Material.field_151578_c), "dreadDirt", 1.0f, 1.0f, 0).func_149672_a(SoundType.field_185849_b);
        BlocksCore.flowerGreen = registerBlockSimple((Block)new BlockHoannaFlower(), "flowerGreen", 1.0f, 1.0f, 0);
        BlocksCore.fruit = registerBlockSimple(new BlockMagicalFruit(), "fruit", 1.0f, 1.0f, 0);
        BlocksCore.root = registerBlockSimple(new BlockEC(Material.field_151575_d), "root", 1.0f, 1.0f, 0);
        BlocksCore.tallGrass = registerBlockSimple((Block)new BlockHoannaTallGrass(), "tallGrass", 1.0f, 1.0f, 0);
        BlocksCore.magicalTeleporter = registerBlockSimple((Block)new BlockMagicalTeleporter(), "magicalTeleporter", 1.0f, 1.0f, 0);
        BlocksCore.magicalFurnace = registerBlockSimple((Block)new BlockMagicalFurnace(), "magicalFurnace", 1.0f, 1.0f, 0);
        BlocksCore.emberForge = registerBlockSimple((Block)new BlockEmberForge(), "emberForge", 1.0f, 1.0f, 0);
        BlocksCore.levitator = registerBlockSimple(new BlockMRULevitator(), "levitator", 1.0f, 100.0f, 0);
        BlocksCore.spreader = registerBlockSimple(new BlockMRUSpreader(), "spreader", 1.0f, 100.0f, 0);
        registerBlockSimple(BlocksCore.fence[0] = new BlockFenceEC(Material.field_151576_e, MapColor.field_151646_E).func_149711_c(8.0f).func_149752_b(150.0f).func_149663_c("essentialcraft.voidFence"), "voidFence");
        registerBlockSimple(BlocksCore.fence[1] = new BlockFenceEC(Material.field_151576_e, MapColor.field_151678_z).func_149711_c(3.0f).func_149752_b(15.0f).func_149663_c("essentialcraft.magicFence"), "magicFence");
        registerBlockSimple(BlocksCore.fence[2] = new BlockFenceEC(Material.field_151576_e).func_149711_c(3.0f).func_149752_b(15.0f).func_149663_c("essentialcraft.fFence"), "fFence");
        (BlocksCore.torch = registerBlockSimple(new BlockMagicLight(), "torch", 0.0f, 0.0f, 1)).func_149715_a(1.0f);
        BlocksCore.blockPale = registerBlockSimple(new BlockEC(Material.field_151576_e, MapColor.field_151652_H), "blockPale", 2.0f, 100.0f, 0).func_149672_a(SoundType.field_185852_e);
        registerBlockSimple(BlocksCore.platingPale = new BlockDyeable(Material.field_151576_e, MapColor.field_151652_H).func_149711_c(3.0f).func_149752_b(100.0f).func_149663_c("essentialcraft.platingPale"), "platingPale");
        BlocksCore.mruCoilHardener = registerBlockSimple((Block)new BlockMRUCoilHardener(), "mruCoilHardener", 1.0f, 100.0f, 0);
        BlocksCore.mruCoil = registerBlockSimple((Block)new BlockMRUCoil(), "mruCoil", 1.0f, 100.0f, 0);
        BlocksCore.corruptionCleaner = registerBlockSimple((Block)new BlockCorruptionCleaner(), "corruptionCleaner", 1.0f, 100.0f, 0);
        registerBlockSimple(BlocksCore.reactorSupport = new BlockReactorSupport().func_149663_c("essentialcraft.reactorSupport").func_149711_c(1.0f).func_149752_b(10.0f).func_149713_g(0), "reactorSupport");
        BlocksCore.reactor = registerBlockSimple((Block)new BlockMRUReactor(), "reactor", 1.0f, 10.0f, 0);
        registerBlockSimple(BlocksCore.air = new BlockEC(Material.field_151576_e).func_149711_c(-1.0f).func_149752_b(-1.0f).func_149715_a(0.0f).func_149663_c("air"), "air");
        BlocksCore.darknessObelisk = registerBlockSimple((Block)new BlockDarknessObelisk(), "darknessObelisk", 1.0f, 1.0f, 0);
        BlocksCore.ultraHeatGen = registerBlockSimple((Block)new BlockUltraHeatGenerator(), "ultraHeatGen", 1.0f, 1.0f, 0);
        BlocksCore.ultraFlowerBurner = registerBlockSimple((Block)new BlockUltraFlowerBurner(), "ultraFlowerBurner", 1.0f, 1.0f, 0);
        BlocksCore.magicalMirror = registerBlockSimple((Block)new BlockMagicalMirror(), "magicalMirror", 1.0f, 1.0f, 0);
        BlocksCore.magicalDisplay = registerBlockSimple((Block)new BlockMagicalDisplay(), "magicalDisplay", 1.0f, 1.0f, 0);
        BlocksCore.portal = registerBlockSimple(new BlockHoannaPortal(), "portal", -1.0f, -1.0f, 1);
        BlocksCore.oreDrops = registerBlockSimple(new BlockDropsOre(), "oreDrops", 1.0f, 1.0f, 1);
        registerBlockSimple(BlocksCore.invertedBlock = new BlockDyeable(Material.field_151576_e, MapColor.field_151651_C).func_149711_c(4.0f).func_149752_b(100.0f).func_149663_c("essentialcraft.mithrilinePlating"), "invertedPlating");
        registerBlockSimple(BlocksCore.mithrilineCrystal = new BlockMithrilineCrystal().func_149663_c("essentialcraft.mithrilineCrystal").func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(1), "mithrilineCrystal", ItemBlockMithrilineCrystal.class);
        BlocksCore.mithrilineFurnace = registerBlockSimple((Block)new BlockMithrilineFurnace(), "mithrilineFurnace", 1.0f, 1.0f, 1);
        registerBlockSimple(BlocksCore.demonicPlating = new BlockDyeable(Material.field_151576_e, MapColor.field_151645_D).func_149711_c(3.0f).func_149752_b(100.0f).func_149663_c("essentialcraft.demonicPlating"), "demonicPlating");
        BlocksCore.playerPentacle = registerBlockSimple((Block)new BlockPlayerPentacle(), "playerPentacle", 0.0f, 0.0f, 0);
        BlocksCore.windRune = registerBlockSimple((Block)new BlockWindRune(), "windRune", 3.0f, 10.0f, 0);
        BlocksCore.rightClicker = registerBlockSimple((Block)new BlockRightClicker(), "rightClicker", 1.0f, 1.0f, 15);
        BlocksCore.redstoneTransmitter = registerBlockSimple((Block)new BlockRedstoneTransmitter(), "redstoneTransmitter", 0.0f, 0.0f, 0);
        BlocksCore.magicalHopper = registerBlockSimple((Block)new BlockMagicalHopper(), "magicalHopper", 1.0f, 1.0f, 15);
        BlocksCore.metadataManager = registerBlockSimple(new BlockMetadataManager(), "metadataManager", 1.0f, 1.0f, 15);
        BlocksCore.blockBreaker = registerBlockSimple(new BlockBlockBreaker(), "blockBreaker", 1.0f, 1.0f, 15);
        BlocksCore.compressed = new BlockCompressedDrops().func_149663_c("essentialcraft.compressed").func_149711_c(0.4f).func_149752_b(1.0f).func_149713_g(15);
        registerBlockSimple(new ItemBlockMeta(BlocksCore.compressed), "compressed");
        BlocksCore.demonicPentacle = registerBlockSimple((Block)new BlockDemonicPentacle(), "demonicPentacle", 0.0f, 0.0f, 0);
        BlocksCore.weaponMaker = registerBlockSimple((Block)new BlockWeaponMaker(), "weaponMaker", 1.0f, 1.0f, 15);
        registerBlockSimple(BlocksCore.furnaceMagic = new BlockFurnaceMagic().func_149663_c("essentialcraft.furnaceMagic").func_149711_c(1.0f).func_149752_b(1.0f).func_149713_g(15), "furnaceMagic");
        BlocksCore.holopad = registerBlockSimple(new BlockHologramSpawner(), "holopad", 1.0f, 1.0f, 15);
        BlocksCore.chest = registerBlockSimple((Block)new BlockChestEC(), "chest", 1.0f, 1.0f, 0);
        BlocksCore.mimInvStorage = registerBlockSimple((Block)new BlockMIMInventoryStorage(), "mimInvStorage", 1.0f, 1.0f, 15);
        registerBlockSimple(BlocksCore.newMim = new BlockMIM().func_149752_b(1.0f).func_149711_c(1.0f).func_149713_g(0).func_149663_c("essentialcraft.newMim"), "newMim");
        BlocksCore.mimScreen = registerBlockSimple((Block)new BlockMIMScreen(), "mimScreen", 1.0f, 1.0f, 15);
        BlocksCore.mimCrafter = registerBlockSimple((Block)new BlockMIMCraftingManager(), "mimCrafter", 1.0f, 1.0f, 15);
        BlocksCore.mimEjector = registerBlockSimple((Block)new BlockMIMExporter(), "mimEjector", 1.0f, 1.0f, 0);
        BlocksCore.mimInjector = registerBlockSimple((Block)new BlockMIMImporter(), "mimInjector", 1.0f, 1.0f, 0);
        registerBlockSimple(BlocksCore.device = new BlockRedstoneDeviceNotSided().func_149711_c(1.0f).func_149752_b(1.0f).func_149663_c("essentialcraft.device"), "device", ItemBlockRDNS.class);
        BlocksCore.advBreaker = registerBlockSimple((Block)new BlockAdvBlockBreaker(), "advBreaker", 1.0f, 1.0f, 0);
        BlocksCore.mimEjectorP = registerBlockSimple((Block)new BlockMIMExporterPersistant(), "mimEjectorP", 1.0f, 1.0f, 0);
        BlocksCore.mimInjectorP = registerBlockSimple((Block)new BlockMIMImporterPersistant(), "mimInjectorP", 1.0f, 1.0f, 0);
        registerBlockSimple(BlocksCore.oreMithriline = new BlockMithrilineOre().func_149663_c("essentialcraft.oreMithriline").func_149711_c(0.4f).func_149752_b(1.0f).func_149713_g(15), "oreMithriline");
        BlocksCore.crystalLamp = new BlockCrystalLamp().func_149663_c("essentialcraft.crystalLamp").func_149711_c(0.4f).func_149752_b(1.0f).func_149713_g(15);
        registerBlockSimple(new ItemBlockMeta(BlocksCore.crystalLamp), "crystalLamp");
        registerBlockSimple(BlocksCore.mimic = new BlockMimic().func_149663_c("essentialcraft.mimic").func_149752_b(15.0f).func_149711_c(3.0f).func_149713_g(15), "mimic");
        registerBlockSimple(BlocksCore.water = new BlockEC(Material.field_151586_h).func_149711_c(-1.0f).func_149752_b(-1.0f).func_149715_a(0.0f).func_149663_c("water"), "water");
        registerBlockSimple(BlocksCore.lava = new BlockEC(Material.field_151587_i).func_149711_c(-1.0f).func_149752_b(-1.0f).func_149715_a(0.0f).func_149663_c("lava"), "lava");
        registerBlockSimple(BlocksCore.fire = new BlockEC(Material.field_151581_o).func_149711_c(-1.0f).func_149752_b(-1.0f).func_149715_a(0.0f).func_149663_c("fire"), "fire");
        BlocksCore.chunkLoader = registerBlockSimple((Block)new BlockChunkLoader(), "chunkLoader", 1.0f, 1.0f, 0);
        BlocksCore.dimTransciever = registerBlockSimple((Block)new BlockDimensionalTransciever(), "dimTransciever", 1.0f, 1.0f, 0);
        BlocksCore.intersector = registerBlockSimple((Block)new BlockMRUIntersector(), "intersector", 1.0f, 1.0f, 15);
        BlocksCore.weatherController = registerBlockSimple((Block)new BlockWeatherController(), "weatherController", 1.0f, 1.0f, 15);
    }
    
    public static void postInitLoad() {
        createFancyBlock(Material.field_151576_e, "mru", "mru", 1.0f, 100.0f, new ItemStack(ItemsCore.magicalSlag));
        createFancyBlock(Material.field_151576_e, "concrete", "concrete", 1.0f, 5.0f, new ItemStack(BlocksCore.concrete));
        createFancyBlock(Material.field_151576_e, "fortifiedStone", "fortifiedStone", 1.5f, 8.0f, new ItemStack(BlocksCore.fortifiedStone));
        createFancyBlock(Material.field_151592_s, "coldStone", "coldStone", 0.7f, 1.0f, new ItemStack(BlocksCore.coldStone));
        createFancyBlock(Material.field_151576_e, "magicPlating", "magicPlating", 2.0f, 8.0f, new ItemStack(BlocksCore.magicPlating));
        createFancyBlock(Material.field_151576_e, "palePlating", "palePlating", 2.0f, 8.0f, new ItemStack(BlocksCore.platingPale));
        createFancyBlock(Material.field_151576_e, "voidStone", "voidStone", 3.0f, 28.0f, new ItemStack(BlocksCore.voidStone));
        createFancyBlock(Material.field_151576_e, "mithrilinePlating", "mithrilinePlating", 3.0f, 100.0f, new ItemStack(BlocksCore.invertedBlock));
        createFancyBlock(Material.field_151576_e, "demonicPlating", "demonicPlating", 3.0f, 100.0f, new ItemStack(BlocksCore.demonicPlating));
        final Block mimicFancy = new BlockFancyMimic().func_149663_c("essentialcraft.fancyBlock.mimic").func_149752_b(15.0f).func_149711_c(3.0f).func_149713_g(15);
        registerFancyBlock(mimicFancy, "mimic", new ItemStack(BlocksCore.mimic));
    }
    
    public static <T extends Block> T registerBlockSimple(final T c, final String name, final float hardness, final float resistance, final int opacity) {
        try {
            c.func_149663_c("essentialcraft." + name).func_149752_b(resistance).func_149711_c(hardness).func_149713_g(opacity);
            BlockRegistry.registerBlock((ItemBlock)new ItemBlockGeneric(c), name, (Class)EssentialCraftCore.class);
            EssentialCraftCore.proxy.handleBlockRegister(c);
            return c;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static <T extends Block> T registerBlockSimple(final Block b, final String name) {
        BlockRegistry.registerBlock((ItemBlock)new ItemBlockGeneric(b), name, (Class)EssentialCraftCore.class);
        EssentialCraftCore.proxy.handleBlockRegister(b);
        return (T)b;
    }
    
    public static <T extends Block> T registerBlockSimple(final Block b, final String name, final Class<? extends ItemBlock> ib) {
        try {
            ib.getConstructor(Block.class).setAccessible(true);
            BlockRegistry.registerBlock((ItemBlock)ib.getConstructor(Block.class).newInstance(b), name, (Class)EssentialCraftCore.class);
            EssentialCraftCore.proxy.handleBlockRegister(b);
            return (T)b;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static ItemBlock registerBlockSimple(final ItemBlock ib, final String name) {
        BlockRegistry.registerBlock(ib, name, (Class)EssentialCraftCore.class);
        EssentialCraftCore.proxy.handleBlockRegister(ib.func_179223_d());
        return ib;
    }
    
    public static void createFancyBlock(final Material m, final String name, final String texture, final float hardness, final float resistance, final ItemStack createdFrom) {
        final Block fancy = new BlockFancy(m).func_149663_c("essentialcraft.fancyBlock." + name).func_149752_b(resistance).func_149711_c(hardness);
        BlockRegistry.registerBlock((ItemBlock)new ItemBlockFancy(fancy), "fancyBlock." + name, (Class)EssentialCraftCore.class);
        EssentialCraftCore.proxy.handleBlockRegister(fancy);
        BlocksCore.fancyBlocks.add(fancy);
        RecipesCore.fancyBlockRecipes.put(fancy, createdFrom);
    }
    
    public static Block registerFancyBlock(final Block fancy, final String name, final ItemStack createdFrom) {
        BlockRegistry.registerBlock((ItemBlock)new ItemBlockFancy(fancy), "fancyBlock." + name, (Class)EssentialCraftCore.class);
        EssentialCraftCore.proxy.handleBlockRegister(fancy);
        BlocksCore.fancyBlocks.add(fancy);
        RecipesCore.fancyBlockRecipes.put(fancy, createdFrom);
        return fancy;
    }
    
    static {
        BlocksCore.fence = new Block[3];
        BlocksCore.fancyBlocks = new ArrayList<Block>();
        BlocksCore.lightCorruption = new Block[4];
    }
}
