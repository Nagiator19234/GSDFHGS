package essentialcraft.common.block;

import DummyCore.Client.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.creativetab.*;
import net.minecraft.block.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.world.*;
import net.minecraft.world.chunk.*;
import net.minecraftforge.common.property.*;
import net.minecraft.item.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.*;

public class BlockRightClicker extends BlockContainer implements IModelRegisterer
{
    public static final PropertyEnum<ActivatorType> TYPE;
    public static final PropertyDirection FACING;
    public static final UnlistedPropertyObject<IBlockState> STATE;
    public static final UnlistedPropertyObject<IBlockAccess> WORLD;
    public static final UnlistedPropertyObject<BlockPos> POS;
    
    public BlockRightClicker() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockRightClicker.TYPE, (Comparable)ActivatorType.NORMAL).func_177226_a((IProperty)BlockRightClicker.FACING, (Comparable)EnumFacing.NORTH));
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public boolean canRenderInLayer(final IBlockState state, final BlockRenderLayer layer) {
        return true;
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public int func_180651_a(final IBlockState meta) {
        return ((ActivatorType)meta.func_177229_b((IProperty)BlockRightClicker.TYPE)).getIndex();
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        items.add((Object)new ItemStack((Block)this, 1, 0));
        items.add((Object)new ItemStack((Block)this, 1, 1));
        items.add((Object)new ItemStack((Block)this, 1, 2));
        items.add((Object)new ItemStack((Block)this, 1, 3));
        items.add((Object)new ItemStack((Block)this, 1, 4));
        items.add((Object)new ItemStack((Block)this, 1, 5));
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public TileEntity func_149915_a(final World world, final int metadata) {
        return new TileRightClicker();
    }
    
    public void func_180633_a(final World w, final BlockPos p, final IBlockState s, final EntityLivingBase placer, final ItemStack stack) {
        final int l = EnumFacing.func_190914_a(p, placer).func_176745_a();
        final TileEntity tile = w.func_175625_s(p);
        if (tile != null && tile instanceof TileRightClicker) {
            ((TileRightClicker)tile).rotation = l;
        }
    }
    
    protected BlockStateContainer func_180661_e() {
        return (BlockStateContainer)new ExtendedBlockState((Block)this, new IProperty[] { (IProperty)BlockRightClicker.TYPE, (IProperty)BlockRightClicker.FACING }, new IUnlistedProperty[] { (IUnlistedProperty)BlockRightClicker.STATE, (IUnlistedProperty)BlockRightClicker.WORLD, (IUnlistedProperty)BlockRightClicker.POS });
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockRightClicker.TYPE, (Comparable)ActivatorType.fromIndex(meta % 6));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((ActivatorType)state.func_177229_b((IProperty)BlockRightClicker.TYPE)).getIndex();
    }
    
    public IBlockState func_176221_a(final IBlockState state, final IBlockAccess world, final BlockPos pos) {
        final TileEntity tile = (world instanceof ChunkCache) ? ((ChunkCache)world).func_190300_a(pos, Chunk.EnumCreateEntityType.CHECK) : world.func_175625_s(pos);
        if (tile != null && tile instanceof TileRightClicker) {
            return state.func_177226_a((IProperty)BlockRightClicker.FACING, (Comparable)((TileRightClicker)tile).getRotation());
        }
        return state;
    }
    
    public IBlockState getExtendedState(IBlockState state, final IBlockAccess world, final BlockPos pos) {
        state = (IBlockState)((IExtendedBlockState)this.func_176221_a(state, world, pos)).withProperty((IUnlistedProperty)BlockRightClicker.WORLD, (Object)world).withProperty((IUnlistedProperty)BlockRightClicker.POS, (Object)pos);
        final TileEntity tile = world.func_175625_s(pos);
        if (tile != null && tile instanceof TileRightClicker) {
            return (IBlockState)((IExtendedBlockState)state).withProperty((IUnlistedProperty)BlockRightClicker.STATE, (Object)((TileRightClicker)tile).getState());
        }
        return state;
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        for (int i = 0; i < 6; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:rightclicker", "facing=north,type=" + ActivatorType.fromIndex(i)));
            for (int j = 0; j < 6; ++j) {
                if (j != 2) {
                    ModelBakery.registerItemVariants(Item.func_150898_a((Block)this), new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:rightclicker", "facing=" + EnumFacing.func_82600_a(j).func_176610_l() + ",type=" + ActivatorType.fromIndex(i)) });
                }
            }
        }
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMap.Builder().func_178442_a(new IProperty[] { (IProperty)BlockRightClicker.FACING, (IProperty)BlockRightClicker.TYPE }).func_178441_a());
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)ActivatorType.class);
        FACING = PropertyDirection.func_177714_a("facing");
        STATE = new UnlistedPropertyObject("state", (Class)IBlockState.class);
        WORLD = new UnlistedPropertyObject("world", (Class)IBlockAccess.class);
        POS = new UnlistedPropertyObject("pos", (Class)BlockPos.class);
    }
    
    public enum ActivatorType implements IStringSerializable
    {
        NORMAL("normal"), 
        NORMALSNEAKY("normal_sneaky"), 
        EXTENDED("extended"), 
        EXTENDEDSNEAKY("extended_sneaky"), 
        ADVANCED("advanced"), 
        ADVANCEDSNEAKY("advanced_sneaky");
        
        private int index;
        private String name;
        
        private ActivatorType(final String s) {
            this.index = this.ordinal();
            this.name = s;
        }
        
        public String func_176610_l() {
            return this.name;
        }
        
        @Override
        public String toString() {
            return this.name;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public static ActivatorType fromIndex(final int i) {
            return values()[i % 6];
        }
    }
}
