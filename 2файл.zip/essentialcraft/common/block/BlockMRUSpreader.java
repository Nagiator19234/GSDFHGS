package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import java.util.*;
import net.minecraft.util.math.*;
import essentialcraft.common.mod.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockMRUSpreader extends Block implements IModelRegisterer
{
    public static final AxisAlignedBB BLOCK_AABB;
    
    public BlockMRUSpreader() {
        super(Material.field_151576_e, MapColor.field_151678_z);
        this.func_149675_a(true);
        this.func_149715_a(1.0f);
    }
    
    public void func_180655_c(final IBlockState s, final World state, final BlockPos world, final Random rand) {
        for (int i = 0; i < 5; ++i) {
            Vec3d rotateVec = new Vec3d(1.0, 1.0, 1.0);
            rotateVec = rotateVec.func_178789_a(rand.nextFloat() * 360.0f);
            rotateVec = rotateVec.func_178785_b(rand.nextFloat() * 360.0f);
            for (int i2 = 0; i2 < 10; ++i2) {
                EssentialCraftCore.proxy.spawnParticle("mruFX", world.func_177958_n() + 0.5f, world.func_177956_o() + 1.0f, world.func_177952_p() + 0.5f, rotateVec.field_72450_a * 10.0, rotateVec.field_72448_b * 10.0, rotateVec.field_72449_c * 10.0);
            }
        }
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        return BlockMRUSpreader.BLOCK_AABB;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:spreader", "inventory"));
    }
    
    static {
        BLOCK_AABB = new AxisAlignedBB(0.3, 0.0, 0.3, 0.7, 0.8, 0.7);
    }
}
