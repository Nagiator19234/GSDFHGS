package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.statemap.*;
import net.minecraft.item.*;
import net.minecraftforge.fml.relauncher.*;

public class BlockMagicalRepairer extends BlockContainer implements IModelRegisterer
{
    public BlockMagicalRepairer() {
        super(Material.field_151576_e, MapColor.field_151678_z);
    }
    
    public void func_180663_b(final World world, final BlockPos pos, final IBlockState blockstate) {
        final IInventory inv = (IInventory)world.func_175625_s(pos);
        InventoryHelper.func_180175_a(world, pos, inv);
        super.func_180663_b(world, pos, blockstate);
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileMagicalRepairer();
    }
    
    public boolean func_180639_a(final World world, final BlockPos par2, final IBlockState par3, final EntityPlayer player, final EnumHand par5, final EnumFacing par7, final float par8, final float par9, final float par10) {
        if (player.func_70093_af()) {
            return false;
        }
        if (!world.field_72995_K) {
            player.openGui((Object)EssentialCraftCore.core, Config.guiID[0], world, par2.func_177958_n(), par2.func_177956_o(), par2.func_177952_p());
            return true;
        }
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        if (Loader.isModLoaded("codechickenlib")) {
            ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new StateMapperBase() {
                protected ModelResourceLocation func_178132_a(final IBlockState state) {
                    return new ModelResourceLocation("essentialcraft:magicalrepairertemp", "normal");
                }
            });
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:magicalrepairertemp", "inventory"));
            return;
        }
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:magicalrepairer", "inventory"));
    }
}
