package essentialcraft.common.block;

import DummyCore.Client.*;
import net.minecraft.block.material.*;
import net.minecraft.block.state.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.common.entity.*;
import net.minecraft.entity.*;
import net.minecraft.util.text.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockDemonicPentacle extends BlockContainer implements IModelRegisterer
{
    public static final AxisAlignedBB BLOCK_AABB;
    
    public BlockDemonicPentacle() {
        super(Material.field_151576_e, MapColor.field_151660_b);
    }
    
    public AxisAlignedBB func_185496_a(final IBlockState state, final IBlockAccess source, final BlockPos pos) {
        return BlockDemonicPentacle.BLOCK_AABB;
    }
    
    public AxisAlignedBB func_180646_a(final IBlockState blockState, final IBlockAccess worldIn, final BlockPos pos) {
        return BlockDemonicPentacle.field_185506_k;
    }
    
    public boolean func_149662_c(final IBlockState s) {
        return false;
    }
    
    public boolean func_149686_d(final IBlockState s) {
        return false;
    }
    
    public EnumBlockRenderType func_149645_b(final IBlockState s) {
        return EnumBlockRenderType.MODEL;
    }
    
    public TileEntity func_149915_a(final World world, final int meta) {
        return new TileDemonicPentacle();
    }
    
    public boolean func_180639_a(final World world, final BlockPos pos, final IBlockState blockstate, final EntityPlayer player, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        final TileDemonicPentacle pentacle = (TileDemonicPentacle)world.func_175625_s(pos);
        if (pentacle.consumeEnderstarEnergy(666)) {
            final EntityDemon demon = new EntityDemon(world);
            demon.func_70080_a(pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.1, pos.func_177952_p() + 0.5, 0.0f, 0.0f);
            demon.func_70642_aH();
            if (!world.field_72995_K) {
                world.func_72838_d((Entity)demon);
            }
        }
        else if (world.field_72995_K) {
            player.func_145747_a(new TextComponentTranslation("essentialcraft.txt.noEnergy", new Object[0]).func_150255_a(new Style().func_150238_a(TextFormatting.RED)));
        }
        return true;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), 0, new ModelResourceLocation("essentialcraft:demonicpentacle", "inventory"));
    }
    
    static {
        BLOCK_AABB = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.0625, 1.0);
    }
}
