package essentialcraft.common.block;

import net.minecraft.block.*;
import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.block.material.*;
import net.minecraft.block.properties.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class BlockCrystalLamp extends Block implements IModelRegisterer
{
    public static final PropertyEnum<EnumDropType> TYPE;
    
    public BlockCrystalLamp() {
        super(Material.field_151576_e);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)BlockCrystalLamp.TYPE, (Comparable)EnumDropType.FIRE));
        this.func_149715_a(1.0f);
    }
    
    public void func_149666_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        for (int i = 0; i < 6; ++i) {
            items.add((Object)new ItemStack((Block)this, 1, i));
        }
    }
    
    public int func_180651_a(final IBlockState state) {
        return ((EnumDropType)state.func_177229_b((IProperty)BlockCrystalLamp.TYPE)).getIndex();
    }
    
    public ItemStack getPickBlock(final IBlockState state, final RayTraceResult target, final World world, final BlockPos pos, final EntityPlayer player) {
        return new ItemStack((Block)this, 1, ((EnumDropType)state.func_177229_b((IProperty)BlockCrystalLamp.TYPE)).getIndex());
    }
    
    public IBlockState func_176203_a(final int meta) {
        return this.func_176223_P().func_177226_a((IProperty)BlockCrystalLamp.TYPE, (Comparable)EnumDropType.fromIndex(meta));
    }
    
    public int func_176201_c(final IBlockState state) {
        return ((EnumDropType)state.func_177229_b((IProperty)BlockCrystalLamp.TYPE)).getIndex();
    }
    
    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[] { (IProperty)BlockCrystalLamp.TYPE });
    }
    
    public void registerModels() {
        for (int i = 0; i < EnumDropType.values().length; ++i) {
            ModelLoader.setCustomModelResourceLocation(Item.func_150898_a((Block)this), i, new ModelResourceLocation("essentialcraft:crystallamp", "type=" + EnumDropType.fromIndex(i).func_176610_l()));
        }
    }
    
    static {
        TYPE = PropertyEnum.func_177709_a("type", (Class)EnumDropType.class);
    }
}
