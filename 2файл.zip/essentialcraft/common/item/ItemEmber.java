package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemEmber extends Item implements IModelRegisterer
{
    public static String[] unlocalisedName;
    
    public ItemEmber() {
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + ItemEmber.unlocalisedName[Math.min(stack.func_77952_i(), ItemEmber.unlocalisedName.length - 1)];
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < ItemEmber.unlocalisedName.length - 1; ++i) {
                items.add((Object)new ItemStack((Item)this, 1, i));
            }
        }
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemEmber.unlocalisedName.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/ember", "type=" + ItemEmber.unlocalisedName[i]));
        }
    }
    
    static {
        ItemEmber.unlocalisedName = new String[] { "acidic", "chaos", "common", "corrupted", "crystal", "divine", "magical", "flame", "unknown" };
    }
}
