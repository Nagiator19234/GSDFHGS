package essentialcraft.common.item;

import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

public class ItemWindSword extends ItemSwordEC
{
    public ItemWindSword(final Item.ToolMaterial m) {
        super(m);
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        return ItemsCore.wind_elemental_hoe.func_180614_a(player, world, pos, hand, facing, hitX, hitY, hitZ);
    }
}
