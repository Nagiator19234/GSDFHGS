package essentialcraft.common.item;

import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.potion.*;
import net.minecraft.client.util.*;
import org.lwjgl.input.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.util.math.*;
import net.minecraft.util.text.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.player.*;
import essentialcraft.api.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import essentialcraft.common.registry.*;
import essentialcraft.common.entity.*;
import java.util.*;
import net.minecraft.nbt.*;
import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import DummyCore.Utils.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.*;

public class ItemGun extends ItemMRUGeneric implements IModelRegisterer
{
    Random rnd;
    public String gunType;
    
    public ItemGun(final String s) {
        this.rnd = new Random();
        this.func_77627_a(true);
        this.func_77625_d(1);
        this.func_77664_n();
        this.func_77656_e(0);
        this.gunType = s;
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        if (isCurrentItem && this.gunType.equalsIgnoreCase("gatling") && entity instanceof EntityLivingBase) {
            ((EntityLivingBase)entity).func_70690_d(new PotionEffect(MobEffects.field_76421_d, 3, 3, true, true));
        }
        if (MiscUtils.getStackTag(itemStack).func_74764_b("cool")) {
            MiscUtils.getStackTag(itemStack).func_74776_a("cool", MiscUtils.getStackTag(itemStack).func_74760_g("cool") - 1.0f);
            if (MiscUtils.getStackTag(itemStack).func_74760_g("cool") <= 0.0f) {
                MiscUtils.getStackTag(itemStack).func_82580_o("cool");
            }
        }
        if (MiscUtils.getStackTag(itemStack).func_74764_b("gunShots") && isCurrentItem) {
            final float current = MiscUtils.getStackTag(itemStack).func_74760_g("gunShots");
            final float max = MiscUtils.getStackTag(itemStack).func_74775_l("stats").func_74760_g("shots");
            if (current + 1.0f >= max) {
                Vec3d look = entity.func_70040_Z();
                look = look.func_178789_a(-0.5f);
                world.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, entity.field_70165_t + look.field_72450_a, entity.field_70163_u - 0.5 + look.field_72448_b, entity.field_70161_v + look.field_72449_c, 0.0, 0.0, 0.0, new int[0]);
            }
        }
        super.func_77663_a(itemStack, world, entity, indexInInventory, isCurrentItem);
    }
    
    @SideOnly(Side.CLIENT)
    @Override
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        if (MiscUtils.getStackTag(stack).func_74764_b("stats") && Keyboard.isKeyDown(42)) {
            final NBTTagCompound stats = MiscUtils.getStackTag(stack).func_74775_l("stats");
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.damage") + " " + MathHelper.func_76141_d(stats.func_74760_g("damage")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.durability") + " " + MathHelper.func_76141_d(stats.func_74760_g("durability")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.reload") + " " + MathHelper.func_76141_d(stats.func_74760_g("reload")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.knockback") + " " + MathHelper.func_76141_d(stats.func_74760_g("knockback")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.speed") + " " + MathHelper.func_76141_d(stats.func_74760_g("speed")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.spread") + " " + MathHelper.func_76141_d(stats.func_74760_g("spread")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.shots") + " " + MathHelper.func_76141_d(stats.func_74760_g("shots")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.zoom") + " " + MathHelper.func_76141_d(stats.func_74760_g("zoom")));
            list.add(I18n.func_74838_a("essentialcraft.gun.txt.balance_" + MathHelper.func_76141_d(stats.func_74760_g("balance"))));
        }
        else if (MiscUtils.getStackTag(stack).func_74764_b("stats")) {
            list.add(TextFormatting.BLUE + "" + TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.viewInfoHotkey"));
        }
        super.func_77624_a(stack, player, list, par4);
    }
    
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand h) {
        final ItemStack gun = p.func_184586_b(h);
        if (!gun.func_77978_p().func_74764_b("base") && !w.field_72995_K) {
            createRandomGun(gun);
            return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
        }
        if (p.func_184587_cr()) {
            return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
        }
        if (this.gunType.equalsIgnoreCase("rifle") || this.gunType.equalsIgnoreCase("gatling")) {
            p.func_184598_c(h);
        }
        else if (gun.func_77978_p().func_74764_b("base")) {
            float balance = 0.0f;
            if (gun.func_77978_p().func_74764_b("lense")) {
                final String lenseID = gun.func_77978_p().func_74779_i("lense");
                final GunRegistry.LenseMaterial lense = GunRegistry.getLenseFromID(lenseID);
                for (final GunRegistry.GunType gt : GunRegistry.GunType.values()) {
                    if (lense != null && lense.materialData.containsKey(gt)) {
                        for (final DummyData d : lense.materialData.get(gt)) {
                            if (d.fieldName.equalsIgnoreCase("balance")) {
                                balance = (float)(int)Float.parseFloat(d.fieldValue);
                            }
                        }
                    }
                }
            }
            if (MiscUtils.getStackTag(gun).func_74764_b("stats")) {
                final NBTTagCompound stats = MiscUtils.getStackTag(gun).func_74775_l("stats");
                if (!MiscUtils.getStackTag(gun).func_74764_b("gunDamage")) {
                    MiscUtils.getStackTag(gun).func_74776_a("gunDamage", 0.0f);
                }
                if (!MiscUtils.getStackTag(gun).func_74764_b("gunShots")) {
                    MiscUtils.getStackTag(gun).func_74776_a("gunShots", 0.0f);
                }
                if (MiscUtils.getStackTag(gun).func_74764_b("cool")) {
                    return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
                }
                if (MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f > stats.func_74760_g("shots")) {
                    p.func_184598_c(h);
                    return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
                }
                MiscUtils.getStackTag(gun).func_74776_a("gunShots", MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f);
                if (ECUtils.playerUseMRU(p, gun, (int)(stats.func_74760_g("damage") * 10.0f))) {
                    if (MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f <= stats.func_74760_g("durability")) {
                        MiscUtils.getStackTag(gun).func_74776_a("gunDamage", MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f);
                    }
                    else if (!w.field_72995_K && w.field_73012_v.nextFloat() <= 0.25f) {
                        w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundEvents.field_187635_cQ, SoundCategory.PLAYERS, 1.0f, 1.0f, false);
                        MiscUtils.getStackTag(gun).func_74776_a("gunShots", stats.func_74760_g("shots"));
                    }
                    MiscUtils.getStackTag(gun).func_74776_a("cool", stats.func_74760_g("speed") * 2.0f);
                    w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundRegistry.gunBeam, SoundCategory.PLAYERS, 0.1f + stats.func_74760_g("damage") / 100.0f, 2.0f - stats.func_74760_g("damage") / 50.0f, false);
                    final EntityMRURay ray = new EntityMRURay(w, (EntityLivingBase)p, stats.func_74760_g("damage"), stats.func_74760_g("spread") / 2.0f, balance);
                    if (!w.field_72995_K) {
                        w.func_72838_d((Entity)ray);
                    }
                    p.field_70125_A -= stats.func_74760_g("knockback");
                }
            }
        }
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
    }
    
    public static void createRandomGun(final ItemStack gun) {
        final Random rand = new Random();
        final NBTTagCompound tag = MiscUtils.getStackTag(gun);
        tag.func_74778_a("base", GunRegistry.GUN_MATERIALS.get(rand.nextInt(GunRegistry.GUN_MATERIALS.size())).id);
        tag.func_74778_a("device", GunRegistry.GUN_MATERIALS.get(rand.nextInt(GunRegistry.GUN_MATERIALS.size())).id);
        tag.func_74778_a("handle", GunRegistry.GUN_MATERIALS.get(rand.nextInt(GunRegistry.GUN_MATERIALS.size())).id);
        tag.func_74778_a("lense", GunRegistry.LENSE_MATERIALS.get(rand.nextInt(GunRegistry.LENSE_MATERIALS.size())).id);
        final ItemGun g = (ItemGun)gun.func_77973_b();
        if (g.gunType.equalsIgnoreCase("sniper")) {
            tag.func_74778_a("scope", GunRegistry.SCOPE_MATERIALS_SNIPER.get(rand.nextInt(GunRegistry.SCOPE_MATERIALS_SNIPER.size())).id);
        }
        else if (!g.gunType.equalsIgnoreCase("gatling")) {
            tag.func_74778_a("scope", GunRegistry.SCOPE_MATERIALS.get(rand.nextInt(GunRegistry.SCOPE_MATERIALS.size())).id);
        }
        gun.func_77982_d(tag);
        calculateGunStats(gun);
    }
    
    public static void calculateGunStats(final ItemStack gun) {
        final NBTTagCompound gunTag = MiscUtils.getStackTag(gun);
        if (gunTag.func_74764_b("stats")) {
            gunTag.func_82580_o("stats");
        }
        final NBTTagCompound stats = new NBTTagCompound();
        GunRegistry.GunMaterial base = null;
        GunRegistry.GunMaterial handle = null;
        GunRegistry.GunMaterial device = null;
        GunRegistry.LenseMaterial lense = null;
        GunRegistry.ScopeMaterial scope = null;
        final ItemGun iGun = (ItemGun)gun.func_77973_b();
        float damage = 0.0f;
        float durability = 0.0f;
        float reload = 0.0f;
        float knockback = 0.0f;
        float speed = 0.0f;
        float spread = 0.0f;
        float shots = 0.0f;
        float zoom = 0.0f;
        float balance = 0.0f;
        final GunRegistry.GunType gt = iGun.gunType.equalsIgnoreCase("pistol") ? GunRegistry.GunType.PISTOL : (iGun.gunType.equalsIgnoreCase("rifle") ? GunRegistry.GunType.RIFLE : (iGun.gunType.equalsIgnoreCase("sniper") ? GunRegistry.GunType.SNIPER : (iGun.gunType.equalsIgnoreCase("gatling") ? GunRegistry.GunType.GATLING : GunRegistry.GunType.PISTOL)));
        if (gunTag.func_74764_b("base")) {
            base = GunRegistry.getGunFromID(gunTag.func_74779_i("base"));
        }
        if (gunTag.func_74764_b("device")) {
            device = GunRegistry.getGunFromID(gunTag.func_74779_i("device"));
        }
        if (gunTag.func_74764_b("handle")) {
            handle = GunRegistry.getGunFromID(gunTag.func_74779_i("handle"));
        }
        if (gunTag.func_74764_b("lense")) {
            lense = GunRegistry.getLenseFromID(gunTag.func_74779_i("lense"));
        }
        if (gunTag.func_74764_b("scope")) {
            if (((ItemGun)gun.func_77973_b()).gunType.equalsIgnoreCase("sniper")) {
                scope = GunRegistry.getScopeSniperFromID(gunTag.func_74779_i("scope"));
            }
            else {
                scope = GunRegistry.getScopeFromID(gunTag.func_74779_i("scope"));
            }
        }
        if (base != null && base.materialData.containsKey(gt)) {
            for (final DummyData d : base.materialData.get(gt)) {
                if (d.fieldName.equalsIgnoreCase("durability")) {
                    durability += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("damage")) {
                    damage += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("reload")) {
                    reload += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("knockback")) {
                    knockback += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("spread")) {
                    spread += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("speed")) {
                    speed += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("shots")) {
                    shots += Float.parseFloat(d.fieldValue);
                }
            }
        }
        if (handle != null && handle.materialData.containsKey(gt)) {
            for (final DummyData d : handle.materialData.get(gt)) {
                if (d.fieldName.equalsIgnoreCase("durability")) {
                    durability += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("damage")) {
                    damage += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("reload")) {
                    reload += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("knockback")) {
                    knockback += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("spread")) {
                    spread += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("speed")) {
                    speed += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("shots")) {
                    shots += Float.parseFloat(d.fieldValue) / 3.0f;
                }
            }
        }
        if (device != null && device.materialData.containsKey(gt)) {
            for (final DummyData d : device.materialData.get(gt)) {
                if (d.fieldName.equalsIgnoreCase("durability")) {
                    durability += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("damage")) {
                    damage += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("reload")) {
                    reload += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("knockback")) {
                    knockback += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("spread")) {
                    spread += Float.parseFloat(d.fieldValue);
                }
                if (d.fieldName.equalsIgnoreCase("speed")) {
                    speed += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("shots")) {
                    shots += Float.parseFloat(d.fieldValue) / 3.0f;
                }
            }
        }
        if (lense != null && lense.materialData.containsKey(gt)) {
            for (final DummyData d : lense.materialData.get(gt)) {
                if (d.fieldName.equalsIgnoreCase("durability")) {
                    durability += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("damage")) {
                    damage += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("reload")) {
                    reload += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("knockback")) {
                    knockback += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("spread")) {
                    spread += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("speed")) {
                    speed += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("shots")) {
                    shots += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("balance")) {
                    balance = (float)(int)Float.parseFloat(d.fieldValue);
                }
            }
        }
        if (scope != null && scope.materialData.containsKey(gt)) {
            for (final DummyData d : scope.materialData.get(gt)) {
                if (d.fieldName.equalsIgnoreCase("durability")) {
                    durability += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("damage")) {
                    damage += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("reload")) {
                    reload += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("knockback")) {
                    knockback += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("spread")) {
                    spread += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("speed")) {
                    speed += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("shots")) {
                    shots += Float.parseFloat(d.fieldValue) / 3.0f;
                }
                if (d.fieldName.equalsIgnoreCase("scope.zoom")) {
                    zoom += Float.parseFloat(d.fieldValue);
                }
            }
        }
        if (gt == GunRegistry.GunType.GATLING) {
            speed = 0.0f;
            spread *= 4.5f;
            shots *= 20.0f;
        }
        if (gt == GunRegistry.GunType.RIFLE) {
            speed = 0.0f;
            spread *= 1.3f;
            shots *= 6.0f;
        }
        if (gt == GunRegistry.GunType.SNIPER) {
            speed *= 9.0f;
            spread /= 10.0f;
            damage *= 2.0f;
        }
        if (gt == GunRegistry.GunType.PISTOL) {
            reload /= 2.0f;
        }
        stats.func_74776_a("damage", damage);
        stats.func_74776_a("durability", durability);
        stats.func_74776_a("reload", reload);
        stats.func_74776_a("knockback", knockback);
        stats.func_74776_a("speed", speed);
        stats.func_74776_a("spread", spread);
        stats.func_74776_a("shots", shots);
        stats.func_74776_a("zoom", zoom);
        stats.func_74776_a("balance", balance);
        gunTag.func_74782_a("stats", (NBTBase)stats);
    }
    
    public ItemStack func_77654_b(final ItemStack gun, final World w, final EntityLivingBase p) {
        if (gun.func_77942_o()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(gun);
            if (tag.func_74764_b("stats") && tag.func_74760_g("gunShots") + 1.0f >= tag.func_74775_l("stats").func_74760_g("shots")) {
                tag.func_74776_a("gunShots", 0.0f);
                tag.func_74776_a("cool", 60.0f);
            }
        }
        return gun;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        if (!(player instanceof EntityPlayer)) {
            return;
        }
        final ItemStack gun = stack;
        final EntityPlayer p = (EntityPlayer)player;
        final World w = p.func_130014_f_();
        if (this.func_77661_b(stack) == EnumAction.BLOCK) {
            if (count % 20 == 0) {
                player.func_130014_f_().func_184134_a(player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187646_bt, SoundCategory.PLAYERS, 0.4f, 1.0f + MathUtils.randomFloat(player.func_130014_f_().field_73012_v), false);
            }
            return;
        }
        if (this.gunType.equalsIgnoreCase("rifle") && count % 3 == 0 && gun.func_77978_p().func_74764_b("base")) {
            float balance = 0.0f;
            if (gun.func_77978_p().func_74764_b("lense")) {
                final String lenseID = gun.func_77978_p().func_74779_i("lense");
                final GunRegistry.LenseMaterial lense = GunRegistry.getLenseFromID(lenseID);
                for (final GunRegistry.GunType gt : GunRegistry.GunType.values()) {
                    if (lense != null && lense.materialData.containsKey(gt)) {
                        for (final DummyData d : lense.materialData.get(gt)) {
                            if (d.fieldName.equalsIgnoreCase("balance")) {
                                balance = (float)(int)Float.parseFloat(d.fieldValue);
                            }
                        }
                    }
                }
            }
            if (MiscUtils.getStackTag(gun).func_74764_b("stats")) {
                final NBTTagCompound stats = MiscUtils.getStackTag(gun).func_74775_l("stats");
                if (!MiscUtils.getStackTag(gun).func_74764_b("gunDamage")) {
                    MiscUtils.getStackTag(gun).func_74776_a("gunDamage", 0.0f);
                }
                if (!MiscUtils.getStackTag(gun).func_74764_b("gunShots")) {
                    MiscUtils.getStackTag(gun).func_74776_a("gunShots", 0.0f);
                }
                if (MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f > stats.func_74760_g("shots")) {
                    p.func_184597_cx();
                    return;
                }
                MiscUtils.getStackTag(gun).func_74776_a("gunShots", MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f);
                if (ECUtils.playerUseMRU(p, gun, (int)(stats.func_74760_g("damage") * 3.0f))) {
                    if (MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f <= stats.func_74760_g("durability")) {
                        MiscUtils.getStackTag(gun).func_74776_a("gunDamage", MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f);
                    }
                    else if (!w.field_72995_K && w.field_73012_v.nextFloat() <= 0.25f) {
                        w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundEvents.field_187635_cQ, SoundCategory.PLAYERS, 1.0f, 1.0f, false);
                        MiscUtils.getStackTag(gun).func_74776_a("gunShots", stats.func_74760_g("shots"));
                    }
                    MiscUtils.getStackTag(gun).func_74776_a("cool", stats.func_74760_g("speed") * 2.0f);
                    w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundRegistry.gunBeam, SoundCategory.PLAYERS, 0.1f + stats.func_74760_g("damage") / 100.0f, 2.0f - stats.func_74760_g("damage") / 50.0f, false);
                    final EntityMRURay ray = new EntityMRURay(w, (EntityLivingBase)p, stats.func_74760_g("damage"), stats.func_74760_g("spread") / 2.0f, balance);
                    if (!w.field_72995_K) {
                        w.func_72838_d((Entity)ray);
                    }
                }
            }
        }
        if (this.gunType.equalsIgnoreCase("gatling")) {
            final int usingTicks = 10000 - count;
            if (count >= 9940 && count % 5 == 0) {
                w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundEvents.field_187780_dr, SoundCategory.PLAYERS, 0.1f, 0.0f + usingTicks / 30.0f, false);
            }
            if (usingTicks >= 60) {
                ECUtils.playSoundToAllNearby(p.field_70165_t, p.field_70163_u, p.field_70161_v, "essentialcraft:sound.beam", 1.0f, 2.0f, 16.0, p.field_71093_bK);
                if (gun.func_77978_p().func_74764_b("base")) {
                    float balance2 = 0.0f;
                    if (gun.func_77978_p().func_74764_b("lense")) {
                        final String lenseID2 = gun.func_77978_p().func_74779_i("lense");
                        final GunRegistry.LenseMaterial lense2 = GunRegistry.getLenseFromID(lenseID2);
                        for (final GunRegistry.GunType gt2 : GunRegistry.GunType.values()) {
                            if (lense2 != null && lense2.materialData.containsKey(gt2)) {
                                for (final DummyData d2 : lense2.materialData.get(gt2)) {
                                    if (d2.fieldName.equalsIgnoreCase("balance")) {
                                        balance2 = (float)(int)Float.parseFloat(d2.fieldValue);
                                    }
                                }
                            }
                        }
                    }
                    if (MiscUtils.getStackTag(gun).func_74764_b("stats")) {
                        final NBTTagCompound stats2 = MiscUtils.getStackTag(gun).func_74775_l("stats");
                        if (!MiscUtils.getStackTag(gun).func_74764_b("gunDamage")) {
                            MiscUtils.getStackTag(gun).func_74776_a("gunDamage", 0.0f);
                        }
                        if (!MiscUtils.getStackTag(gun).func_74764_b("gunShots") && !w.field_72995_K) {
                            MiscUtils.getStackTag(gun).func_74776_a("gunShots", 0.0f);
                        }
                        if (MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f > stats2.func_74760_g("shots")) {
                            p.func_184597_cx();
                            return;
                        }
                        if (!w.field_72995_K) {
                            MiscUtils.getStackTag(gun).func_74776_a("gunShots", MiscUtils.getStackTag(gun).func_74760_g("gunShots") + 1.0f);
                        }
                        if (ECUtils.playerUseMRU(p, gun, (int)(stats2.func_74760_g("damage") * 2.0f))) {
                            if (MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f <= stats2.func_74760_g("durability")) {
                                MiscUtils.getStackTag(gun).func_74776_a("gunDamage", MiscUtils.getStackTag(gun).func_74760_g("gunDamage") + 1.0f);
                            }
                            else if (!w.field_72995_K && w.field_73012_v.nextFloat() <= 0.25f) {
                                w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundEvents.field_187635_cQ, SoundCategory.PLAYERS, 1.0f, 1.0f, false);
                                MiscUtils.getStackTag(gun).func_74776_a("gunShots", stats2.func_74760_g("shots"));
                            }
                            final EntityMRURay ray2 = new EntityMRURay(w, (EntityLivingBase)p, stats2.func_74760_g("damage"), stats2.func_74760_g("spread") / 2.0f, balance2);
                            if (!w.field_72995_K) {
                                w.func_72838_d((Entity)ray2);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public boolean showDurabilityBar(final ItemStack stack) {
        return stack.func_77942_o() && MiscUtils.getStackTag(stack).func_74764_b("stats");
    }
    
    public double getDurabilityForDisplay(final ItemStack stack) {
        if (stack.func_77942_o()) {
            final NBTTagCompound gunTag = MiscUtils.getStackTag(stack);
            if (gunTag.func_74764_b("stats")) {
                final float currentDamage = gunTag.func_74760_g("gunDamage");
                final float maxDamage = gunTag.func_74775_l("stats").func_74760_g("durability");
                return currentDamage / maxDamage;
            }
        }
        return stack.func_77952_i() / (double)stack.func_77958_k();
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        if (stack.func_77942_o()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(stack);
            if (tag.func_74764_b("stats")) {
                final float current = tag.func_74760_g("gunShots") + 1.0f;
                final float max = tag.func_74775_l("stats").func_74760_g("shots");
                if (current >= max) {
                    return EnumAction.BLOCK;
                }
            }
        }
        return EnumAction.BOW;
    }
    
    public int func_77626_a(final ItemStack stack) {
        if (stack.func_77942_o()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(stack);
            if (tag.func_74764_b("stats")) {
                final float current = tag.func_74760_g("gunShots") + 1.0f;
                final float max = tag.func_74775_l("stats").func_74760_g("shots");
                if (current >= max) {
                    return MathHelper.func_76141_d(tag.func_74775_l("stats").func_74760_g("reload") * 20.0f);
                }
            }
        }
        return 10000;
    }
    
    public void registerModels() {
        ModelUtils.setItemModelSingleIcon((Item)this, new String[] { "essentialcraft:item/" + this.getRegistryName().func_110623_a(), "internal" });
        ModelBakery.registerItemVariants((Item)this, new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory") });
        if (this == ItemsCore.sniper) {
            ModelBakery.registerItemVariants((Item)this, new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:item/blank", "inventory") });
        }
        MiscUtils.addItemOverlayElement((Item)this, (IItemOverlayElement)ItemOverlayGun.INSTANCE);
    }
    
    public static class ItemOverlayGun implements IItemOverlayElement
    {
        public static final ItemOverlayGun INSTANCE;
        
        public void renderItemOverlayIntoGUI(final FontRenderer fr, final ItemStack item, final int x, final int y, final String text) {
            double health = 0.0;
            if (item.func_77942_o()) {
                final NBTTagCompound tag = MiscUtils.getStackTag(item);
                if (tag.func_74764_b("stats")) {
                    float current = tag.func_74760_g("gunShots");
                    final float max = tag.func_74775_l("stats").func_74760_g("shots");
                    if (current > max) {
                        current = max;
                    }
                    health = current / max;
                }
            }
            final int j = (int)Math.round(13.0 - health * 13.0);
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            GlStateManager.func_179090_x();
            GlStateManager.func_179118_c();
            GlStateManager.func_179084_k();
            final Tessellator tessellator = Tessellator.func_178181_a();
            final BufferBuilder BufferBuilder = tessellator.func_178180_c();
            this.draw(BufferBuilder, x + 14, y, 2, 14, 0, 0, 0, 255);
            this.draw(BufferBuilder, x + 14, y, 1, 13, 51, 51, 51, 255);
            this.draw(BufferBuilder, x + 14, y + j, 1, 13 - j, 186, 0, 0, 255);
            GlStateManager.func_179147_l();
            GlStateManager.func_179141_d();
            GlStateManager.func_179098_w();
            GlStateManager.func_179145_e();
            GlStateManager.func_179126_j();
        }
        
        private void draw(final BufferBuilder renderer, final int x, final int y, final int width, final int height, final int red, final int green, final int blue, final int alpha) {
            renderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
            renderer.func_181662_b((double)(x + 0), (double)(y + 0), 0.0).func_181669_b(red, green, blue, alpha).func_181675_d();
            renderer.func_181662_b((double)(x + 0), (double)(y + height), 0.0).func_181669_b(red, green, blue, alpha).func_181675_d();
            renderer.func_181662_b((double)(x + width), (double)(y + height), 0.0).func_181669_b(red, green, blue, alpha).func_181675_d();
            renderer.func_181662_b((double)(x + width), (double)(y + 0), 0.0).func_181669_b(red, green, blue, alpha).func_181675_d();
            Tessellator.func_178181_a().func_78381_a();
        }
        
        static {
            INSTANCE = new ItemOverlayGun();
        }
    }
}
