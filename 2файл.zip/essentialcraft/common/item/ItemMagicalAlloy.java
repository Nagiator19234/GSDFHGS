package essentialcraft.common.item;

import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import essentialcraft.api.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import DummyCore.Client.*;

public class ItemMagicalAlloy extends Item implements IItemColor, IModelRegisterer
{
    public ItemMagicalAlloy() {
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (final OreSmeltingRecipe recipe : OreSmeltingRecipe.RECIPES) {
                final ItemStack toAdd = new ItemStack((Item)this, 1, 0);
                final NBTTagCompound tag = MiscUtils.getStackTag(toAdd);
                tag.func_74778_a("ore", recipe.oreName);
                items.add((Object)toAdd);
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> tooltip, final ITooltipFlag isAdvanced) {
        tooltip.add(OreSmeltingRecipe.getLocalizedOreName(stack));
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int layer) {
        return (layer == 0) ? 16777215 : OreSmeltingRecipe.getColorFromItemStack(stack);
    }
    
    public void registerModels() {
        ModelUtils.setItemModelSingleIcon((Item)this, new String[] { "essentialcraft:item/magicalalloy" });
    }
}
