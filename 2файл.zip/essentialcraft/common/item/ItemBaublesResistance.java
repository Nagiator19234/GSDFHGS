package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.client.util.*;
import java.util.*;
import net.minecraft.util.text.*;
import net.minecraftforge.fml.relauncher.*;
import baubles.api.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;

public class ItemBaublesResistance extends Item implements IBauble, IModelRegisterer
{
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        final NBTTagCompound bTag = MiscUtils.getStackTag(stack);
        if (!bTag.func_74764_b("type")) {
            initRandomTag(stack, world.field_73012_v);
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public static void initRandomTag(final ItemStack stk, final Random rand) {
        final NBTTagCompound bTag = MiscUtils.getStackTag(stk);
        final int type = rand.nextInt(3);
        bTag.func_74768_a("type", type);
        bTag.func_74768_a("b", rand.nextInt(6));
        bTag.func_74768_a("t", rand.nextInt(6));
        bTag.func_74776_a("mrucr", rand.nextFloat() / 10.0f);
        bTag.func_74776_a("mrurr", rand.nextFloat() / 10.0f);
        bTag.func_74776_a("car", rand.nextFloat() / 10.0f);
        stk.func_77982_d(bTag);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag flag) {
        super.func_77624_a(stack, world, (List)list, flag);
        final NBTTagCompound bTag = MiscUtils.getStackTag(stack);
        if (bTag.func_74764_b("type")) {
            new ArrayList();
            list.add(TextFormatting.GOLD + "+" + (int)(bTag.func_74760_g("mrucr") * 100.0f) + "% " + TextFormatting.DARK_PURPLE + "to MRUCorruption resistance");
            list.add(TextFormatting.GOLD + "+" + (int)(bTag.func_74760_g("mrurr") * 100.0f) + "% " + TextFormatting.DARK_PURPLE + "to MRURadiation resistance");
            list.add(TextFormatting.GOLD + "-" + (int)(bTag.func_74760_g("car") * 100.0f) + "% " + TextFormatting.DARK_PURPLE + "to Corruption affection");
        }
    }
    
    public BaubleType getBaubleType(final ItemStack itemstack) {
        final NBTTagCompound bTag = MiscUtils.getStackTag(itemstack);
        if (bTag.func_74764_b("type")) {
            final int type = bTag.func_74762_e("type");
            switch (type) {
                case 0: {
                    return BaubleType.AMULET;
                }
                case 1: {
                    return BaubleType.BELT;
                }
                case 2: {
                    return BaubleType.RING;
                }
                case 3: {
                    return BaubleType.TRINKET;
                }
                case 4: {
                    return BaubleType.HEAD;
                }
                case 5: {
                    return BaubleType.BODY;
                }
                case 6: {
                    return BaubleType.CHARM;
                }
            }
        }
        return BaubleType.TRINKET;
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomMeshDefinition((Item)this, (ItemMeshDefinition)new MeshDefinitionBaublesWearable());
        final ArrayList<ModelResourceLocation> names = new ArrayList<ModelResourceLocation>();
        for (int bottomInt = 0; bottomInt < 6; ++bottomInt) {
            for (int topInt = 0; topInt < 6; ++topInt) {
                names.add(new ModelResourceLocation("essentialcraft:item/baublesamulet", "bottom=" + bottomInt + ",top=" + topInt));
                names.add(new ModelResourceLocation("essentialcraft:item/baublesbelt", "bottom=" + bottomInt + ",top=" + topInt));
                names.add(new ModelResourceLocation("essentialcraft:item/baublesring", "bottom=" + bottomInt + ",top=" + topInt));
            }
        }
        ModelBakery.registerItemVariants((Item)this, (ResourceLocation[])names.toArray((ResourceLocation[])new ModelResourceLocation[0]));
    }
    
    public static class MeshDefinitionBaublesWearable implements ItemMeshDefinition
    {
        public ModelResourceLocation func_178113_a(final ItemStack stk) {
            final NBTTagCompound bTag = MiscUtils.getStackTag(stk);
            if (bTag.func_74764_b("type")) {
                final int type = bTag.func_74762_e("type");
                final int bottomInt = bTag.func_74762_e("b");
                final int topInt = bTag.func_74762_e("t");
                switch (type) {
                    case 0: {
                        return new ModelResourceLocation("essentialcraft:item/baublesamulet", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 1: {
                        return new ModelResourceLocation("essentialcraft:item/baublesbelt", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 2: {
                        return new ModelResourceLocation("essentialcraft:item/baublesring", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 3: {
                        return new ModelResourceLocation("essentialcraft:item/baublestrinket", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 4: {
                        return new ModelResourceLocation("essentialcraft:item/baubleshead", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 5: {
                        return new ModelResourceLocation("essentialcraft:item/baublesbody", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                    case 6: {
                        return new ModelResourceLocation("essentialcraft:item/baublescharm", "bottom=" + bottomInt + ",top=" + topInt);
                    }
                }
            }
            return new ModelResourceLocation("essentialcraft:item/baublesamulet", "bottom=0,top=0");
        }
    }
}
