package essentialcraft.common.item;

import net.minecraft.item.*;
import DummyCore.Client.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemEC extends Item implements IModelRegisterer
{
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
