package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import essentialcraft.common.block.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.block.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.client.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemWindTablet extends ItemMRUGeneric implements IModelRegisterer
{
    public static String[] windMessages;
    
    public ItemWindTablet() {
        this.field_77777_bU = 1;
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World worldIn, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        if (ECUtils.playerUseMRU(player, player.func_184586_b(hand), 500)) {
            final int currentWindRev = WindRelations.getPlayerWindRelations(player);
            final int maxWindRev = 3500;
            final String windName = "Owethanna Else Hugaida";
            final int revPos = MathUtils.pixelatedTextureSize(currentWindRev, maxWindRev, windName.length());
            if (revPos >= 22) {
                if (!worldIn.field_72995_K) {
                    final Block b = worldIn.func_180495_p(pos).func_177230_c();
                    if (b == Blocks.field_150427_aO) {
                        for (int i = 0; worldIn.func_180495_p(pos.func_177982_a(i, 0, 0)).func_177230_c() == Blocks.field_150427_aO; ++i) {
                            for (int j = 0; worldIn.func_180495_p(pos.func_177982_a(i, j, 0)).func_177230_c() == Blocks.field_150427_aO; ++j) {
                                for (int k = 0; worldIn.func_180495_p(pos.func_177982_a(i, j, k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(i, j, k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(i, j, k)));
                                    worldIn.func_180501_a(pos.func_177982_a(i, j, k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                                for (int k = 1; worldIn.func_180495_p(pos.func_177982_a(i, j, -k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(i, j, -k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(i, j, -k)));
                                    worldIn.func_180501_a(pos.func_177982_a(i, j, -k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                            }
                            for (int j = 1; worldIn.func_180495_p(pos.func_177982_a(i, -j, 0)).func_177230_c() == Blocks.field_150427_aO; ++j) {
                                for (int k = 0; worldIn.func_180495_p(pos.func_177982_a(i, -j, k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(i, -j, k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(i, -j, k)));
                                    worldIn.func_180501_a(pos.func_177982_a(i, -j, k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                                for (int k = 1; worldIn.func_180495_p(pos.func_177982_a(i, -j, -k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(i, -j, -k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(i, -j, -k)));
                                    worldIn.func_180501_a(pos.func_177982_a(i, -j, -k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                            }
                        }
                        for (int i = 1; worldIn.func_180495_p(pos.func_177982_a(-i, 0, 0)).func_177230_c() == Blocks.field_150427_aO; ++i) {
                            for (int j = 0; worldIn.func_180495_p(pos.func_177982_a(-i, j, 0)).func_177230_c() == Blocks.field_150427_aO; ++j) {
                                for (int k = 0; worldIn.func_180495_p(pos.func_177982_a(-i, j, k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(-i, j, k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(-i, j, k)));
                                    worldIn.func_180501_a(pos.func_177982_a(-i, j, k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                                for (int k = 1; worldIn.func_180495_p(pos.func_177982_a(-i, j, -k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(-i, j, -k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(-i, j, -k)));
                                    worldIn.func_180501_a(pos.func_177982_a(-i, j, -k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                            }
                            for (int j = 1; worldIn.func_180495_p(pos.func_177982_a(-i, -j, 0)).func_177230_c() == Blocks.field_150427_aO; ++j) {
                                for (int k = 0; worldIn.func_180495_p(pos.func_177982_a(-i, -j, k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(-i, -j, k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(-i, -j, k)));
                                    worldIn.func_180501_a(pos.func_177982_a(-i, -j, k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                                for (int k = 1; worldIn.func_180495_p(pos.func_177982_a(-i, -j, -k)).func_177230_c() == Blocks.field_150427_aO; ++k) {
                                    final int metadata = worldIn.func_180495_p(pos.func_177982_a(-i, -j, -k)).func_177230_c().func_176201_c(worldIn.func_180495_p(pos.func_177982_a(-i, -j, -k)));
                                    worldIn.func_180501_a(pos.func_177982_a(-i, -j, -k), BlocksCore.portal.func_176203_a(metadata), 2);
                                }
                            }
                        }
                    }
                    worldIn.func_184148_a(player, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187814_ei, SoundCategory.BLOCKS, 10.0f, 0.01f);
                }
                return EnumActionResult.SUCCESS;
            }
        }
        return super.func_180614_a(player, worldIn, pos, hand, facing, hitX, hitY, hitZ);
    }
    
    @SideOnly(Side.CLIENT)
    @Override
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, list, par4);
        final int currentWindRev = WindRelations.getPlayerWindRelations((EntityPlayer)Minecraft.func_71410_x().field_71439_g);
        final int maxWindRev = 3500;
        final String windName = "Owethanna Else Hugaida";
        final String hidden = "??????????????????????";
        final int revPos = MathUtils.pixelatedTextureSize(currentWindRev, maxWindRev, windName.length());
        list.add("Wind Name:");
        list.add(windName.substring(0, revPos) + hidden.substring(revPos));
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/windtablet", "inventory"));
    }
    
    static {
        ItemWindTablet.windMessages = new String[] { "A wind blow rotates around you...", "The wind howls...", "The wind ruffles your hair...", "The wind blows around your fingers...", "The wind says something...", "The wind makes you sneeze!", "You hear something similar to laugh...", "The wind rotates around your legs...", "The wind tickles you...", "The wind stops all other sounds...", "The wind whispers 'Owethanna'...", "The wind whispers your name...", "The wind brings a very nostalgic smell...", "The wind creates a miniature tornado...", "The wind thows some leaves around...", "The wind says 'Owethanna Else '...", "The wind pushes you upwards...", "The wind rotates very fast around you...", "The wind goes into your lungs...", "You feel very powerfull!", "You fly up using the wind!", "You start seeing other worlds!", "You and the wind laugh...", "The wind and you shout:" };
    }
}
