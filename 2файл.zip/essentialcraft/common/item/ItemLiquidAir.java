package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.registry.*;
import net.minecraft.potion.*;
import essentialcraft.utils.common.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemLiquidAir extends Item implements IModelRegisterer
{
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase entityLiving) {
        if (entityLiving instanceof EntityPlayer && !world.field_72995_K) {
            ((EntityPlayer)entityLiving).field_71071_by.func_70298_a(((EntityPlayer)entityLiving).field_71071_by.field_70461_c, 1);
            ECUtils.calculateAndAddPE((EntityPlayer)entityLiving, PotionRegistry.paranormalLightness, 9600, 2400);
            WindRelations.increasePlayerWindRelations((EntityPlayer)entityLiving, 100);
        }
        return stack;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 32;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.DRINK;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/air_potion", "inventory"));
    }
}
