package essentialcraft.common.item;

import DummyCore.Client.*;
import essentialcraft.api.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import net.minecraft.block.state.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraftforge.common.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemMagicalDigger extends ItemPickaxe implements IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public int maxMRU;
    
    public ItemMagicalDigger() {
        super(ItemsCore.elemental);
        this.maxMRU = 5000;
        this.field_77777_bU = 1;
        this.field_77789_bW = false;
        this.func_77656_e(0);
    }
    
    public boolean func_77616_k(final ItemStack stack) {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184609_a(hand);
        player.field_70733_aJ = 0.3f;
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public boolean func_77662_d() {
        return true;
    }
    
    public float func_150893_a(final ItemStack stack, final IBlockState par2Block) {
        if (((IMRUHandlerItem)stack.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() >= 9) {
            return 32.0f;
        }
        return 1.0f;
    }
    
    public boolean canBreak(final ItemStack s) {
        return ((IMRUHandlerItem)s.getCapability((Capability)ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() >= 9;
    }
    
    public boolean func_179218_a(final ItemStack stack, final World world, final IBlockState par3, final BlockPos par4, final EntityLivingBase par7EntityLivingBase) {
        if (par7EntityLivingBase instanceof EntityPlayer && !par7EntityLivingBase.func_70093_af() && this.canBreak(stack)) {
            this.break3x3x3Blocks((EntityPlayer)par7EntityLivingBase, new Coord3D((float)par4.func_177958_n(), (float)par4.func_177956_o(), (float)par4.func_177952_p()), stack, world.func_180495_p(par4).func_177230_c());
        }
        return true;
    }
    
    public void break3x3x3Blocks(final EntityPlayer e, final Coord3D c, final ItemStack s, final Block id) {
        for (int x = -1; x <= 1; ++x) {
            for (int y = -1; y <= 1; ++y) {
                for (int z = -1; z <= 1; ++z) {
                    final Coord3D c00rd = new Coord3D(c.x + x, c.y + y, c.z + z);
                    for (int v = 0; v < 10; ++v) {
                        e.func_130014_f_().func_175688_a(EnumParticleTypes.REDSTONE, (double)(c.x + x + e.func_130014_f_().field_73012_v.nextFloat()), (double)(c.y + y + e.func_130014_f_().field_73012_v.nextFloat()), (double)(c.z + z + e.func_130014_f_().field_73012_v.nextFloat()), 1.0, 0.0, 1.0, new int[0]);
                    }
                    e.func_130014_f_().func_184133_a(e, e.func_180425_c(), SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 0.2f, 6.0f);
                    final Block b = e.func_130014_f_().func_180495_p(new BlockPos((int)c.x + x, (int)c.y + y, (int)c.z + z)).func_177230_c();
                    if (b != null && b == id && ECUtils.playerUseMRU(e, s, 9) && !e.func_130014_f_().field_72995_K) {
                        this.breakBlock(e, c00rd, s);
                    }
                }
            }
        }
    }
    
    public void breakBlock(final EntityPlayer e, final Coord3D coord, final ItemStack s) {
        final int x = (int)coord.x;
        final int y = (int)coord.y;
        final int z = (int)coord.z;
        final BlockPos p = new BlockPos(x, y, z);
        if (this.canBreak(s)) {
            final Block b = e.func_130014_f_().func_180495_p(p).func_177230_c();
            GameType type = GameType.SURVIVAL;
            if (e.field_71075_bZ.field_75098_d) {
                type = GameType.CREATIVE;
            }
            if (!e.field_71075_bZ.field_75099_e) {
                type = GameType.ADVENTURE;
            }
            final int be = ForgeHooks.onBlockBreakEvent(e.func_130014_f_(), type, (EntityPlayerMP)e, p);
            if (be != -1) {
                b.func_180657_a(e.func_130014_f_(), e, p, e.func_130014_f_().func_180495_p(p), e.func_130014_f_().func_175625_s(p), s);
                e.func_130014_f_().func_175698_g(p);
            }
        }
    }
    
    public boolean canHarvestBlock(final IBlockState par1Block, final ItemStack itemStack) {
        return true;
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicaldigger", "inventory"));
    }
    
    static {
        ItemMagicalDigger.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
}
