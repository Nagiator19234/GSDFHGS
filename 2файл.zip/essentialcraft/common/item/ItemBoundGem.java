package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import essentialcraft.common.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.init.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.item.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;

public class ItemBoundGem extends Item implements IModelRegisterer
{
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, BlockPos pos, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack stack = player.func_184586_b(hand);
        if (stack.func_77978_p() != null && MiscUtils.getStackTag(stack).func_74764_b("pos")) {
            return EnumActionResult.PASS;
        }
        if (world.func_180495_p(pos).func_177230_c() == BlocksCore.rayTower && ((EnumLayer)world.func_180495_p(pos).func_177229_b((IProperty)BlockRayTower.LAYER)).getIndexTwo() == 1) {
            pos = pos.func_177977_b();
        }
        final ItemStack is = this.createTag(stack);
        MiscUtils.getStackTag(is).func_74783_a("pos", new int[] { pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p() });
        MiscUtils.getStackTag(is).func_74768_a("dim", player.field_71093_bK);
        MiscUtils.getStackTag(is).func_74757_a("created", !player.func_70093_af());
        if (stack.func_190916_E() <= 0) {
            player.field_71071_by.func_70299_a(player.field_71071_by.field_70461_c, ItemStack.field_190927_a);
        }
        if (!player.field_71071_by.func_70441_a(is)) {
            player.func_71019_a(is, false);
        }
        if (player.field_71070_bA != null) {
            player.field_71070_bA.func_75142_b();
        }
        world.func_184148_a((EntityPlayer)null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187802_ec, SoundCategory.PLAYERS, 1.0f, 2.0f);
        return EnumActionResult.SUCCESS;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        if (stack.func_77978_p() != null && !world.field_72995_K && player.func_70093_af()) {
            if (stack.func_77978_p().func_74767_n("created")) {
                stack.func_77982_d((NBTTagCompound)null);
                world.func_184148_a((EntityPlayer)null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187679_dF, SoundCategory.PLAYERS, 1.0f, 0.01f);
            }
            else {
                MiscUtils.getStackTag(stack).func_74757_a("created", true);
            }
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag flag) {
        super.func_77624_a(stack, world, (List)list, flag);
        this.addInfo(stack, world, list);
    }
    
    public void addInfo(final ItemStack stack, final World world, final List<String> list) {
        if (stack.func_77978_p() != null) {
            final int[] coord = MiscUtils.getStackTag(stack).func_74759_k("pos");
            list.add("Currently Bound To Block At:");
            list.add("x: " + coord[0]);
            list.add("y: " + coord[1]);
            list.add("z: " + coord[2]);
            list.add("Dimension: " + MiscUtils.getStackTag(stack).func_74762_e("dim"));
        }
    }
    
    public static int[] getCoords(final ItemStack stack) {
        return MiscUtils.getStackTag(stack).func_74759_k("pos");
    }
    
    public EnumRarity func_77613_e(final ItemStack stack) {
        return (stack.func_77978_p() != null) ? EnumRarity.EPIC : EnumRarity.COMMON;
    }
    
    public ItemStack createTag(final ItemStack stack) {
        final ItemStack retStk = stack.func_77946_l();
        retStk.func_190920_e(1);
        stack.func_190918_g(1);
        if (retStk.func_77978_p() == null) {
            final NBTTagCompound tag = new NBTTagCompound();
            tag.func_74783_a("pos", new int[] { 0, 0, 0 });
            retStk.func_77982_d(tag);
            return retStk;
        }
        return retStk;
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomMeshDefinition((Item)this, (ItemMeshDefinition)MeshDefinitionBoundGem.INSTANCE);
        ModelBakery.registerItemVariants((Item)this, new ResourceLocation[] { (ResourceLocation)new ModelResourceLocation("essentialcraft:item/bound_gem", "active=true"), (ResourceLocation)new ModelResourceLocation("essentialcraft:item/bound_gem", "active=false") });
    }
    
    public static class MeshDefinitionBoundGem implements ItemMeshDefinition
    {
        public static final MeshDefinitionBoundGem INSTANCE;
        
        public ModelResourceLocation func_178113_a(final ItemStack stack) {
            return new ModelResourceLocation("essentialcraft:item/bound_gem", "active=" + Boolean.toString(stack.func_77942_o()));
        }
        
        static {
            INSTANCE = new MeshDefinitionBoundGem();
        }
    }
}
