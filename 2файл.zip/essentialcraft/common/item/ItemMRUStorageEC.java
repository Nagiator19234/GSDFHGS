package essentialcraft.common.item;

import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import baubles.api.*;
import net.minecraft.entity.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemMRUStorageEC extends Item implements IBauble, IItemColor, IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public int[] maxMRU;
    public static int[] colors;
    public static String[] dropNames;
    
    public ItemMRUStorageEC(final int[] maxMRU) {
        this.maxMRU = new int[6];
        this.maxMRU = maxMRU;
        this.func_77625_d(1);
        this.func_77627_a(true);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag flag) {
        super.func_77624_a(stack, world, (List)list, flag);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 5; ++i) {
                final ItemStack min = new ItemStack((Item)this, 1, i);
                final ItemStack max = new ItemStack((Item)this, 1, i);
                ((IMRUHandlerItem)min.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
                ((IMRUHandlerItem)max.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU[i]);
                items.add((Object)min);
                items.add((Object)max);
            }
        }
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + ItemMRUStorageEC.dropNames[Math.min(stack.func_77952_i(), ItemMRUStorageEC.dropNames.length - 1)];
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int tintIndex) {
        final int dam = stack.func_77952_i();
        if (dam != -1) {
            final int currentMRU = ((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU();
            final int maxMRU = ((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU();
            int percentage = MathUtils.getPercentage(currentMRU, maxMRU);
            percentage /= 10;
            return ItemMRUStorageEC.colors[percentage];
        }
        return 16777215;
    }
    
    public BaubleType getBaubleType(final ItemStack itemstack) {
        return BaubleType.RING;
    }
    
    public void onWornTick(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public void onEquipped(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public void onUnequipped(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public boolean canEquip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public boolean canUnequip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        if (stack.func_77952_i() >= 0 && stack.func_77952_i() < 5) {
            return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU[stack.func_77952_i()], true);
        }
        return null;
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemMRUStorageEC.dropNames.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/storage", "type=" + ItemMRUStorageEC.dropNames[i].toLowerCase(Locale.ENGLISH)));
        }
    }
    
    static {
        ItemMRUStorageEC.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        ItemMRUStorageEC.colors = new int[] { 5592405, 6706517, 7820629, 8934741, 10048853, 11162965, 12277077, 13391189, 14505301, 15623782, 16737894 };
        ItemMRUStorageEC.dropNames = new String[] { "SoulShard", "SoulSphere", "DarkSoulMatter", "RedSoulMatter", "MatterOfEternity", "Unknown" };
    }
}
