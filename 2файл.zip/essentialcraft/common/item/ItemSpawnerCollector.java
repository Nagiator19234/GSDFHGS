package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.tileentity.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemSpawnerCollector extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemSpawnerCollector() {
        this.setMaxMRU(10000);
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final Block b = world.func_180495_p(pos).func_177230_c();
        if (b != null && b instanceof BlockMobSpawner) {
            if (world.func_175625_s(pos) == null || !(world.func_175625_s(pos) instanceof TileEntityMobSpawner)) {
                return EnumActionResult.PASS;
            }
            if (ECUtils.playerUseMRU(player, player.func_184586_b(hand), 5000)) {
                final TileEntityMobSpawner t = (TileEntityMobSpawner)world.func_175625_s(pos);
                final NBTTagCompound mobTag = new NBTTagCompound();
                t.func_189515_b(mobTag);
                final ItemStack collectedSpawner = new ItemStack(ItemsCore.collectedSpawner, 1, 0);
                MiscUtils.getStackTag(collectedSpawner).func_74782_a("monsterSpawner", (NBTBase)mobTag);
                final EntityItem item = new EntityItem(world, pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, collectedSpawner);
                if (!world.field_72995_K) {
                    world.func_72838_d((Entity)item);
                }
                world.func_175698_g(pos);
                player.func_184609_a(hand);
            }
        }
        return EnumActionResult.PASS;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/spawnercollector", "inventory"));
    }
}
