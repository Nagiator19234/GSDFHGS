package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.text.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.api.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemBalanceSetter extends Item implements IModelRegisterer
{
    public void func_77663_a(final ItemStack stack, final World worldIn, final Entity entityIn, final int itemSlot, final boolean isSelected) {
        if (!stack.func_77942_o()) {
            MiscUtils.getStackTag(stack).func_74768_a("Mode", 0);
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World worldIn, final EntityPlayer playerIn, final EnumHand handIn) {
        final ItemStack stackIn = playerIn.func_184586_b(handIn);
        if (!playerIn.func_70093_af()) {
            int currentMode = MiscUtils.getStackTag(stackIn).func_74762_e("Mode");
            currentMode = (currentMode + 1) % 3;
            if (!worldIn.field_72995_K) {
                playerIn.func_145747_a((ITextComponent)new TextComponentString("Set Mode To " + currentMode));
            }
            MiscUtils.getStackTag(stackIn).func_74768_a("Mode", currentMode);
        }
        return (ActionResult<ItemStack>)new ActionResult(EnumActionResult.PASS, (Object)stackIn);
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World worldIn, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        if (player.func_70093_af()) {
            final TileEntity tile = worldIn.func_175625_s(pos);
            if (tile != null && tile.hasCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)) {
                final IMRUHandler handler = (IMRUHandler)tile.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null);
                handler.setBalance((float)MiscUtils.getStackTag(player.func_184586_b(hand)).func_74762_e("Mode"));
                return EnumActionResult.SUCCESS;
            }
        }
        return EnumActionResult.PASS;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("minecraft:blaze_rod", "inventory"));
    }
}
