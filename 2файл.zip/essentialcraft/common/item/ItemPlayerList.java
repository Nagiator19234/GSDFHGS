package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import DummyCore.Utils.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemPlayerList extends Item implements IModelRegisterer
{
    public ItemPlayerList() {
        this.field_77777_bU = 1;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final NBTTagCompound itemTag = MiscUtils.getStackTag(player.func_184586_b(hand));
        if (!itemTag.func_74764_b("usernames")) {
            itemTag.func_74778_a("usernames", "||username:null");
        }
        String str = itemTag.func_74779_i("usernames");
        final DummyData[] dt = DataStorage.parseData(str);
        boolean canAddUsername = true;
        for (final DummyData element : dt) {
            if (element.fieldValue.equals(MiscUtils.getUUIDFromPlayer(player).toString())) {
                canAddUsername = false;
            }
        }
        if (canAddUsername) {
            str = str + "||username:" + MiscUtils.getUUIDFromPlayer(player).toString();
        }
        itemTag.func_74778_a("usernames", str);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        if (stack.func_77978_p() != null) {
            list.add("Allowed Players:");
            final NBTTagCompound itemTag = MiscUtils.getStackTag(stack);
            if (!itemTag.func_74764_b("usernames")) {
                itemTag.func_74778_a("usernames", "||username:null");
            }
            final String str = itemTag.func_74779_i("usernames");
            final DummyData[] data;
            final DummyData[] dt = data = DataStorage.parseData(str);
            for (final DummyData element : data) {
                final String name = element.fieldValue;
                if (!name.equals("null")) {
                    list.add(" -" + MiscUtils.getUsernameFromUUID(name));
                }
            }
        }
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("minecraft:paper", "inventory"));
    }
}
