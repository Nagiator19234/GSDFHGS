package essentialcraft.common.item;

import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.block.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import essentialcraft.common.entity.*;
import essentialcraft.api.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraftforge.common.capabilities.*;
import DummyCore.Client.*;

public class ItemSpawnEggEC extends ItemMonsterPlacer implements IItemColor, IModelRegisterer
{
    public ItemSpawnEggEC() {
        this.func_77627_a(true);
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int pass) {
        return 16777215;
    }
    
    public EnumActionResult onItemUseFirst(final EntityPlayer player, final World world, BlockPos pos, final EnumFacing facing, final float hitX, final float hitY, final float hitZ, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        if (!player.field_71075_bZ.field_75098_d) {
            stack.func_190918_g(1);
        }
        if (world.field_72995_K) {
            return EnumActionResult.SUCCESS;
        }
        final Block block = world.func_180495_p(pos).func_177230_c();
        pos = pos.func_177972_a(facing);
        double d0 = 0.0;
        if (facing == EnumFacing.UP) {
            d0 = block.func_180646_a(world.func_180495_p(pos.func_177977_b()), (IBlockAccess)world, pos.func_177977_b()).field_72337_e - 1.0;
        }
        final Entity entity = spawnCreature(world, stack.func_77952_i(), pos.func_177958_n() + 0.5, pos.func_177956_o() + d0, pos.func_177952_p() + 0.5);
        if (entity != null && entity instanceof EntityLivingBase && stack.func_82837_s()) {
            ((EntityLiving)entity).func_96094_a(stack.func_82833_r());
        }
        return EnumActionResult.SUCCESS;
    }
    
    public String func_77653_i(final ItemStack stack) {
        String s = ("" + I18n.func_74838_a(this.func_77658_a() + ".name")).trim();
        final String s2 = EntitiesCore.REGISTERED_ENTITIES.get(stack.func_77952_i()).getName();
        if (s2 != null) {
            s = s + " " + I18n.func_74838_a("entity." + s2 + ".name");
        }
        return s;
    }
    
    public void func_150895_a(final CreativeTabs t, final NonNullList<ItemStack> l) {
        if (this.func_194125_a(t)) {
            for (int j = 0; j < EntitiesCore.REGISTERED_ENTITIES.size(); ++j) {
                l.add((Object)new ItemStack((Item)this, 1, j));
            }
        }
    }
    
    public static Entity spawnCreature(final World world, final int index, final double x, final double y, final double z) {
        try {
            Entity entity = null;
            for (int j = 0; j < 1; ++j) {
                entity = EntitiesCore.REGISTERED_ENTITIES.get(index).newInstance(world);
                if (entity != null && entity instanceof EntityLivingBase) {
                    final EntityLivingBase entityliving = (EntityLivingBase)entity;
                    entity.func_70012_b(x, y, z, MathHelper.func_76142_g(world.field_73012_v.nextFloat() * 360.0f), 0.0f);
                    entityliving.field_70759_as = entityliving.field_70177_z;
                    entityliving.field_70761_aq = entityliving.field_70177_z;
                    if (entity instanceof EntityLiving) {
                        ((EntityLiving)entityliving).func_180482_a(world.func_175649_E(new BlockPos(x, y, z)), (IEntityLivingData)null);
                    }
                    world.func_72838_d(entity);
                    if (entity instanceof EntityLiving) {
                        ((EntityLiving)entityliving).func_70642_aH();
                    }
                    if (entity instanceof EntityMRUPresence) {
                        ((IMRUHandler)entity.getCapability((Capability)CapabilityMRUHandler.MRU_HANDLER_CAPABILITY, (EnumFacing)null)).setMRU(500);
                    }
                }
            }
            return entity;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void registerModels() {
        ModelUtils.setItemModelSingleIcon((Item)this, new String[] { "essentialcraft:item/fruit_item" });
    }
}
