package essentialcraft.common.item;

import net.minecraft.item.*;
import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import net.minecraft.util.text.*;
import net.minecraft.tileentity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemTestEC extends Item implements IModelRegisterer
{
    public EnumActionResult func_180614_a(final EntityPlayer playerIn, final World worldIn, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        final TileEntity tile = worldIn.func_175625_s(pos);
        if (!worldIn.field_72995_K && tile != null) {
            playerIn.func_145747_a((ITextComponent)new TextComponentString(tile.func_189515_b(new NBTTagCompound()).toString()));
        }
        return EnumActionResult.PASS;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("minecraft:blaze_rod", "inventory"));
    }
}
