package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.potion.*;
import net.minecraft.util.math.*;
import net.minecraft.block.material.*;
import baubles.api.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemCharm extends ItemMRUGeneric implements IBauble, IModelRegisterer
{
    public String[] name;
    
    public ItemCharm() {
        this.name = new String[] { "Fire", "Water", "Earth", "Air", "Steam", "Magma", "Lightning", "Life", "Rain", "Dust", "None" };
        this.func_77656_e(0);
        this.field_77777_bU = 1;
        this.field_77789_bW = false;
        this.func_77627_a(true);
    }
    
    public void onWornTick(final ItemStack s, final EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            final EntityPlayer e = (EntityPlayer)entity;
            final int dam = s.func_77952_i();
            switch (dam) {
                case 0: {
                    this.updateFire(e, s);
                    break;
                }
                case 1: {
                    this.updateWater(e, s);
                    break;
                }
                case 2: {
                    this.updateEarth(e, s);
                    break;
                }
                case 3: {
                    this.updateAir(e, s);
                    break;
                }
                case 4: {
                    this.updateSteam(e, s);
                    break;
                }
                case 5: {
                    this.updateMagma(e, s);
                    break;
                }
                case 6: {
                    this.updateLightning(e, s);
                    break;
                }
                case 7: {
                    this.updateLife(e, s);
                    break;
                }
                case 8: {
                    this.updateRain(e, s);
                    break;
                }
                case 9: {
                    this.updateDust(e, s);
                    break;
                }
            }
        }
    }
    
    @Override
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int var4 = 0; var4 < 10; ++var4) {
                final ItemStack min = new ItemStack((Item)this, 1, var4);
                final ItemStack max = new ItemStack((Item)this, 1, var4);
                ((IMRUHandlerItem)min.getCapability((Capability)ItemCharm.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
                ((IMRUHandlerItem)max.getCapability((Capability)ItemCharm.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
                items.add((Object)min);
                items.add((Object)max);
            }
        }
    }
    
    public void updateFire(final EntityPlayer e, final ItemStack s) {
        if (e.func_70027_ad() && !e.func_70644_a(MobEffects.field_76426_n) && ECUtils.playerUseMRU(e, s, 50)) {
            e.func_70066_B();
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187541_bC, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }
    
    public void updateWater(final EntityPlayer e, final ItemStack s) {
        if (e.func_70086_ai() < 10 && e.func_70090_H() && ECUtils.playerUseMRU(e, s, 100)) {
            e.func_70050_g(100);
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_189109_ed, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }
    
    public void updateEarth(final EntityPlayer e, final ItemStack s) {
        if (e.field_70737_aN > 0 && !e.func_70644_a(MobEffects.field_76429_m) && ECUtils.playerUseMRU(e, s, 200)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 100, 0));
        }
    }
    
    public void updateAir(final EntityPlayer e, final ItemStack s) {
        if (e.func_70051_ag() && !e.func_70644_a(MobEffects.field_76424_c) && ECUtils.playerUseMRU(e, s, 10)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 20, 1));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_189109_ed, SoundCategory.PLAYERS, 1.0f, 0.01f);
        }
    }
    
    public void updateSteam(final EntityPlayer e, final ItemStack s) {
        if (e.func_110143_aJ() < 5.0f && !e.func_70644_a(MobEffects.field_76424_c) && ECUtils.playerUseMRU(e, s, 200)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 100, 5));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_189109_ed, SoundCategory.PLAYERS, 1.0f, 0.01f);
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187541_bC, SoundCategory.PLAYERS, 1.0f, 0.01f);
        }
    }
    
    public void updateMagma(final EntityPlayer e, final ItemStack s) {
        final Material m = e.func_130014_f_().func_180495_p(new BlockPos((int)e.field_70165_t - 1, (int)e.field_70163_u - 1, (int)e.field_70161_v)).func_185904_a();
        final Material m2 = e.func_130014_f_().func_180495_p(new BlockPos((int)e.field_70165_t - 1, (int)e.field_70163_u, (int)e.field_70161_v)).func_185904_a();
        if ((m == Material.field_151587_i || m2 == Material.field_151587_i) && !e.func_70644_a(MobEffects.field_76426_n) && ECUtils.playerUseMRU(e, s, 100)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76426_n, 100, 0));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187656_cX, SoundCategory.PLAYERS, 1.0f, 10.0f);
        }
    }
    
    public void updateLightning(final EntityPlayer e, final ItemStack s) {
        if (e.func_130014_f_().func_72911_I() && !e.func_70644_a(MobEffects.field_76420_g) && ECUtils.playerUseMRU(e, s, 100)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76426_n, 100, 0));
            e.func_70690_d(new PotionEffect(MobEffects.field_76439_r, 600, 0));
            e.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 100, 0));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187754_de, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }
    
    public void updateLife(final EntityPlayer e, final ItemStack s) {
        if (e.func_110143_aJ() < 5.0f && !e.func_70644_a(MobEffects.field_76428_l) && ECUtils.playerUseMRU(e, s, 200)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76428_l, 50, 1));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187604_bf, SoundCategory.PLAYERS, 1.0f, 10.0f);
        }
        if (e.func_110143_aJ() < 20.0f && !e.func_70644_a(MobEffects.field_76428_l) && ECUtils.playerUseMRU(e, s, 50)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76428_l, 50, 0));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187604_bf, SoundCategory.PLAYERS, 1.0f, 10.0f);
        }
    }
    
    public void updateRain(final EntityPlayer e, final ItemStack s) {
        if (e.func_130014_f_().func_72896_J() && !e.func_70644_a(MobEffects.field_76422_e) && ECUtils.playerUseMRU(e, s, 50)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76422_e, 100, 0));
            e.func_70690_d(new PotionEffect(MobEffects.field_76430_j, 100, 2));
            e.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 100, 0));
            e.func_130014_f_().func_184148_a(e, e.field_70165_t, e.field_70163_u, e.field_70161_v, SoundEvents.field_187806_ee, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }
    
    public void updateDust(final EntityPlayer e, final ItemStack s) {
        final Material m = e.func_130014_f_().func_180495_p(new BlockPos((int)e.field_70165_t - 1, (int)e.field_70163_u - 1, (int)e.field_70161_v)).func_185904_a();
        if (m == Material.field_151595_p && !e.func_70644_a(MobEffects.field_76429_m) && ECUtils.playerUseMRU(e, s, 100)) {
            e.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 100, 0));
            e.func_70690_d(new PotionEffect(MobEffects.field_76428_l, 100, 0));
        }
    }
    
    public String func_77653_i(final ItemStack stack) {
        return "Charm Of " + this.name[Math.min(stack.func_77952_i(), this.name.length - 1)];
    }
    
    public BaubleType getBaubleType(final ItemStack itemstack) {
        return BaubleType.AMULET;
    }
    
    public void registerModels() {
        for (int i = 0; i < this.name.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/charm", "type=" + this.name[i].toLowerCase(Locale.ENGLISH)));
        }
    }
}
