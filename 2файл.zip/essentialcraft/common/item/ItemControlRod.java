package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import essentialcraft.common.tile.*;
import net.minecraft.util.text.*;
import net.minecraft.inventory.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemControlRod extends Item implements IModelRegisterer
{
    public ItemControlRod() {
        this.field_77777_bU = 1;
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        final ItemStack stack = player.func_184586_b(hand);
        if (world.field_72995_K) {
            return EnumActionResult.SUCCESS;
        }
        if (stack.func_77978_p() == null) {
            final TileEntity tile = world.func_175625_s(pos);
            if (tile != null && tile instanceof TileMagicalMirror) {
                MiscUtils.getStackTag(stack).func_74783_a("pos", new int[] { pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p() });
                player.func_145747_a(new TextComponentString("Mirror linked to the wand!").func_150255_a(new Style().func_150238_a(TextFormatting.GREEN)));
                return EnumActionResult.SUCCESS;
            }
        }
        else {
            final TileEntity tile = world.func_175625_s(pos);
            if (tile != null && tile instanceof IInventory) {
                final int[] o = MiscUtils.getStackTag(stack).func_74759_k("pos");
                final float distance = new DummyDistance(new Coord3D((float)pos.func_177958_n(), (float)pos.func_177956_o(), (float)pos.func_177952_p()), new Coord3D((float)o[0], (float)o[1], (float)o[2])).getDistance();
                if (distance <= TileMagicalMirror.cfgMaxDistance) {
                    final TileEntity tile2 = world.func_175625_s(new BlockPos(o[0], o[1], o[2]));
                    if (tile2 != null && tile2 instanceof TileMagicalMirror) {
                        ((TileMagicalMirror)tile2).inventoryPos = pos;
                        player.func_145747_a(new TextComponentString("Mirror linked to the inventory!").func_150255_a(new Style().func_150238_a(TextFormatting.GREEN)));
                        stack.func_77982_d((NBTTagCompound)null);
                        return EnumActionResult.SUCCESS;
                    }
                }
            }
        }
        return EnumActionResult.PASS;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        if (stack.func_77978_p() != null) {
            final int[] coord = MiscUtils.getStackTag(stack).func_74759_k("pos");
            list.add("Currently linked to Mirror At:");
            list.add("x: " + coord[0]);
            list.add("y: " + coord[1]);
            list.add("z: " + coord[2]);
            list.add("dimension: " + MiscUtils.getStackTag(stack).func_74762_e("dim"));
        }
    }
    
    public static int[] getCoords(final ItemStack stack) {
        return MiscUtils.getStackTag(stack).func_74759_k("pos");
    }
    
    public boolean createTag(final ItemStack stack) {
        if (stack.func_77978_p() == null) {
            final NBTTagCompound tag = new NBTTagCompound();
            tag.func_74783_a("pos", new int[] { 0, 0, 0 });
            return true;
        }
        return false;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/controlrod", "inventory"));
    }
}
