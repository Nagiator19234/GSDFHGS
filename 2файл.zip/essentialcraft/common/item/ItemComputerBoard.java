package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import baubles.api.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemComputerBoard extends Item implements IBauble, IModelRegisterer
{
    public BaubleType getBaubleType(final ItemStack itemstack) {
        return BaubleType.BELT;
    }
    
    public void onWornTick(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public void onEquipped(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public void onUnequipped(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public boolean canEquip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public boolean canUnequip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/computer_board", "inventory"));
    }
}
