package essentialcraft.common.item;

import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import essentialcraft.api.*;
import net.minecraft.entity.player.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.math.*;
import DummyCore.Client.*;
import net.minecraft.item.*;

public class ItemShadeSlasher extends ItemSwordEC
{
    public ItemShadeSlasher() {
        super(ItemsCore.shade);
    }
    
    public void toggleActivity(final ItemStack is, final boolean b) {
        if (!is.func_190926_b()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(is);
            if (tag.func_74767_n("active") != b) {
                tag.func_74757_a("active", b);
            }
        }
    }
    
    public boolean onEntityItemUpdate(final EntityItem entityItem) {
        this.toggleActivity(entityItem.func_92059_d(), false);
        return super.onEntityItemUpdate(entityItem);
    }
    
    public void func_77663_a(final ItemStack sword, final World w, final Entity e, final int slotNum, final boolean held) {
        if (e instanceof EntityLivingBase && !w.field_72995_K && held) {
            ((EntityLivingBase)e).func_70690_d(new PotionEffect(MobEffects.field_76419_f, 3, 3, true, true));
        }
        if (e instanceof IShadeHandlerEntity) {
            this.toggleActivity(sword, true);
        }
        if (e instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)e;
            if (ECUtils.getData(p).getMatrixTypeID() == 4) {
                this.toggleActivity(sword, true);
            }
            else {
                this.toggleActivity(sword, false);
            }
        }
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mp = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (MiscUtils.getStackTag(stack).func_74767_n("active") && s == EntityEquipmentSlot.MAINHAND) {
            mp.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemShadeSlasher.field_111210_e, "Weapon modifier", 32.0, 0));
            mp.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemShadeSlasher.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return mp;
    }
    
    public boolean isItemTool(final ItemStack stack) {
        return true;
    }
    
    public boolean func_77644_a(final ItemStack weapon, final EntityLivingBase attacked, final EntityLivingBase attacker) {
        if (attacker instanceof IShadeHandlerEntity && attacked instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)attacked;
            ShadeUtils.attackPlayerWithShade(p, attacker, weapon);
        }
        if ((attacker instanceof IShadeHandlerEntity || (attacker instanceof EntityPlayer && ECUtils.getData((EntityPlayer)attacker).getMatrixTypeID() == 4)) && !attacker.func_130014_f_().field_72995_K) {
            if (attacker.func_130014_f_().field_73012_v.nextFloat() <= 0.6f) {
                final float i = 3.0f;
                attacked.func_70024_g((double)(-MathHelper.func_76126_a(attacker.field_70177_z * 3.1415927f / 180.0f) * i * 0.5f), 0.1, (double)(MathHelper.func_76134_b(attacker.field_70177_z * 3.1415927f / 180.0f) * i * 0.5f));
            }
            if (attacker.func_130014_f_().field_73012_v.nextFloat() <= 0.01f) {
                attacker.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 20, 20, true, true));
            }
        }
        return false;
    }
    
    @Override
    public void registerModels() {
        ModelUtils.setItemModelNBTActive((Item)this, new String[] { "essentialcraft:item/shadeslasher" });
    }
}
