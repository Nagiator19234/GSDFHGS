package essentialcraft.common.item;

import DummyCore.Client.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.world.biome.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemBiomeWand extends ItemMRUGeneric implements IModelRegisterer, IItemColor
{
    public ItemBiomeWand() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public static boolean isBiomeSaved(final ItemStack stack) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        return tag.func_74764_b("biome");
    }
    
    public static int getBiomeID(final ItemStack stack) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        if (isBiomeSaved(stack)) {
            return tag.func_74762_e("biome");
        }
        return -1;
    }
    
    public static void setBiomeID(final ItemStack stack, final int bID, final boolean remove) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        if (remove) {
            tag.func_82580_o("biome");
            return;
        }
        tag.func_74768_a("biome", bID);
        stack.func_77982_d(tag);
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack stack = player.func_184586_b(hand);
        if (!player.func_70093_af()) {
            if (isBiomeSaved(stack)) {
                if (ECUtils.playerUseMRU(player, stack, 100)) {
                    for (int x = pos.func_177958_n() - 1; x <= pos.func_177958_n() + 1; ++x) {
                        for (int z = pos.func_177952_p() - 1; z <= pos.func_177952_p() + 1; ++z) {
                            MiscUtils.changeBiome(world, Biome.func_150568_d(getBiomeID(stack)), x, z);
                            player.func_184609_a(hand);
                        }
                    }
                }
            }
            else {
                final int cbiome = Biome.func_185362_a(world.func_180494_b(pos));
                setBiomeID(stack, cbiome, false);
                player.func_184609_a(hand);
            }
        }
        else {
            setBiomeID(stack, 0, true);
            player.func_184609_a(hand);
        }
        return EnumActionResult.PASS;
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int par2) {
        if (isBiomeSaved(stack)) {
            return Biome.func_150568_d(getBiomeID(stack)).func_180625_c(BlockPos.field_177992_a);
        }
        return 16777215;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/biomewand", "inventory"));
    }
}
