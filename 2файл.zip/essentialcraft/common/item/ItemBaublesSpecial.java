package essentialcraft.common.item;

import DummyCore.Client.*;
import baubles.api.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import essentialcraft.api.*;
import essentialcraft.utils.cfg.*;
import essentialcraft.utils.common.*;
import java.lang.reflect.*;
import net.minecraft.potion.*;
import net.minecraft.init.*;
import net.minecraft.creativetab.*;
import net.minecraft.entity.monster.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.client.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.util.text.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemBaublesSpecial extends Item implements IBauble, IUBMRUGainModifyHandler, IWindResistHandler, IWindModifyHandler, IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public static String[] names;
    public BaubleType[] btALST;
    public int maxMRU;
    
    public ItemBaublesSpecial() {
        this.btALST = new BaubleType[] { BaubleType.AMULET, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.AMULET, BaubleType.AMULET, BaubleType.AMULET, BaubleType.BELT, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.BELT, BaubleType.AMULET, BaubleType.AMULET, BaubleType.BELT, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.AMULET, BaubleType.BELT, BaubleType.AMULET, BaubleType.BELT, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING, BaubleType.RING };
        this.maxMRU = 5000;
        this.func_77656_e(0);
        this.func_77627_a(true);
        this.func_77625_d(1);
    }
    
    public BaubleType getBaubleType(final ItemStack itemstack) {
        return (this.btALST.length > itemstack.func_77952_i()) ? this.btALST[itemstack.func_77952_i()] : BaubleType.RING;
    }
    
    public void onWornTick(final ItemStack itemstack, final EntityLivingBase player) {
        if (itemstack.func_77952_i() == 0 && player instanceof EntityPlayer) {
            int ubmrucu = ApiCore.getPlayerData((EntityPlayer)player).getPlayerUBMRU();
            if (ubmrucu >= 1 && ((IMRUHandlerItem)itemstack.getCapability((Capability)ItemBaublesSpecial.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() < this.maxMRU) {
                --ubmrucu;
                ((IMRUHandlerItem)itemstack.getCapability((Capability)ItemBaublesSpecial.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).addMRU(10, true);
                ApiCore.getPlayerData((EntityPlayer)player).modifyUBMRU(ubmrucu);
            }
        }
        if (itemstack.func_77952_i() == 17 && player instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)player;
            p.func_71020_j(0.01f);
            if (p.field_70173_aa % 10 == 0) {
                ApiCore.getPlayerData((EntityPlayer)player).modifyUBMRU(ApiCore.getPlayerData((EntityPlayer)player).getPlayerUBMRU() + 1);
            }
        }
        if (itemstack.func_77952_i() == 18 && player instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)player;
            if (p.func_130014_f_().field_73011_w != null && p.func_130014_f_().field_73011_w.getDimension() != Config.dimensionID) {
                RadiationManager.increasePlayerRadiation(p, -3);
            }
        }
        if (itemstack.func_77952_i() == 19 && player instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)player;
            if (p.func_130014_f_().field_73011_w != null && p.func_130014_f_().field_73011_w.getDimension() == Config.dimensionID && !p.field_71075_bZ.field_75098_d) {
                RadiationManager.increasePlayerRadiation(p, 1);
            }
        }
        if (itemstack.func_77952_i() == 7 && player instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)player;
            PotionEffect[] peArray = new PotionEffect[p.func_70651_bq().size()];
            final PotionEffect[] array;
            peArray = (array = p.func_70651_bq().toArray(peArray));
            for (final PotionEffect element : array) {
                final PotionEffect effect = p.func_70660_b(element.func_188419_a());
                if (isPotionBad(element.func_188419_a())) {
                    try {
                        final Class<PotionEffect> cz = PotionEffect.class;
                        final Field duration = cz.getDeclaredFields()[1];
                        duration.setAccessible(true);
                        int d = duration.getInt(effect);
                        duration.setInt(effect, --d);
                        duration.setAccessible(false);
                    }
                    catch (Exception e) {}
                }
            }
        }
    }
    
    public static boolean isPotionBad(final Potion p) {
        return p == MobEffects.field_82731_v || p == MobEffects.field_76436_u || p == MobEffects.field_76438_s || p == MobEffects.field_76440_q || p == MobEffects.field_76431_k || p == MobEffects.field_76419_f || p == MobEffects.field_76421_d || p == MobEffects.field_76437_t;
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < ItemBaublesSpecial.names.length - 1; ++i) {
                items.add((Object)new ItemStack((Item)this, 1, i));
            }
        }
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + "." + ItemBaublesSpecial.names[Math.min(stack.func_77952_i(), ItemBaublesSpecial.names.length - 1)];
    }
    
    public float getModifiedValue(float original, final ItemStack mod, final Random rng, final EntityPlayer p) {
        if (mod.func_77952_i() == 31) {
            return original * 2.0f;
        }
        if (mod.func_77952_i() == 29) {
            return original / 2.0f;
        }
        if (mod.func_77952_i() == 20) {
            final float divide = original / 100.0f * 25.0f;
            original -= divide;
            final double x = p.field_70165_t;
            final double y = p.field_70163_u;
            final double z = p.field_70161_v;
            final List<EntityMob> mobs = (List<EntityMob>)p.func_130014_f_().func_72872_a((Class)EntityMob.class, new AxisAlignedBB(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5).func_72314_b(6.0, 3.0, 6.0));
            for (final EntityMob mob : mobs) {
                mob.func_70097_a(DamageSource.func_76365_a(p), 3.0f);
            }
            return original;
        }
        if (mod.func_77952_i() == 1) {
            return original + rng.nextInt(100);
        }
        if (mod.func_77952_i() == 2) {
            final float divide2 = original / 10.0f;
            original -= divide2;
            final EntityXPOrb orb = new EntityXPOrb(p.func_130014_f_(), p.field_70165_t + MathUtils.randomFloat(rng), p.field_70163_u + MathUtils.randomFloat(rng), p.field_70161_v + MathUtils.randomFloat(rng), MathHelper.func_76141_d(divide2 / 4.0f));
            orb.field_70532_c = 100;
            if (!p.func_130014_f_().field_72995_K) {
                p.func_130014_f_().func_72838_d((Entity)orb);
            }
            return original;
        }
        if (mod.func_77952_i() == 4) {
            final float divide3 = original / 100.0f * 30.0f;
            original -= divide3;
            p.func_70691_i(divide3 / 30.0f);
            return original;
        }
        if (mod.func_77952_i() == 7) {
            return 0.0f;
        }
        return original;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, world, (List)list, par4);
        if (stack.func_77952_i() == 0) {
            list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemBaublesSpecial.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemBaublesSpecial.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
        }
        list.addAll(this.buildHelpList(I18n.func_74838_a("essentialcraft.txt.help.baubles." + stack.func_77952_i())));
    }
    
    public boolean resistWind(final EntityPlayer p, final ItemStack stk) {
        return stk.func_77952_i() == 3;
    }
    
    public float getModifier(final ItemStack stk, final EntityPlayer p) {
        if (stk.func_77952_i() == 5) {
            if (!p.func_130014_f_().field_72995_K && p.func_130014_f_().field_73012_v.nextFloat() <= 0.15f) {
                final ItemStack windKeeper = new ItemStack(ItemsCore.windKeeper);
                if (!p.field_71071_by.func_70441_a(windKeeper)) {
                    p.func_71019_a(windKeeper, true);
                }
                p.func_145747_a(new TextComponentString("The wind catcher catches some wind...").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_RED).func_150217_b(Boolean.valueOf(true))));
            }
            return -0.1f;
        }
        if (stk.func_77952_i() == 6) {
            return 0.3f;
        }
        return 0.0f;
    }
    
    public List<String> buildHelpList(String s) {
        final List<String> ret = new ArrayList<String>();
        String addedString = "";
        while (s.indexOf("|") != -1) {
            final int index = s.indexOf("|");
            final String charType = s.substring(index + 1, index + 2);
            s = s.substring(0, index) + s.substring(index + 2);
            if (charType.equals("n")) {
                final int nextIndex = s.indexOf("|n");
                if (nextIndex != -1) {
                    addedString = s.substring(0, index);
                    ret.add(addedString);
                    addedString = "";
                    s = s.substring(index);
                }
                else {
                    addedString = s.substring(0, index);
                    ret.add(addedString);
                    addedString = "";
                    s = s.substring(index);
                }
            }
            else if (charType.equals("r")) {
                s = s.substring(0, index) + TextFormatting.RESET + s.substring(index);
            }
            else {
                s = s.substring(0, index) + this.findByChar(charType.charAt(0)) + s.substring(index);
            }
        }
        addedString += s;
        ret.add(addedString);
        return ret;
    }
    
    public TextFormatting findByChar(final char c) {
        for (int i = 0; i < TextFormatting.values().length; ++i) {
            final TextFormatting ecf = TextFormatting.values()[i];
            final char w = ecf.toString().charAt(1);
            if (w == c) {
                return ecf;
            }
        }
        return TextFormatting.RESET;
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        if (stack.func_77952_i() == 0) {
            return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
        }
        return super.initCapabilities(stack, nbt);
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemBaublesSpecial.names.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/baublescore", "type=" + ItemBaublesSpecial.names[i].toLowerCase(Locale.ENGLISH)));
        }
    }
    
    static {
        ItemBaublesSpecial.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        ItemBaublesSpecial.names = new String[] { "portableMD", "ringOfStability", "ringOfExperience", "ringOfResistance", "lifePendant", "windCatcher", "windMagesTalisman", "doctorsBelt", "alphaRing", "betaRing", "gammaRing", "deltaRing", "epsilonBelt", "dzetaAmulet", "etaAmulet", "thetaBelt", "iotaRing", "kappaRing", "lambdaRing", "muRing", "nuAmulet", "xiBelt", "omicronAmulet", "piBelt", "rhoRing", "sigmaRing", "tauRing", "upsilonRing", "phiRing", "chiRing", "psiRing", "omegaRing", "unknown" };
    }
}
