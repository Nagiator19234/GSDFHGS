package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.*;
import essentialcraft.common.inventory.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemCraftingFrame extends Item implements IModelRegisterer
{
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand h) {
        p.openGui((Object)EssentialCraftCore.core, Config.guiID[0], w, 0, -2, 0);
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        final InventoryCraftingFrame inv = new InventoryCraftingFrame(stack);
        if (inv != null) {
            list.add("Current recipe:");
            for (int i = 0; i < 9; ++i) {
                final ItemStack stk = inv.func_70301_a(i);
                if (stk.func_190926_b()) {
                    list.add(i + ": Empty");
                }
                else {
                    list.add(i + ": " + stk.func_82833_r());
                }
            }
            final ItemStack stk2 = inv.func_70301_a(9);
            if (stk2.func_190926_b()) {
                list.add("Result: None");
            }
            else {
                list.add("Result: " + stk2.func_82833_r());
            }
        }
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        if (!isCurrentItem || !(entity instanceof EntityPlayer) || ((EntityPlayer)entity).field_71070_bA == null || !(((EntityPlayer)entity).field_71070_bA instanceof ContainerCraftingFrame)) {
            return;
        }
        final ContainerCraftingFrame c = (ContainerCraftingFrame)((EntityPlayer)entity).field_71070_bA;
        c.saveToNBT(itemStack);
    }
    
    public ItemCraftingFrame() {
        this.func_77625_d(1);
    }
    
    public boolean shouldCauseReequipAnimation(final ItemStack oldStack, final ItemStack newStack, final boolean slotChanged) {
        return !oldStack.func_77973_b().equals(newStack.func_77973_b());
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/craftingframe", "inventory"));
    }
}
