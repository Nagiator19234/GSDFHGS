package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import DummyCore.Utils.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.nbt.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemCollectedMonsterSpawner extends Item implements IModelRegisterer
{
    public EnumActionResult func_180614_a(final EntityPlayer placer, final World w, final BlockPos pos, final EnumHand hand, final EnumFacing side, final float vecX, final float vecY, final float vecZ) {
        final ItemStack stk = placer.func_184586_b(hand);
        final BlockPos nP = pos.func_177972_a(side);
        if (placer.func_175151_a(nP, side.func_176734_d(), stk)) {
            final NBTTagCompound tag = MiscUtils.getStackTag(stk);
            if (tag.func_74764_b("monsterSpawner") && Blocks.field_150474_ac.func_176196_c(w, nP)) {
                final NBTTagCompound spawnerTag = tag.func_74775_l("monsterSpawner");
                spawnerTag.func_74768_a("x", nP.func_177958_n());
                spawnerTag.func_74768_a("y", nP.func_177956_o());
                spawnerTag.func_74768_a("z", nP.func_177952_p());
                if (w.func_180501_a(nP, Blocks.field_150474_ac.func_176223_P(), 3)) {
                    final TileEntity tile = w.func_175625_s(nP);
                    if (tile != null) {
                        tile.func_145839_a(spawnerTag);
                    }
                    placer.func_184609_a(hand);
                    stk.func_190918_g(1);
                }
            }
        }
        return EnumActionResult.PASS;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stk, final World player, final List<String> lst, final ITooltipFlag flag) {
        super.func_77624_a(stk, player, (List)lst, flag);
        final NBTTagCompound tag = MiscUtils.getStackTag(stk);
        if (tag.func_74764_b("monsterSpawner")) {
            final NBTTagCompound spawnerTag = tag.func_74775_l("monsterSpawner");
            if (spawnerTag.func_74764_b("SpawnData")) {
                final NBTTagCompound dataTag = spawnerTag.func_74775_l("SpawnData");
                if (dataTag.func_74764_b("id")) {
                    String id = dataTag.func_74779_i("id");
                    id = ((EntityEntry)ForgeRegistries.ENTITIES.getValue(new ResourceLocation(id))).getName();
                    lst.add(I18n.func_74838_a(id));
                }
            }
            else if (spawnerTag.func_74764_b("SpawnPotentials")) {
                final NBTTagList nbttaglist = spawnerTag.func_150295_c("SpawnPotentials", 10);
                for (int i = 0; i < nbttaglist.func_74745_c(); ++i) {
                    final NBTTagCompound dataTag2 = nbttaglist.func_150305_b(i);
                    if (dataTag2.func_74764_b("id")) {
                        String id2 = dataTag2.func_74779_i("id");
                        id2 = ((EntityEntry)ForgeRegistries.ENTITIES.getValue(new ResourceLocation(id2))).getName();
                        final int weight = dataTag2.func_74762_e("Weight");
                        lst.add(I18n.func_74838_a(id2) + " (" + weight + ")");
                    }
                }
            }
        }
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/collectedspawner", "inventory"));
    }
}
