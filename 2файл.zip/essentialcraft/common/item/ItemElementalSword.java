package essentialcraft.common.item;

import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.entity.effect.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.nbt.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import com.google.common.base.*;
import java.util.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemElementalSword extends ItemSword implements IModelRegisterer
{
    public static String[] names;
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public static int maxMRU;
    static Random rand;
    
    public ItemElementalSword() {
        super(ItemsCore.elemental);
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
        this.func_77656_e(0);
    }
    
    public boolean func_77616_k(final ItemStack stack) {
        return true;
    }
    
    public boolean func_77644_a(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        if (attacker instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)attacker;
            final String attrib = getPrimaryAttribute(stack);
            if (attrib.contains("Fire") && ECUtils.playerUseMRU(player, stack, 50)) {
                target.func_70015_d(5);
            }
            if (attrib.contains("Water") && ECUtils.playerUseMRU(player, stack, 50)) {
                target.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 40, 0));
                target.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 40, 0));
            }
            if (attrib.contains("Earth") && ECUtils.playerUseMRU(player, stack, 50)) {
                target.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 40, 0));
                target.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 40, 0));
            }
            if (attrib.contains("Air") && ECUtils.playerUseMRU(player, stack, 50)) {
                attacker.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 50, 0));
                attacker.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 50, 0));
            }
            final List<String> embers = getEmberEffects(stack);
            if (ECUtils.playerUseMRU(player, stack, 50)) {
                if (embers.contains("Slowness")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 60, 0));
                }
                if (embers.contains("Greater Slowness")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 60, 1));
                }
                if (embers.contains("Poison")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 60, 0));
                }
                if (embers.contains("Greater Poison")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 60, 1));
                }
                if (embers.contains("Damage Self")) {
                    attacker.func_70097_a(DamageSource.func_76358_a(attacker), 2.0f);
                }
                if (embers.contains("Lightning")) {
                    final EntityLightningBolt bold = new EntityLightningBolt(target.func_130014_f_(), target.field_70165_t, target.field_70163_u, target.field_70161_v, false);
                    target.func_130014_f_().func_72942_c((Entity)bold);
                    if (!target.func_130014_f_().field_72995_K) {
                        target.func_130014_f_().func_72838_d((Entity)bold);
                    }
                    attacker.func_70690_d(new PotionEffect(MobEffects.field_76426_n, 60, 1));
                }
                if (embers.contains("Lifesteal")) {
                    attacker.func_70691_i(1.0f);
                }
                if (embers.contains("Greater Lifesteal")) {
                    attacker.func_70691_i(3.0f);
                }
                if (embers.contains("Weakness")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 60, 0));
                }
                if (embers.contains("Greater Weakness")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 60, 1));
                }
                if (embers.contains("Greater Damage Boost")) {
                    attacker.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 60, 1));
                }
                if (embers.contains("Damage Boost")) {
                    attacker.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 60, 0));
                }
                if (embers.contains("Greater Speed Boost")) {
                    attacker.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 60, 1));
                }
                if (embers.contains("Speed Boost")) {
                    attacker.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 60, 0));
                }
                if (embers.contains("Greater Hunger")) {
                    target.func_70690_d(new PotionEffect(MobEffects.field_76438_s, 60, 1));
                }
            }
        }
        return false;
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> multimap = (Multimap<String, AttributeModifier>)HashMultimap.create();
        final String attrib = getPrimaryAttribute(stack);
        int damage = 0;
        if (attrib.contains("Fire")) {
            damage += 7;
        }
        if (attrib.contains("Water")) {
            damage += 3;
        }
        if (attrib.contains("Earth")) {
            damage += 8;
        }
        if (attrib.contains("Air")) {
            damage += 8;
        }
        if (attrib.contains("Combined")) {
            damage += 5;
        }
        final List<String> embers = getEmberEffects(stack);
        for (int i = 0; i < 11; ++i) {
            if (embers.contains("Damage +" + i)) {
                damage += i;
            }
        }
        if (s == EntityEquipmentSlot.MAINHAND) {
            multimap.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemElementalSword.field_111210_e, "Weapon modifier", (double)damage, 0));
            multimap.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemElementalSword.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return multimap;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag tooltipFlag) {
        super.func_77624_a(stack, player, (List)list, tooltipFlag);
        if (stack.func_77978_p() != null && stack.func_77978_p().func_74764_b("ember_0")) {
            list.add("Primal: " + stack.func_77978_p().func_74779_i("primary"));
            list.add("Second: " + stack.func_77978_p().func_74779_i("secondary"));
            final List<String> l = getEmberEffects(stack);
            list.addAll(l);
        }
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemElementalSword.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemElementalSword.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs creativeTabs, final NonNullList<ItemStack> list) {
        if (this.func_194125_a(creativeTabs)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemElementalSword.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemElementalSword.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(ItemElementalSword.maxMRU);
            list.add((Object)min);
            list.add((Object)max);
        }
    }
    
    public static void setPrimaryAttribute(final ItemStack s) {
        final NBTTagCompound tag = s.func_77978_p();
        if (tag.func_74764_b("primary") || !tag.func_74764_b("focus_0")) {
            return;
        }
        String s_0 = tag.func_74779_i("focus_0");
        String s_2 = tag.func_74779_i("focus_1");
        String s_3 = tag.func_74779_i("focus_2");
        String s_4 = tag.func_74779_i("focus_3");
        s_0 = s_0.toLowerCase();
        s_2 = s_2.toLowerCase();
        s_3 = s_3.toLowerCase();
        s_4 = s_4.toLowerCase();
        int fire = 0;
        int water = 0;
        int earth = 0;
        int air = 0;
        if (s_0.toLowerCase().contains("ffocus")) {
            ++fire;
        }
        if (s_2.toLowerCase().contains("ffocus")) {
            ++fire;
        }
        if (s_3.toLowerCase().contains("ffocus")) {
            ++fire;
        }
        if (s_4.toLowerCase().contains("ffocus")) {
            ++fire;
        }
        if (s_0.toLowerCase().contains("wfocus")) {
            ++water;
        }
        if (s_2.toLowerCase().contains("wfocus")) {
            ++water;
        }
        if (s_3.toLowerCase().contains("wfocus")) {
            ++water;
        }
        if (s_4.toLowerCase().contains("wfocus")) {
            ++water;
        }
        if (s_0.toLowerCase().contains("efocus")) {
            ++earth;
        }
        if (s_2.toLowerCase().contains("efocus")) {
            ++earth;
        }
        if (s_3.toLowerCase().contains("efocus")) {
            ++earth;
        }
        if (s_4.toLowerCase().contains("efocus")) {
            ++earth;
        }
        if (s_0.toLowerCase().contains("afocus")) {
            ++air;
        }
        if (s_2.toLowerCase().contains("afocus")) {
            ++air;
        }
        if (s_3.toLowerCase().contains("afocus")) {
            ++air;
        }
        if (s_4.toLowerCase().contains("afocus")) {
            ++air;
        }
        if (fire > water && fire > earth && fire > air) {
            tag.func_74778_a("primary", "Fire");
        }
        else if (water > fire && water > earth && water > air) {
            tag.func_74778_a("primary", "Water");
        }
        else if (earth > water && earth > fire && earth > air) {
            tag.func_74778_a("primary", "Earth");
        }
        else if (air > water && air > earth && air > fire) {
            tag.func_74778_a("primary", "Air");
        }
        else {
            tag.func_74778_a("primary", "Combined");
        }
        final List<String> secondaryAttribs = new ArrayList<String>();
        if (fire != 0) {
            secondaryAttribs.add("Fire");
        }
        if (water != 0) {
            secondaryAttribs.add("Water");
        }
        if (earth != 0) {
            secondaryAttribs.add("Earth");
        }
        if (air != 0) {
            secondaryAttribs.add("Air");
        }
        if (!secondaryAttribs.isEmpty()) {
            tag.func_74778_a("secondary", (String)secondaryAttribs.get(ItemElementalSword.rand.nextInt(secondaryAttribs.size())));
        }
        else {
            tag.func_74778_a("secondary", getPrimaryAttribute(s));
        }
    }
    
    public static String getPrimaryAttribute(final ItemStack s) {
        if (s.func_77942_o()) {
            return s.func_77978_p().func_74779_i("primary");
        }
        return "combined";
    }
    
    public static String getSecondaryAttribute(final ItemStack s) {
        if (s.func_77942_o()) {
            return s.func_77978_p().func_74779_i("secondary");
        }
        return "combined";
    }
    
    public static String getA(final ItemStack s, final int pass) {
        String a = "";
        if (pass == 0) {
            a = getPrimaryAttribute(s);
        }
        else {
            a = getSecondaryAttribute(s);
        }
        if (a.contains("Fire")) {
            return "fire";
        }
        if (a.contains("Water")) {
            return "water";
        }
        if (a.contains("Earth")) {
            return "earth";
        }
        if (a.contains("Air")) {
            return "air";
        }
        return "normal";
    }
    
    public static List<String> getEmberEffects(final ItemStack stack) {
        final List<String> ret = new ArrayList<String>();
        if (stack.func_77942_o()) {
            String allEmbers = stack.func_77978_p().func_74779_i("ember_0") + " " + stack.func_77978_p().func_74779_i("ember_1") + " " + stack.func_77978_p().func_74779_i("ember_2") + " " + stack.func_77978_p().func_74779_i("ember_3");
            allEmbers = allEmbers.toLowerCase();
            if (allEmbers.contains("acid") && allEmbers.contains("chaos")) {
                ret.add("Damage +4");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("common")) {
                ret.add("Damage +2");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("corruption")) {
                ret.add("Slowness");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("crystal")) {
                ret.add("Damage +6");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("divine")) {
                ret.add("Poison");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("magic")) {
                ret.add("Greater Poison");
            }
            if (allEmbers.contains("acid") && allEmbers.contains("flame")) {
                ret.add("Damage +8");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("common")) {
                ret.add("Damage Self");
                ret.add("Damage +7");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("corruption")) {
                ret.add("Greater Slow");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("crystal")) {
                ret.add("Damage +5");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("divine")) {
                ret.add("Lightning");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("magic")) {
                ret.add("Damage +6");
            }
            if (allEmbers.contains("chaos") && allEmbers.contains("flame")) {
                ret.add("Damage +4");
            }
            if (allEmbers.contains("common") && allEmbers.contains("corruption")) {
                ret.add("Weakness");
            }
            if (allEmbers.contains("common") && allEmbers.contains("crystal")) {
                ret.add("Damage +3");
            }
            if (allEmbers.contains("common") && allEmbers.contains("divine")) {
                ret.add("Damage Boost");
            }
            if (allEmbers.contains("common") && allEmbers.contains("magic")) {
                ret.add("Speed Boost");
            }
            if (allEmbers.contains("common") && allEmbers.contains("flame")) {
                ret.add("Damage +11");
            }
            if (allEmbers.contains("corruption") && allEmbers.contains("crystal")) {
                ret.add("Lifesteal");
            }
            if (allEmbers.contains("corruption") && allEmbers.contains("divine")) {
                ret.add("Damage Self");
                ret.add("Greater Hunger");
            }
            if (allEmbers.contains("corruption") && allEmbers.contains("magic")) {
                ret.add("Greater Lifesteal");
            }
            if (allEmbers.contains("corruption") && allEmbers.contains("flame")) {
                ret.add("Damage +5");
            }
            if (allEmbers.contains("crystal") && allEmbers.contains("divine")) {
                ret.add("Damage +9");
            }
            if (allEmbers.contains("crystal") && allEmbers.contains("magic")) {
                ret.add("Damage +7");
            }
            if (allEmbers.contains("crystal") && allEmbers.contains("flame")) {
                ret.add("Greater Speed Boost");
            }
            if (allEmbers.contains("magic") && allEmbers.contains("flame")) {
                ret.add("Damage +6");
            }
        }
        return ret;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BLOCK;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 72000;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        player.func_184598_c(hand);
        final String attrib = getSecondaryAttribute(stack);
        if (attrib.contains("Fire") && ECUtils.playerUseMRU(player, stack, 50)) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76426_n, 50, 0));
            final List<EntityLivingBase> l = (List<EntityLivingBase>)world.func_175647_a((Class)EntityLivingBase.class, new AxisAlignedBB(player.field_70165_t - 2.0, player.field_70163_u - 1.0, player.field_70161_v - 2.0, player.field_70165_t + 2.0, player.field_70163_u + 3.0, player.field_70161_v + 2.0), Predicates.and(EntitySelectors.field_180132_d, e -> e != player));
            if (!l.isEmpty()) {
                for (final EntityLivingBase b : l) {
                    b.func_70015_d(2);
                }
            }
        }
        if (attrib.contains("Water") && ECUtils.playerUseMRU(player, stack, 50)) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76428_l, 40, 0));
        }
        if (attrib.contains("Earth") && ECUtils.playerUseMRU(player, stack, 50)) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, 40, 0));
        }
        if (attrib.contains("Air") && ECUtils.playerUseMRU(player, stack, 50)) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 30, 0));
            player.func_70690_d(new PotionEffect(MobEffects.field_76420_g, 30, 0));
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, ItemElementalSword.maxMRU);
    }
    
    @SideOnly(Side.CLIENT)
    public void registerModels() {
        ModelLoader.setCustomMeshDefinition((Item)this, (ItemMeshDefinition)new MeshDefinitionElementalSword());
        final ArrayList<ModelResourceLocation> locations = new ArrayList<ModelResourceLocation>();
        for (final String name : ItemElementalSword.names) {
            for (final String name2 : ItemElementalSword.names) {
                locations.add(new ModelResourceLocation("essentialcraft:item/elementalsword", "bottom=" + name + ",top=" + name2));
            }
        }
        ModelBakery.registerItemVariants((Item)this, (ResourceLocation[])locations.toArray((ResourceLocation[])new ModelResourceLocation[0]));
    }
    
    static {
        ItemElementalSword.names = new String[] { "fire", "water", "earth", "air", "normal" };
        ItemElementalSword.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        ItemElementalSword.maxMRU = 5000;
        ItemElementalSword.rand = new Random(8192L);
    }
    
    public static class MeshDefinitionElementalSword implements ItemMeshDefinition
    {
        public ModelResourceLocation func_178113_a(final ItemStack stack) {
            return new ModelResourceLocation("essentialcraft:item/elementalsword", "bottom=" + ItemElementalSword.getA(stack, 0) + ",top=" + ItemElementalSword.getA(stack, 1));
        }
    }
}
