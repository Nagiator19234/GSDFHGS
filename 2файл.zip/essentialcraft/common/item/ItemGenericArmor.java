package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.inventory.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemGenericArmor extends ItemArmor implements IItemColor, IModelRegisterer
{
    public ItemGenericArmor(final ItemArmor.ArmorMaterial material, final int renderIndex, final int type) {
        super(material, renderIndex, EntityEquipmentSlot.values()[5 - type]);
    }
    
    public ItemGenericArmor(final ItemArmor.ArmorMaterial material, final int renderIndex, final EntityEquipmentSlot type) {
        super(material, renderIndex, type);
    }
    
    public String getArmorTexture(final ItemStack itemstack, final Entity entity, final EntityEquipmentSlot slot, final String type) {
        if (type != null && type.equalsIgnoreCase("overlay")) {
            return "essentialcraft:textures/blocks/null.png";
        }
        switch (slot) {
            case LEGS: {
                return "essentialcraft:textures/special/armor/wind_layer_2.png";
            }
            default: {
                return "essentialcraft:textures/special/armor/wind_layer_1.png";
            }
        }
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int renderPass) {
        int j = this.func_82814_b(stack);
        if (j < 0) {
            j = 16777215;
        }
        return j;
    }
    
    public boolean func_82816_b_(final ItemStack stk) {
        return stk.func_77942_o() && stk.func_77978_p().func_150297_b("display", 10) && stk.func_77978_p().func_74775_l("display").func_150297_b("color", 3);
    }
    
    public int func_82814_b(final ItemStack stack) {
        final NBTTagCompound nbttagcompound = stack.func_77978_p();
        if (nbttagcompound == null) {
            return 16777215;
        }
        final NBTTagCompound nbttagcompound2 = nbttagcompound.func_74775_l("display");
        return (nbttagcompound2 == null) ? 16777215 : (nbttagcompound2.func_150297_b("color", 3) ? nbttagcompound2.func_74762_e("color") : 16777215);
    }
    
    public void func_82815_c(final ItemStack stk) {
        final NBTTagCompound nbttagcompound = stk.func_77978_p();
        if (nbttagcompound != null) {
            final NBTTagCompound nbttagcompound2 = nbttagcompound.func_74775_l("display");
            if (nbttagcompound2.func_74764_b("color")) {
                nbttagcompound2.func_82580_o("color");
            }
        }
    }
    
    public void func_82813_b(final ItemStack stk, final int newColor) {
        NBTTagCompound nbttagcompound = stk.func_77978_p();
        if (nbttagcompound == null) {
            nbttagcompound = new NBTTagCompound();
            stk.func_77982_d(nbttagcompound);
        }
        final NBTTagCompound nbttagcompound2 = nbttagcompound.func_74775_l("display");
        if (!nbttagcompound.func_150297_b("display", 10)) {
            nbttagcompound.func_74782_a("display", (NBTBase)nbttagcompound2);
        }
        nbttagcompound2.func_74768_a("color", newColor);
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot equipmentSlot, final ItemStack s) {
        final Multimap<String, AttributeModifier> mods = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (this == ItemsCore.wind_chestplate && equipmentSlot == EntityEquipmentSlot.CHEST) {
            mods.put((Object)SharedMonsterAttributes.field_111263_d.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "mSpeed", 0.075, 0));
        }
        return mods;
    }
    
    public boolean hasOverlay(final ItemStack stack) {
        return this.func_82816_b_(stack);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
