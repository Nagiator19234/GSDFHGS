package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemPickaxeEC extends ItemPickaxe implements IModelRegisterer
{
    public ItemPickaxeEC(final Item.ToolMaterial material) {
        super(material);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
