package essentialcraft.common.item;

import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import essentialcraft.common.block.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.relauncher.*;

public class ItemBlockFancy extends ItemBlock
{
    public ItemBlockFancy(final Block block) {
        super(block);
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public int func_77647_b(final int damage) {
        return damage;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> tooltip, final ITooltipFlag isAdvanced) {
        super.func_77624_a(stack, player, (List)tooltip, isAdvanced);
        tooltip.add(I18n.func_74838_a("essentialcraft.desc.fancy." + BlockFancy.overlays[stack.func_77952_i()]));
    }
}
