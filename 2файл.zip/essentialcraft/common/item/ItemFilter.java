package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.inventory.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.*;
import essentialcraft.common.inventory.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemFilter extends Item implements IModelRegisterer
{
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand hand) {
        p.openGui((Object)EssentialCraftCore.core, Config.guiID[0], w, 0, -1, 0);
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
    }
    
    protected int containerMatchesItem(final Container openContainer) {
        return 0;
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int var4 = 0; var4 < 4; ++var4) {
                final ItemStack min = new ItemStack((Item)this, 1, var4);
                items.add((Object)min);
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        if (stack.func_77952_i() == 1 || stack.func_77952_i() == 3) {
            list.add(I18n.func_74838_a("essentialcraft.txt.desc.advanced"));
        }
        if (stack.func_77952_i() > 1) {
            list.add(I18n.func_74838_a("essentialcraft.txt.desc.blacklist"));
        }
        else {
            list.add(I18n.func_74838_a("essentialcraft.txt.desc.whitelist"));
        }
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        if (world.field_72995_K || !isCurrentItem || !(entity instanceof EntityPlayer)) {
            return;
        }
        if (((EntityPlayer)entity).field_71070_bA == null || !(((EntityPlayer)entity).field_71070_bA instanceof ContainerFilter)) {
            return;
        }
        final int containerType = this.containerMatchesItem(((EntityPlayer)entity).field_71070_bA);
        if (containerType == 0) {
            final ContainerFilter c = (ContainerFilter)((EntityPlayer)entity).field_71070_bA;
            c.saveToNBT(itemStack);
        }
    }
    
    public ItemFilter() {
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/itemfilter", "type=whitelist"));
        ModelLoader.setCustomModelResourceLocation((Item)this, 1, new ModelResourceLocation("essentialcraft:item/itemfilter", "type=whitelist_advanced"));
        ModelLoader.setCustomModelResourceLocation((Item)this, 2, new ModelResourceLocation("essentialcraft:item/itemfilter", "type=blacklist"));
        ModelLoader.setCustomModelResourceLocation((Item)this, 3, new ModelResourceLocation("essentialcraft:item/itemfilter", "type=blacklist_advanced"));
    }
}
