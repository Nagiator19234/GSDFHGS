package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import essentialcraft.utils.common.*;
import essentialcraft.common.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemOrbitalRemote extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemOrbitalRemote() {
        this.setMaxMRU(20000);
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        super.func_77663_a(itemStack, world, entity, indexInInventory, isCurrentItem);
        if (!(entity instanceof EntityPlayer) || entity.field_70173_aa % 20 == 0) {}
    }
    
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand hand) {
        final ItemStack stk = p.func_184586_b(hand);
        final float f = 1.0f;
        final double d0 = p.field_70169_q + (p.field_70165_t - p.field_70169_q) * f;
        final double d2 = p.field_70167_r + (p.field_70163_u - p.field_70167_r) * f + p.func_70047_e();
        final double d3 = p.field_70166_s + (p.field_70161_v - p.field_70166_s) * f;
        final Vec3d lookVec = new Vec3d(d0, d2, d3);
        final float f2 = p.field_70127_C + (p.field_70125_A - p.field_70127_C);
        final float f3 = p.field_70126_B + (p.field_70177_z - p.field_70126_B);
        final float f4 = MathHelper.func_76134_b(-f3 * 0.017453292f - 3.1415927f);
        final float f5 = MathHelper.func_76126_a(-f3 * 0.017453292f - 3.1415927f);
        final float f6 = -MathHelper.func_76134_b(-f2 * 0.017453292f);
        final float f7 = MathHelper.func_76126_a(-f2 * 0.017453292f);
        final float f8 = f5 * f6;
        final float f9 = f4 * f6;
        final double d4 = 32.0;
        final Vec3d distanced = lookVec.func_72441_c(f8 * d4, f7 * d4, f9 * d4);
        final RayTraceResult mop = p.func_130014_f_().func_147447_a(lookVec, distanced, true, false, false);
        if (mop != null && mop.field_72313_a == RayTraceResult.Type.BLOCK && ECUtils.playerUseMRU(p, stk, 10000)) {
            final EntityOrbitalStrike eos = new EntityOrbitalStrike(w, mop.func_178782_a().func_177958_n() + 0.5, mop.func_178782_a().func_177956_o() + 1, mop.func_178782_a().func_177952_p() + 0.5, 128.0, 3.0, (EntityLivingBase)p);
            if (!w.field_72995_K) {
                w.func_72838_d((Entity)eos);
            }
        }
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/orbitalremote", "inventory"));
    }
}
