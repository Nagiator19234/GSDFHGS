package essentialcraft.common.item;

import DummyCore.Client.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.text.*;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import essentialcraft.utils.common.*;
import net.minecraftforge.common.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import DummyCore.Utils.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.*;

public class ItemMagicalBuilder extends ItemMRUGeneric implements IModelRegisterer
{
    @SideOnly(Side.CLIENT)
    @Override
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        switch (stack.func_77952_i()) {
            case 0: {
                list.add(I18n.func_74838_a("essentialcraft.txt.fillMode.normal"));
                break;
            }
            case 1: {
                list.add(I18n.func_74838_a("essentialcraft.txt.fillMode.air"));
                break;
            }
            case 2: {
                list.add(I18n.func_74838_a("essentialcraft.txt.fillMode.replaceSelected"));
                break;
            }
            case 3: {
                list.add(I18n.func_74838_a("essentialcraft.txt.fillMode.replaceButSelected"));
                break;
            }
            case 4: {
                list.add(I18n.func_74838_a("essentialcraft.txt.fillMode.replaceAll"));
                break;
            }
        }
        if (this.hasFirstPoint(stack)) {
            list.add(I18n.func_74838_a("essentialcraft.txt.p1") + "| X:" + this.getFirstPoint(stack).x + ", Y:" + this.getFirstPoint(stack).y + ", Z:" + this.getFirstPoint(stack).z);
        }
        if (this.hasSecondPoint(stack)) {
            list.add(I18n.func_74838_a("essentialcraft.txt.p2") + "| X:" + this.getSecondPoint(stack).x + ", Y:" + this.getSecondPoint(stack).y + ", Z:" + this.getSecondPoint(stack).z);
        }
        if (this.hasStoredBlock(stack) && !this.retrieveStackFromNBT(stack).func_190926_b()) {
            list.add(I18n.func_74838_a("essentialcraft.txt.storedStack") + ": " + this.retrieveStackFromNBT(stack).func_82833_r());
        }
        list.add(" ");
        super.func_77624_a(stack, player, list, par4);
    }
    
    @Override
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 5; ++i) {
                final ItemStack min = new ItemStack((Item)this, 1, i);
                final ItemStack max = new ItemStack((Item)this, 1, i);
                ((IMRUHandlerItem)min.getCapability((Capability)ItemMagicalBuilder.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
                ((IMRUHandlerItem)max.getCapability((Capability)ItemMagicalBuilder.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
                items.add((Object)min);
                items.add((Object)max);
            }
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand hand) {
        final ItemStack is = p.func_184586_b(hand);
        final RayTraceResult mop = this.func_77621_a(w, p, p.field_71075_bZ.field_75098_d);
        if (mop != null && mop.field_72313_a == RayTraceResult.Type.BLOCK) {
            if (!p.func_70093_af()) {
                final boolean hasPos1 = this.hasFirstPoint(is);
                final boolean hasPos2 = this.hasSecondPoint(is);
                if (!hasPos1) {
                    this.setFirstPoint(is, mop.func_178782_a().func_177958_n(), mop.func_178782_a().func_177956_o(), mop.func_178782_a().func_177952_p());
                    if (p.func_130014_f_().field_72995_K) {
                        p.func_145747_a(new TextComponentString("[Magical Builder] First position: " + mop.func_178782_a().func_177958_n() + ", " + mop.func_178782_a().func_177956_o() + ", " + mop.func_178782_a().func_177952_p()).func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                    }
                    return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
                }
                if (!hasPos2) {
                    final Coord3D first = this.getFirstPoint(is);
                    final Coord3D second = new Coord3D((float)mop.func_178782_a().func_177958_n(), (float)mop.func_178782_a().func_177956_o(), (float)mop.func_178782_a().func_177952_p());
                    final DummyDistance dist = new DummyDistance(first, second);
                    if (dist.getDistance() > 48.0f) {
                        if (p.func_130014_f_().field_72995_K) {
                            p.func_145747_a(new TextComponentString("[Magical Builder]The distance between points (" + dist.getDistance() + ") is too large, max: 48!").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                        }
                        return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
                    }
                    this.setSecondPoint(is, mop.func_178782_a().func_177958_n(), mop.func_178782_a().func_177956_o(), mop.func_178782_a().func_177952_p());
                    if (p.func_130014_f_().field_72995_K) {
                        p.func_145747_a(new TextComponentString("[Magical Builder] Second position: " + mop.func_178782_a().func_177958_n() + ", " + mop.func_178782_a().func_177956_o() + ", " + mop.func_178782_a().func_177952_p()).func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                    }
                    return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
                }
                else if (hasPos1 && hasPos2 && p.func_130014_f_().field_72995_K) {
                    p.func_145747_a(new TextComponentString("[Magical Builder]Both points already set! Shift-rightclick air to reset!").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                }
            }
            else if (this.setStoredStack(is, w, mop.func_178782_a().func_177958_n(), mop.func_178782_a().func_177956_o(), mop.func_178782_a().func_177952_p()) && !this.retrieveStackFromNBT(is).func_190926_b() && p.func_130014_f_().field_72995_K) {
                p.func_145747_a(new TextComponentString("[Magical Builder]Set the block to: " + this.retrieveStackFromNBT(is).func_82833_r()).func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
            }
        }
        else if (mop == null) {
            if (p.func_70093_af()) {
                this.resetPoints(is);
                if (p.func_130014_f_().field_72995_K) {
                    p.func_145747_a(new TextComponentString("[Magical Builder]Both points reseted!").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                }
            }
            else if (this.hasFirstPoint(is) && this.hasSecondPoint(is) && ((this.hasStoredBlock(is) && !this.retrieveStackFromNBT(is).func_190926_b()) || is.func_77952_i() == 1)) {
                final int setted = this.setAreaToBlock(p, is);
                if (p.func_130014_f_().field_72995_K) {
                    p.func_145747_a(new TextComponentString("[Magical Builder]Filled selected area! " + setted + " blocks got replaced!").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_PURPLE)));
                }
            }
        }
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, hand);
    }
    
    public Coord3D getFirstPoint(final ItemStack is) {
        return new Coord3D((float)MiscUtils.getStackTag(is).func_74762_e("p1_x"), (float)MiscUtils.getStackTag(is).func_74762_e("p1_y"), (float)MiscUtils.getStackTag(is).func_74762_e("p1_z"));
    }
    
    public Coord3D getSecondPoint(final ItemStack is) {
        return new Coord3D((float)MiscUtils.getStackTag(is).func_74762_e("p2_x"), (float)MiscUtils.getStackTag(is).func_74762_e("p2_y"), (float)MiscUtils.getStackTag(is).func_74762_e("p2_z"));
    }
    
    public boolean resetPoints(final ItemStack is) {
        final NBTTagCompound tag = MiscUtils.getStackTag(is);
        if (!tag.func_74764_b("p1_x") && !tag.func_74764_b("p2_x")) {
            return false;
        }
        tag.func_82580_o("p1_x");
        tag.func_82580_o("p1_y");
        tag.func_82580_o("p1_z");
        tag.func_82580_o("p2_x");
        tag.func_82580_o("p2_y");
        tag.func_82580_o("p2_z");
        return true;
    }
    
    public boolean hasFirstPoint(final ItemStack is) {
        return MiscUtils.getStackTag(is).func_74764_b("p1_x");
    }
    
    public boolean hasSecondPoint(final ItemStack is) {
        return MiscUtils.getStackTag(is).func_74764_b("p2_x");
    }
    
    public void setFirstPoint(final ItemStack is, final int x, final int y, final int z) {
        MiscUtils.getStackTag(is).func_74768_a("p1_x", x);
        MiscUtils.getStackTag(is).func_74768_a("p1_y", y);
        MiscUtils.getStackTag(is).func_74768_a("p1_z", z);
    }
    
    public void setSecondPoint(final ItemStack is, final int x, final int y, final int z) {
        MiscUtils.getStackTag(is).func_74768_a("p2_x", x);
        MiscUtils.getStackTag(is).func_74768_a("p2_y", y);
        MiscUtils.getStackTag(is).func_74768_a("p2_z", z);
    }
    
    public boolean hasStoredBlock(final ItemStack is) {
        return MiscUtils.getStackTag(is).func_74764_b("storedStackTag");
    }
    
    public ItemStack retrieveStackFromNBT(final ItemStack is) {
        if (!this.hasStoredBlock(is)) {
            return ItemStack.field_190927_a;
        }
        return new ItemStack(MiscUtils.getStackTag(is).func_74775_l("storedStackTag"));
    }
    
    public void nullifyStoredStack(final ItemStack is) {
        MiscUtils.getStackTag(is).func_82580_o("storedStackTag");
    }
    
    public boolean setStoredStack(final ItemStack is, final World w, final int x, final int y, final int z) {
        if (!w.func_175623_d(new BlockPos(x, y, z))) {
            final ItemStack stored = new ItemStack(w.func_180495_p(new BlockPos(x, y, z)).func_177230_c(), 1, w.func_180495_p(new BlockPos(x, y, z)).func_177230_c().func_176201_c(w.func_180495_p(new BlockPos(x, y, z))));
            final NBTTagCompound tag = new NBTTagCompound();
            stored.func_77955_b(tag);
            MiscUtils.getStackTag(is).func_74782_a("storedStackTag", (NBTBase)tag);
            return true;
        }
        return false;
    }
    
    public int findPlayerISSlot(final EntityPlayer e, final ItemStack is) {
        if (is.func_190926_b()) {
            return -1;
        }
        if (e.field_71075_bZ.field_75098_d) {
            return Integer.MAX_VALUE;
        }
        for (int i = 0; i < e.field_71071_by.func_70302_i_(); ++i) {
            final ItemStack stk = e.field_71071_by.func_70301_a(i);
            if (!stk.func_190926_b() && stk.func_77969_a(is)) {
                return i;
            }
        }
        return -1;
    }
    
    public int decreasePlayerStackInSlot(final EntityPlayer e, final ItemStack is, final int slot) {
        if (e.field_71075_bZ.field_75098_d) {
            return Integer.MAX_VALUE;
        }
        e.field_71071_by.func_70298_a(slot, 1);
        if (e.field_71071_by.func_70301_a(slot).func_190926_b() || e.field_71071_by.func_70301_a(slot).func_190916_E() <= 0) {
            return this.findPlayerISSlot(e, is);
        }
        return slot;
    }
    
    public int setAreaToBlock(final EntityPlayer e, final ItemStack is) {
        final Coord3D start = this.getFirstPoint(is);
        final Coord3D end = this.getSecondPoint(is);
        final int diffX = MathHelper.func_76128_c(MathUtils.module((double)(end.x - start.x)));
        final int diffY = MathHelper.func_76128_c(MathUtils.module((double)(end.y - start.y)));
        final int diffZ = MathHelper.func_76128_c(MathUtils.module((double)(end.z - start.z)));
        final ItemStack setTo = this.retrieveStackFromNBT(is);
        int slotNum = this.findPlayerISSlot(e, setTo);
        int itemsSet = 0;
        if (is.func_77952_i() == 1) {
            slotNum = Integer.MAX_VALUE;
        }
        if (is.func_77952_i() == 2 || is.func_77952_i() == 3) {
            slotNum = ((this.hasStoredBlock(is) && !setTo.func_190926_b()) ? Integer.MAX_VALUE : -1);
        }
        if (slotNum != -1) {
            for (int x = 0; x <= diffX; ++x) {
                int dx = x;
                if (start.x >= end.x) {
                    dx = MathHelper.func_76141_d(end.x + x);
                }
                else {
                    dx = MathHelper.func_76141_d(start.x + x);
                }
                for (int y = 0; y <= diffY; ++y) {
                    int dy = y;
                    if (start.y >= end.y) {
                        dy = MathHelper.func_76141_d(end.y + y);
                    }
                    else {
                        dy = MathHelper.func_76141_d(start.y + y);
                    }
                    for (int z = 0; z <= diffZ; ++z) {
                        int dz = z;
                        if (start.z >= end.z) {
                            dz = (int)(end.z + z);
                        }
                        else {
                            dz = (int)(start.z + z);
                        }
                        final ItemStack settedTo = setTo.func_190926_b() ? ItemStack.field_190927_a : setTo.func_77946_l();
                        final BlockPos dp = new BlockPos(dx, dy, dz);
                        if (is.func_77952_i() == 0 && e.func_130014_f_().func_175623_d(dp)) {
                            if (!e.func_175151_a(dp, EnumFacing.DOWN, settedTo)) {
                                continue;
                            }
                            if (!ECUtils.playerUseMRU(e, is, 25)) {
                                return itemsSet;
                            }
                            slotNum = this.decreasePlayerStackInSlot(e, settedTo, slotNum);
                            if (ForgeHooks.onPlaceItemIntoWorld(settedTo, e, e.func_130014_f_(), dp, EnumFacing.DOWN, 0.0f, 0.0f, 0.0f, EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                ++itemsSet;
                            }
                            else {
                                settedTo.func_190920_e(1);
                                if (!e.field_71071_by.func_70441_a(settedTo)) {
                                    e.func_71019_a(settedTo, false);
                                }
                            }
                            if (slotNum == -1) {
                                return itemsSet;
                            }
                        }
                        if (is.func_77952_i() == 1) {
                            if (!e.func_175151_a(dp, EnumFacing.DOWN, settedTo)) {
                                continue;
                            }
                            if (!ECUtils.playerUseMRU(e, is, 250)) {
                                return itemsSet;
                            }
                            if (e.func_130014_f_().func_180495_p(dp).func_185887_b(e.func_130014_f_(), dp) >= 0.0f && !e.func_130014_f_().field_72995_K) {
                                GameType type = GameType.SURVIVAL;
                                if (e.field_71075_bZ.field_75098_d) {
                                    type = GameType.CREATIVE;
                                }
                                if (!e.field_71075_bZ.field_75099_e) {
                                    type = GameType.ADVENTURE;
                                }
                                final int be = ForgeHooks.onBlockBreakEvent(e.func_130014_f_(), type, (EntityPlayerMP)e, dp);
                                if (be != -1) {
                                    e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176226_b(e.func_130014_f_(), dp, e.func_130014_f_().func_180495_p(new BlockPos(dx, dy, dz)), 0);
                                    e.func_130014_f_().func_175698_g(dp);
                                    ++itemsSet;
                                }
                            }
                        }
                        if (is.func_77952_i() == 2) {
                            if (!e.func_175151_a(dp, EnumFacing.DOWN, settedTo)) {
                                continue;
                            }
                            if (e.func_130014_f_().func_180495_p(dp).func_185887_b(e.func_130014_f_(), dp) >= 0.0f && !e.func_130014_f_().field_72995_K) {
                                final ItemStack worldStack = new ItemStack(e.func_130014_f_().func_180495_p(dp).func_177230_c(), 1, e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176201_c(e.func_130014_f_().func_180495_p(dp)));
                                if (!worldStack.func_190926_b() && setTo.func_77969_a(worldStack)) {
                                    if (!ECUtils.playerUseMRU(e, is, 250)) {
                                        return itemsSet;
                                    }
                                    GameType type2 = GameType.SURVIVAL;
                                    if (e.field_71075_bZ.field_75098_d) {
                                        type2 = GameType.CREATIVE;
                                    }
                                    if (!e.field_71075_bZ.field_75099_e) {
                                        type2 = GameType.ADVENTURE;
                                    }
                                    final int be2 = ForgeHooks.onBlockBreakEvent(e.func_130014_f_(), type2, (EntityPlayerMP)e, dp);
                                    if (be2 != -1) {
                                        e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176226_b(e.func_130014_f_(), dp, e.func_130014_f_().func_180495_p(dp), 0);
                                        e.func_130014_f_().func_175698_g(dp);
                                        ++itemsSet;
                                    }
                                }
                            }
                        }
                        if (is.func_77952_i() == 3) {
                            if (!e.func_175151_a(dp, EnumFacing.DOWN, settedTo)) {
                                continue;
                            }
                            if (e.func_130014_f_().func_180495_p(dp).func_185887_b(e.func_130014_f_(), dp) >= 0.0f && !e.func_130014_f_().field_72995_K) {
                                final ItemStack worldStack = new ItemStack(e.func_130014_f_().func_180495_p(dp).func_177230_c(), 1, e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176201_c(e.func_130014_f_().func_180495_p(dp)));
                                if (!worldStack.func_190926_b() && !setTo.func_77969_a(worldStack)) {
                                    if (!ECUtils.playerUseMRU(e, is, 250)) {
                                        return itemsSet;
                                    }
                                    GameType type2 = GameType.SURVIVAL;
                                    if (e.field_71075_bZ.field_75098_d) {
                                        type2 = GameType.CREATIVE;
                                    }
                                    if (!e.field_71075_bZ.field_75099_e) {
                                        type2 = GameType.ADVENTURE;
                                    }
                                    final int be2 = ForgeHooks.onBlockBreakEvent(e.func_130014_f_(), type2, (EntityPlayerMP)e, dp);
                                    if (be2 != -1) {
                                        e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176226_b(e.func_130014_f_(), dp, e.func_130014_f_().func_180495_p(dp), 0);
                                        e.func_130014_f_().func_175698_g(dp);
                                        ++itemsSet;
                                    }
                                }
                            }
                        }
                        if (is.func_77952_i() == 4) {
                            if (e.func_175151_a(dp, EnumFacing.DOWN, settedTo)) {
                                if (e.func_130014_f_().func_175623_d(dp)) {
                                    if (!ECUtils.playerUseMRU(e, is, 25)) {
                                        return itemsSet;
                                    }
                                    slotNum = this.decreasePlayerStackInSlot(e, setTo, slotNum);
                                    if (ForgeHooks.onPlaceItemIntoWorld(settedTo, e, e.func_130014_f_(), dp, EnumFacing.DOWN, 0.0f, 0.0f, 0.0f, EnumHand.MAIN_HAND) == EnumActionResult.SUCCESS) {
                                        ++itemsSet;
                                    }
                                    else {
                                        settedTo.func_190920_e(1);
                                        if (!e.field_71071_by.func_70441_a(settedTo)) {
                                            e.func_71019_a(settedTo, false);
                                        }
                                    }
                                    if (slotNum == -1) {
                                        return itemsSet;
                                    }
                                }
                                else if (e.func_130014_f_().func_180495_p(dp).func_185887_b(e.func_130014_f_(), dp) >= 0.0f && !e.func_130014_f_().field_72995_K) {
                                    slotNum = this.decreasePlayerStackInSlot(e, setTo, slotNum);
                                    if (!ECUtils.playerUseMRU(e, is, 300)) {
                                        return itemsSet;
                                    }
                                    GameType type = GameType.SURVIVAL;
                                    if (e.field_71075_bZ.field_75098_d) {
                                        type = GameType.CREATIVE;
                                    }
                                    if (!e.field_71075_bZ.field_75099_e) {
                                        type = GameType.ADVENTURE;
                                    }
                                    final int be = ForgeHooks.onBlockBreakEvent(e.func_130014_f_(), type, (EntityPlayerMP)e, dp);
                                    if (be != -1) {
                                        e.func_130014_f_().func_180495_p(dp).func_177230_c().func_176226_b(e.func_130014_f_(), dp, e.func_130014_f_().func_180495_p(dp), 0);
                                        e.func_130014_f_().func_180501_a(dp, Block.func_149634_a(setTo.func_77973_b()).func_176203_a(setTo.func_77952_i()), 3);
                                        ++itemsSet;
                                    }
                                    if (slotNum == -1) {
                                        return itemsSet;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return itemsSet;
    }
    
    public void registerModels() {
        for (int i = 0; i < 5; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/magicalbuilder", "inventory"));
        }
        MiscUtils.addItemOverlayElement((Item)this, (IItemOverlayElement)ItemOverlayMagicalBuilder.INSTANCE);
    }
    
    public static class ItemOverlayMagicalBuilder implements IItemOverlayElement
    {
        public static final ItemOverlayMagicalBuilder INSTANCE;
        
        public void renderItemOverlayIntoGUI(final FontRenderer fr, final ItemStack item, final int x, final int y, final String text) {
            GlStateManager.func_179097_i();
            final ItemMagicalBuilder builder = (ItemMagicalBuilder)item.func_77973_b();
            if (builder.hasStoredBlock(item) && !builder.retrieveStackFromNBT(item).func_190926_b()) {
                final ItemStack rendered = builder.retrieveStackFromNBT(item);
                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b((float)(8 + x), (float)(8 + y), 0.0f);
                GlStateManager.func_179152_a(0.5f, 0.5f, 0.5f);
                Minecraft.func_71410_x().func_175599_af().func_175042_a(rendered, 0, 0);
                GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
                GlStateManager.func_179121_F();
            }
            GlStateManager.func_179126_j();
        }
        
        static {
            INSTANCE = new ItemOverlayMagicalBuilder();
        }
    }
}
