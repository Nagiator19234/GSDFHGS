package essentialcraft.common.item;

import thaumcraft.api.items.*;
import net.minecraftforge.common.*;
import DummyCore.Client.*;
import DummyCore.Utils.*;
import essentialcraft.api.*;
import net.minecraft.inventory.*;
import net.minecraft.world.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import java.util.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import essentialcraft.common.mod.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

@DCASMCheck
@ExistenceCheck(classPath = { "thaumcraft.api.items.IVisDiscountGear", "thaumcraft.api.items.IRevealer", "thaumcraft.api.items.IGoggles" })
public class ItemArmorEC extends ItemArmor implements IVisDiscountGear, IRevealer, IGoggles, ISpecialArmor, IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public String armorTexture;
    public String desc;
    public int aType;
    public ItemArmor.ArmorMaterial mat;
    public int maxMRU;
    public static int[][] discount;
    
    public ItemArmorEC(final ItemArmor.ArmorMaterial material, final int renderIndex, final int slot, final int it) {
        super(material, renderIndex, EntityEquipmentSlot.values()[5 - slot]);
        this.armorTexture = "";
        this.desc = "";
        this.maxMRU = 5000;
        this.aType = it;
        this.mat = material;
    }
    
    public ItemArmorEC setArmorTexture(final String path) {
        this.armorTexture = path;
        return this;
    }
    
    public ItemArmorEC setDescription(final String desc) {
        this.desc = desc;
        return this;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, world, (List)list, par4);
        if (!this.desc.isEmpty()) {
            list.add(this.desc);
        }
        if (this.aType == 1) {
            list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
        }
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mods = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (this == ItemsCore.magicArmorItems[5] && s == EntityEquipmentSlot.CHEST) {
            mods.put((Object)SharedMonsterAttributes.field_111267_a.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "hp", 20.0, 0));
        }
        if (this == ItemsCore.magicArmorItems[7] && s == EntityEquipmentSlot.FEET) {
            mods.put((Object)SharedMonsterAttributes.field_111263_d.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "movespeed", 0.075, 0));
        }
        if (this == ItemsCore.magicArmorItems[9] && s == EntityEquipmentSlot.CHEST) {
            mods.put((Object)SharedMonsterAttributes.field_111267_a.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "hp", 30.0, 0));
        }
        if (this == ItemsCore.magicArmorItems[11] && s == EntityEquipmentSlot.FEET) {
            mods.put((Object)SharedMonsterAttributes.field_111263_d.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "movespeed", 0.1, 0));
        }
        return mods;
    }
    
    public String getArmorTexture(final ItemStack itemstack, final Entity entity, final EntityEquipmentSlot slot, final String type) {
        switch (slot) {
            case LEGS: {
                return "essentialcraft:textures/special/armor/" + this.armorTexture + "_1.png";
            }
            default: {
                return "essentialcraft:textures/special/armor/" + this.armorTexture + "_0.png";
            }
        }
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.aType != 1) {
            super.func_150895_a(tab, (NonNullList)items);
        }
        else if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public ModelBiped getArmorModel(final EntityLivingBase entityLiving, final ItemStack itemStack, final EntityEquipmentSlot armorSlot, final ModelBiped _default) {
        ModelBiped armorModel = null;
        if (!itemStack.func_190926_b()) {
            if (itemStack.func_77973_b() instanceof ItemArmorEC) {
                GlStateManager.func_179147_l();
                OpenGlHelper.func_148821_a(770, 771, 1, 0);
                final EntityEquipmentSlot type = ((ItemArmor)itemStack.func_77973_b()).field_77881_a;
                if (type == EntityEquipmentSlot.LEGS) {
                    armorModel = EssentialCraftCore.proxy.getClientModel(0);
                }
                else if (type == EntityEquipmentSlot.CHEST) {
                    armorModel = EssentialCraftCore.proxy.getClientModel(2);
                }
                else {
                    armorModel = EssentialCraftCore.proxy.getClientModel(1);
                }
            }
            if (armorModel != null) {
                armorModel.field_78116_c.field_78806_j = (armorSlot == EntityEquipmentSlot.HEAD);
                armorModel.field_178720_f.field_78806_j = (armorSlot == EntityEquipmentSlot.HEAD);
                armorModel.field_78115_e.field_78806_j = (armorSlot == EntityEquipmentSlot.CHEST || armorSlot == EntityEquipmentSlot.LEGS);
                armorModel.field_178723_h.field_78806_j = (armorSlot == EntityEquipmentSlot.CHEST);
                armorModel.field_178724_i.field_78806_j = (armorSlot == EntityEquipmentSlot.CHEST);
                armorModel.field_178721_j.field_78806_j = (armorSlot == EntityEquipmentSlot.LEGS || armorSlot == EntityEquipmentSlot.FEET);
                armorModel.field_178722_k.field_78806_j = (armorSlot == EntityEquipmentSlot.LEGS || armorSlot == EntityEquipmentSlot.FEET);
                armorModel.field_78117_n = entityLiving.func_70093_af();
                armorModel.field_78093_q = entityLiving.func_184218_aH();
                armorModel.field_78091_s = entityLiving.func_70631_g_();
                armorModel.field_187076_m = (entityLiving.func_184586_b(EnumHand.MAIN_HAND).func_190926_b() ? ModelBiped.ArmPose.EMPTY : ModelBiped.ArmPose.ITEM);
                armorModel.field_187075_l = (entityLiving.func_184586_b(EnumHand.OFF_HAND).func_190926_b() ? ModelBiped.ArmPose.EMPTY : ModelBiped.ArmPose.ITEM);
                if (entityLiving instanceof EntityPlayer) {
                    armorModel.field_187076_m = ((((EntityPlayer)entityLiving).func_184605_cv() > 2) ? ModelBiped.ArmPose.BOW_AND_ARROW : ModelBiped.ArmPose.EMPTY);
                }
            }
        }
        return armorModel;
    }
    
    public boolean showIngamePopups(final ItemStack itemstack, final EntityLivingBase player) {
        final EntityEquipmentSlot type = ((ItemArmor)itemstack.func_77973_b()).field_77881_a;
        return type == EntityEquipmentSlot.HEAD;
    }
    
    public boolean showNodes(final ItemStack itemstack, final EntityLivingBase player) {
        final EntityEquipmentSlot type = ((ItemArmor)itemstack.func_77973_b()).field_77881_a;
        return type == EntityEquipmentSlot.HEAD;
    }
    
    public int getVisDiscount(final ItemStack stack, final EntityPlayer player) {
        final EntityEquipmentSlot type = ((ItemArmor)stack.func_77973_b()).field_77881_a;
        return ItemArmorEC.discount[this.aType][5 - type.ordinal()];
    }
    
    public ISpecialArmor.ArmorProperties getProperties(final EntityLivingBase player, final ItemStack armor, final DamageSource source, final double damage, final int slot) {
        if (this.aType != 1) {
            if (!source.func_76363_c()) {
                final ItemArmor aarmor = (ItemArmor)armor.func_77973_b();
                return new ISpecialArmor.ArmorProperties(0, aarmor.field_77879_b / 25.0, aarmor.func_77612_l() + 1 - armor.func_77952_i());
            }
            return new ISpecialArmor.ArmorProperties(0, 0.0, armor.func_77958_k() + 1 - armor.func_77952_i());
        }
        else {
            final int mru = ((IMRUHandlerItem)armor.getCapability((Capability)ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU();
            if (mru > 0) {
                final ItemArmor aarmor2 = (ItemArmor)armor.func_77973_b();
                return new ISpecialArmor.ArmorProperties(0, aarmor2.field_77879_b / 20.0, aarmor2.func_77612_l() + 1 - armor.func_77952_i());
            }
            return new ISpecialArmor.ArmorProperties(0, 0.0, armor.func_77958_k() + 1 - armor.func_77952_i());
        }
    }
    
    public int getArmorDisplay(final EntityPlayer player, final ItemStack armor, final int slot) {
        return this.mat.func_78044_b(this.field_77881_a);
    }
    
    public void damageArmor(final EntityLivingBase entity, final ItemStack stack, final DamageSource source, final int damage, final int slot) {
        if (this.aType == 1 && entity instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)entity;
            if (ECUtils.playerUseMRU(p, stack, damage * 800)) {}
        }
        else {
            stack.func_77972_a(damage, entity);
        }
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        if (this.aType != 1) {
            return super.initCapabilities(stack, nbt);
        }
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    public void registerModels() {
        if (!Loader.isModLoaded("codechickenlib")) {
            ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
        }
        else {
            ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:armor", "inventory"));
        }
    }
    
    static {
        ItemArmorEC.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        ItemArmorEC.discount = new int[][] { { 5, 5, 3, 2 }, { 8, 10, 7, 5 }, { 10, 15, 8, 7 }, { 2, 3, 2, 1 } };
    }
}
