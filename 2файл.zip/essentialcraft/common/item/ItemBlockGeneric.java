package essentialcraft.common.item;

import net.minecraft.item.*;
import net.minecraft.block.*;

public class ItemBlockGeneric extends ItemBlock
{
    public ItemBlockGeneric(final Block block) {
        super(block);
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public int func_77647_b(final int damage) {
        return damage;
    }
}
