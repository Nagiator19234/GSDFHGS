package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemAxeEC extends ItemAxe implements IModelRegisterer
{
    public ItemAxeEC(final Item.ToolMaterial material) {
        super(material, material.func_78000_c(), material.func_77998_b());
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
