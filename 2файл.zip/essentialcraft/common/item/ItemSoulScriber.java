package essentialcraft.common.item;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.util.math.*;
import essentialcraft.api.*;
import net.minecraft.entity.player.*;
import DummyCore.Utils.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import net.minecraftforge.fml.common.registry.*;

public class ItemSoulScriber extends ItemSwordEC
{
    public ItemSoulScriber() {
        super(Item.ToolMaterial.WOOD);
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mp = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (s == EntityEquipmentSlot.MAINHAND) {
            mp.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemSoulScriber.field_111210_e, "Weapon modifier", 1.0, 0));
            mp.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemSoulScriber.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return mp;
    }
    
    public boolean func_77644_a(final ItemStack weapon, final EntityLivingBase attacked, final EntityLivingBase attacker) {
        if (MathHelper.func_76141_d(attacked.func_110143_aJ()) <= 2) {
            final EntityEntry e = EntityRegistry.getEntry((Class)attacked.getClass());
            final boolean createSoul = DemonTrade.ALL_MOBS.contains(e);
            if (createSoul && attacker instanceof EntityPlayer) {
                final ItemStack soul = new ItemStack(ItemsCore.soul, 1, 0);
                MiscUtils.getStackTag(soul).func_74778_a("entity", e.getRegistryName().toString());
                final EntityItem ei = new EntityItem(attacked.func_130014_f_(), attacked.field_70165_t, attacked.field_70163_u, attacked.field_70161_v, soul);
                if (!attacked.func_130014_f_().field_72995_K) {
                    attacked.func_130014_f_().func_72838_d((Entity)ei);
                }
                attacked.func_70106_y();
            }
        }
        return false;
    }
}
