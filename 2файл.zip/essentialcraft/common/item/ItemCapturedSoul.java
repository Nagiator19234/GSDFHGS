package essentialcraft.common.item;

import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import essentialcraft.api.*;
import DummyCore.Utils.*;
import java.util.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.nbt.*;
import DummyCore.Client.*;

public class ItemCapturedSoul extends Item implements IModelRegisterer
{
    public ItemCapturedSoul() {
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> lst) {
        if (this.func_194125_a(tab)) {
            for (final EntityEntry e : DemonTrade.ALL_MOBS) {
                final ItemStack stack = new ItemStack((Item)this, 1, 0);
                MiscUtils.getStackTag(stack).func_74778_a("entity", e.getRegistryName().toString());
                lst.add((Object)stack);
            }
        }
    }
    
    public String func_77653_i(final ItemStack stack) {
        String s = "";
        if (stack.func_77978_p() != null) {
            final NBTTagCompound tag = MiscUtils.getStackTag(stack);
            if (tag.func_74764_b("entity")) {
                final EntityEntry e = (EntityEntry)ForgeRegistries.ENTITIES.getValue(new ResourceLocation(tag.func_74779_i("entity")));
                if (e != null) {
                    s = "entity." + e.getName() + ".name";
                }
            }
        }
        return super.func_77653_i(stack) + " - " + I18n.func_74838_a(s);
    }
    
    public void registerModels() {
        ModelUtils.setItemModelSingleIcon((Item)this, new String[] { "essentialcraft:item/soul" });
    }
}
