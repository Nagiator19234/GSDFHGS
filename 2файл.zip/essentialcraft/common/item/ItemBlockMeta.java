package essentialcraft.common.item;

import net.minecraft.block.*;
import net.minecraft.item.*;

public class ItemBlockMeta extends ItemBlockGeneric
{
    public ItemBlockMeta(final Block block) {
        super(block);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return super.func_77667_c(stack) + "." + stack.func_77952_i();
    }
}
