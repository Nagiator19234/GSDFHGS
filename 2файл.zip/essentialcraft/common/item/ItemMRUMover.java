package essentialcraft.common.item;

import DummyCore.Utils.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import essentialcraft.common.entity.*;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import DummyCore.Client.*;

public class ItemMRUMover extends Item implements IModelRegisterer
{
    public int func_77626_a(final ItemStack stack) {
        return 72000;
    }
    
    public boolean shouldCauseReequipAnimation(final ItemStack oldStack, final ItemStack newStack, final boolean slotChanged) {
        return !oldStack.func_77973_b().equals(newStack.func_77973_b()) || MiscUtils.getStackTag(oldStack).func_74767_n("active") != MiscUtils.getStackTag(newStack).func_74767_n("active");
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BOW;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        tag.func_74757_a("active", true);
        final Vec3d mainLookVec = player.func_70040_Z();
        final int i = 0;
        if (i < 20) {
            final Vec3d additionalVec = mainLookVec.func_72441_c(mainLookVec.field_72450_a * i, mainLookVec.field_72448_b * i, mainLookVec.field_72449_c * i);
            final List<EntityMRUPresence> entityList = (List<EntityMRUPresence>)player.func_130014_f_().func_72872_a((Class)EntityMRUPresence.class, new AxisAlignedBB(player.field_70165_t + additionalVec.field_72450_a - 1.0, player.field_70163_u + additionalVec.field_72448_b - 2.0, player.field_70161_v + additionalVec.field_72449_c - 1.0, player.field_70165_t + additionalVec.field_72450_a + 1.0, player.field_70163_u + additionalVec.field_72448_b + 2.0, player.field_70161_v + additionalVec.field_72449_c + 1.0));
            if (!entityList.isEmpty()) {
                final EntityMRUPresence presence = entityList.get(player.func_130014_f_().field_73012_v.nextInt(entityList.size()));
                player.func_130014_f_().func_175688_a(EnumParticleTypes.PORTAL, player.field_70165_t, player.field_70163_u, player.field_70161_v, presence.field_70165_t - player.field_70165_t, presence.field_70163_u - player.field_70163_u - 1.0, presence.field_70161_v - player.field_70161_v, new int[0]);
                float moveX = 0.0f;
                float moveY = 0.0f;
                float moveZ = 0.0f;
                moveX = (float)(-(mainLookVec.field_72450_a / 10.0));
                moveY = (float)(-(mainLookVec.field_72448_b / 10.0));
                moveZ = (float)(-(mainLookVec.field_72449_c / 10.0));
                if (!player.func_70093_af()) {
                    presence.func_70080_a(presence.field_70165_t + moveX, presence.field_70163_u + moveY, presence.field_70161_v + moveZ, 0.0f, 0.0f);
                }
                else {
                    presence.func_70080_a(presence.field_70165_t - moveX, presence.field_70163_u - moveY, presence.field_70161_v - moveZ, 0.0f, 0.0f);
                }
                if (count % 20 == 0) {
                    stack.func_77972_a(1, player);
                }
            }
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World worldIn, final EntityLivingBase entityLiving) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        tag.func_74757_a("active", false);
        return stack;
    }
    
    public void func_77615_a(final ItemStack stack, final World worldIn, final EntityLivingBase entityLiving, final int timeLeft) {
        final NBTTagCompound tag = MiscUtils.getStackTag(stack);
        tag.func_74757_a("active", false);
    }
    
    public void registerModels() {
        ModelUtils.setItemModelNBTActive((Item)this, new String[] { "essentialcraft:item/" + this.getRegistryName().func_110623_a() });
    }
}
