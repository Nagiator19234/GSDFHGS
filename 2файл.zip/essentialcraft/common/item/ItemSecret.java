package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.util.text.translation.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.math.*;
import net.minecraft.world.biome.*;
import net.minecraft.util.text.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemSecret extends Item implements IModelRegisterer
{
    public static String[] dropNames;
    
    public ItemSecret() {
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, world, (List)list, par4);
        final int metadata = stack.func_77952_i();
        switch (metadata) {
            case 0: {
                for (int i = 0; i < 5; ++i) {
                    list.add(I18n.func_74838_a("essentialcraft.text.desc.secret_" + metadata + "_" + i));
                }
                break;
            }
            case 1: {
                for (int i = 0; i < 4; ++i) {
                    list.add(I18n.func_74838_a("essentialcraft.text.desc.secret_" + metadata + "_" + i));
                }
                break;
            }
            case 2: {
                list.add("The branch seems to be made of " + TextFormatting.WHITE + "iron");
                list.add("However it is clearly a branch of a tree");
                list.add("You feel better while holding it");
                list.add("Maybe it can improve your " + TextFormatting.AQUA + "spells?");
                break;
            }
            case 3: {
                list.add("This seems to be a regular stick");
                list.add("But it gives you a strange feel of power");
                list.add("You only know one thing");
                list.add("Whoever controls the stick controls the " + TextFormatting.DARK_AQUA + "universe...");
                break;
            }
            case 4: {
                list.add("This stone is too smooth");
                list.add("It makes you feel better");
                list.add("It is also very silky");
                list.add("Maybe some kind of " + TextFormatting.DARK_GREEN + "bird" + TextFormatting.GRAY + " would like it?");
                break;
            }
            case 5: {
                list.add("This is a very strange figure");
                list.add("It seems to be from the future");
                list.add("You can't do anything with it");
                list.add("But it seems a bit " + TextFormatting.DARK_GRAY + "damaged...");
                break;
            }
            case 6: {
                list.add("This is a very strange symbol");
                list.add("It seems to be an image of something");
                list.add("When you look at it you want to glory something");
                list.add("There are letters on the bottom that say " + TextFormatting.LIGHT_PURPLE + "EZIC");
                break;
            }
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        final int metadata = stack.func_77952_i();
        switch (metadata) {
            case 0: {
                final World wrld = player.func_130014_f_();
                final List<EntityPlayer> playerLst = (List<EntityPlayer>)wrld.func_72872_a((Class)EntityPlayer.class, new AxisAlignedBB(player.field_70165_t - 10.0, player.field_70163_u - 10.0, player.field_70161_v - 10.0, player.field_70165_t + 10.0, player.field_70163_u + 10.0, player.field_70161_v + 10.0));
                final Biome biome = wrld.func_180494_b(new BlockPos(MathHelper.func_76128_c(player.field_70165_t), MathHelper.func_76128_c(player.field_70163_u), MathHelper.func_76128_c(player.field_70161_v)));
                final boolean canWork = wrld.func_72820_D() % 24000L >= 14000L && wrld.func_72820_D() % 24000L <= 16000L && player.field_70125_A <= -42.0f && player.field_70125_A >= -65.0f && playerLst.size() == 1 && !wrld.func_72896_J() && (biome.func_150561_m() == Biome.TempCategory.WARM || biome.func_150561_m() == Biome.TempCategory.MEDIUM);
                if (canWork) {
                    player.field_71071_by.func_70299_a(player.field_71071_by.field_70461_c, new ItemStack(ItemsCore.record_everlastingSummer, 1, 0));
                    if (wrld.field_72995_K) {
                        final Style style = new Style().func_150238_a(TextFormatting.WHITE);
                        player.func_145747_a(new TextComponentString("You gase into the stars holding the ticket.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("Suddenly a gust of wind swoops upon you.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You are immediately beeing attacked by lots of feels.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("Strange, warm feels fall upon you.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You feel calm and relaxed.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("A feeling falls upon you. You feel like you've just lived a whole another life.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You try to remember what happened, but memory lets you down.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You suddenly realise, that you no longer keep the ticket in your hand.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("Instead a music disk is in your hand.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("When you gaze to the disk, you begin to hear the song, written on it.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You start feeling really sad, like you've missed something very important to you.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("You feel lonely, like missing another half of you.").func_150255_a(style));
                        player.func_145747_a(new TextComponentString("After some time you calm down.").func_150255_a(style));
                    }
                    return (ActionResult<ItemStack>)ActionResult.newResult(EnumActionResult.SUCCESS, (Object)stack);
                }
                break;
            }
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + ItemSecret.dropNames[Math.min(stack.func_77952_i(), ItemSecret.dropNames.length - 1)];
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 7; ++i) {
                items.add((Object)new ItemStack((Item)this, 1, i));
            }
        }
    }
    
    public boolean func_77636_d(final ItemStack stack) {
        final int metadata = stack.func_77952_i();
        switch (metadata) {
            case 0: {
                return EssentialCraftCore.proxy.itemHasEffect(stack);
            }
            default: {
                return super.func_77636_d(stack);
            }
        }
    }
    
    public EnumRarity func_77613_e(final ItemStack stack) {
        return EssentialCraftCore.proxy.itemHasEffect(stack) ? EnumRarity.RARE : EnumRarity.COMMON;
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemSecret.dropNames.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/secret", "type=" + ItemSecret.dropNames[i]));
        }
    }
    
    static {
        ItemSecret.dropNames = new String[] { "410_ticket", "d6", "ironwood_branch", "mysterious_stick", "smoothandsilkystone", "strange_figure", "strange_symbol", "the_true_unknown" };
    }
}
