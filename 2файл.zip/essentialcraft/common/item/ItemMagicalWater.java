package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagicalWater extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemMagicalWater() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase entityLiving) {
        if (entityLiving instanceof EntityPlayer && ECUtils.playerUseMRU((EntityPlayer)entityLiving, stack, 500)) {
            entityLiving.func_70674_bp();
        }
        return stack;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 32;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.DRINK;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicwaterbottle", "inventory"));
    }
}
