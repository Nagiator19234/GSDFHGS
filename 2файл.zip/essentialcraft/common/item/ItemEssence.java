package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemEssence extends Item implements IModelRegisterer
{
    public static String[] dropNames;
    
    public ItemEssence() {
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + ItemEssence.dropNames[stack.func_77952_i() % 4];
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int var4 = 0; var4 < 16; ++var4) {
                final ItemStack min = new ItemStack((Item)this, 1, var4);
                items.add((Object)min);
            }
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        final int t = stack.func_77952_i() / 4;
        if (t == 0) {
            list.add("Rarity: �fCommon");
        }
        if (t == 1) {
            list.add("Rarity: �eUncommon");
        }
        if (t == 2) {
            list.add("Rarity: �bRare");
        }
        if (t == 3) {
            list.add("Rarity: �dExceptional");
        }
    }
    
    public EnumRarity func_77613_e(final ItemStack stack) {
        final int t = stack.func_77952_i() / 4;
        if (t == 1) {
            return EnumRarity.UNCOMMON;
        }
        if (t == 2) {
            return EnumRarity.RARE;
        }
        if (t == 3) {
            return EnumRarity.EPIC;
        }
        return EnumRarity.COMMON;
    }
    
    public void registerModels() {
        for (int i = 0; i < 16; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/essence", "type=" + ItemEssence.dropNames[i % 4].toLowerCase(Locale.ENGLISH)));
        }
    }
    
    static {
        ItemEssence.dropNames = new String[] { "Fire", "Water", "Earth", "Air" };
    }
}
