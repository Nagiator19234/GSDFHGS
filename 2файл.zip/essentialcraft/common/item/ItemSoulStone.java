package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.client.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.text.*;
import essentialcraft.common.mod.*;
import essentialcraft.network.*;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import essentialcraft.api.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraftforge.fml.common.*;
import java.lang.reflect.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemSoulStone extends Item implements IItemColor, IModelRegisterer
{
    int clientTimer;
    
    public ItemSoulStone() {
        this.clientTimer = 0;
        this.field_77777_bU = 1;
    }
    
    public void func_77663_a(final ItemStack stk, final World w, final Entity e, final int slotnum, final boolean held) {
        if (stk.func_77978_p() != null && stk.func_77952_i() == 0 && stk.func_77978_p().func_74764_b("bloodInfused")) {
            stk.func_77978_p().func_82580_o("bloodInfused");
            stk.func_77964_b(1);
        }
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        if (!world.field_72995_K && !player.func_70093_af()) {
            final NBTTagCompound playerTag = MiscUtils.getStackTag(stack);
            playerTag.func_74778_a("playerName", MiscUtils.getUUIDFromPlayer(player).toString());
            stack.func_77982_d(playerTag);
        }
        if (stack.func_77978_p() != null && !world.field_72995_K && player.func_70093_af()) {
            MiscUtils.getStackTag(stack).func_82580_o("playerName");
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag par4) {
        if (stack.func_77978_p() != null) {
            final String username = stack.func_77978_p().func_74779_i("playerName");
            final EntityPlayer player = (EntityPlayer)Minecraft.func_71410_x().field_71439_g;
            if (player != null) {
                if (ECUtils.playerDataExists(username)) {
                    final IPlayerData data = ECUtils.getData(player);
                    final int currentEnergy = data.getPlayerUBMRU();
                    final int att = data.getMatrixTypeID();
                    list.add(TextFormatting.DARK_GRAY + "Tracking MRU Matrix of " + TextFormatting.GOLD + MiscUtils.getUsernameFromUUID(username));
                    list.add(TextFormatting.DARK_GRAY + "Detected " + TextFormatting.GREEN + currentEnergy + TextFormatting.DARK_GRAY + " UBMRU Energy");
                    String at = "Neutral";
                    switch (att) {
                        case 0: {
                            at = TextFormatting.GREEN + "Neutral";
                            break;
                        }
                        case 1: {
                            at = TextFormatting.RED + "Chaos";
                            break;
                        }
                        case 2: {
                            at = TextFormatting.BLUE + "Frozen";
                            break;
                        }
                        case 3: {
                            at = TextFormatting.LIGHT_PURPLE + "Magic";
                            break;
                        }
                        case 4: {
                            at = TextFormatting.GRAY + "Shade";
                            break;
                        }
                        default: {
                            at = TextFormatting.GREEN + "Unknown";
                            break;
                        }
                    }
                    list.add(TextFormatting.DARK_GRAY + "MRU Matrix twists with " + at + TextFormatting.DARK_GRAY + " Energies");
                    if (data.isWindbound()) {
                        list.add(TextFormatting.DARK_GRAY + "The player is " + TextFormatting.GREEN + "Windbound" + TextFormatting.DARK_GRAY);
                    }
                }
            }
            else {
                list.add(TextFormatting.DARK_GRAY + "The MRU Matrix of the owner is too weak to track");
                if (this.clientTimer == 0) {
                    final NBTTagCompound sTag = new NBTTagCompound();
                    sTag.func_74778_a("syncplayer", username);
                    sTag.func_74778_a("sender", MiscUtils.getUUIDFromPlayer(player).toString());
                    EssentialCraftCore.network.sendToServer((IMessage)new PacketNBT(sTag).setID(1));
                    this.clientTimer = 100;
                }
                else {
                    --this.clientTimer;
                }
            }
            this.addBloodMagicDescription(stack, player, list, par4);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public void addBloodMagicDescription(final ItemStack stack, final EntityPlayer player, final List<String> list, final ITooltipFlag par4) {
        if (Loader.isModLoaded("bloodmagic") && stack.func_77952_i() == 1) {
            stack.func_77978_p().func_74779_i("playerName");
            if (EssentialCraftCore.clazzExists("WayofTime.bloodmagic.api.BloodMagicAPI")) {
                try {
                    final Class<?> classNetworkHelper = Class.forName("WayofTime.bloodmagic.api.util.helper.NetworkHelper");
                    final Method getSoulNetwork = classNetworkHelper.getMethod("getSoulNetwork", EntityPlayer.class);
                    final Class<?> classSoulNetwork = Class.forName("WayofTime.bloodmagic.api.saving.SoulNetwork");
                    final Method getCurrentEssence = classSoulNetwork.getMethod("getCurrentEssence", (Class<?>[])new Class[0]);
                    final int currentEssence = (int)getCurrentEssence.invoke(getSoulNetwork.invoke(null, player), new Object[0]);
                    list.add(TextFormatting.DARK_GRAY + "Detected " + TextFormatting.DARK_RED + currentEssence + TextFormatting.DARK_GRAY + " Life Essence");
                }
                catch (Exception e) {
                    e.printStackTrace();
                    list.add(TextFormatting.DARK_GRAY + "The owner's life network is pure and untouched");
                }
            }
            if (EssentialCraftCore.clazzExists("WayofTime.bloodmagic.apibutnotreally.BloodMagicAPI")) {
                try {
                    final Class<?> classNetworkHelper = Class.forName("WayofTime.bloodmagic.apibutnotreally.util.helper.NetworkHelper");
                    final Method getSoulNetwork = classNetworkHelper.getMethod("getSoulNetwork", EntityPlayer.class);
                    final Class<?> classSoulNetwork = Class.forName("WayofTime.bloodmagic.apibutnotreally.saving.SoulNetwork");
                    final Method getCurrentEssence = classSoulNetwork.getMethod("getCurrentEssence", (Class<?>[])new Class[0]);
                    final int currentEssence = (int)getCurrentEssence.invoke(getSoulNetwork.invoke(null, player), new Object[0]);
                    list.add(TextFormatting.DARK_GRAY + "Detected " + TextFormatting.DARK_RED + currentEssence + TextFormatting.DARK_GRAY + " Life Essence");
                }
                catch (Exception e) {
                    e.printStackTrace();
                    list.add(TextFormatting.DARK_GRAY + "The owner's life network is pure and untouched");
                }
            }
        }
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int layer) {
        if (stack.func_77952_i() == 1) {
            return 16711680;
        }
        return 16777215;
    }
    
    public void registerModels() {
        for (int i = 0; i < 2; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/soulstone", "inventory"));
        }
    }
}
