package essentialcraft.common.item;

import essentialcraft.api.*;
import net.minecraft.item.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemMRUGeneric extends Item
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public int maxMRU;
    
    public ItemMRUGeneric() {
        this.maxMRU = 5000;
    }
    
    public ItemMRUGeneric setMaxMRU(final int maxMRU) {
        this.maxMRU = maxMRU;
        return this;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUGeneric.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemMRUGeneric.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemMRUGeneric.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemMRUGeneric.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    public boolean shouldCauseReequipAnimation(final ItemStack oldStack, final ItemStack newStack, final boolean slotChanged) {
        return !oldStack.func_77973_b().equals(newStack.func_77973_b());
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    static {
        ItemMRUGeneric.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
}
