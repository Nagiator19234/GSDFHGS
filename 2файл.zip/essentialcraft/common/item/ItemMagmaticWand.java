package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraftforge.oredict.*;
import essentialcraft.api.*;
import essentialcraft.utils.common.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraftforge.common.*;
import net.minecraft.entity.item.*;
import DummyCore.Utils.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagmaticWand extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemMagmaticWand() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack ore = new ItemStack(world.func_180495_p(pos).func_177230_c(), 1, world.func_180495_p(pos).func_177230_c().func_176201_c(world.func_180495_p(pos)));
        if (!ore.func_190926_b()) {
            final int[] oreIds = OreDictionary.getOreIDs(ore);
            String oreName = "Unknown";
            if (oreIds.length > 0) {
                oreName = OreDictionary.getOreName(oreIds[0]);
            }
            int metadata = -1;
            for (int i = 0; i < OreSmeltingRecipe.RECIPES.size(); ++i) {
                final OreSmeltingRecipe oreColor = OreSmeltingRecipe.RECIPES.get(i);
                if (oreName.equalsIgnoreCase(oreColor.oreName)) {
                    metadata = i;
                    break;
                }
            }
            if (metadata != -1 && ECUtils.playerUseMRU(player, player.func_184586_b(hand), 500) && !player.func_130014_f_().field_72995_K) {
                int suggestedStackSize = OreSmeltingRecipe.RECIPES.get(metadata).dropAmount;
                if (world.field_73012_v.nextFloat() <= 0.33f) {
                    suggestedStackSize = OreSmeltingRecipe.RECIPES.get(metadata).dropAmount * 2;
                }
                final ItemStack sugStk = OreSmeltingRecipe.getAlloyStack(OreSmeltingRecipe.RECIPES.get(metadata), suggestedStackSize);
                GameType type = GameType.SURVIVAL;
                if (player.field_71075_bZ.field_75098_d) {
                    type = GameType.CREATIVE;
                }
                if (!player.field_71075_bZ.field_75099_e) {
                    type = GameType.ADVENTURE;
                }
                final int be = ForgeHooks.onBlockBreakEvent(player.func_130014_f_(), type, (EntityPlayerMP)player, pos);
                if (be != -1 && !world.field_72995_K) {
                    world.func_175698_g(pos);
                    final EntityItem drop = new EntityItem(world, (double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), sugStk);
                    drop.field_70159_w = MathUtils.randomDouble(world.field_73012_v) / 10.0;
                    drop.field_70181_x = MathUtils.randomDouble(world.field_73012_v) / 10.0;
                    drop.field_70179_y = MathUtils.randomDouble(world.field_73012_v) / 10.0;
                    world.func_72838_d((Entity)drop);
                }
                player.func_184609_a(hand);
            }
        }
        return EnumActionResult.PASS;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magmaticstaff", "inventory"));
    }
}
