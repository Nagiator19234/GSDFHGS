package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemFruit extends ItemFood implements IModelRegisterer
{
    public ItemFruit(final int amount, final float saturation, final boolean isWolfFood) {
        super(amount, saturation, isWolfFood);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/fruit_item", "inventory"));
    }
}
