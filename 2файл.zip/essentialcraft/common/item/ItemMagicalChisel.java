package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.item.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemMagicalChisel extends Item implements IModelRegisterer
{
    public ItemStack getContainerItem(final ItemStack itemStack) {
        if (!this.hasContainerItem(itemStack)) {
            return ItemStack.field_190927_a;
        }
        return new ItemStack(itemStack.func_77973_b(), itemStack.func_190916_E(), itemStack.func_77952_i() + 1);
    }
    
    public boolean hasContainerItem(final ItemStack stack) {
        return stack.func_77952_i() < stack.func_77958_k();
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicalchisel", "inventory"));
    }
}
