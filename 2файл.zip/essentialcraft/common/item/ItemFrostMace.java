package essentialcraft.common.item;

import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemFrostMace extends ItemSword implements IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    int maxMRU;
    
    public ItemFrostMace() {
        super(ItemsCore.elemental);
        this.maxMRU = 5000;
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
        this.func_77656_e(0);
    }
    
    public boolean func_77616_k(final ItemStack stack) {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemFrostMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemFrostMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemFrostMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemFrostMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase entityLiving) {
        final Vec3d playerLookVec = entityLiving.func_70040_Z();
        entityLiving.field_70159_w += playerLookVec.field_72450_a;
        entityLiving.field_70181_x += playerLookVec.field_72448_b;
        entityLiving.field_70179_y += playerLookVec.field_72449_c;
        return stack;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 32;
    }
    
    public boolean func_77644_a(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        try {
            if (attacker instanceof EntityPlayer) {
                final EntityPlayer player = (EntityPlayer)attacker;
                if (ECUtils.playerUseMRU(player, stack, 250)) {
                    final int att = ECUtils.getData(player).getMatrixTypeID();
                    if (att == 2) {
                        final PotionEffect eff = target.func_70660_b(MobEffects.field_76421_d);
                        if ((eff != null && target.field_70172_ad == 0) || (target.field_70172_ad >= 15 && eff != null)) {
                            target.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 1000, eff.func_76458_c() + 1));
                            return true;
                        }
                        if (target.field_70172_ad == 0 || target.field_70172_ad >= 15) {
                            target.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 1000, 0));
                            return true;
                        }
                    }
                }
            }
        }
        catch (Exception e) {
            return false;
        }
        return false;
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> multimap = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (s == EntityEquipmentSlot.MAINHAND) {
            multimap.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemFrostMace.field_111210_e, "Weapon modifier", 16.0, 0));
            multimap.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemFrostMace.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return multimap;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BOW;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/frozenmace", "inventory"));
    }
    
    static {
        ItemFrostMace.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
}
