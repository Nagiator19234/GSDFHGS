package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import essentialcraft.common.mod.*;
import java.util.*;
import net.minecraft.client.util.*;
import DummyCore.Utils.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.nbt.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemKnowledgeBook extends Item implements IModelRegisterer
{
    public ItemKnowledgeBook() {
        this.field_77777_bU = 1;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        EssentialCraftCore.proxy.openBookGUIForPlayer();
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        final NBTTagCompound theTag = MiscUtils.getStackTag(stack);
        list.add("�6" + I18n.func_74838_a("essentialcraft.txt.book.containedKnowledge"));
        for (int tier = theTag.func_74762_e("tier"), i = 0; i <= tier; ++i) {
            list.add("�7-�o" + I18n.func_74838_a("essentialcraft.txt.book.tier_" + i));
        }
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 5; ++i) {
                final ItemStack book = new ItemStack((Item)this);
                final NBTTagCompound bookTag = new NBTTagCompound();
                bookTag.func_74768_a("tier", i);
                book.func_77982_d(bookTag);
                items.add((Object)book);
            }
        }
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/research_book", "inventory"));
    }
}
