package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemRecordEC extends ItemRecord implements IModelRegisterer
{
    protected ItemRecordEC(final String name, final SoundEvent sound) {
        super(name, sound);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
