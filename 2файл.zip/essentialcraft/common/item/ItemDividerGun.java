package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import essentialcraft.utils.common.*;
import essentialcraft.common.registry.*;
import net.minecraft.util.*;
import essentialcraft.common.entity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemDividerGun extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemDividerGun() {
        this.setMaxMRU(20000);
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        super.func_77663_a(itemStack, world, entity, indexInInventory, isCurrentItem);
        if (!(entity instanceof EntityPlayer) || entity.field_70173_aa % 20 == 0) {}
    }
    
    public ActionResult<ItemStack> func_77659_a(final World w, final EntityPlayer p, final EnumHand h) {
        p.func_184598_c(h);
        return (ActionResult<ItemStack>)super.func_77659_a(w, p, h);
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BOW;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 20;
    }
    
    public ItemStack func_77654_b(final ItemStack stk, final World w, final EntityLivingBase p) {
        if (p instanceof EntityPlayer && ECUtils.playerUseMRU((EntityPlayer)p, stk, 5000)) {
            w.func_184134_a(p.field_70165_t, p.field_70163_u, p.field_70161_v, SoundRegistry.gunBeam, SoundCategory.PLAYERS, 1.0f, 2.0f, false);
            final EntityDividerProjectile proj = new EntityDividerProjectile(w, p);
            proj.func_184538_a((Entity)p, p.field_70125_A, p.field_70177_z, 0.0f, 1.5f, 1.0f);
            if (!w.field_72995_K) {
                w.func_72838_d((Entity)proj);
            }
        }
        return stk;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/dividergun", "inventory"));
    }
}
