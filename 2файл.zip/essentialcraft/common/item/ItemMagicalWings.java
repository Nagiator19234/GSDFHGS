package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import baubles.api.*;
import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import net.minecraft.entity.*;
import DummyCore.Utils.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagicalWings extends ItemMRUGeneric implements IBauble, IModelRegisterer
{
    public ItemMagicalWings() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public void func_77663_a(final ItemStack s, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        super.func_77663_a(s, world, entity, indexInInventory, isCurrentItem);
        if (entity instanceof EntityPlayer) {
            final EntityPlayer e = (EntityPlayer)entity;
            if ((e.func_184614_ca() == s || e.func_184592_cb() == s) && ECUtils.playerUseMRU(e, s, 1)) {
                if (!e.func_70093_af()) {
                    final EntityPlayer entityPlayer = e;
                    entityPlayer.field_70181_x += 0.10000000149011612;
                    e.field_70143_R = 0.0f;
                }
                else {
                    e.field_70181_x = -0.20000000298023224;
                    e.field_70143_R = 0.0f;
                }
                world.func_175688_a(EnumParticleTypes.REDSTONE, e.field_70165_t + MathUtils.randomDouble(world.field_73012_v) / 2.0, e.field_70163_u - 1.0 + MathUtils.randomDouble(world.field_73012_v), e.field_70161_v + MathUtils.randomDouble(world.field_73012_v) / 2.0, 0.0, 1.0, 1.0, new int[0]);
            }
            if (e.field_70181_x < -0.20000000298023224 && e.func_70093_af() && ECUtils.playerUseMRU(e, s, 1)) {
                e.field_70181_x = -0.20000000298023224;
                e.field_70143_R = 0.0f;
                world.func_175688_a(EnumParticleTypes.REDSTONE, e.field_70165_t + MathUtils.randomDouble(world.field_73012_v) / 2.0, e.field_70163_u - 1.0 + MathUtils.randomDouble(world.field_73012_v), e.field_70161_v + MathUtils.randomDouble(world.field_73012_v) / 2.0, 0.0, 1.0, 1.0, new int[0]);
            }
        }
    }
    
    public BaubleType getBaubleType(final ItemStack itemstack) {
        return BaubleType.BELT;
    }
    
    public void onWornTick(final ItemStack itemstack, final EntityLivingBase player) {
        if (player instanceof EntityPlayer) {
            final EntityPlayer e = (EntityPlayer)player;
            if (e.field_70181_x < -0.20000000298023224 && !e.func_70093_af() && ECUtils.playerUseMRU(e, itemstack, 1)) {
                e.field_70181_x = -0.20000000298023224;
                e.field_70143_R = 0.0f;
                e.func_130014_f_().func_175688_a(EnumParticleTypes.REDSTONE, e.field_70165_t + MathUtils.randomDouble(e.func_130014_f_().field_73012_v) / 2.0, e.field_70163_u - 1.0 + MathUtils.randomDouble(e.func_130014_f_().field_73012_v), e.field_70161_v + MathUtils.randomDouble(e.func_130014_f_().field_73012_v) / 2.0, 0.0, 1.0, 1.0, new int[0]);
            }
            if (((IMRUHandlerItem)itemstack.getCapability((Capability)ItemMagicalWings.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() >= 1) {
                EssentialCraftCore.proxy.wingsAction(e, itemstack);
            }
            MiscUtils.applyPlayerModifier((EntityPlayer)player, SharedMonsterAttributes.field_111263_d, "EC300", 0.10000000149011612, false, 0, "bauble");
        }
    }
    
    public void onEquipped(final ItemStack itemstack, final EntityLivingBase player) {
    }
    
    public void onUnequipped(final ItemStack itemstack, final EntityLivingBase player) {
        if (player instanceof EntityPlayer) {
            MiscUtils.applyPlayerModifier((EntityPlayer)player, SharedMonsterAttributes.field_111263_d, "EC300", 0.10000000149011612, true, 0, "bauble");
        }
    }
    
    public boolean canEquip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public boolean canUnequip(final ItemStack itemstack, final EntityLivingBase player) {
        return true;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicalwings", "inventory"));
    }
}
