package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.item.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagnetizingStaff extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemMagnetizingStaff() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return Integer.MAX_VALUE;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        if (count % 8 == 0 && player instanceof EntityPlayer && ECUtils.playerUseMRU((EntityPlayer)player, stack, 50)) {
            player.func_184609_a(EnumHand.MAIN_HAND);
            final List<EntityItem> items = (List<EntityItem>)player.func_130014_f_().func_72872_a((Class)EntityItem.class, new AxisAlignedBB(player.field_70165_t - 0.5, player.field_70163_u, player.field_70161_v - 0.5, player.field_70165_t + 0.5, player.field_70163_u + 1.0, player.field_70161_v + 0.5).func_72314_b(12.0, 6.0, 12.0));
            for (final EntityItem item : items) {
                if (player.field_70165_t < item.field_70165_t) {
                    final EntityItem entityItem = item;
                    entityItem.field_70159_w -= 0.10000000149011612;
                }
                else {
                    final EntityItem entityItem2 = item;
                    entityItem2.field_70159_w += 0.10000000149011612;
                }
                if (player.field_70163_u < item.field_70163_u) {
                    final EntityItem entityItem3 = item;
                    entityItem3.field_70181_x -= 0.10000000149011612;
                }
                else {
                    final EntityItem entityItem4 = item;
                    entityItem4.field_70181_x += 0.5;
                }
                if (player.field_70161_v < item.field_70161_v) {
                    final EntityItem entityItem5 = item;
                    entityItem5.field_70179_y -= 0.10000000149011612;
                }
                else {
                    final EntityItem entityItem6 = item;
                    entityItem6.field_70179_y += 0.10000000149011612;
                }
            }
            final List<EntityXPOrb> orbs = (List<EntityXPOrb>)player.func_130014_f_().func_72872_a((Class)EntityXPOrb.class, new AxisAlignedBB(player.field_70165_t - 0.5, player.field_70163_u, player.field_70161_v - 0.5, player.field_70165_t + 0.5, player.field_70163_u + 1.0, player.field_70161_v + 0.5).func_72321_a(12.0, 6.0, 12.0));
            for (final EntityXPOrb item2 : orbs) {
                if (player.field_70165_t < item2.field_70165_t) {
                    final EntityXPOrb entityXPOrb = item2;
                    entityXPOrb.field_70159_w -= 0.10000000149011612;
                }
                else {
                    final EntityXPOrb entityXPOrb2 = item2;
                    entityXPOrb2.field_70159_w += 0.10000000149011612;
                }
                if (player.field_70163_u < item2.field_70163_u) {
                    final EntityXPOrb entityXPOrb3 = item2;
                    entityXPOrb3.field_70181_x -= 0.10000000149011612;
                }
                else {
                    final EntityXPOrb entityXPOrb4 = item2;
                    entityXPOrb4.field_70181_x += 0.5;
                }
                if (player.field_70161_v < item2.field_70161_v) {
                    final EntityXPOrb entityXPOrb5 = item2;
                    entityXPOrb5.field_70179_y -= 0.10000000149011612;
                }
                else {
                    final EntityXPOrb entityXPOrb6 = item2;
                    entityXPOrb6.field_70179_y += 0.10000000149011612;
                }
            }
        }
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BOW;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magnetizingstaff", "inventory"));
    }
}
