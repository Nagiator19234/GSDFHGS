package essentialcraft.common.item;

import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import java.util.*;

public class ItemWindShovel extends ItemShovelEC
{
    public ItemWindShovel(final Item.ToolMaterial m) {
        super(m);
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing facing, final float hitX, final float hitY, final float hitZ) {
        return ItemsCore.wind_elemental_hoe.func_180614_a(player, world, pos, hand, facing, hitX, hitY, hitZ);
    }
    
    public boolean func_77644_a(final ItemStack weapon, final EntityLivingBase attacked, final EntityLivingBase attacker) {
        if (attacker instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)attacker;
            final ItemStack currentTool = weapon;
            if (!p.func_130014_f_().field_72995_K && currentTool.func_77973_b() instanceof ItemTool && ((ItemTool)currentTool.func_77973_b()).func_77861_e().equals(ItemsCore.windElemental.name())) {
                final String clazz = "sword";
                String currentToolClass = "";
                if (currentTool.func_77973_b() instanceof ItemPickaxe) {
                    currentToolClass = "pickaxe";
                }
                if (currentTool.func_77973_b() instanceof ItemAxe) {
                    currentToolClass = "axe";
                }
                if (currentTool.func_77973_b() instanceof ItemSpade) {
                    currentToolClass = "shovel";
                }
                if (currentTool.func_77973_b() instanceof ItemHoe) {
                    currentToolClass = "hoe";
                }
                if (currentTool.func_77973_b() instanceof ItemSword) {
                    currentToolClass = "sword";
                }
                final NBTTagCompound toolTag = new NBTTagCompound();
                NBTTagCompound genericTag = new NBTTagCompound();
                currentTool.func_77955_b(toolTag);
                if (toolTag.func_74764_b("tag")) {
                    genericTag = toolTag.func_74775_l("tag").func_74737_b();
                    toolTag.func_74775_l("tag").func_82580_o("pickaxe");
                    toolTag.func_74775_l("tag").func_82580_o("axe");
                    toolTag.func_74775_l("tag").func_82580_o("shovel");
                    toolTag.func_74775_l("tag").func_82580_o("hoe");
                    toolTag.func_74775_l("tag").func_82580_o("sword");
                    toolTag.func_74775_l("tag").func_82580_o("tag");
                }
                final Set<String> tags = (Set<String>)genericTag.func_150296_c();
                final List<String> tagKeyLst = new ArrayList<String>();
                tags.forEach(name -> tagKeyLst.add(name));
                if (tagKeyLst.indexOf("pickaxe") != -1) {
                    tagKeyLst.remove("pickaxe");
                }
                if (tagKeyLst.indexOf("axe") != -1) {
                    tagKeyLst.remove("axe");
                }
                if (tagKeyLst.indexOf("shovel") != -1) {
                    tagKeyLst.remove("shovel");
                }
                if (tagKeyLst.indexOf("hoe") != -1) {
                    tagKeyLst.remove("hoe");
                }
                if (tagKeyLst.indexOf("sword") != -1) {
                    tagKeyLst.remove("sword");
                }
                for (final String element : tagKeyLst) {
                    genericTag.func_82580_o(element);
                }
                ItemStack efficent = ItemStack.field_190927_a;
                if (genericTag.func_74764_b(clazz)) {
                    final NBTTagCompound loadFrom = genericTag.func_74775_l(clazz).func_74737_b();
                    genericTag.func_82580_o(clazz);
                    efficent = new ItemStack(loadFrom);
                }
                else {
                    if (clazz.equalsIgnoreCase("pickaxe")) {
                        efficent = new ItemStack(ItemsCore.wind_elemental_pick, 1, currentTool.func_77952_i());
                    }
                    if (clazz.equalsIgnoreCase("shovel")) {
                        efficent = new ItemStack(ItemsCore.wind_elemental_shovel, 1, currentTool.func_77952_i());
                    }
                    if (clazz.equalsIgnoreCase("hoe")) {
                        efficent = new ItemStack(ItemsCore.wind_elemental_hoe, 1, currentTool.func_77952_i());
                    }
                    if (clazz.equalsIgnoreCase("sword")) {
                        efficent = new ItemStack(ItemsCore.wind_elemental_sword, 1, currentTool.func_77952_i());
                    }
                    if (clazz.equalsIgnoreCase("axe")) {
                        efficent = new ItemStack(ItemsCore.wind_elemental_axe, 1, currentTool.func_77952_i());
                    }
                }
                if (!efficent.func_190926_b() && efficent.func_77973_b() != null) {
                    final NBTTagCompound anotherTag = MiscUtils.getStackTag(efficent);
                    if (genericTag.func_74764_b("pickaxe")) {
                        anotherTag.func_74782_a("pickaxe", genericTag.func_74781_a("pickaxe"));
                    }
                    if (genericTag.func_74764_b("axe")) {
                        anotherTag.func_74782_a("axe", genericTag.func_74781_a("axe"));
                    }
                    if (genericTag.func_74764_b("shovel")) {
                        anotherTag.func_74782_a("shovel", genericTag.func_74781_a("shovel"));
                    }
                    if (genericTag.func_74764_b("hoe")) {
                        anotherTag.func_74782_a("hoe", genericTag.func_74781_a("hoe"));
                    }
                    if (genericTag.func_74764_b("sword")) {
                        anotherTag.func_74782_a("sword", genericTag.func_74781_a("sword"));
                    }
                    if (toolTag != null) {
                        anotherTag.func_74782_a(currentToolClass, (NBTBase)toolTag);
                    }
                    p.field_71071_by.func_70299_a(p.field_71071_by.field_70461_c, efficent);
                }
            }
        }
        return true;
    }
}
