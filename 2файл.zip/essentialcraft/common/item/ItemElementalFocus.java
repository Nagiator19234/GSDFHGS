package essentialcraft.common.item;

import net.minecraft.item.*;
import DummyCore.Client.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemElementalFocus extends Item implements IModelRegisterer
{
    public ItemElementalFocus() {
        this.func_77656_e(3000);
        this.func_77625_d(1);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
