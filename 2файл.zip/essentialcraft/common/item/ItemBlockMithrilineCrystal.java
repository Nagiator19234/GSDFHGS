package essentialcraft.common.item;

import net.minecraft.block.*;
import net.minecraft.item.*;

public class ItemBlockMithrilineCrystal extends ItemBlock
{
    public ItemBlockMithrilineCrystal(final Block block) {
        super(block);
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public int func_77647_b(final int meta) {
        return meta;
    }
    
    public String func_77667_c(final ItemStack stack) {
        final int meta = stack.func_77952_i() / 3;
        String added = "mithriline";
        if (meta == 1) {
            added = "pale";
        }
        if (meta == 2) {
            added = "void";
        }
        if (meta == 3) {
            added = "demonic";
        }
        if (meta == 4) {
            added = "shade";
        }
        return super.func_77667_c(stack) + "." + added;
    }
}
