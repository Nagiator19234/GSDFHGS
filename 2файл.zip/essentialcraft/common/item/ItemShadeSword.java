package essentialcraft.common.item;

import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import essentialcraft.api.*;
import net.minecraft.entity.player.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import DummyCore.Client.*;
import net.minecraft.item.*;

public class ItemShadeSword extends ItemSwordEC
{
    public ItemShadeSword() {
        super(ItemsCore.shade);
    }
    
    public void toggleActivity(final ItemStack is, final boolean b) {
        if (!is.func_190926_b()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(is);
            if (tag.func_74767_n("active") != b) {
                tag.func_74757_a("active", b);
            }
        }
    }
    
    public boolean onEntityItemUpdate(final EntityItem entityItem) {
        this.toggleActivity(entityItem.func_92059_d(), false);
        return super.onEntityItemUpdate(entityItem);
    }
    
    public void func_77663_a(final ItemStack sword, final World w, final Entity e, final int slotNum, final boolean held) {
        if (e instanceof IShadeHandlerEntity) {
            this.toggleActivity(sword, true);
        }
        if (e instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)e;
            if (ECUtils.getData(p).getMatrixTypeID() == 4) {
                this.toggleActivity(sword, true);
            }
            else {
                this.toggleActivity(sword, false);
            }
        }
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mp = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (MiscUtils.getStackTag(stack).func_74767_n("active") && s == EntityEquipmentSlot.MAINHAND) {
            mp.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemShadeSword.field_111210_e, "Weapon modifier", 16.0, 0));
            mp.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemShadeSword.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return mp;
    }
    
    public boolean isItemTool(final ItemStack stack) {
        return true;
    }
    
    public boolean func_77644_a(final ItemStack weapon, final EntityLivingBase attacked, final EntityLivingBase attacker) {
        if (attacker instanceof IShadeHandlerEntity && attacked instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)attacked;
            ShadeUtils.attackPlayerWithShade(p, attacker, weapon);
        }
        if ((attacker instanceof IShadeHandlerEntity || (attacker instanceof EntityPlayer && ECUtils.getData((EntityPlayer)attacker).getMatrixTypeID() == 4)) && !attacker.func_130014_f_().field_72995_K) {
            if (attacker.func_130014_f_().field_73012_v.nextFloat() <= 0.33f) {
                final Vec3d offsetVec = new Vec3d(attacker.field_70165_t - attacked.field_70165_t, attacked.field_70163_u - attacker.field_70163_u, attacker.field_70161_v - attacked.field_70161_v);
                float newYaw = 0.0f;
                if (attacker.field_70759_as >= 180.0f) {
                    newYaw = attacker.field_70759_as - 180.0f;
                }
                else {
                    newYaw = attacker.field_70759_as + 180.0f;
                }
                attacker.func_70080_a(attacked.field_70165_t - offsetVec.field_72450_a, attacker.field_70163_u, attacked.field_70161_v - offsetVec.field_72449_c, newYaw, attacker.field_70125_A);
                attacker.field_70759_as = newYaw;
                if (attacker instanceof EntityPlayer) {
                    ECUtils.changePlayerPositionOnClient((EntityPlayer)attacker);
                }
            }
            if (attacker.func_130014_f_().field_73012_v.nextDouble() <= 0.1) {
                MiscUtils.damageEntityIgnoreEvent(attacked, DamageSource.func_76358_a(attacker), 16.0f);
                attacked.field_70172_ad = 0;
                attacked.field_70737_aN = 0;
            }
        }
        return false;
    }
    
    @Override
    public void registerModels() {
        ModelUtils.setItemModelNBTActive((Item)this, new String[] { "essentialcraft:item/shadesword" });
    }
}
