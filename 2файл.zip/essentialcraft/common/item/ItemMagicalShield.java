package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagicalShield extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemMagicalShield() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        player.field_70172_ad = 20;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 40;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BLOCK;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        if (ECUtils.playerUseMRU(player, player.func_184586_b(hand), 2000)) {
            player.func_184598_c(hand);
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicalshield", "inventory"));
    }
}
