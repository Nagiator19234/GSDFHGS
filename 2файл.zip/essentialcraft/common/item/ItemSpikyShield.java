package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.entity.monster.*;
import net.minecraft.util.math.*;
import java.util.*;
import net.minecraft.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemSpikyShield extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemSpikyShield() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase entityLiving) {
        if (entityLiving instanceof EntityPlayer && ECUtils.playerUseMRU((EntityPlayer)entityLiving, stack, 100)) {
            final List<EntityMob> mobs = (List<EntityMob>)world.func_72872_a((Class)EntityMob.class, new AxisAlignedBB(entityLiving.field_70165_t - 5.0, entityLiving.field_70163_u - 2.0, entityLiving.field_70161_v - 5.0, entityLiving.field_70165_t + 5.0, entityLiving.field_70163_u + 2.0, entityLiving.field_70161_v + 5.0));
            if (!mobs.isEmpty()) {
                for (final EntityMob mob : mobs) {
                    mob.func_70097_a(DamageSource.func_76365_a((EntityPlayer)entityLiving), 12.0f);
                }
            }
        }
        return stack;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        player.field_70172_ad = 20;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 40;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BLOCK;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        if (ECUtils.playerUseMRU(player, player.func_184586_b(hand), 2000)) {}
        player.func_184598_c(hand);
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/spikyshield", "inventory"));
    }
}
