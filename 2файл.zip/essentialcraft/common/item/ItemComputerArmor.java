package essentialcraft.common.item;

import thaumcraft.api.items.*;
import net.minecraftforge.common.*;
import DummyCore.Client.*;
import DummyCore.Utils.*;
import essentialcraft.api.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraft.util.text.*;
import net.minecraft.util.text.translation.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

@DCASMCheck
@ExistenceCheck(classPath = { "thaumcraft.api.items.IVisDiscountGear", "thaumcraft.api.items.IRevealer", "thaumcraft.api.items.IGoggles" })
public class ItemComputerArmor extends ItemArmor implements IVisDiscountGear, IRevealer, IGoggles, ISpecialArmor, IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public int maxMRU;
    public static int[] discount;
    public ItemArmor.ArmorMaterial mat;
    public String textureName;
    
    public ItemComputerArmor(final ItemArmor.ArmorMaterial material, final int texture, final int armorType) {
        super(material, texture, EntityEquipmentSlot.values()[5 - armorType]);
        this.maxMRU = 1000000;
        this.textureName = "";
        this.mat = material;
    }
    
    public String getArmorTexture(final ItemStack itemstack, final Entity entity, final EntityEquipmentSlot slot, final String type) {
        switch (slot) {
            case LEGS: {
                return "essentialcraft:textures/special/armor/computer_layer_2.png";
            }
            default: {
                return "essentialcraft:textures/special/armor/computer_layer_1.png";
            }
        }
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot slot, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mods = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (this == ItemsCore.computer_chestplate && slot == EntityEquipmentSlot.CHEST) {
            mods.put((Object)SharedMonsterAttributes.field_111267_a.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0000"), "hp", 40.0, 0));
        }
        if (this == ItemsCore.computer_leggings && slot == EntityEquipmentSlot.LEGS) {
            mods.put((Object)SharedMonsterAttributes.field_111263_d.func_111108_a(), (Object)new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0001"), "movespeed", 0.15, 0));
        }
        return mods;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
        switch (this.field_77881_a) {
            case HEAD: {
                list.add(TextFormatting.DARK_PURPLE + I18n.func_74838_a("essentialcraft.txt.computer_helmet.props"));
                break;
            }
            case CHEST: {
                list.add(TextFormatting.DARK_PURPLE + I18n.func_74838_a("essentialcraft.txt.computer_chestplate.props"));
                break;
            }
            case LEGS: {
                list.add(TextFormatting.DARK_PURPLE + I18n.func_74838_a("essentialcraft.txt.computer_legs.props"));
                break;
            }
            case FEET: {
                list.add(TextFormatting.DARK_PURPLE + I18n.func_74838_a("essentialcraft.txt.computer_boots.props"));
                break;
            }
        }
        list.add(" ");
        list.add((hasFullset((EntityPlayer)Minecraft.func_71410_x().field_71439_g) ? TextFormatting.GREEN : TextFormatting.RESET) + I18n.func_74838_a("essentialcraft.txt.fullset"));
        list.add(TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.fullset.computer.props"));
        list.add(TextFormatting.ITALIC + I18n.func_74838_a("essentialcraft.txt.fullset.computer.props_2"));
    }
    
    public static boolean hasFullset(final EntityPlayer p) {
        if (p == null) {
            return false;
        }
        for (int i = 0; i < 4; ++i) {
            if (!(((ItemStack)p.field_71071_by.field_70460_b.get(i)).func_77973_b() instanceof ItemComputerArmor)) {
                return false;
            }
        }
        return true;
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    public boolean showIngamePopups(final ItemStack itemstack, final EntityLivingBase player) {
        final EntityEquipmentSlot type = ((ItemArmor)itemstack.func_77973_b()).field_77881_a;
        return type == EntityEquipmentSlot.HEAD;
    }
    
    public boolean showNodes(final ItemStack itemstack, final EntityLivingBase player) {
        final EntityEquipmentSlot type = ((ItemArmor)itemstack.func_77973_b()).field_77881_a;
        return type == EntityEquipmentSlot.HEAD;
    }
    
    public int getVisDiscount(final ItemStack stack, final EntityPlayer player) {
        final EntityEquipmentSlot type = ((ItemArmor)stack.func_77973_b()).field_77881_a;
        return ItemComputerArmor.discount[5 - type.ordinal()];
    }
    
    public ISpecialArmor.ArmorProperties getProperties(final EntityLivingBase player, final ItemStack armor, final DamageSource source, final double damage, final int slot) {
        if (armor.func_77973_b() == ItemsCore.computer_chestplate && player instanceof EntityPlayer) {
            boolean hasFullSet = true;
            final EntityPlayer p = (EntityPlayer)player;
            for (int i = 0; i < 4; ++i) {
                if (!(((ItemStack)p.field_71071_by.field_70460_b.get(i)).func_77973_b() instanceof ItemComputerArmor)) {
                    hasFullSet = false;
                    break;
                }
            }
            if (source.func_76346_g() != null && hasFullSet) {
                float newDamage = (float)(damage / 2.0);
                if (newDamage < 0.5) {
                    newDamage = 0.0f;
                }
                ECUtils.playSoundToAllNearby(player.field_70165_t, player.field_70163_u, player.field_70161_v, "essentialcraft:sound.lightning_hit", 0.2f, 1.0f, 8.0, player.field_71093_bK);
                source.func_76346_g().func_70097_a(DamageSource.func_92087_a((Entity)player), newDamage);
            }
        }
        final int mru = ((IMRUHandlerItem)armor.getCapability((Capability)ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU();
        if (mru > 0) {
            final ItemArmor aarmor = (ItemArmor)armor.func_77973_b();
            return new ISpecialArmor.ArmorProperties(0, aarmor.field_77879_b / 10.0, Integer.MAX_VALUE);
        }
        return new ISpecialArmor.ArmorProperties(0, 0.0, 1);
    }
    
    public int getArmorDisplay(final EntityPlayer player, final ItemStack armor, final int slot) {
        return this.mat.func_78044_b(this.field_77881_a);
    }
    
    public void damageArmor(final EntityLivingBase entity, final ItemStack stack, final DamageSource source, final int damage, final int slot) {
        if (entity instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)entity;
            if (ECUtils.playerUseMRU(p, stack, damage * 250)) {}
        }
    }
    
    public ItemComputerArmor setTextureName(final String name) {
        this.textureName = name;
        return this;
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
    
    static {
        ItemComputerArmor.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        ItemComputerArmor.discount = new int[] { 18, 25, 12, 15 };
    }
}
