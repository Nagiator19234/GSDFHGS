package essentialcraft.common.item;

import essentialcraft.api.*;
import DummyCore.Client.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMonocle extends Item implements IMRUVisibilityHandler, IModelRegisterer
{
    public ItemMonocle() {
        this.field_77777_bU = 1;
        this.func_77656_e(16);
    }
    
    public boolean func_77662_d() {
        return true;
    }
    
    public int func_77619_b() {
        return 10;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicmonocle", "inventory"));
    }
    
    public boolean canSeeMRU(final ItemStack stk) {
        return true;
    }
}
