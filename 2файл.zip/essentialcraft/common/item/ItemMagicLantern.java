package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import essentialcraft.common.block.*;
import net.minecraft.block.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemMagicLantern extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemMagicLantern() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public void func_77663_a(final ItemStack itemStack, final World world, final Entity entity, final int indexInInventory, final boolean isCurrentItem) {
        if (!world.field_72995_K) {
            final int fX = MathHelper.func_76128_c(entity.field_70165_t);
            final int fY = MathHelper.func_76128_c(entity.field_70163_u);
            final int fZ = MathHelper.func_76128_c(entity.field_70161_v);
            final Block b = world.func_180495_p(new BlockPos(fX, fY, fZ)).func_177230_c();
            if (b == Blocks.field_150350_a && isCurrentItem) {
                world.func_180501_a(new BlockPos(fX, fY, fZ), BlocksCore.torch.func_176203_a(1), 2);
                world.func_175684_a(new BlockPos(fX, fY, fZ), BlocksCore.torch, 20);
            }
        }
        super.func_77663_a(itemStack, world, entity, indexInInventory, isCurrentItem);
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing dir, final float hitX, final float hitY, final float hitZ) {
        final Block b = world.func_180495_p(pos.func_177972_a(dir)).func_177230_c();
        if (b == Blocks.field_150350_a && player.field_71071_by.func_70431_c(new ItemStack(ItemsCore.magicalSlag)) && ECUtils.playerUseMRU(player, player.func_184586_b(hand), 100)) {
            int slotID = -1;
            for (int i = 0; i < player.field_71071_by.func_70302_i_(); ++i) {
                final ItemStack stk = player.field_71071_by.func_70301_a(i);
                if (stk.func_77973_b() == ItemsCore.magicalSlag) {
                    slotID = i;
                    break;
                }
            }
            if (slotID != -1) {
                player.field_71071_by.func_70298_a(slotID, 1);
                world.func_180501_a(pos.func_177972_a(dir), BlocksCore.torch.func_176203_a(0), 3);
                player.func_184609_a(hand);
            }
        }
        return EnumActionResult.PASS;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/magicallantern", "inventory"));
    }
}
