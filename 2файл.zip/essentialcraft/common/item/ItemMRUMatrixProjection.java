package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.util.text.*;
import essentialcraft.utils.common.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemMRUMatrixProjection extends Item implements IModelRegisterer
{
    public static String[] names;
    
    public ItemMRUMatrixProjection() {
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return super.func_77667_c(stack) + "_" + ItemMRUMatrixProjection.names[Math.min(stack.func_77952_i(), ItemMRUMatrixProjection.names.length - 1)];
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        if (stack.func_77978_p() != null) {
            final String username = stack.func_77978_p().func_74779_i("playerName");
            if (username.equals(MiscUtils.getUUIDFromPlayer(player).toString())) {
                player.func_184598_c(hand);
            }
        }
        if (stack.func_77978_p() == null && !world.field_72995_K && !player.func_70093_af()) {
            final NBTTagCompound playerTag = new NBTTagCompound();
            playerTag.func_74778_a("playerName", MiscUtils.getUUIDFromPlayer(player).toString());
            stack.func_77982_d(playerTag);
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World world, final List<String> list, final ITooltipFlag flag) {
        if (stack.func_77978_p() != null) {
            final String username = MiscUtils.getUsernameFromUUID(stack.func_77978_p().func_74779_i("playerName"));
            list.add(TextFormatting.DARK_GRAY + "Thus is a projection of " + TextFormatting.GOLD + username + TextFormatting.DARK_GRAY + "'s MRU Matrix");
        }
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 5; ++i) {
                items.add((Object)new ItemStack((Item)this, 1, i));
            }
        }
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        return EnumAction.BLOCK;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 200;
    }
    
    public void onUsingTick(final ItemStack stack, final EntityLivingBase player, final int count) {
        if (count % 40 == 0) {
            player.func_184185_a(SoundEvents.field_187812_eh, 0.3f, 2.0f);
            player.func_184185_a(SoundEvents.field_187814_ei, 0.3f, 2.0f);
        }
        if (count == 100) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76431_k, 200, 0, true, true));
        }
        if (count <= 50) {
            player.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 2000, 0, true, true));
        }
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase entity) {
        if (entity instanceof EntityPlayer) {
            entity.func_184185_a(SoundEvents.field_187814_ei, 0.3f, 0.01f);
            entity.func_70690_d(new PotionEffect(MobEffects.field_82731_v, 760, 0, true, true));
            entity.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 760, 4, true, true));
            entity.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 760, 4, true, true));
            entity.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 760, 4, true, true));
            entity.func_70690_d(new PotionEffect(MobEffects.field_76438_s, 760, 0, true, true));
            if (!entity.func_130014_f_().field_72995_K) {
                entity.func_145747_a(new TextComponentString("Your MRU Matrix twists with new colors!").func_150255_a(new Style().func_150238_a(TextFormatting.AQUA)));
                ECUtils.getData((EntityPlayer)entity).modifyMatrixType(stack.func_77952_i());
            }
            stack.func_190918_g(1);
        }
        return stack;
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemMRUMatrixProjection.names.length; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/mrumatrixprojection", "type=" + ItemMRUMatrixProjection.names[i]));
        }
    }
    
    static {
        ItemMRUMatrixProjection.names = new String[] { "empty", "chaos", "frozen", "magic", "shade" };
    }
}
