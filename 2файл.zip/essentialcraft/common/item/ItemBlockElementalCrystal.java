package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import DummyCore.Utils.*;

public class ItemBlockElementalCrystal extends ItemBlock implements IItemColor
{
    public ItemBlockElementalCrystal(final Block block) {
        super(block);
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    public int getColorFromItemstack(final ItemStack stack, final int tintIndex) {
        double fire = 0.0;
        double water = 0.0;
        double earth = 0.0;
        double air = 0.0;
        double neutral = 10.0;
        if (MiscUtils.getStackTag(stack) != null) {
            fire = MiscUtils.getStackTag(stack).func_74760_g("fire");
            water = MiscUtils.getStackTag(stack).func_74760_g("water");
            earth = MiscUtils.getStackTag(stack).func_74760_g("earth");
            air = MiscUtils.getStackTag(stack).func_74760_g("air");
        }
        final double total = fire + water + earth + air + neutral;
        fire /= total;
        water /= total;
        earth /= total;
        air /= total;
        neutral /= total;
        final double red = 0.5098039215686274 * fire + 0.19607843137254902 * water + 0.06666666666666667 * earth + 0.5215686274509804 * air + 0.8352941176470589 * neutral;
        final double green = 0.12941176470588237 * fire + 0.596078431372549 * water + 0.30980392156862746 * earth + 0.5529411764705883 * air + 0.9529411764705882 * neutral;
        final double blue = 0.043137254901960784 * fire + 0.8313725490196079 * water + 0.10980392156862745 * earth + 0.5725490196078431 * air + 0.9568627450980393 * neutral;
        return ((int)(red * 255.0) << 16) + ((int)(blue * 255.0) << 8) + (int)(green * 255.0);
    }
}
