package essentialcraft.common.item;

import net.minecraft.block.*;
import net.minecraft.item.*;
import essentialcraft.common.block.*;

public class ItemBlockRDNS extends ItemBlock
{
    public ItemBlockRDNS(final Block block) {
        super(block);
        this.func_77627_a(true);
        this.func_77656_e(0);
    }
    
    public int func_77647_b(final int damage) {
        return damage;
    }
    
    public String func_77667_c(final ItemStack stack) {
        return super.func_77667_c(stack) + "." + BlockRedstoneDeviceNotSided.NAMES[stack.func_77952_i()];
    }
}
