package essentialcraft.common.item;

import DummyCore.Client.*;
import essentialcraft.api.*;
import net.minecraft.world.*;
import java.util.*;
import net.minecraft.client.util.*;
import net.minecraftforge.fml.relauncher.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import essentialcraft.common.capabilities.mru.*;

public class ItemHolyMace extends ItemSword implements IModelRegisterer
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public int maxMRU;
    
    public ItemHolyMace() {
        super(ItemsCore.elemental);
        this.maxMRU = 5000;
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
        this.func_77656_e(0);
    }
    
    public boolean func_77616_k(final ItemStack stack) {
        return true;
    }
    
    @SideOnly(Side.CLIENT)
    public void func_77624_a(final ItemStack stack, final World player, final List<String> list, final ITooltipFlag par4) {
        super.func_77624_a(stack, player, (List)list, par4);
        list.add(((IMRUHandlerItem)stack.getCapability((Capability)ItemHolyMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() + "/" + ((IMRUHandlerItem)stack.getCapability((Capability)ItemHolyMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMaxMRU() + " MRU");
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            final ItemStack min = new ItemStack((Item)this, 1, 0);
            final ItemStack max = new ItemStack((Item)this, 1, 0);
            ((IMRUHandlerItem)min.getCapability((Capability)ItemHolyMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(0);
            ((IMRUHandlerItem)max.getCapability((Capability)ItemHolyMace.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).setMRU(this.maxMRU);
            items.add((Object)min);
            items.add((Object)max);
        }
    }
    
    public boolean func_77644_a(final ItemStack stack, final EntityLivingBase target, final EntityLivingBase attacker) {
        return attacker instanceof EntityPlayer && ECUtils.playerUseMRU((EntityPlayer)attacker, stack, 250);
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stk) {
        final Multimap<String, AttributeModifier> multimap = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (s == EntityEquipmentSlot.MAINHAND) {
            multimap.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemHolyMace.field_111210_e, "Weapon modifier", 12.0, 0));
            multimap.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemHolyMace.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return multimap;
    }
    
    public ICapabilityProvider initCapabilities(final ItemStack stack, final NBTTagCompound nbt) {
        return (ICapabilityProvider)new MRUItemStorage(stack, this.maxMRU);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/holymace", "inventory"));
    }
    
    static {
        ItemHolyMace.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
    }
}
