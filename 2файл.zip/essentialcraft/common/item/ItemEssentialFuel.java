package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemEssentialFuel extends Item implements IModelRegisterer
{
    public String[] name;
    
    public ItemEssentialFuel() {
        this.name = new String[] { "Fiery", "Watery", "Earthen", "Windy", "Unknown" };
        this.func_77656_e(0);
        this.field_77777_bU = 16;
        this.field_77789_bW = false;
        this.func_77627_a(true);
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < 4; ++i) {
                final ItemStack min = new ItemStack((Item)this, 1, i);
                items.add((Object)min);
            }
        }
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + this.name[Math.min(stack.func_77952_i(), this.name.length - 1)];
    }
    
    public EnumRarity func_77613_e(final ItemStack stack) {
        return EnumRarity.RARE;
    }
    
    public void registerModels() {
        for (int i = 0; i < this.name.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/elementalfuel", "type=" + this.name[i].toLowerCase(Locale.ENGLISH)));
        }
    }
}
