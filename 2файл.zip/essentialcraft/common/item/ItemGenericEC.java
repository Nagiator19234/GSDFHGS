package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import baubles.api.*;
import essentialcraft.api.*;
import net.minecraft.init.*;
import baubles.api.cap.*;
import net.minecraft.item.*;
import net.minecraft.creativetab.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemGenericEC extends Item implements IModelRegisterer
{
    public static String[] names;
    
    public ItemGenericEC() {
        this.func_77656_e(0);
        this.func_77627_a(true);
    }
    
    public ItemStack func_77654_b(final ItemStack stack, final World world, final EntityLivingBase base) {
        if (base instanceof EntityPlayer) {
            if (!((EntityPlayer)base).field_71075_bZ.field_75098_d) {
                stack.func_190918_g(1);
            }
            if (!world.field_72995_K && stack.func_77952_i() == 6) {
                int addedEnergy = 0;
                final IBaublesItemHandler b = BaublesApi.getBaublesHandler((EntityPlayer)base);
                if (b != null) {
                    for (int i = 0; i < b.getSlots(); ++i) {
                        final ItemStack is = b.getStackInSlot(i);
                        if (is.func_77973_b() instanceof ItemBaublesSpecial && is.func_77952_i() == 8) {
                            addedEnergy = 500;
                        }
                    }
                }
                final int current = ApiCore.getPlayerData((EntityPlayer)base).getPlayerUBMRU();
                ApiCore.getPlayerData((EntityPlayer)base).modifyUBMRU(current + addedEnergy);
            }
        }
        return (stack.func_190916_E() <= 0) ? new ItemStack(Items.field_151069_bo) : stack;
    }
    
    public int func_77626_a(final ItemStack stack) {
        return 32;
    }
    
    public EnumAction func_77661_b(final ItemStack stack) {
        if (stack.func_77952_i() == 6) {
            return EnumAction.DRINK;
        }
        return super.func_77661_b(stack);
    }
    
    public static ItemStack getStkByName(final String name) {
        final List<String> lst = Arrays.asList(ItemGenericEC.names);
        if (lst.contains(name)) {
            final ItemStack stk = new ItemStack(ItemsCore.genericItem, 1, lst.indexOf(name));
            return stk;
        }
        return ItemStack.field_190927_a;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World worldIn, final EntityPlayer playerIn, final EnumHand hand) {
        if (playerIn.func_184586_b(hand).func_77952_i() == 6) {
            playerIn.func_184598_c(hand);
        }
        return (ActionResult<ItemStack>)super.func_77659_a(worldIn, playerIn, hand);
    }
    
    public String func_77667_c(final ItemStack stack) {
        return this.func_77658_a() + ItemGenericEC.names[Math.min(stack.func_77952_i(), ItemGenericEC.names.length - 1)];
    }
    
    public void func_150895_a(final CreativeTabs tab, final NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (int i = 0; i < ItemGenericEC.names.length - 1; ++i) {
                items.add((Object)new ItemStack((Item)this, 1, i));
            }
        }
    }
    
    public void registerModels() {
        for (int i = 0; i < ItemGenericEC.names.length - 1; ++i) {
            ModelLoader.setCustomModelResourceLocation((Item)this, i, new ModelResourceLocation("essentialcraft:item/genitem", "type=" + ItemGenericEC.names[i].toLowerCase(Locale.ENGLISH)));
        }
    }
    
    static {
        ItemGenericEC.names = new String[] { "combinedMagicalAlloys", "elementalCore", "enderScalePlating", "magicalEssence", "magicalGoldenOrb", "magicalIngot", "magicalWater", "magicFortifiedPlating", "magicPurifyedEnderScaleAlloy", "magicPurifyedGlassAlloy", "magicPurifyedGoldAlloy", "magicPurifyedRedstoneAlloy", "mruShard", "mruCrystal", "mruGem", "mruChunk", "mruLargeChunk", "inventoryUpgrade", "efficencyUpgrade", "diamondUpgrade", "crystalDust", "diamondPlate", "emeraldPlate", "eyeOfAbsorbtion", "fortifiedFrame", "heatingRod", "ironSupport", "magicalScreen", "matrixLink", "mruCatcher", "mruConversionMatrix", "obsidianPlate", "sunImbuedGlass", "worldInteractor", "magicPlate", "voidPlating", "voidCore", "voidMruReactor", "palePearl", "paleIngot", "gemPale", "palePlate", "paleCore", "mruMagnet", "mruResonatingCrystal", "lapisCore", "fadingDust", "fadingCrystal", "mithrilineCrystal", "mithrilinePlate", "mithrilineIngot", "mithrilineDust", "ackroniteIngot", "demonicCore", "demonicPlate", "windGem", "computerEngine", "forceFieldGenerator", "forceFieldPlating", "neuronicEnrichedPlating", "pressureStabiliser", "repulsionGenerator", "thrusterEngine", "visionLense", "speakerPlate", "forcefieldCore", "particleCatcher", "particleEmitter", "forceEmitter", "logicCore", "additionCore", "divisionCore", "multiplicationCore", "substructionCore", "forceAbsorber", "soundManager", "glitchyCore", "blazingUpgrade", "fortuneUpgrade", "magicPurifyedBlazeAlloy", "silkyUpgrade", "voidUpgrade", "unknown" };
    }
}
