package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.text.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;

public class ItemWindKeeper extends Item implements IModelRegisterer
{
    public int rel;
    
    public ItemWindKeeper(final int windReleased) {
        this.rel = windReleased;
    }
    
    public ActionResult<ItemStack> func_77659_a(final World world, final EntityPlayer player, final EnumHand hand) {
        final ItemStack stack = player.func_184586_b(hand);
        stack.func_190918_g(1);
        player.func_184185_a(SoundEvents.field_187561_bM, 1.0f, 1.0f);
        if (!world.field_72995_K) {
            WindRelations.increasePlayerWindRelations(player, this.rel);
            player.func_145747_a(new TextComponentString("You hear a very pale 'Thank you'...").func_150255_a(new Style().func_150238_a(TextFormatting.DARK_AQUA).func_150217_b(Boolean.valueOf(true))));
        }
        return (ActionResult<ItemStack>)super.func_77659_a(world, player, hand);
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/" + this.getRegistryName().func_110623_a(), "inventory"));
    }
}
