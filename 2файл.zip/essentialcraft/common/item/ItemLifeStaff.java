package essentialcraft.common.item;

import DummyCore.Client.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import essentialcraft.utils.common.*;
import essentialcraft.api.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.entity.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraftforge.client.model.*;
import net.minecraft.item.*;

public class ItemLifeStaff extends ItemMRUGeneric implements IModelRegisterer
{
    public ItemLifeStaff() {
        this.field_77777_bU = 1;
        this.field_77789_bW = true;
    }
    
    public EnumActionResult func_180614_a(final EntityPlayer player, final World world, final BlockPos pos, final EnumHand hand, final EnumFacing side, final float hitX, final float hitY, final float hitZ) {
        final ItemStack stack = player.func_184586_b(hand);
        if (ECUtils.playerUseMRU(player, stack, 100) && ItemDye.applyBonemeal(new ItemStack(stack.func_77973_b(), stack.func_77952_i(), stack.func_190916_E() + 1), world, pos, player, hand)) {
            for (int px = -5; px <= 5; ++px) {
                for (int pz = -5; pz <= 5; ++pz) {
                    if (((IMRUHandlerItem)stack.getCapability((Capability)ItemLifeStaff.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)).getMRU() >= 100 && ItemDye.applyBonemeal(new ItemStack(stack.func_77973_b(), stack.func_77952_i(), stack.func_190916_E() + 1), world, pos.func_177982_a(px, 0, pz), player, hand)) {
                        ECUtils.playerUseMRU(player, stack, 100);
                    }
                }
            }
        }
        return EnumActionResult.PASS;
    }
    
    public boolean onLeftClickEntity(final ItemStack stack, final EntityPlayer player, final Entity entity) {
        if (entity instanceof EntityZombieVillager) {
            final EntityZombieVillager e = (EntityZombieVillager)entity;
            if (ECUtils.playerUseMRU(player, stack, 500) && !e.func_130014_f_().field_72995_K) {
                final EntityVillager entityvillager = new EntityVillager(e.func_130014_f_());
                entityvillager.func_82149_j((Entity)e);
                entityvillager.func_180482_a(entity.func_130014_f_().func_175649_E(entity.func_180425_c()), (IEntityLivingData)null);
                if (e.func_70631_g_()) {
                    entityvillager.func_70873_a(-24000);
                }
                e.func_130014_f_().func_72900_e((Entity)e);
                e.func_130014_f_().func_72838_d((Entity)entityvillager);
                entityvillager.func_70690_d(new PotionEffect(MobEffects.field_76431_k, 200, 0));
                e.func_130014_f_().func_180498_a((EntityPlayer)null, 1017, e.func_180425_c(), 0);
            }
            return true;
        }
        if (entity instanceof EntityAgeable) {
            final EntityAgeable e2 = (EntityAgeable)entity;
            if (e2.func_70631_g_() && ECUtils.playerUseMRU(player, stack, 100) && !e2.func_130014_f_().field_72995_K) {
                e2.func_70873_a(0);
            }
        }
        return true;
    }
    
    public void registerModels() {
        ModelLoader.setCustomModelResourceLocation((Item)this, 0, new ModelResourceLocation("essentialcraft:item/staffoflife", "inventory"));
    }
}
