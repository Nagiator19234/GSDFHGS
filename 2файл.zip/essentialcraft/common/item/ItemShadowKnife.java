package essentialcraft.common.item;

import essentialcraft.api.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import essentialcraft.common.entity.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import essentialcraft.utils.common.*;
import DummyCore.Client.*;
import net.minecraft.item.*;

public class ItemShadowKnife extends ItemSwordEC
{
    public boolean onEntitySwing(final EntityLivingBase entityLiving, final ItemStack stack) {
        if (stack.func_190916_E() >= 2 && (entityLiving instanceof IShadeHandlerEntity || (entityLiving instanceof EntityPlayer && ECUtils.getData((EntityPlayer)entityLiving).getMatrixTypeID() == 4))) {
            if (!(entityLiving instanceof EntityPlayer) || !((EntityPlayer)entityLiving).field_71075_bZ.field_75098_d) {
                stack.func_190918_g(1);
            }
            if (stack.func_190916_E() <= 0) {
                final EntityEquipmentSlot slot = (entityLiving.field_184622_au == EnumHand.MAIN_HAND) ? EntityEquipmentSlot.MAINHAND : ((entityLiving.field_184622_au == EnumHand.OFF_HAND) ? EntityEquipmentSlot.OFFHAND : null);
                entityLiving.func_184201_a(slot, ItemStack.field_190927_a);
            }
            final EntityShadowKnife knife = new EntityShadowKnife(entityLiving.func_130014_f_(), entityLiving);
            knife.func_184538_a((Entity)entityLiving, entityLiving.field_70125_A, entityLiving.field_70177_z, 0.0f, 1.5f, 1.0f);
            if (!entityLiving.func_130014_f_().field_72995_K) {
                entityLiving.func_130014_f_().func_72838_d((Entity)knife);
            }
        }
        return false;
    }
    
    public ItemShadowKnife() {
        super(ItemsCore.shade);
    }
    
    public void toggleActivity(final ItemStack is, final boolean b) {
        if (!is.func_190926_b()) {
            final NBTTagCompound tag = MiscUtils.getStackTag(is);
            if (tag.func_74767_n("active") != b) {
                tag.func_74757_a("active", b);
            }
        }
    }
    
    public boolean onEntityItemUpdate(final EntityItem entityItem) {
        this.toggleActivity(entityItem.func_92059_d(), false);
        return super.onEntityItemUpdate(entityItem);
    }
    
    public void func_77663_a(final ItemStack sword, final World w, final Entity e, final int slotNum, final boolean held) {
        if (e.field_70173_aa % 20 == 0 && !w.field_72995_K && held) {
            sword.func_190917_f(1);
            if (sword.func_190916_E() >= 32) {
                sword.func_190920_e(32);
            }
        }
        if (e instanceof IShadeHandlerEntity) {
            this.toggleActivity(sword, true);
        }
        if (e instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)e;
            if (ECUtils.getData(p).getMatrixTypeID() == 4) {
                this.toggleActivity(sword, true);
            }
            else {
                this.toggleActivity(sword, false);
            }
        }
    }
    
    public Multimap<String, AttributeModifier> getAttributeModifiers(final EntityEquipmentSlot s, final ItemStack stack) {
        final Multimap<String, AttributeModifier> mp = (Multimap<String, AttributeModifier>)HashMultimap.create();
        if (MiscUtils.getStackTag(stack).func_74767_n("active") && s == EntityEquipmentSlot.MAINHAND) {
            mp.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemShadowKnife.field_111210_e, "Weapon modifier", 12.0, 0));
            mp.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemShadowKnife.field_185050_h, "Weapon modifier", -2.4, 0));
        }
        return mp;
    }
    
    public boolean isItemTool(final ItemStack stack) {
        return true;
    }
    
    public boolean func_77644_a(final ItemStack weapon, final EntityLivingBase attacked, final EntityLivingBase attacker) {
        if (attacker instanceof IShadeHandlerEntity && attacked instanceof EntityPlayer) {
            final EntityPlayer p = (EntityPlayer)attacked;
            ShadeUtils.attackPlayerWithShade(p, attacker, weapon);
        }
        return false;
    }
    
    @Override
    public void registerModels() {
        ModelUtils.setItemModelNBTActive((Item)this, new String[] { "essentialcraft:item/shadeknife" });
    }
}
