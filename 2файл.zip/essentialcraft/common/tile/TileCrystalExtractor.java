package essentialcraft.common.tile;

import essentialcraft.common.item.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.tileentity.*;
import net.minecraftforge.common.config.*;

public class TileCrystalExtractor extends TileMRUGeneric
{
    public int progressLevel;
    public static int cfgMaxMRU;
    public static int mruUsage;
    public static int requiredTime;
    
    public TileCrystalExtractor() {
        super(TileCrystalExtractor.cfgMaxMRU);
        this.setSlotsNum(13);
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            this.doWork();
        }
        this.spawnParticles();
    }
    
    public void doWork() {
        if (this.canWork() && this.mruStorage.getMRU() >= TileCrystalExtractor.mruUsage) {
            this.mruStorage.extractMRU(TileCrystalExtractor.mruUsage, true);
            ++this.progressLevel;
            if (this.progressLevel >= TileCrystalExtractor.requiredTime) {
                this.progressLevel = 0;
                this.createItems();
            }
        }
    }
    
    public void createItems() {
        final TileElementalCrystal t = this.getCrystal();
        final double f = t.fire;
        final double w = t.water;
        final double e = t.earth;
        final double a = t.air;
        final double s = t.size * 3000.0;
        final double[] baseChance = { f, w, e, a };
        final int[] essenceChance = { 37500, 50000, 75000, 150000 };
        final int[] getChance = new int[16];
        for (int i = 0; i < 16; ++i) {
            getChance[i] = (int)(s * baseChance[i % 4] / essenceChance[i / 4]);
        }
        for (int i = 1; i < 13; ++i) {
            final ItemStack st = new ItemStack(ItemsCore.essence, 1, this.func_145831_w().field_73012_v.nextInt(16));
            if (this.func_145831_w().field_73012_v.nextInt(100) < getChance[st.func_77952_i()]) {
                final int sts = this.func_145831_w().field_73012_v.nextInt(1 + getChance[st.func_77952_i()] / 4);
                st.func_190920_e(sts);
                if (st.func_190916_E() <= 0) {
                    st.func_190920_e(1);
                }
                this.func_70299_a(i, st);
            }
        }
    }
    
    public boolean canWork() {
        for (int i = 1; i < 13; ++i) {
            if (!this.func_70301_a(i).func_190926_b()) {
                return false;
            }
        }
        return this.getCrystal() != null;
    }
    
    public boolean hasItemInSlots() {
        for (int i = 1; i < 13; ++i) {
            if (!this.func_70301_a(i).func_190926_b()) {
                return true;
            }
        }
        return false;
    }
    
    public void spawnParticles() {
        if (this.field_145850_b.field_72995_K && this.canWork() && this.mruStorage.getMRU() > 0) {
            final TileElementalCrystal t = this.getCrystal();
            if (t != null) {
                for (int o = 0; o < 10; ++o) {
                    this.func_145831_w().func_175688_a(EnumParticleTypes.PORTAL, this.field_174879_c.func_177958_n() + this.func_145831_w().field_73012_v.nextDouble(), t.func_174877_v().func_177956_o() + this.func_145831_w().field_73012_v.nextDouble(), this.field_174879_c.func_177952_p() + this.func_145831_w().field_73012_v.nextDouble(), (double)(t.func_174877_v().func_177958_n() - this.field_174879_c.func_177958_n()), 0.0, (double)(t.func_174877_v().func_177952_p() - this.field_174879_c.func_177952_p()), new int[0]);
                }
            }
        }
    }
    
    public TileElementalCrystal getCrystal() {
        TileElementalCrystal t = null;
        if (this.hasCrystalOnEast()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177974_f());
        }
        if (this.hasCrystalOnWest()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177976_e());
        }
        if (this.hasCrystalOnSouth()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177968_d());
        }
        if (this.hasCrystalOnNorth()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177978_c());
        }
        return t;
    }
    
    public boolean hasCrystalOnEast() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177974_f());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnWest() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177976_e());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnSouth() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177968_d());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnNorth() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177978_c());
        return t instanceof TileElementalCrystal;
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.crystalextractor";
            TileCrystalExtractor.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileCrystalExtractor.mruUsage = cfg.get(category, "MRUUsage", 100).setMinValue(0).setMaxValue(TileCrystalExtractor.cfgMaxMRU).getInt();
            TileCrystalExtractor.requiredTime = cfg.get(category, "RequiredTicks", 1000, "Ticks required to get an essence").setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return slot == 0 && this.isBoundGem(stack);
    }
    
    static {
        TileCrystalExtractor.cfgMaxMRU = 5000;
        TileCrystalExtractor.mruUsage = 100;
        TileCrystalExtractor.requiredTime = 1000;
    }
}
