package essentialcraft.common.tile;

import net.minecraftforge.common.capabilities.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraftforge.common.config.*;
import essentialcraft.common.capabilities.mru.*;

public class TileChargingChamber extends TileMRUGeneric
{
    public static Capability<IMRUHandlerItem> MRU_HANDLER_ITEM_CAPABILITY;
    public static int cfgMaxMRU;
    public static double reqMRUModifier;
    
    public TileChargingChamber() {
        super(TileChargingChamber.cfgMaxMRU);
        this.setSlotsNum(2);
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            this.tryChargeTools();
        }
    }
    
    public void tryChargeTools() {
        final ItemStack stack = this.func_70301_a(1);
        if (!stack.func_190926_b() && stack.hasCapability((Capability)TileChargingChamber.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null)) {
            final IMRUHandlerItem mruHandler = (IMRUHandlerItem)stack.getCapability((Capability)TileChargingChamber.MRU_HANDLER_ITEM_CAPABILITY, (EnumFacing)null);
            final int mru = mruHandler.getMRU();
            final int maxMRU = mruHandler.getMaxMRU();
            final int p = (int)(maxMRU / 20.0);
            if (mru < maxMRU) {
                if (mru + p < maxMRU) {
                    final int amount = (int)(this.mruStorage.extractMRU((int)(p * TileChargingChamber.reqMRUModifier), true) / TileChargingChamber.reqMRUModifier);
                    mruHandler.addMRU(amount, true);
                }
                else {
                    final int k = maxMRU - mru;
                    final int amount2 = (int)(this.mruStorage.extractMRU((int)(k * TileChargingChamber.reqMRUModifier), true) / TileChargingChamber.reqMRUModifier);
                    mruHandler.addMRU(amount2, true);
                }
            }
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.chargingchamber";
            TileChargingChamber.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileChargingChamber.reqMRUModifier = cfg.get(category, "ChargeCostModifier", 1.0).setMinValue(Double.MIN_NORMAL).getDouble();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 1 };
    }
    
    static {
        TileChargingChamber.MRU_HANDLER_ITEM_CAPABILITY = CapabilityMRUHandler.MRU_HANDLER_ITEM_CAPABILITY;
        TileChargingChamber.cfgMaxMRU = 5000;
        TileChargingChamber.reqMRUModifier = 1.0;
    }
}
