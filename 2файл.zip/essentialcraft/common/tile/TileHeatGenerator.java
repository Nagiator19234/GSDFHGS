package essentialcraft.common.tile;

import net.minecraft.block.*;
import net.minecraft.init.*;
import essentialcraft.api.*;
import net.minecraft.world.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.config.*;

public class TileHeatGenerator extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static float cfgBalance;
    public static int mruGenerated;
    public int currentBurnTime;
    public int currentMaxBurnTime;
    private boolean firstTick;
    
    public TileHeatGenerator() {
        super(TileHeatGenerator.cfgMaxMRU);
        this.firstTick = true;
        this.slot0IsBoundGem = false;
        this.setSlotsNum(2);
    }
    
    @Override
    public void func_73660_a() {
        if (this.firstTick) {
            if (TileHeatGenerator.cfgBalance < 0.0f) {
                this.mruStorage.setBalance(this.func_145831_w().field_73012_v.nextFloat() * 2.0f);
            }
            else {
                this.mruStorage.setBalance(TileHeatGenerator.cfgBalance);
            }
        }
        super.func_73660_a();
        this.firstTick = false;
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            if (this.currentBurnTime > 0) {
                --this.currentBurnTime;
                double mruGen = TileHeatGenerator.mruGenerated;
                double mruFactor = 1.0;
                final Block[] b = { this.func_145831_w().func_180495_p(this.field_174879_c.func_177965_g(2)).func_177230_c(), this.func_145831_w().func_180495_p(this.field_174879_c.func_177985_f(2)).func_177230_c(), this.func_145831_w().func_180495_p(this.field_174879_c.func_177970_e(2)).func_177230_c(), this.func_145831_w().func_180495_p(this.field_174879_c.func_177964_d(2)).func_177230_c() };
                final int[] ox = { 2, -2, 0, 0 };
                final int[] oz = { 0, 0, 2, -2 };
                for (int i = 0; i < 4; ++i) {
                    if (b[i] == Blocks.field_150350_a) {
                        mruFactor *= 0.0;
                    }
                    else if (b[i] == Blocks.field_150424_aL) {
                        mruFactor *= 0.75;
                    }
                    else if (b[i] == Blocks.field_150353_l) {
                        mruFactor *= 0.95;
                    }
                    else if (b[i] == Blocks.field_150480_ab) {
                        mruFactor *= 0.7;
                    }
                    else if (b[i] instanceof IHotBlock) {
                        mruFactor *= ((IHotBlock)b[i]).getHeatModifier((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177982_a(ox[i], 0, oz[i]));
                    }
                    else {
                        mruFactor *= 0.5;
                    }
                }
                mruGen *= mruFactor;
                if (mruGen >= 1.0) {
                    this.mruStorage.addMRU((int)mruGen, true);
                }
            }
            if (!this.func_70301_a(0).func_190926_b() && this.currentBurnTime == 0 && this.mruStorage.getMRU() < this.mruStorage.getMaxMRU()) {
                final int func_145952_a = TileEntityFurnace.func_145952_a(this.func_70301_a(0));
                this.currentBurnTime = func_145952_a;
                this.currentMaxBurnTime = func_145952_a;
                if (this.currentBurnTime > 0 && !this.func_70301_a(0).func_190926_b()) {
                    if (this.func_70301_a(1).func_190926_b() || this.func_70301_a(1).func_190916_E() < this.func_70297_j_()) {
                        if (this.func_70301_a(1).func_77973_b() == ItemsCore.magicalSlag) {
                            final ItemStack stk = this.func_70301_a(1);
                            stk.func_190917_f(1);
                            this.func_70299_a(1, stk);
                        }
                        if (this.func_70301_a(1).func_190926_b()) {
                            final ItemStack stk = new ItemStack(ItemsCore.magicalSlag, 1, 0);
                            this.func_70299_a(1, stk);
                        }
                    }
                    if (this.func_70301_a(0).func_190916_E() == 0) {
                        this.func_70299_a(0, this.func_70301_a(0).func_77973_b().getContainerItem(this.func_70301_a(0)));
                    }
                    this.func_70298_a(0, 1);
                }
            }
        }
        if (this.func_145831_w().field_72995_K) {
            for (int j = 2; j < 6; ++j) {
                final EnumFacing rotation = EnumFacing.func_82600_a(j);
                final float rotXAdv = rotation.func_82601_c() - 0.5f;
                final float rotZAdv = rotation.func_82599_e() - 0.5f;
                EssentialCraftCore.proxy.FlameFX(this.field_174879_c.func_177958_n() + 0.725f + rotXAdv / 2.2f, this.field_174879_c.func_177956_o() + 0.4f, this.field_174879_c.func_177952_p() + 0.725f + rotZAdv / 2.2f, 0.0, 0.0, 0.0, 0.8, 0.5, 0.5, 0.5);
                EssentialCraftCore.proxy.FlameFX(this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.2f, this.field_174879_c.func_177956_o() + 0.65f, this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.2f, 0.0, 0.009999999776482582, 0.0, 0.8, 0.5, 0.5, 1.0);
            }
            EssentialCraftCore.proxy.SmokeFX(this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.05f, this.field_174879_c.func_177956_o() + 0.8f, this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.05f, 0.0, 0.0, 0.0, 1.0);
        }
    }
    
    @Override
    public void func_145839_a(final NBTTagCompound i) {
        this.currentBurnTime = i.func_74762_e("burn");
        this.currentMaxBurnTime = i.func_74762_e("burnMax");
        super.func_145839_a(i);
    }
    
    @Override
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        i.func_74768_a("burn", this.currentBurnTime);
        i.func_74768_a("burnMax", this.currentMaxBurnTime);
        return super.func_189515_b(i);
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.heatgenerator";
            TileHeatGenerator.cfgMaxMRU = cfg.get(category, "MaxMRU", 10000).setMinValue(1).getInt();
            TileHeatGenerator.cfgBalance = (float)cfg.get(category, "Balance", -1.0, "Default balance (-1 is random)").setMinValue(-1.0).setMinValue(2.0).getDouble();
            TileHeatGenerator.mruGenerated = cfg.get(category, "MRUGenerated", 20, "Max MRU generated per tick").setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 1 };
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return slot == 0;
    }
    
    static {
        TileHeatGenerator.cfgMaxMRU = 10000;
        TileHeatGenerator.cfgBalance = -1.0f;
        TileHeatGenerator.mruGenerated = 20;
    }
}
