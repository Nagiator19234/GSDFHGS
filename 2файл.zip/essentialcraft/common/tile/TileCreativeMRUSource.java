package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import net.minecraftforge.common.config.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.common.capabilities.mru.*;

public class TileCreativeMRUSource extends TileEntity implements ITickable
{
    public static int cfgMaxMRU;
    protected MRUTileStorage mruStorage;
    
    public TileCreativeMRUSource() {
        this.mruStorage = new MRUTileStorage(TileCreativeMRUSource.cfgMaxMRU);
    }
    
    public void func_73660_a() {
        this.mruStorage.setMRU(this.mruStorage.getMaxMRU());
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.creativemrusource";
            TileCreativeMRUSource.cfgMaxMRU = cfg.get(category, "MaxMRU", 1000000).setMinValue(1).getInt();
        }
        catch (Exception e) {}
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityMRUHandler.MRU_HANDLER_CAPABILITY || super.hasCapability((Capability)capability, facing);
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityMRUHandler.MRU_HANDLER_CAPABILITY) ? this.mruStorage : super.getCapability((Capability)capability, facing));
    }
    
    static {
        TileCreativeMRUSource.cfgMaxMRU = 1000000;
    }
}
