package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import java.util.function.*;
import essentialcraft.common.capabilities.espe.*;
import net.minecraftforge.common.capabilities.*;
import essentialcraft.api.*;
import essentialcraft.common.entity.*;
import net.minecraft.util.math.*;
import essentialcraft.common.mod.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.world.*;
import essentialcraft.common.block.*;
import net.minecraft.init.*;

public class TileDemonicPentacle extends TileEntity implements ITickable
{
    public int tier;
    public int sCheckTick;
    protected static Vec3i[] coords;
    protected static BiPredicate<IBlockAccess, BlockPos> tier0Checker;
    
    public TileDemonicPentacle() {
        this.tier = -1;
        this.sCheckTick = 0;
    }
    
    public boolean consumeEnderstarEnergy(final int consumed) {
        double aconsumed = 0.0;
        for (final Vec3i coord : TileDemonicPentacle.coords) {
            final TileEntity tile = this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(coord));
            if (tile != null) {
                if (tile.hasCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IESPEHandler handler = (IESPEHandler)tile.getCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null);
                    final double req = consumed - aconsumed;
                    aconsumed += handler.extractESPE(req, false);
                    if (aconsumed >= consumed) {
                        break;
                    }
                }
            }
        }
        if (aconsumed < consumed) {
            return false;
        }
        aconsumed = 0.0;
        for (final Vec3i coord : TileDemonicPentacle.coords) {
            final TileEntity tile = this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(coord));
            if (tile != null) {
                if (tile.hasCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IESPEHandler handler = (IESPEHandler)tile.getCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null);
                    final double req = consumed - aconsumed;
                    aconsumed += handler.extractESPE(req, true);
                    if (aconsumed >= consumed) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public int getEnderstarEnergy() {
        if (this.tier == -1) {
            return 0;
        }
        double energy = 0.0;
        for (final Vec3i coord : TileDemonicPentacle.coords) {
            final TileEntity tile = this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(coord));
            if (tile != null) {
                if (tile.hasCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null)) {
                    final IESPEHandler handler = (IESPEHandler)tile.getCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null);
                    energy += handler.getESPE();
                }
            }
        }
        return MathHelper.func_76128_c(energy);
    }
    
    public void func_73660_a() {
        final List<EntityDemon> demons = (List<EntityDemon>)this.func_145831_w().func_72872_a((Class)EntityDemon.class, new AxisAlignedBB(this.field_174879_c));
        if (!demons.isEmpty()) {
            for (int i = 0; i < 4; ++i) {
                final int time = (int)((this.func_145831_w().func_72820_D() + 9 * i) % 36L) * 10;
                final double timeSin = Math.sin(Math.toRadians(time)) * 1.1;
                final double timeCos = Math.cos(Math.toRadians(time)) * 1.1;
                final double x = this.field_174879_c.func_177958_n() + 0.5 + timeSin;
                final double y = this.field_174879_c.func_177956_o();
                final double z = this.field_174879_c.func_177952_p() + 0.5 + timeCos;
                EssentialCraftCore.proxy.SmokeFX(x, y, z, 0.0, 0.1, 0.0, 1.0, 1.0, 0.0, 0.0);
            }
        }
        if (this.sCheckTick == 0) {
            this.checkStructureAndTier();
            this.sCheckTick = 40;
        }
        else {
            --this.sCheckTick;
        }
        if (this.func_145831_w().field_72995_K && this.tier >= 0) {
            int movement = (int)(this.func_145831_w().func_72820_D() % 60L);
            if (movement > 30) {
                movement = 60 - movement;
            }
            for (int j = 0; j < 4; ++j) {
                if (this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(TileDemonicPentacle.coords[j])) instanceof TileMithrilineCrystal) {
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, -1.0, 1.0, 0.0, new int[0]);
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + 2 + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, -1.0, 1.0, 0.0, new int[0]);
                }
            }
            for (int j = 4; j < 12; ++j) {
                if (this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(TileDemonicPentacle.coords[j])) instanceof TileMithrilineCrystal) {
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, -1.0, 0.0, 1.0, new int[0]);
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + 2 + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, -1.0, 0.0, 1.0, new int[0]);
                }
            }
            for (int j = 12; j < 16; ++j) {
                if (this.func_145831_w().func_175625_s(this.field_174879_c.func_177971_a(TileDemonicPentacle.coords[j])) instanceof TileMithrilineCrystal) {
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, 0.1, 0.0, 0.1, new int[0]);
                    this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + TileDemonicPentacle.coords[j].func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + TileDemonicPentacle.coords[j].func_177956_o() + 2 + movement / 30.0, this.field_174879_c.func_177952_p() + TileDemonicPentacle.coords[j].func_177952_p() + 0.5, 0.1, 0.0, 0.1, new int[0]);
                }
            }
        }
    }
    
    protected static boolean testBlock(final IBlockAccess world, final BlockPos pos, final Block block) {
        return world.func_180495_p(pos).func_177230_c() == block;
    }
    
    protected static boolean testESPEHandler(final IBlockAccess world, final BlockPos pos, final int minTier) {
        final TileEntity tile = world.func_175625_s(pos);
        return tile != null && tile.hasCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null) && ((IESPEHandler)tile.getCapability((Capability)CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY, (EnumFacing)null)).getTier() >= minTier;
    }
    
    public void checkStructureAndTier() {
        final World w = this.func_145831_w();
        final BlockPos cp = this.field_174879_c.func_177977_b();
        this.tier = -1;
        if (TileDemonicPentacle.tier0Checker.test((IBlockAccess)w, cp)) {
            this.tier = 0;
        }
    }
    
    static {
        TileDemonicPentacle.coords = new Vec3i[] { new Vec3i(2, 1, 2), new Vec3i(2, 1, -2), new Vec3i(-2, 1, 2), new Vec3i(-2, 1, -2), new Vec3i(3, 0, 2), new Vec3i(3, 0, -2), new Vec3i(-3, 0, 2), new Vec3i(-3, 0, -2), new Vec3i(2, 0, 3), new Vec3i(2, 0, -3), new Vec3i(-2, 0, 3), new Vec3i(-2, 0, -3), new Vec3i(3, 1, 0), new Vec3i(-3, 1, 0), new Vec3i(0, 1, 3), new Vec3i(0, 1, -3) };
        TileDemonicPentacle.tier0Checker = ((w, cp) -> testBlock(w, cp.func_177982_a(0, 0, 0), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(2, 0, 0), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(-2, 0, 0), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(0, 0, -2), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(0, 0, 2), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(3, 0, 1), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(3, 0, -1), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(-3, 0, 1), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(-3, 0, -1), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(1, 0, 3), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(-1, 0, 3), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(1, 0, -3), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(-1, 0, -3), BlocksCore.voidStone) && testBlock(w, cp.func_177982_a(3, 1, 0), Blocks.field_150426_aN) && testBlock(w, cp.func_177982_a(-3, 1, 0), Blocks.field_150426_aN) && testBlock(w, cp.func_177982_a(0, 1, 3), Blocks.field_150426_aN) && testBlock(w, cp.func_177982_a(0, 1, -3), Blocks.field_150426_aN) && testBlock(w, cp.func_177982_a(2, 1, 2), BlocksCore.invertedBlock) && testBlock(w, cp.func_177982_a(-2, 1, 2), BlocksCore.invertedBlock) && testBlock(w, cp.func_177982_a(2, 1, -2), BlocksCore.invertedBlock) && testBlock(w, cp.func_177982_a(-2, 1, -2), BlocksCore.invertedBlock) && testBlock(w, cp.func_177982_a(1, 0, 0), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-1, 0, 0), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(0, 0, 1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(0, 0, -1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(2, 0, 1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(2, 0, -1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-2, 0, 1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-2, 0, -1), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(1, 0, 2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(1, 0, -2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-1, 0, 2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-1, 0, -2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(3, 0, 2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(3, 0, -2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-3, 0, 2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-3, 0, -2), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(2, 0, 3), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(2, 0, -3), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-2, 0, 3), BlocksCore.platingPale) && testBlock(w, cp.func_177982_a(-2, 0, -3), BlocksCore.platingPale) && testESPEHandler(w, cp.func_177982_a(2, 2, 2), 0) && testESPEHandler(w, cp.func_177982_a(-2, 2, 2), 0) && testESPEHandler(w, cp.func_177982_a(2, 2, -2), 0) && testESPEHandler(w, cp.func_177982_a(-2, 2, -2), 0) && testESPEHandler(w, cp.func_177982_a(3, 1, 2), 1) && testESPEHandler(w, cp.func_177982_a(3, 1, -2), 1) && testESPEHandler(w, cp.func_177982_a(-3, 1, 2), 1) && testESPEHandler(w, cp.func_177982_a(-3, 1, -2), 1) && testESPEHandler(w, cp.func_177982_a(2, 1, 3), 1) && testESPEHandler(w, cp.func_177982_a(2, 1, -3), 1) && testESPEHandler(w, cp.func_177982_a(-2, 1, 3), 1) && testESPEHandler(w, cp.func_177982_a(-2, 1, -3), 1) && testESPEHandler(w, cp.func_177982_a(3, 2, 0), 2) && testESPEHandler(w, cp.func_177982_a(-3, 2, 0), 2) && testESPEHandler(w, cp.func_177982_a(0, 2, 3), 2) && testESPEHandler(w, cp.func_177982_a(0, 2, -3), 2));
    }
}
