package essentialcraft.common.tile;

import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.potion.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.init.*;
import essentialcraft.api.*;
import net.minecraft.world.*;
import net.minecraft.block.*;
import net.minecraftforge.common.config.*;

public class TileColdDistillator extends TileMRUGeneric
{
    public static float balanceProduced;
    public static int cfgMaxMRU;
    public static double mruGenModifier;
    public static boolean harmEntities;
    
    public TileColdDistillator() {
        super(TileColdDistillator.cfgMaxMRU);
        this.slot0IsBoundGem = false;
    }
    
    public boolean canGenerateMRU() {
        return false;
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.setBalance(TileColdDistillator.balanceProduced);
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            final int mruGenerated = (int)(this.getMRU() * TileColdDistillator.mruGenModifier);
            this.mruStorage.addMRU(mruGenerated, true);
            if (mruGenerated > 0 && !this.func_145831_w().field_72995_K && TileColdDistillator.harmEntities) {
                this.damageAround();
            }
        }
    }
    
    public void damageAround() {
        final List<EntityLivingBase> l = (List<EntityLivingBase>)this.func_145831_w().func_72872_a((Class)EntityLivingBase.class, new AxisAlignedBB(this.field_174879_c).func_72314_b(3.0, 3.0, 3.0));
        if (!l.isEmpty()) {
            final EntityLivingBase e = l.get(this.func_145831_w().field_73012_v.nextInt(l.size()));
            if (e instanceof EntityPlayer && !((EntityPlayer)e).field_71075_bZ.field_75098_d) {
                e.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 3000, 2));
                e.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 3000, 2));
                e.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 3000, 2));
                if (this.func_145831_w().field_73012_v.nextFloat() < 0.2f) {
                    e.func_70097_a(DamageSource.field_76366_f, 1.0f);
                }
            }
            else if (!(e instanceof EntityPlayer)) {
                e.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 3000, 2));
                e.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 3000, 2));
                e.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 3000, 2));
                if (this.func_145831_w().field_73012_v.nextFloat() < 0.2f) {
                    e.func_70097_a(DamageSource.field_76366_f, 1.0f);
                }
            }
        }
    }
    
    public int getMRU() {
        double i = 0.0;
        for (int x = -3; x <= 3; ++x) {
            for (int z = -3; z <= 3; ++z) {
                for (int y = -3; y <= 3; ++y) {
                    if (this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(x, y, z)).func_177230_c() == Blocks.field_150432_aD) {
                        i += 0.15;
                    }
                    if (this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(x, y, z)).func_177230_c() == Blocks.field_150433_aE) {
                        i += 0.2;
                    }
                    if (this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(x, y, z)).func_177230_c() == Blocks.field_150431_aC) {
                        i += 0.05;
                    }
                    if (this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(x, y, z)).func_177230_c() == Blocks.field_150403_cj) {
                        i += 0.3;
                    }
                    final Block b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(x, y, z)).func_177230_c();
                    if (b != null && b instanceof IColdBlock) {
                        i += ((IColdBlock)b).getColdModifier((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177982_a(x, y, z));
                    }
                }
            }
        }
        return (int)i;
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.colddistillator";
            TileColdDistillator.balanceProduced = (float)cfg.get(category, "Balance", 0.0).setMinValue(0.0).setMaxValue(2.0).getDouble();
            TileColdDistillator.cfgMaxMRU = cfg.get(category, "MaxMRU", 100000).setMinValue(1).getInt();
            TileColdDistillator.mruGenModifier = cfg.get(category, "MRUGenModifier", 1.0).setMinValue(0.0).getDouble();
            TileColdDistillator.harmEntities = cfg.get(category, "DamageEntitiesAround", true).getBoolean();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileColdDistillator.balanceProduced = 0.0f;
        TileColdDistillator.cfgMaxMRU = 100000;
        TileColdDistillator.mruGenModifier = 1.0;
        TileColdDistillator.harmEntities = true;
    }
}
