package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import net.minecraft.nbt.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.common.*;
import net.minecraft.block.state.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;
import net.minecraftforge.common.config.*;

public class TileElementalCrystal extends TileEntity implements ITickable
{
    public int syncTick;
    public double size;
    public double fire;
    public double water;
    public double earth;
    public double air;
    private TileStatTracker tracker;
    public boolean requestSync;
    public static double mutationChance;
    public static double growthModifier;
    
    public TileElementalCrystal() {
        this.syncTick = 10;
        this.requestSync = true;
        this.tracker = new TileStatTracker((TileEntity)this);
    }
    
    public void func_145839_a(final NBTTagCompound i) {
        super.func_145839_a(i);
        this.size = i.func_74769_h("size");
        this.fire = i.func_74769_h("fire");
        this.water = i.func_74769_h("water");
        this.earth = i.func_74769_h("earth");
        this.air = i.func_74769_h("air");
    }
    
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        super.func_189515_b(i);
        i.func_74780_a("size", this.size);
        i.func_74780_a("fire", this.fire);
        i.func_74780_a("water", this.water);
        i.func_74780_a("earth", this.earth);
        i.func_74780_a("air", this.air);
        return i;
    }
    
    public double getElementByNum(final int num) {
        if (num == 0) {
            return this.fire;
        }
        if (num == 1) {
            return this.water;
        }
        if (num == 2) {
            return this.earth;
        }
        if (num == 3) {
            return this.air;
        }
        return -1.0;
    }
    
    public void setElementByNum(final int num, final double amount) {
        if (num == 0) {
            this.fire += amount;
        }
        if (num == 1) {
            this.water += amount;
        }
        if (num == 2) {
            this.earth += amount;
        }
        if (num == 3) {
            this.air += amount;
        }
    }
    
    public void randomlyMutate() {
        final Random r = this.func_145831_w().field_73012_v;
        if (r.nextDouble() <= TileElementalCrystal.mutationChance) {
            this.mutate(r.nextInt(4), r.nextInt(3) - r.nextInt(3));
        }
    }
    
    public boolean mutate(final int element, final int amount) {
        if (this.getElementByNum(element) + amount <= 100.0 && this.getElementByNum(element) + amount >= 0.0) {
            this.setElementByNum(element, amount);
        }
        return false;
    }
    
    public int getDominant() {
        if (this.fire > this.water && this.fire > this.earth && this.fire > this.air) {
            return 0;
        }
        if (this.water > this.fire && this.water > this.earth && this.water > this.air) {
            return 1;
        }
        if (this.earth > this.water && this.earth > this.fire && this.earth > this.air) {
            return 2;
        }
        if (this.air > this.fire && this.air > this.earth && this.air > this.water) {
            return 3;
        }
        return -1;
    }
    
    public void func_73660_a() {
        final int metadata = this.func_145832_p();
        if (metadata == 1) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177977_b());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177977_b(), EnumFacing.UP)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (metadata == 0) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177984_a());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177984_a(), EnumFacing.DOWN)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (metadata == 3) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177978_c());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177978_c(), EnumFacing.SOUTH)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (metadata == 2) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177968_d());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177968_d(), EnumFacing.NORTH)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (metadata == 5) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177976_e());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177976_e(), EnumFacing.EAST)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (metadata == 4) {
            final IBlockState b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177974_f());
            if (!b.isSideSolid((IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177974_f(), EnumFacing.WEST)) {
                this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c().func_176226_b(this.func_145831_w(), this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c), 0);
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        if (this.size < 100.0) {
            this.func_145831_w().func_175688_a(EnumParticleTypes.ENCHANTMENT_TABLE, (double)(this.field_174879_c.func_177958_n() + this.func_145831_w().field_73012_v.nextFloat()), (double)(this.field_174879_c.func_177956_o() + 1), (double)(this.field_174879_c.func_177952_p() + this.func_145831_w().field_73012_v.nextFloat()), 0.0, 0.0, 0.0, new int[0]);
            if (!this.func_145831_w().field_72995_K) {
                this.size += 0.002 * TileElementalCrystal.growthModifier;
                this.randomlyMutate();
            }
        }
        if (this.syncTick == 0) {
            if (this.tracker == null) {
                Notifier.notifyCustomMod("EssentialCraft", "[WARNING][SEVERE]TileEntity " + this + " at pos " + this.field_174879_c.func_177958_n() + ", " + this.field_174879_c.func_177956_o() + ", " + this.field_174879_c.func_177952_p() + " tries to sync itself, but has no TileTracker attached to it! SEND THIS MESSAGE TO THE DEVELOPER OF THE MOD!");
            }
            else if (!this.func_145831_w().field_72995_K && this.tracker.tileNeedsSyncing()) {
                MiscUtils.sendPacketToAllAround(this.func_145831_w(), (Packet)this.func_189518_D_(), this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p(), this.func_145831_w().field_73011_w.getDimension(), 32.0);
            }
            this.syncTick = 60;
        }
        else {
            --this.syncTick;
        }
        if (this.requestSync && this.func_145831_w().field_72995_K) {
            this.requestSync = false;
            ECUtils.requestScheduledTileSync(this, EssentialCraftCore.proxy.getClientPlayer());
        }
    }
    
    public SPacketUpdateTileEntity func_189518_D_() {
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        this.func_189515_b(nbttagcompound);
        return new SPacketUpdateTileEntity(this.field_174879_c, -10, nbttagcompound);
    }
    
    public void onDataPacket(final NetworkManager net, final SPacketUpdateTileEntity pkt) {
        if (pkt.func_148853_f() == -10) {
            this.func_145839_a(pkt.func_148857_g());
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.elementalcrystal";
            TileElementalCrystal.mutationChance = cfg.get(category, "MutationChance", 0.001, "Chance to mutate per tick").setMinValue(0.0).setMaxValue(1.0).getDouble();
            TileElementalCrystal.growthModifier = cfg.get(category, "GrowthModifier", 1.0).setMinValue(0).getDouble();
        }
        catch (Exception e) {}
    }
    
    static {
        TileElementalCrystal.mutationChance = 0.001;
        TileElementalCrystal.growthModifier = 1.0;
    }
}
