package essentialcraft.common.tile;

import essentialcraft.common.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.block.*;
import net.minecraft.nbt.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.config.*;
import net.minecraft.util.math.*;

public class TileCorruptionCleaner extends TileMRUGeneric
{
    public BlockPos cleared;
    public int clearTime;
    public static int maxRadius;
    public static boolean removeBlock;
    public static int mruUsage;
    public static int ticksRequired;
    public static int cfgMaxMRU;
    
    public TileCorruptionCleaner() {
        super(TileCorruptionCleaner.cfgMaxMRU);
        this.clearTime = 0;
        this.setSlotsNum(1);
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (!this.func_145831_w().field_72995_K && this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            if (this.cleared == null) {
                final int offsetX = (int)(MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileCorruptionCleaner.maxRadius);
                final int offsetY = (int)(MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileCorruptionCleaner.maxRadius);
                final int offsetZ = (int)(MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileCorruptionCleaner.maxRadius);
                final Block b = this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(offsetX, offsetY, offsetZ)).func_177230_c();
                if (b instanceof BlockCorruption) {
                    this.cleared = this.field_174879_c.func_177982_a(offsetX, offsetY, offsetZ);
                    this.clearTime = TileCorruptionCleaner.ticksRequired;
                }
            }
            else {
                final Block b2 = this.func_145831_w().func_180495_p(this.cleared).func_177230_c();
                if (!(b2 instanceof BlockCorruption)) {
                    this.cleared = null;
                    this.clearTime = 0;
                    return;
                }
                if (this.mruStorage.getMRU() >= TileCorruptionCleaner.mruUsage) {
                    --this.clearTime;
                    this.mruStorage.extractMRU(TileCorruptionCleaner.mruUsage, true);
                    if (this.clearTime <= 0) {
                        final int metadata = (int)this.func_145831_w().func_180495_p(this.cleared).func_177229_b((IProperty)BlockCorruption.LEVEL);
                        if (metadata == 0 || TileCorruptionCleaner.removeBlock) {
                            this.func_145831_w().func_175698_g(this.cleared);
                        }
                        else {
                            this.func_145831_w().func_180501_a(this.cleared, b2.func_176203_a(metadata - 1), 2);
                        }
                        this.cleared = null;
                    }
                }
            }
        }
    }
    
    @Override
    public void func_145839_a(final NBTTagCompound i) {
        if (i.func_74764_b("coord")) {
            final String str = i.func_74779_i("coord");
            if (!str.equals("null")) {
                final DummyData[] coordData = DataStorage.parseData(i.func_74779_i("coord"));
                this.cleared = new BlockPos(Integer.parseInt(coordData[0].fieldValue), Integer.parseInt(coordData[1].fieldValue), Integer.parseInt(coordData[2].fieldValue));
            }
            else {
                this.cleared = null;
            }
        }
        this.clearTime = i.func_74762_e("clear");
        super.func_145839_a(i);
    }
    
    @Override
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        if (this.cleared != null) {
            i.func_74778_a("coord", "||x:" + this.cleared.func_177958_n() + "||y:" + this.cleared.func_177956_o() + "||z:" + this.cleared.func_177952_p());
        }
        else {
            i.func_74778_a("coord", "null");
        }
        i.func_74768_a("clear", this.clearTime);
        return super.func_189515_b(i);
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.corruptioncleaner";
            TileCorruptionCleaner.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileCorruptionCleaner.mruUsage = cfg.get(category, "MRUUsage", 20, "Usage per tick").setMinValue(0).setMaxValue(TileCorruptionCleaner.cfgMaxMRU).getInt();
            TileCorruptionCleaner.ticksRequired = cfg.get(category, "TicksRequired", 200, "Time required to destroy corruption").setMinValue(0).getInt();
            TileCorruptionCleaner.removeBlock = cfg.get(category, "RemoveBlock", false, "Should remove corruption blocks instead of reducing their growth").getBoolean();
            TileCorruptionCleaner.maxRadius = cfg.get(category, "MaxRadius", 8).setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    public AxisAlignedBB getRenderBoundingBox() {
        return new AxisAlignedBB((double)(-TileCorruptionCleaner.maxRadius), (double)(-TileCorruptionCleaner.maxRadius), (double)(-TileCorruptionCleaner.maxRadius), (double)(1 + TileCorruptionCleaner.maxRadius), (double)(1 + TileCorruptionCleaner.maxRadius), (double)(1 + TileCorruptionCleaner.maxRadius));
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileCorruptionCleaner.maxRadius = 8;
        TileCorruptionCleaner.removeBlock = false;
        TileCorruptionCleaner.mruUsage = 20;
        TileCorruptionCleaner.ticksRequired = 200;
        TileCorruptionCleaner.cfgMaxMRU = 5000;
    }
}
