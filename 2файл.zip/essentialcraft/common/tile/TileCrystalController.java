package essentialcraft.common.tile;

import net.minecraft.util.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import net.minecraft.tileentity.*;
import net.minecraftforge.common.config.*;

public class TileCrystalController extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static int mruUsage;
    public static double chanceToUseMRU;
    public static double mutateModifier;
    
    public TileCrystalController() {
        super(TileCrystalController.cfgMaxMRU);
        this.setSlotsNum(2);
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0 && !this.func_145831_w().field_72995_K && this.func_145831_w().field_73012_v.nextDouble() < TileCrystalController.chanceToUseMRU && this.mruStorage.getMRU() >= TileCrystalController.mruUsage) {
            this.mruStorage.extractMRU(TileCrystalController.mruUsage, true);
        }
        this.spawnParticles();
        if (!this.func_145831_w().field_72995_K && this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            this.mutateToElement();
        }
    }
    
    public void spawnParticles() {
        if (this.field_145850_b.field_72995_K && this.mruStorage.getMRU() > 0 && this.getCrystal() != null) {
            for (int o = 0; o < 2; ++o) {
                this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.3 + this.func_145831_w().field_73012_v.nextDouble() / 2.0, (double)(this.field_174879_c.func_177956_o() + 0.3f + o / 2.0f), this.field_174879_c.func_177952_p() + 0.3 + this.func_145831_w().field_73012_v.nextDouble() / 2.0, -1.0, 1.0, 0.0, new int[0]);
            }
        }
    }
    
    public void mutateToElement() {
        if (!this.func_70301_a(1).func_190926_b() && this.func_70301_a(1).func_77973_b() instanceof ItemEssence && this.mruStorage.getMRU() > TileCrystalController.mruUsage * 10 && this.getCrystal() != null && this.getCrystal().size < 100.0) {
            final ItemStack e = this.func_70301_a(1);
            final TileElementalCrystal c = this.getCrystal();
            final int rarity = (int)(e.func_77952_i() / 4.0);
            final double chance = TileCrystalController.mutateModifier * (rarity + 1);
            if (this.func_145831_w().field_73012_v.nextDouble() < chance) {
                this.mruStorage.extractMRU(TileCrystalController.mruUsage * 10, true);
                final int type = e.func_77952_i() % 4;
                c.mutate(type, this.func_145831_w().field_73012_v.nextInt((rarity + 1) * 2));
                this.func_70298_a(1, 1);
            }
        }
    }
    
    public TileElementalCrystal getCrystal() {
        TileElementalCrystal t = null;
        if (this.hasCrystalOnEast()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177974_f());
        }
        if (this.hasCrystalOnWest()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177976_e());
        }
        if (this.hasCrystalOnSouth()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177968_d());
        }
        if (this.hasCrystalOnNorth()) {
            t = (TileElementalCrystal)this.func_145831_w().func_175625_s(this.field_174879_c.func_177978_c());
        }
        return t;
    }
    
    public boolean hasCrystalOnEast() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177974_f());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnWest() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177976_e());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnSouth() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177968_d());
        return t instanceof TileElementalCrystal;
    }
    
    public boolean hasCrystalOnNorth() {
        final TileEntity t = this.func_145831_w().func_175625_s(this.field_174879_c.func_177978_c());
        return t instanceof TileElementalCrystal;
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.crystalcontroller";
            TileCrystalController.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileCrystalController.mruUsage = cfg.get(category, "MRUUsage", 100).setMinValue(0).setMaxValue(TileCrystalController.cfgMaxMRU).getInt();
            TileCrystalController.chanceToUseMRU = cfg.get(category, "UseMRUChance", 0.05).setMinValue(0.0).setMaxValue(1.0).getDouble();
            TileCrystalController.mutateModifier = cfg.get(category, "MutationChanceModifier", 0.001).setMinValue(0.0).getDouble();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileCrystalController.cfgMaxMRU = 5000;
        TileCrystalController.mruUsage = 100;
        TileCrystalController.chanceToUseMRU = 0.05;
        TileCrystalController.mutateModifier = 0.001;
    }
}
