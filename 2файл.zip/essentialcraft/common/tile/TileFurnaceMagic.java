package essentialcraft.common.tile;

import net.minecraft.nbt.*;
import net.minecraftforge.oredict.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import essentialcraft.utils.common.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraftforge.common.config.*;

public class TileFurnaceMagic extends TileMRUGeneric
{
    public int progressLevel;
    public int smeltingLevel;
    public static int cfgMaxMRU;
    public static boolean generatesCorruption;
    public static int genCorruption;
    public static int mruUsage;
    public static int smeltingTime;
    
    public TileFurnaceMagic() {
        super(TileFurnaceMagic.cfgMaxMRU);
        this.setSlotsNum(3);
    }
    
    @Override
    public void func_145839_a(final NBTTagCompound i) {
        super.func_145839_a(i);
        this.progressLevel = i.func_74762_e("progress");
        this.smeltingLevel = i.func_74762_e("smelting");
    }
    
    @Override
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        super.func_189515_b(i);
        i.func_74768_a("progress", this.progressLevel);
        i.func_74768_a("smelting", this.smeltingLevel);
        return i;
    }
    
    @Override
    public void func_73660_a() {
        final int usage = TileFurnaceMagic.mruUsage;
        final int time = TileFurnaceMagic.smeltingTime / (this.func_145832_p() / 4 + 1);
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            final ItemStack ore = this.func_70301_a(1);
            if (!ore.func_190926_b()) {
                final int[] oreIds = OreDictionary.getOreIDs(ore);
                String oreName = "Unknown";
                if (oreIds.length > 0) {
                    oreName = OreDictionary.getOreName(oreIds[0]);
                }
                int metadata = -1;
                for (int i = 0; i < OreSmeltingRecipe.RECIPES.size(); ++i) {
                    final OreSmeltingRecipe oreColor = OreSmeltingRecipe.RECIPES.get(i);
                    if (oreName.equalsIgnoreCase(oreColor.oreName)) {
                        metadata = i;
                        break;
                    }
                }
                if (metadata != -1) {
                    if (this.func_70301_a(2).func_190926_b()) {
                        if (this.mruStorage.getMRU() >= usage) {
                            this.mruStorage.extractMRU(usage, true);
                            this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, (double)this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, 0.0, -0.1, 0.0, new int[0]);
                            ++this.progressLevel;
                            if (TileFurnaceMagic.generatesCorruption) {
                                ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.field_174879_c, this.func_145831_w().field_73012_v, TileFurnaceMagic.genCorruption);
                            }
                            if (this.progressLevel >= time) {
                                this.func_70298_a(1, 1);
                                final int suggestedStackSize = OreSmeltingRecipe.RECIPES.get(metadata).dropAmount;
                                this.func_70299_a(2, OreSmeltingRecipe.getAlloyStack(OreSmeltingRecipe.RECIPES.get(metadata), suggestedStackSize));
                                this.progressLevel = 0;
                                this.syncTick = 0;
                            }
                        }
                    }
                    else if (this.func_70301_a(2).func_77973_b() == ItemsCore.magicalAlloy && OreSmeltingRecipe.getIndex(this.func_70301_a(2)) == metadata && this.func_70301_a(2).func_190916_E() + 1 <= this.func_70301_a(2).func_77976_d() && this.func_70301_a(2).func_190916_E() + 1 <= this.func_70297_j_() && this.mruStorage.getMRU() >= usage) {
                        this.mruStorage.extractMRU(usage, true);
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, (double)this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, 0.0, -0.1, 0.0, new int[0]);
                        ++this.progressLevel;
                        if (TileFurnaceMagic.generatesCorruption) {
                            ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.field_174879_c, this.func_145831_w().field_73012_v, TileFurnaceMagic.genCorruption);
                        }
                        if (this.progressLevel >= time) {
                            this.func_70298_a(1, 1);
                            final int suggestedStackSize = OreSmeltingRecipe.RECIPES.get(metadata).dropAmount;
                            final ItemStack is = this.func_70301_a(2);
                            is.func_190917_f(suggestedStackSize);
                            if (is.func_190916_E() > is.func_77976_d()) {
                                is.func_190920_e(is.func_77976_d());
                            }
                            this.func_70299_a(2, is);
                            this.progressLevel = 0;
                            this.syncTick = 0;
                        }
                    }
                }
                else {
                    this.progressLevel = 0;
                }
            }
            else {
                this.progressLevel = 0;
            }
            final ItemStack alloy = this.func_70301_a(1);
            if (alloy.func_77973_b() == ItemsCore.magicalAlloy) {
                final OreSmeltingRecipe oreColor2 = OreSmeltingRecipe.RECIPES.get(OreSmeltingRecipe.getIndex(alloy));
                final String oreName2 = oreColor2.oreName;
                final String outputName = oreColor2.outputName;
                String suggestedIngotName;
                if (outputName.isEmpty()) {
                    suggestedIngotName = "ingot" + oreName2.substring(3);
                }
                else {
                    suggestedIngotName = outputName;
                }
                final List<ItemStack> oreLst = (List<ItemStack>)OreDictionary.getOres(suggestedIngotName);
                if (oreLst != null && !oreLst.isEmpty()) {
                    final ItemStack ingotStk = oreLst.get(0).func_77946_l();
                    if (this.func_70301_a(2).func_190926_b()) {
                        if (this.mruStorage.getMRU() >= usage) {
                            this.mruStorage.extractMRU(usage, true);
                            this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, (double)this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, 0.0, -0.1, 0.0, new int[0]);
                            ++this.smeltingLevel;
                            if (!this.func_145831_w().field_72995_K && TileFurnaceMagic.generatesCorruption) {
                                ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.field_174879_c, this.func_145831_w().field_73012_v, TileFurnaceMagic.genCorruption);
                            }
                            if (this.smeltingLevel >= time) {
                                this.func_70298_a(1, 1);
                                final int suggestedStackSize2 = 2;
                                ingotStk.func_190920_e(suggestedStackSize2);
                                this.func_70299_a(2, ingotStk);
                                this.smeltingLevel = 0;
                                this.syncTick = 0;
                            }
                        }
                    }
                    else if (this.func_70301_a(2).func_77969_a(ingotStk) && this.func_70301_a(2).func_190916_E() + 2 <= this.func_70301_a(2).func_77976_d() && this.func_70301_a(2).func_190916_E() + 2 <= this.func_70297_j_() && this.mruStorage.getMRU() >= usage) {
                        this.mruStorage.extractMRU(usage, true);
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, (double)this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() + 0.5 + MathUtils.randomDouble(this.func_145831_w().field_73012_v) / 2.2, 0.0, -0.1, 0.0, new int[0]);
                        ++this.smeltingLevel;
                        if (!this.func_145831_w().field_72995_K && TileFurnaceMagic.generatesCorruption) {
                            ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.field_174879_c, this.func_145831_w().field_73012_v, TileFurnaceMagic.genCorruption);
                        }
                        if (this.smeltingLevel >= time) {
                            this.func_70298_a(1, 1);
                            final int suggestedStackSize2 = 2;
                            final ItemStack is2 = this.func_70301_a(2);
                            is2.func_190917_f(suggestedStackSize2);
                            this.func_70299_a(2, is2);
                            this.smeltingLevel = 0;
                            this.syncTick = 0;
                        }
                    }
                }
                else {
                    this.smeltingLevel = 0;
                }
            }
            else {
                this.smeltingLevel = 0;
            }
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.furnacemagic";
            TileFurnaceMagic.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileFurnaceMagic.mruUsage = cfg.get(category, "MRUUsage", 25).setMinValue(0).setMaxValue(TileFurnaceMagic.cfgMaxMRU).getInt();
            TileFurnaceMagic.generatesCorruption = cfg.get(category, "GenerateCorruption", false).getBoolean();
            TileFurnaceMagic.genCorruption = cfg.get(category, "MaxCorruptionGen", 3, "Max amount of corruption generated per tick").setMinValue(0).getInt();
            TileFurnaceMagic.smeltingTime = cfg.get(category, "TicksRequired", 400).setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 2 };
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return (slot == 0) ? this.isBoundGem(stack) : (slot == 1);
    }
    
    static {
        TileFurnaceMagic.cfgMaxMRU = 5000;
        TileFurnaceMagic.generatesCorruption = false;
        TileFurnaceMagic.genCorruption = 2;
        TileFurnaceMagic.mruUsage = 25;
        TileFurnaceMagic.smeltingTime = 400;
    }
}
