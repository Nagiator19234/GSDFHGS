package essentialcraft.common.tile;

import java.util.*;
import com.google.common.collect.*;
import net.minecraftforge.event.*;
import net.minecraft.world.*;
import net.minecraftforge.fml.common.eventhandler.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import net.minecraft.entity.item.*;
import net.minecraft.world.biome.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.config.*;

public class TileDarknessObelisk extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static boolean generatesCorruption;
    public static int genCorruption;
    public static int mruUsage;
    public static double worldSpawnChance;
    public static int mobSpanwerDelay;
    public static boolean enableMobSpawners;
    public static int mobSpawnerRadius;
    public static int worldSpawnerRadius;
    private NBTTagCompound prevTag;
    private List<WeightedSpawnerEntity> potentialSpawns;
    
    public TileDarknessObelisk() {
        super(TileDarknessObelisk.cfgMaxMRU);
        this.prevTag = null;
        this.potentialSpawns = (List<WeightedSpawnerEntity>)Lists.newArrayList();
        this.setSlotsNum(2);
    }
    
    @Override
    public void func_73660_a() {
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.func_174877_v()) == 0) {
            if (this.func_70301_a(1).func_190926_b() || !(this.func_70301_a(1).func_77973_b() instanceof ItemCollectedMonsterSpawner)) {
                final Biome biome = this.func_145831_w().func_180494_b(this.func_174877_v());
                final List<Biome.SpawnListEntry> l = (List<Biome.SpawnListEntry>)biome.func_76747_a(EnumCreatureType.MONSTER);
                if (l != null && !l.isEmpty() && this.func_145831_w().field_73012_v.nextDouble() < TileDarknessObelisk.worldSpawnChance && this.mruStorage.getMRU() >= TileDarknessObelisk.mruUsage && !this.func_145831_w().field_72995_K) {
                    Biome.SpawnListEntry spawnlistentry = null;
                    IEntityLivingData ientitylivingdata = null;
                    final int rndOffsetX = (int)(this.func_174877_v().func_177958_n() + MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileDarknessObelisk.worldSpawnerRadius);
                    final int rndOffsetY = (int)(this.func_174877_v().func_177956_o() + MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileDarknessObelisk.worldSpawnerRadius);
                    final int rndOffsetZ = (int)(this.func_174877_v().func_177952_p() + MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileDarknessObelisk.worldSpawnerRadius);
                    final BlockPos rndPos = new BlockPos(rndOffsetX, rndOffsetY, rndOffsetZ);
                    if (WorldEntitySpawner.func_180267_a(EntityLiving.SpawnPlacementType.ON_GROUND, this.func_145831_w(), rndPos)) {
                        final WorldServer wrld = (WorldServer)this.func_145831_w();
                        spawnlistentry = wrld.func_175734_a(EnumCreatureType.MONSTER, rndPos);
                        if (spawnlistentry != null) {
                            try {
                                final EntityLiving entityliving = spawnlistentry.newInstance(this.field_145850_b);
                                entityliving.func_70012_b(rndOffsetX + 0.5, (double)rndOffsetY, rndOffsetZ + 0.5, wrld.field_73012_v.nextFloat() * 360.0f, 0.0f);
                                final Event.Result canSpawn = ForgeEventFactory.canEntitySpawn(entityliving, (World)wrld, rndOffsetX + 0.5f, (float)rndOffsetY, rndOffsetZ + 0.5f, false);
                                if (canSpawn == Event.Result.ALLOW || (canSpawn == Event.Result.DEFAULT && entityliving.func_70601_bi())) {
                                    wrld.func_72838_d((Entity)entityliving);
                                    this.mruStorage.extractMRU(TileDarknessObelisk.mruUsage, true);
                                    if (TileDarknessObelisk.generatesCorruption) {
                                        ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.func_174877_v(), this.func_145831_w().field_73012_v, TileDarknessObelisk.genCorruption);
                                    }
                                    if (!ForgeEventFactory.doSpecialSpawn(entityliving, (World)wrld, rndOffsetX + 0.5f, (float)rndOffsetY, rndOffsetZ + 0.5f)) {
                                        ientitylivingdata = entityliving.func_180482_a(this.func_145831_w().func_175649_E(rndPos), ientitylivingdata);
                                    }
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                return;
                            }
                        }
                    }
                }
            }
            else if (this.func_70301_a(1).func_77973_b() instanceof ItemCollectedMonsterSpawner && TileDarknessObelisk.enableMobSpawners && this.innerRotation % TileDarknessObelisk.mobSpanwerDelay == 0 && this.mruStorage.getMRU() >= TileDarknessObelisk.mruUsage) {
                final NBTTagCompound tag = MiscUtils.getStackTag(this.func_70301_a(1));
                if (tag.func_74764_b("monsterSpawner")) {
                    final NBTTagCompound spTag = tag.func_74775_l("monsterSpawner");
                    final NBTTagCompound mobTag = this.getMobTag(spTag);
                    if (mobTag != null && mobTag.func_74764_b("id")) {
                        final String id = mobTag.func_74779_i("id");
                        this.innerRotation = 0;
                        this.func_70301_a(1).func_77952_i();
                        final Entity base = ((EntityEntry)ForgeRegistries.ENTITIES.getValue(new ResourceLocation(id))).newInstance(this.func_145831_w());
                        if (base != null && base instanceof EntityLiving) {
                            final EntityLiving entityliving2 = (EntityLiving)base;
                            final int rndOffsetX2 = (int)(this.field_174879_c.func_177958_n() + MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileDarknessObelisk.mobSpawnerRadius);
                            final int rndOffsetY2 = (int)(this.field_174879_c.func_177956_o() + MathUtils.randomDouble(this.func_145831_w().field_73012_v));
                            final int rndOffsetZ2 = (int)(this.field_174879_c.func_177952_p() + MathUtils.randomDouble(this.func_145831_w().field_73012_v) * TileDarknessObelisk.mobSpawnerRadius);
                            entityliving2.func_70012_b(rndOffsetX2 + 0.5, (double)rndOffsetY2, rndOffsetZ2 + 0.5, this.func_145831_w().field_73012_v.nextFloat() * 360.0f, 0.0f);
                            if (entityliving2.func_70601_bi()) {
                                if (!this.func_145831_w().field_72995_K) {
                                    this.func_145831_w().func_72838_d((Entity)entityliving2);
                                }
                                this.func_145831_w().func_175718_b(2004, this.field_174879_c, 0);
                                if (entityliving2 != null) {
                                    entityliving2.func_70656_aK();
                                }
                                this.mruStorage.extractMRU(TileDarknessObelisk.mruUsage, true);
                                if (TileDarknessObelisk.generatesCorruption) {
                                    ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.func_174877_v(), this.func_145831_w().field_73012_v, TileDarknessObelisk.genCorruption);
                                }
                            }
                        }
                    }
                }
            }
        }
        super.func_73660_a();
        final List<EntityPlayer> playerlist = (List<EntityPlayer>)this.func_145831_w().func_72872_a((Class)EntityPlayer.class, new AxisAlignedBB(this.field_174879_c).func_186662_g(8.0));
        if (!playerlist.isEmpty() && this.field_145850_b.field_73012_v.nextInt(10000) == 0) {
            final EntityItem ei = new EntityItem(this.field_145850_b, this.field_174879_c.func_177958_n() + 0.5, (double)(this.field_174879_c.func_177956_o() + 1), this.field_174879_c.func_177952_p() + 0.5, new ItemStack(ItemsCore.secret, 1, 0));
            this.func_145831_w().func_72838_d((Entity)ei);
        }
    }
    
    public NBTTagCompound getMobTag(final NBTTagCompound nbt) {
        if (this.prevTag == null || !this.prevTag.equals((Object)nbt)) {
            this.prevTag = nbt;
            if (nbt.func_150297_b("SpawnPotentials", 9)) {
                final NBTTagList nbttaglist = nbt.func_150295_c("SpawnPotentials", 10);
                for (int i = 0; i < nbttaglist.func_74745_c(); ++i) {
                    this.potentialSpawns.add(new WeightedSpawnerEntity(nbttaglist.func_150305_b(i)));
                }
            }
        }
        if (nbt.func_150297_b("SpawnData", 10)) {
            return nbt.func_74775_l("SpawnData");
        }
        if (!this.potentialSpawns.isEmpty()) {
            return ((WeightedSpawnerEntity)WeightedRandom.func_76271_a(this.func_145831_w().field_73012_v, (List)this.potentialSpawns)).func_185277_b();
        }
        return null;
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.darknessobelisk";
            TileDarknessObelisk.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileDarknessObelisk.mruUsage = cfg.get(category, "MRUUsage", 500).setMinValue(0).setMaxValue(TileDarknessObelisk.cfgMaxMRU).getInt();
            TileDarknessObelisk.mobSpanwerDelay = cfg.get(category, "SpawnerDelay", 100).setMinValue(1).getInt();
            TileDarknessObelisk.generatesCorruption = cfg.get(category, "GenerateCorruption", false).getBoolean();
            TileDarknessObelisk.genCorruption = cfg.get(category, "MaxCorruptionGen", 30, "Max amount of corruption generated per tick").setMinValue(0).getInt();
            TileDarknessObelisk.worldSpawnChance = cfg.get(category, "SpawnChance", 0.1, "Chance per tick to try spawning a mob without a spawner").setMinValue(0.0).setMaxValue(1.0).getDouble();
            TileDarknessObelisk.enableMobSpawners = cfg.get(category, "EnableSpawners", true).getBoolean();
            TileDarknessObelisk.mobSpawnerRadius = cfg.get(category, "SpawnerRadius", 3).setMinValue(0).getInt();
            TileDarknessObelisk.worldSpawnerRadius = cfg.get(category, "NoSpawnerRadius", 8).setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileDarknessObelisk.cfgMaxMRU = 5000;
        TileDarknessObelisk.generatesCorruption = false;
        TileDarknessObelisk.genCorruption = 30;
        TileDarknessObelisk.mruUsage = 500;
        TileDarknessObelisk.worldSpawnChance = 0.1;
        TileDarknessObelisk.mobSpanwerDelay = 100;
        TileDarknessObelisk.enableMobSpawners = true;
        TileDarknessObelisk.mobSpawnerRadius = 3;
        TileDarknessObelisk.worldSpawnerRadius = 8;
    }
}
