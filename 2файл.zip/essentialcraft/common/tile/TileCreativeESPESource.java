package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import net.minecraftforge.common.config.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.common.capabilities.espe.*;

public class TileCreativeESPESource extends TileEntity implements ITickable
{
    public static double cfgMaxESPE;
    protected ESPEStorage espeStorage;
    
    public TileCreativeESPESource() {
        this.espeStorage = new ESPEStorage(TileCreativeESPESource.cfgMaxESPE, 1073741823);
    }
    
    public void func_73660_a() {
        this.espeStorage.setESPE(this.espeStorage.getMaxESPE());
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.creativeespesource";
            TileCreativeESPESource.cfgMaxESPE = cfg.get(category, "MaxESPE", 1000000.0).setMinValue(Double.MIN_NORMAL).getDouble();
        }
        catch (Exception e) {}
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY || super.hasCapability((Capability)capability, facing);
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityESPEHandler.ESPE_HANDLER_CAPABILITY) ? this.espeStorage : super.getCapability((Capability)capability, facing));
    }
    
    static {
        TileCreativeESPESource.cfgMaxESPE = 1000000.0;
    }
}
