package essentialcraft.common.tile;

import java.util.function.*;
import net.minecraft.world.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.entity.*;
import java.util.*;
import net.minecraft.block.*;
import essentialcraft.common.mod.*;
import net.minecraftforge.common.config.*;
import essentialcraft.common.block.*;
import essentialcraft.common.item.*;
import DummyCore.Utils.*;

public class TileEmberForge extends TileMRUGeneric
{
    public int progressLevel;
    public int soundArray;
    public static boolean nightRequired;
    public static int timeRequired;
    protected static BiPredicate<IBlockAccess, BlockPos> structureChecker;
    
    public TileEmberForge() {
        super(0);
        this.setSlotsNum(0);
    }
    
    @Override
    public void func_145839_a(final NBTTagCompound nbt) {
        super.func_145839_a(nbt);
        this.progressLevel = nbt.func_74762_e("progress");
    }
    
    @Override
    public NBTTagCompound func_189515_b(final NBTTagCompound nbt) {
        super.func_189515_b(nbt);
        nbt.func_74768_a("progress", this.progressLevel);
        return nbt;
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.spawnParticles();
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            if (TileEmberForge.structureChecker.test((IBlockAccess)this.func_145831_w(), this.func_174877_v())) {
                boolean flag = false;
                if (this.field_145850_b.field_72995_K) {
                    for (int i = 0; i < 2; ++i) {
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + this.func_145831_w().field_73012_v.nextDouble(), this.field_174879_c.func_177956_o() + 1.1, this.field_174879_c.func_177952_p() + this.func_145831_w().field_73012_v.nextDouble(), 0.0, 0.0, 0.0, new int[0]);
                    }
                }
                List<EntityItem> list = null;
                EntityItem ember_0 = null;
                EntityItem ember_2 = null;
                EntityItem ember_3 = null;
                EntityItem ember_4 = null;
                EntityItem focus_0 = null;
                EntityItem focus_2 = null;
                EntityItem focus_3 = null;
                EntityItem focus_4 = null;
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(2, 1, 0)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemEmber);
                if (!list.isEmpty()) {
                    ember_0 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(-2, 1, 0)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemEmber);
                if (!list.isEmpty()) {
                    ember_2 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(0, 1, 2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemEmber);
                if (!list.isEmpty()) {
                    ember_3 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(0, 1, -2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemEmber);
                if (!list.isEmpty()) {
                    ember_4 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(2, 2, 2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemElementalFocus);
                if (!list.isEmpty()) {
                    focus_0 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(-2, 2, 2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemElementalFocus);
                if (!list.isEmpty()) {
                    focus_2 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(2, 2, -2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemElementalFocus);
                if (!list.isEmpty()) {
                    focus_3 = list.get(0);
                }
                list = (List<EntityItem>)this.func_145831_w().func_175647_a((Class)EntityItem.class, new AxisAlignedBB(this.field_174879_c.func_177982_a(-2, 2, -2)), ei -> ei.func_92059_d().func_77973_b() instanceof ItemElementalFocus);
                if (!list.isEmpty()) {
                    focus_4 = list.get(0);
                }
                --this.soundArray;
                if (isAllNonNull(ember_0, ember_2, ember_3, ember_4, focus_0, focus_2, focus_3, focus_4) && (!TileEmberForge.nightRequired || this.func_145831_w().field_73011_w.func_177495_o() || !this.func_145831_w().field_73011_w.func_191066_m() || !this.func_145831_w().func_72935_r())) {
                    if (this.soundArray <= 0) {
                        this.func_145831_w().func_184133_a((EntityPlayer)null, this.field_174879_c, SoundEvents.field_187814_ei, SoundCategory.BLOCKS, 1.0f, 0.2f);
                        this.soundArray = 50;
                    }
                    ++this.progressLevel;
                    if (this.progressLevel >= TileEmberForge.timeRequired) {
                        this.progressLevel = 0;
                        if (!this.field_145850_b.field_72995_K) {
                            ember_0.func_92059_d().func_190918_g(1);
                            if (ember_0.func_92059_d().func_190926_b()) {
                                ember_0.func_70106_y();
                            }
                            ember_2.func_92059_d().func_190918_g(1);
                            if (ember_2.func_92059_d().func_190926_b()) {
                                ember_2.func_70106_y();
                            }
                            ember_3.func_92059_d().func_190918_g(1);
                            if (ember_3.func_92059_d().func_190926_b()) {
                                ember_3.func_70106_y();
                            }
                            ember_4.func_92059_d().func_190918_g(1);
                            if (ember_4.func_92059_d().func_190926_b()) {
                                ember_4.func_70106_y();
                            }
                            focus_0.func_92059_d().func_190918_g(1);
                            if (focus_0.func_92059_d().func_190926_b()) {
                                focus_0.func_70106_y();
                            }
                            focus_2.func_92059_d().func_190918_g(1);
                            if (focus_2.func_92059_d().func_190926_b()) {
                                focus_2.func_70106_y();
                            }
                            focus_3.func_92059_d().func_190918_g(1);
                            if (focus_3.func_92059_d().func_190926_b()) {
                                focus_3.func_70106_y();
                            }
                            focus_4.func_92059_d().func_190918_g(1);
                            if (focus_4.func_92059_d().func_190926_b()) {
                                focus_4.func_70106_y();
                            }
                            final NBTTagCompound swordTag = new NBTTagCompound();
                            swordTag.func_74778_a("ember_0", ember_0.func_92059_d().func_77973_b().func_77667_c(ember_0.func_92059_d()));
                            swordTag.func_74778_a("ember_1", ember_2.func_92059_d().func_77973_b().func_77667_c(ember_2.func_92059_d()));
                            swordTag.func_74778_a("ember_2", ember_3.func_92059_d().func_77973_b().func_77667_c(ember_3.func_92059_d()));
                            swordTag.func_74778_a("ember_3", ember_4.func_92059_d().func_77973_b().func_77667_c(ember_4.func_92059_d()));
                            swordTag.func_74778_a("focus_0", focus_0.func_92059_d().func_77973_b().func_77667_c(focus_0.func_92059_d()));
                            swordTag.func_74778_a("focus_1", focus_2.func_92059_d().func_77973_b().func_77667_c(focus_2.func_92059_d()));
                            swordTag.func_74778_a("focus_2", focus_3.func_92059_d().func_77973_b().func_77667_c(focus_3.func_92059_d()));
                            swordTag.func_74778_a("focus_3", focus_4.func_92059_d().func_77973_b().func_77667_c(focus_4.func_92059_d()));
                            final ItemStack eSword = new ItemStack(ItemsCore.elementalSword, 1, 0);
                            eSword.func_77982_d(swordTag);
                            ItemElementalSword.setPrimaryAttribute(eSword);
                            final EntityItem elementalSword = new EntityItem(this.func_145831_w(), this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 2.1, this.field_174879_c.func_177952_p() + 0.5, eSword);
                            elementalSword.field_70159_w = 0.0;
                            elementalSword.field_70181_x = 0.2;
                            elementalSword.field_70179_y = 0.0;
                            this.func_145831_w().func_72838_d((Entity)elementalSword);
                        }
                    }
                    if (this.field_145850_b.field_72995_K) {
                        for (int j = 0; j < this.progressLevel / 50; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.LAVA, this.field_174879_c.func_177958_n() + this.func_145831_w().field_73012_v.nextDouble(), (double)(this.field_174879_c.func_177956_o() + 1), this.field_174879_c.func_177952_p() + this.func_145831_w().field_73012_v.nextDouble(), 0.0, 0.0, 0.0, new int[0]);
                        }
                    }
                    flag = true;
                }
                else {
                    this.progressLevel = 0;
                    flag = false;
                }
                if (ember_0 != null) {
                    ember_0.func_70107_b(this.field_174879_c.func_177958_n() + 2.5, this.field_174879_c.func_177956_o() + 1.25, this.field_174879_c.func_177952_p() + 0.5);
                    final EntityItem entityItem = ember_0;
                    ++entityItem.lifespan;
                    ember_0.field_70159_w = 0.0;
                    ember_0.field_70181_x = 0.0;
                    ember_0.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.5 + j / 5.0f, this.field_174879_c.func_177956_o() + 0.9 + j / 12.5, this.field_174879_c.func_177952_p() + 0.5, 1.0, 0.0, 0.0, new int[0]);
                        }
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 2.5, (double)(this.field_174879_c.func_177956_o() + 2), this.field_174879_c.func_177952_p() + 0.5, 0.0, 0.0, 0.0, new int[0]);
                    }
                    if (!flag) {
                        this.func_145831_w().func_184133_a((EntityPlayer)null, ember_0.func_180425_c(), SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 0.2f, 2.0f);
                    }
                }
                if (ember_2 != null) {
                    ember_2.func_70107_b(this.field_174879_c.func_177958_n() - 1.5, this.field_174879_c.func_177956_o() + 1.25, this.field_174879_c.func_177952_p() + 0.5);
                    final EntityItem entityItem2 = ember_2;
                    ++entityItem2.lifespan;
                    ember_2.field_70159_w = 0.0;
                    ember_2.field_70181_x = 0.0;
                    ember_2.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.5 - j / 5.0f, this.field_174879_c.func_177956_o() + 0.9 + j / 12.5, this.field_174879_c.func_177952_p() + 0.5, 1.0, 0.0, 0.0, new int[0]);
                        }
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() - 1.5, (double)(this.field_174879_c.func_177956_o() + 2), this.field_174879_c.func_177952_p() + 0.5, 0.0, 0.0, 0.0, new int[0]);
                    }
                    if (!flag) {
                        this.func_145831_w().func_184133_a((EntityPlayer)null, ember_2.func_180425_c(), SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 0.2f, 2.0f);
                    }
                }
                if (ember_3 != null) {
                    ember_3.func_70107_b(this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 1.25, this.field_174879_c.func_177952_p() + 2.5);
                    final EntityItem entityItem3 = ember_3;
                    ++entityItem3.lifespan;
                    ember_3.field_70159_w = 0.0;
                    ember_3.field_70181_x = 0.0;
                    ember_3.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9 + j / 12.5, this.field_174879_c.func_177952_p() + 0.5 + j / 5.0f, 1.0, 0.0, 0.0, new int[0]);
                        }
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5, (double)(this.field_174879_c.func_177956_o() + 2), this.field_174879_c.func_177952_p() + 2.5, 0.0, 0.0, 0.0, new int[0]);
                    }
                    if (!flag) {
                        this.func_145831_w().func_184133_a((EntityPlayer)null, ember_3.func_180425_c(), SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 0.2f, 2.0f);
                    }
                }
                if (ember_4 != null) {
                    ember_4.func_70107_b(this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 1.25, this.field_174879_c.func_177952_p() - 1.5);
                    final EntityItem entityItem4 = ember_4;
                    ++entityItem4.lifespan;
                    ember_4.field_70159_w = 0.0;
                    ember_4.field_70181_x = 0.0;
                    ember_4.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9 + j / 12.5, this.field_174879_c.func_177952_p() + 0.5 - j / 5.0f, 1.0, 0.0, 0.0, new int[0]);
                        }
                        this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, this.field_174879_c.func_177958_n() + 0.5, (double)(this.field_174879_c.func_177956_o() + 2), this.field_174879_c.func_177952_p() - 1.5, 0.0, 0.0, 0.0, new int[0]);
                    }
                    if (!flag) {
                        this.func_145831_w().func_184133_a((EntityPlayer)null, ember_4.func_180425_c(), SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 0.2f, 2.0f);
                    }
                }
                if (focus_0 != null) {
                    focus_0.func_70107_b(this.field_174879_c.func_177958_n() + 2.5, this.field_174879_c.func_177956_o() + 2.25, this.field_174879_c.func_177952_p() + 2.5);
                    final EntityItem entityItem5 = focus_0;
                    ++entityItem5.lifespan;
                    focus_0.field_70159_w = 0.0;
                    focus_0.field_70181_x = 0.0;
                    focus_0.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        this.func_145831_w().func_175688_a(EnumParticleTypes.PORTAL, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9, this.field_174879_c.func_177952_p() + 0.5, 2.0, 1.0, 2.0, new int[0]);
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 2.5, this.field_174879_c.func_177956_o() + 2.7, this.field_174879_c.func_177952_p() + 2.5, 0.0, 0.0, 1.0, new int[0]);
                        }
                    }
                }
                if (focus_2 != null) {
                    focus_2.func_70107_b(this.field_174879_c.func_177958_n() - 1.5, this.field_174879_c.func_177956_o() + 2.25, this.field_174879_c.func_177952_p() + 2.5);
                    final EntityItem entityItem6 = focus_2;
                    ++entityItem6.lifespan;
                    focus_2.field_70159_w = 0.0;
                    focus_2.field_70181_x = 0.0;
                    focus_2.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        this.func_145831_w().func_175688_a(EnumParticleTypes.PORTAL, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9, this.field_174879_c.func_177952_p() + 0.5, -2.0, 1.0, 2.0, new int[0]);
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() - 1.5, this.field_174879_c.func_177956_o() + 2.7, this.field_174879_c.func_177952_p() + 2.5, 0.0, 0.0, 1.0, new int[0]);
                        }
                    }
                }
                if (focus_3 != null) {
                    focus_3.func_70107_b(this.field_174879_c.func_177958_n() + 2.5, this.field_174879_c.func_177956_o() + 2.25, this.field_174879_c.func_177952_p() - 1.5);
                    final EntityItem entityItem7 = focus_3;
                    ++entityItem7.lifespan;
                    focus_3.field_70159_w = 0.0;
                    focus_3.field_70181_x = 0.0;
                    focus_3.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        this.func_145831_w().func_175688_a(EnumParticleTypes.PORTAL, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9, this.field_174879_c.func_177952_p() + 0.5, 2.0, 1.0, -2.0, new int[0]);
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 2.5, this.field_174879_c.func_177956_o() + 2.7, this.field_174879_c.func_177952_p() - 1.5, 0.0, 0.0, 1.0, new int[0]);
                        }
                    }
                }
                if (focus_4 != null) {
                    focus_4.func_70107_b(this.field_174879_c.func_177958_n() - 1.5, this.field_174879_c.func_177956_o() + 2.25, this.field_174879_c.func_177952_p() - 1.5);
                    final EntityItem entityItem8 = focus_4;
                    ++entityItem8.lifespan;
                    focus_4.field_70159_w = 0.0;
                    focus_4.field_70181_x = 0.0;
                    focus_4.field_70179_y = 0.0;
                    if (this.field_145850_b.field_72995_K) {
                        this.func_145831_w().func_175688_a(EnumParticleTypes.PORTAL, this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 0.9, this.field_174879_c.func_177952_p() + 0.5, -2.0, 1.0, -2.0, new int[0]);
                        for (int j = 0; j < 10; ++j) {
                            this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() - 1.5, this.field_174879_c.func_177956_o() + 2.7, this.field_174879_c.func_177952_p() - 1.5, 0.0, 0.0, 1.0, new int[0]);
                        }
                    }
                }
            }
            else {
                this.progressLevel = 0;
            }
        }
    }
    
    protected static boolean isAllNonNull(final Object... arr) {
        for (final Object obj : arr) {
            if (obj == null) {
                return false;
            }
        }
        return true;
    }
    
    protected static boolean testBlock(final IBlockAccess world, final BlockPos pos, final Block block) {
        return world.func_180495_p(pos).func_177230_c() == block;
    }
    
    public void spawnParticles() {
        if (this.field_145850_b.field_72995_K && TileEmberForge.structureChecker.test((IBlockAccess)this.func_145831_w(), this.func_174877_v())) {
            EssentialCraftCore.proxy.spawnParticle("cSpellFX", this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 3.0f, (float)this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 3.0f, 0.0, 2.0, 0.0);
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.emberforge";
            TileEmberForge.nightRequired = cfg.get(category, "NightRequired", true).getBoolean();
            TileEmberForge.timeRequired = cfg.get(category, "TicksRequired", 500).setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileEmberForge.nightRequired = true;
        TileEmberForge.timeRequired = 500;
        int x;
        int z;
        TileEmberForge.structureChecker = (BiPredicate<IBlockAccess, BlockPos>)BiPredicates.and((world, pos) -> {
            for (x = -2; x <= 2; ++x) {
                z = -2;
                while (z <= 2) {
                    if (!testBlock(world, pos.func_177982_a(x, -1, z), BlocksCore.voidStone)) {
                        return false;
                    }
                    else {
                        ++z;
                    }
                }
            }
            return true;
        }, (world, pos) -> testBlock(world, pos.func_177982_a(2, 0, 2), BlocksCore.voidStone) && testBlock(world, pos.func_177982_a(-2, 0, 2), BlocksCore.voidStone) && testBlock(world, pos.func_177982_a(2, 0, -2), BlocksCore.voidStone) && testBlock(world, pos.func_177982_a(-2, 0, -2), BlocksCore.voidStone) && testBlock(world, pos.func_177982_a(2, 0, 0), BlocksCore.platingPale) && testBlock(world, pos.func_177982_a(0, 0, 2), BlocksCore.platingPale) && testBlock(world, pos.func_177982_a(-2, 0, 0), BlocksCore.platingPale) && testBlock(world, pos.func_177982_a(0, 0, -2), BlocksCore.platingPale) && testBlock(world, pos.func_177982_a(2, 1, 2), BlocksCore.magicPlating) && testBlock(world, pos.func_177982_a(-2, 1, 2), BlocksCore.magicPlating) && testBlock(world, pos.func_177982_a(-2, 1, -2), BlocksCore.magicPlating) && testBlock(world, pos.func_177982_a(2, 1, -2), BlocksCore.magicPlating));
    }
}
