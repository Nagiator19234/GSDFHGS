package essentialcraft.common.tile;

import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraftforge.oredict.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.nbt.*;
import DummyCore.Utils.*;
import net.minecraftforge.common.config.*;

public class TileFlowerBurner extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static float cfgBalance;
    public static int mruGenerated;
    public static int flowerBurnTime;
    public static int saplingBurnTime;
    public static int tallgrassBurnTime;
    public static boolean createDeadBush;
    public BlockPos burnedFlower;
    public int burnTime;
    private boolean firstTick;
    
    public TileFlowerBurner() {
        super(TileFlowerBurner.cfgMaxMRU);
        this.burnTime = 0;
        this.firstTick = true;
        this.slot0IsBoundGem = false;
    }
    
    @Override
    public void func_73660_a() {
        if (this.firstTick) {
            if (TileFlowerBurner.cfgBalance < 0.0f) {
                this.mruStorage.setBalance(this.func_145831_w().field_73012_v.nextFloat() * 2.0f);
            }
            else {
                this.mruStorage.setBalance(TileFlowerBurner.cfgBalance);
            }
        }
        super.func_73660_a();
        this.firstTick = false;
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            if (!this.func_145831_w().field_72995_K) {
                if (this.burnedFlower == null && this.mruStorage.getMRU() < this.mruStorage.getMaxMRU()) {
                    final int offsetX = (int)(MathUtils.randomDouble(this.func_145831_w().field_73012_v) * 8.0);
                    final int offsetZ = (int)(MathUtils.randomDouble(this.func_145831_w().field_73012_v) * 8.0);
                    final IBlockState state = this.func_145831_w().func_180495_p(this.field_174879_c.func_177982_a(offsetX, 0, offsetZ));
                    final Block b = state.func_177230_c();
                    if (b != Blocks.field_150350_a && Item.func_150898_a(b) != null) {
                        final int[] ids = OreDictionary.getOreIDs(new ItemStack(b, 1, b.func_180651_a(state)));
                        String name = "";
                        if (ids != null && ids.length > 0) {
                            for (final int oreDictID : ids) {
                                final String n = OreDictionary.getOreName(oreDictID);
                                if (n != null && !n.isEmpty()) {
                                    name = n;
                                    break;
                                }
                            }
                        }
                        if (name.toLowerCase().contains("flower") || b instanceof BlockFlower) {
                            this.burnedFlower = this.field_174879_c.func_177982_a(offsetX, 0, offsetZ);
                            this.burnTime = TileFlowerBurner.flowerBurnTime;
                        }
                        if (name.toLowerCase().contains("sapling") || b instanceof BlockSapling) {
                            this.burnedFlower = this.field_174879_c.func_177982_a(offsetX, 0, offsetZ);
                            this.burnTime = TileFlowerBurner.saplingBurnTime;
                        }
                        if (name.toLowerCase().contains("tallgrass") || b instanceof BlockTallGrass) {
                            this.burnedFlower = this.field_174879_c.func_177982_a(offsetX, 0, offsetZ);
                            this.burnTime = TileFlowerBurner.tallgrassBurnTime;
                        }
                    }
                }
                else if (this.burnedFlower != null) {
                    --this.burnTime;
                    this.mruStorage.addMRU(TileFlowerBurner.mruGenerated, true);
                    if (this.burnTime <= 0) {
                        if (TileFlowerBurner.createDeadBush) {
                            final Block blk = this.func_145831_w().func_180495_p(this.burnedFlower.func_177977_b()).func_177230_c();
                            if (blk == Blocks.field_150349_c) {
                                this.func_145831_w().func_180501_a(this.burnedFlower.func_177977_b(), Blocks.field_150346_d.func_176223_P(), 3);
                            }
                            this.func_145831_w().func_180501_a(this.burnedFlower, Blocks.field_150330_I.func_176223_P(), 3);
                        }
                        else {
                            this.func_145831_w().func_180501_a(this.burnedFlower, Blocks.field_150350_a.func_176223_P(), 3);
                        }
                        this.burnedFlower = null;
                    }
                }
            }
            if (this.field_145850_b.field_72995_K && this.burnedFlower != null && this.burnTime > 0) {
                this.func_145831_w().func_175688_a(EnumParticleTypes.FLAME, (double)(this.burnedFlower.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.3f), (double)(this.burnedFlower.func_177956_o() + 0.1f + this.func_145831_w().field_73012_v.nextFloat() / 2.0f), (double)(this.burnedFlower.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.3f), 0.0, 0.0, 0.0, new int[0]);
                for (int t = 0; t < 200; ++t) {
                    EssentialCraftCore.proxy.SmokeFX(this.burnedFlower.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.3f, this.burnedFlower.func_177956_o() + 0.1f + this.func_145831_w().field_73012_v.nextFloat() / 2.0f, this.burnedFlower.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.3f, 0.0, 0.0, 0.0, 1.0);
                }
            }
        }
        if (this.field_145850_b.field_72995_K) {
            EssentialCraftCore.proxy.FlameFX(this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.4f, this.field_174879_c.func_177956_o() + 0.1f, this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.4f, 0.0, 0.009999999776482582, 0.0, 1.0, 0.5, 1.0, 1.0);
            EssentialCraftCore.proxy.FlameFX(this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.2f, this.field_174879_c.func_177956_o() + 0.2f, this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.2f, 0.0, 0.009999999776482582, 0.0, 1.0, 0.5, 1.0, 1.0);
            for (int i = 0; i < 10; ++i) {
                EssentialCraftCore.proxy.SmokeFX(this.field_174879_c.func_177958_n() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.1f, this.field_174879_c.func_177956_o() + 0.6f, this.field_174879_c.func_177952_p() + 0.5f + MathUtils.randomFloat(this.func_145831_w().field_73012_v) * 0.1f, 0.0, 0.0, 0.0, 1.0);
            }
        }
    }
    
    @Override
    public void func_145839_a(final NBTTagCompound i) {
        if (i.func_74764_b("coord")) {
            final DummyData[] coordData = DataStorage.parseData(i.func_74779_i("coord"));
            this.burnedFlower = new BlockPos(Integer.parseInt(coordData[0].fieldValue), Integer.parseInt(coordData[1].fieldValue), Integer.parseInt(coordData[2].fieldValue));
        }
        else {
            this.burnedFlower = null;
        }
        this.burnTime = i.func_74762_e("burn");
        super.func_145839_a(i);
    }
    
    @Override
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        if (this.burnedFlower != null) {
            i.func_74778_a("coord", "||x:" + this.burnedFlower.func_177958_n() + "||y:" + this.burnedFlower.func_177956_o() + "||z:" + this.burnedFlower.func_177952_p());
        }
        i.func_74768_a("burn", this.burnTime);
        return super.func_189515_b(i);
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.naturalfurnace";
            TileFlowerBurner.cfgMaxMRU = cfg.get(category, "MaxMRU", 10000).setMinValue(1).getInt();
            TileFlowerBurner.cfgBalance = (float)cfg.get(category, "Balance", -1.0, "Default balance (-1 is random)").setMinValue(-1.0).setMaxValue(2.0).getDouble();
            TileFlowerBurner.mruGenerated = cfg.get(category, "MRUGenerated", 10, "MRU generated per tick").setMinValue(0).getInt();
            TileFlowerBurner.flowerBurnTime = cfg.get(category, "TicksRequiredFlower", 600).setMinValue(0).getInt();
            TileFlowerBurner.saplingBurnTime = cfg.get(category, "TicksRequiredSapling", 900).setMinValue(0).getInt();
            TileFlowerBurner.tallgrassBurnTime = cfg.get(category, "TicksRequiredGrass", 150).setMinValue(0).getInt();
            TileFlowerBurner.createDeadBush = cfg.get(category, "LeaveDeadBush", true).getBoolean();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileFlowerBurner.cfgMaxMRU = 10000;
        TileFlowerBurner.cfgBalance = -1.0f;
        TileFlowerBurner.mruGenerated = 10;
        TileFlowerBurner.flowerBurnTime = 600;
        TileFlowerBurner.saplingBurnTime = 900;
        TileFlowerBurner.tallgrassBurnTime = 150;
        TileFlowerBurner.createDeadBush = true;
    }
}
