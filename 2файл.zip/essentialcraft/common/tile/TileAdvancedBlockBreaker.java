package essentialcraft.common.tile;

import net.minecraft.util.*;
import essentialcraft.common.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import essentialcraft.common.inventory.*;
import essentialcraft.utils.common.*;
import net.minecraft.inventory.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import net.minecraft.world.*;

public class TileAdvancedBlockBreaker extends TileMRUGeneric
{
    public TileAdvancedBlockBreaker() {
        super(0);
        this.slot0IsBoundGem = false;
        this.setSlotsNum(1);
    }
    
    public EnumFacing getRotation() {
        int metadata = ((EnumFacing)this.func_145831_w().func_180495_p(this.field_174879_c).func_177229_b((IProperty)BlockAdvBlockBreaker.FACING)).func_176745_a();
        if (metadata > 5) {
            metadata %= 6;
        }
        return EnumFacing.func_82600_a(metadata);
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 0 };
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return stack.func_77973_b() instanceof ItemFilter;
    }
    
    public void breakBlocks() {
        for (int i = 1; i < 13; ++i) {
            final BlockPos p = this.field_174879_c.func_177967_a(this.getRotation(), i);
            final Block b = this.func_145831_w().func_180495_p(p).func_177230_c();
            if (b != null && !b.isAir(this.func_145831_w().func_180495_p(p), (IBlockAccess)this.func_145831_w(), p)) {
                final ItemStack fromBlock = b.func_185473_a(this.func_145831_w(), p, this.func_145831_w().func_180495_p(p));
                final World w = this.func_145831_w();
                if (this.func_70301_a(0).func_190926_b() || !(this.func_70301_a(0).func_77973_b() instanceof ItemFilter)) {
                    b.func_180663_b(w, p, w.func_180495_p(p));
                    b.func_176206_d(w, p, w.func_180495_p(p));
                    b.func_176226_b(w, p, w.func_180495_p(p), 0);
                    w.func_175698_g(p);
                }
                else if (ECUtils.canFilterAcceptItem((IInventory)new InventoryMagicFilter(this.func_70301_a(0)), fromBlock, this.func_70301_a(0))) {
                    b.func_180663_b(w, p, w.func_180495_p(p));
                    b.func_176206_d(w, p, w.func_180495_p(p));
                    b.func_176226_b(w, p, w.func_180495_p(p), 0);
                    w.func_175698_g(p);
                }
            }
        }
    }
}
