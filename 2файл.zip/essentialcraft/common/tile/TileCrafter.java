package essentialcraft.common.tile;

import net.minecraft.item.*;
import essentialcraft.common.item.*;
import essentialcraft.common.inventory.*;
import essentialcraft.utils.common.*;
import net.minecraft.item.crafting.*;
import net.minecraft.inventory.*;
import java.util.*;

public class TileCrafter extends TileMRUGeneric
{
    public TileCrafter() {
        super(0);
        this.setSlotsNum(11);
        this.slot0IsBoundGem = false;
    }
    
    @Override
    public int func_70297_j_() {
        return 64;
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 9 };
    }
    
    @Override
    public void func_73660_a() {
        if (this.func_145831_w().func_175687_A(this.field_174879_c) > 0 || this.func_145831_w().func_175676_y(this.field_174879_c) > 0) {
            if (!this.hasFrame()) {
                this.makeRecipe();
            }
            else if (this.hasSufficientForCraftWithFrame()) {
                this.makeRecipe();
            }
        }
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return !stack.func_190926_b() && ((slot == 10) ? this.isFrame(stack) : (slot != 9 && this.isItemFineForSlot(stack, slot)));
    }
    
    public boolean isFrame(final ItemStack is) {
        return !is.func_190926_b() && is.func_77973_b() instanceof ItemCraftingFrame && new InventoryCraftingFrame(is).inventory[9] != null;
    }
    
    public boolean isItemFineForSlot(final ItemStack compared, final int slotNum) {
        return !this.hasFrame() || this.areStacksTheSame(this.getRecipeFromFrame()[slotNum], compared, this.hasOreDict());
    }
    
    public boolean hasOreDict() {
        return !this.func_70301_a(10).func_190926_b() && this.func_70301_a(10).func_77973_b() instanceof ItemCraftingFrame && this.func_70301_a(10).func_77978_p() != null && !this.func_70301_a(10).func_77978_p().func_74767_n("ignoreOreDict");
    }
    
    public boolean hasFrame() {
        return !this.func_70301_a(10).func_190926_b() && this.func_70301_a(10).func_77973_b() instanceof ItemCraftingFrame && new InventoryCraftingFrame(this.func_70301_a(10)).inventory[9] != null;
    }
    
    public boolean areStacksTheSame(final ItemStack stk1, final ItemStack stk2, final boolean oreDict) {
        if (stk1.func_190926_b() && stk2.func_190926_b()) {
            return true;
        }
        if (stk1.func_190926_b() || stk2.func_190926_b()) {
            return false;
        }
        if (!oreDict) {
            if (!stk1.func_77969_a(stk2) || !ItemStack.func_77989_b(stk1, stk2)) {
                return false;
            }
        }
        else if (!ECUtils.oreDictionaryCompare(stk1, stk2)) {
            return false;
        }
        return true;
    }
    
    public boolean hasSufficientForCraftWithFrame() {
        final ItemStack[] frame = this.getRecipeFromFrame();
        for (int i = 0; i < 9; ++i) {
            final ItemStack stk = this.func_70301_a(i);
            if (!this.areStacksTheSame(frame[i], stk, this.hasOreDict())) {
                return false;
            }
        }
        return true;
    }
    
    public ItemStack[] getRecipeFromFrame() {
        if (!this.func_70301_a(10).func_190926_b() && this.func_70301_a(10).func_77973_b() instanceof ItemCraftingFrame) {
            final InventoryCraftingFrame cInv = new InventoryCraftingFrame(this.func_70301_a(10));
            if (!cInv.inventory[9].func_190926_b()) {
                final ItemStack[] arrayStk = { cInv.inventory[0], cInv.inventory[3], cInv.inventory[6], cInv.inventory[1], cInv.inventory[4], cInv.inventory[7], cInv.inventory[2], cInv.inventory[5], cInv.inventory[8] };
                return arrayStk;
            }
        }
        return null;
    }
    
    public void makeRecipe() {
        final InventoryCraftingNoContainer craftingInv = new InventoryCraftingNoContainer(3, 3);
        for (int i = 0; i < 9; ++i) {
            craftingInv.func_70299_a(i, this.func_70301_a(i));
        }
        final ItemStack result = CraftingManager.func_82787_a((InventoryCrafting)craftingInv, this.func_145831_w());
        if (!result.func_190926_b()) {
            if (!this.func_70301_a(9).func_190926_b()) {
                this.func_70299_a(9, result.func_77946_l());
                this.decreaseStacks();
            }
            else if (this.func_70301_a(9).func_77969_a(result) && ItemStack.func_77970_a(result, this.func_70301_a(9)) && this.func_70301_a(9).func_190916_E() + result.func_190916_E() <= this.func_70297_j_() && this.func_70301_a(9).func_190916_E() + result.func_190916_E() <= result.func_77976_d()) {
                this.func_70301_a(9).func_190917_f(result.func_190916_E());
                this.decreaseStacks();
            }
        }
    }
    
    public void decreaseStacks() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack is = this.func_70301_a(i);
            if (!is.func_190926_b()) {
                final ItemStack container = is.func_77973_b().getContainerItem(is);
                this.func_70298_a(i, 1);
                if ((!this.func_70301_a(i).func_190926_b() || this.func_70301_a(i).func_190916_E() <= 0) && container != null) {
                    this.func_70299_a(i, container.func_77946_l());
                }
            }
        }
    }
    
    public static class InventoryCraftingNoContainer extends InventoryCrafting
    {
        private ItemStack[] stackList;
        private int inventoryWidth;
        
        public InventoryCraftingNoContainer(final int width, final int height) {
            super((Container)null, width, height);
            final int k = width * height;
            Arrays.fill(this.stackList = new ItemStack[k], ItemStack.field_190927_a);
            this.inventoryWidth = width;
        }
        
        public int func_70302_i_() {
            return this.stackList.length;
        }
        
        public ItemStack func_70301_a(final int slot) {
            return (slot >= this.func_70302_i_()) ? ItemStack.field_190927_a : this.stackList[slot];
        }
        
        public ItemStack func_70463_b(final int row, final int column) {
            if (row >= 0 && row < this.inventoryWidth) {
                final int k = row + column * this.inventoryWidth;
                return this.func_70301_a(k);
            }
            return ItemStack.field_190927_a;
        }
        
        public ItemStack func_70304_b(final int slot) {
            if (!this.stackList[slot].func_190926_b()) {
                final ItemStack itemstack = this.stackList[slot];
                this.stackList[slot] = ItemStack.field_190927_a;
                return itemstack;
            }
            return ItemStack.field_190927_a;
        }
        
        public ItemStack func_70298_a(final int slot, final int amount) {
            if (this.stackList[slot].func_190926_b()) {
                return ItemStack.field_190927_a;
            }
            if (this.stackList[slot].func_190916_E() <= amount) {
                final ItemStack itemstack = this.stackList[slot];
                this.stackList[slot] = ItemStack.field_190927_a;
                return itemstack;
            }
            final ItemStack itemstack = this.stackList[slot].func_77979_a(amount);
            if (this.stackList[slot].func_190916_E() == 0) {
                this.stackList[slot] = ItemStack.field_190927_a;
            }
            return itemstack;
        }
        
        public void func_70299_a(final int slot, final ItemStack stack) {
            this.stackList[slot] = stack;
        }
    }
}
