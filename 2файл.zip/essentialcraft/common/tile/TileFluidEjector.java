package essentialcraft.common.tile;

import net.minecraft.util.*;

public class TileFluidEjector extends TileMRUGeneric
{
    public EnumFacing getRotation() {
        int metadata = this.func_145832_p();
        metadata %= 6;
        return EnumFacing.func_82600_a(metadata);
    }
    
    public TileFluidEjector() {
        super(0);
        this.setSlotsNum(0);
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
}
