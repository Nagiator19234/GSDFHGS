package essentialcraft.common.tile;

import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import net.minecraft.entity.monster.*;
import java.util.*;
import net.minecraftforge.common.config.*;

public class TileAnimalSeparator extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static int mruUsage;
    public static double radius;
    public static double radiusIgnore;
    
    public TileAnimalSeparator() {
        super(TileAnimalSeparator.cfgMaxMRU);
        this.setSlotsNum(1);
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
    }
    
    public void separate(final boolean b) {
        final AxisAlignedBB toTeleport = new AxisAlignedBB(this.field_174879_c).func_72314_b(TileAnimalSeparator.radius, TileAnimalSeparator.radius, TileAnimalSeparator.radius);
        final AxisAlignedBB noTeleport = new AxisAlignedBB(this.field_174879_c).func_72314_b(TileAnimalSeparator.radiusIgnore, TileAnimalSeparator.radiusIgnore, TileAnimalSeparator.radiusIgnore);
        final List<EntityAgeable> tp = (List<EntityAgeable>)this.func_145831_w().func_175647_a((Class)EntityAgeable.class, toTeleport, entity -> !this.func_145831_w().func_72872_a((Class)EntityAgeable.class, noTeleport).contains(entity));
        for (final EntityAgeable e : tp) {
            if (!e.field_70128_L && !(e instanceof IMob) && ((b && e.func_70631_g_()) || (!b && !e.func_70631_g_())) && this.mruStorage.getMRU() >= 100) {
                this.mruStorage.extractMRU(TileAnimalSeparator.mruUsage, true);
                e.func_70080_a(this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 1.5, this.field_174879_c.func_177952_p() + 0.5, 0.0f, 0.0f);
            }
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.animalseparator";
            TileAnimalSeparator.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileAnimalSeparator.mruUsage = cfg.get(category, "MRUUsage", 100).setMinValue(0).setMaxValue(TileAnimalSeparator.cfgMaxMRU).getInt();
            TileAnimalSeparator.radius = cfg.get(category, "Radius", 24.0).setMinValue(0).getDouble();
            TileAnimalSeparator.radiusIgnore = cfg.get(category, "RadiusIgnore", 5.0).setMinValue(0).setMaxValue(TileAnimalSeparator.radius).getDouble();
        }
        catch (Exception e) {}
    }
    
    static {
        TileAnimalSeparator.cfgMaxMRU = 5000;
        TileAnimalSeparator.mruUsage = 100;
        TileAnimalSeparator.radius = 24.0;
        TileAnimalSeparator.radiusIgnore = 5.0;
    }
}
