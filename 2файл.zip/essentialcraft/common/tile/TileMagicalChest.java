package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraftforge.items.wrapper.*;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.player.*;
import DummyCore.Utils.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.items.*;

public class TileMagicalChest extends TileEntity implements ISidedInventory, ITickable
{
    public float lidAngle;
    public float prevLidAngle;
    public int numUsingPlayers;
    private int ticksSinceSync;
    private ItemStack[] inventory;
    public int syncTick;
    public int rotation;
    private TileStatTracker tracker;
    public boolean requestSync;
    public int metadata;
    public IItemHandler itemHandler;
    
    public TileMagicalChest(final int metaData) {
        this();
        this.setSlotsNum(this.metadata = metaData);
    }
    
    public TileMagicalChest() {
        this.inventory = new ItemStack[0];
        this.syncTick = 10;
        this.requestSync = true;
        this.itemHandler = (IItemHandler)new SidedInvWrapper((ISidedInventory)this, EnumFacing.DOWN);
        this.tracker = new TileStatTracker((TileEntity)this);
    }
    
    public void setSlotsNum(final int meta) {
        Arrays.fill(this.inventory = new ItemStack[(meta == 0) ? 54 : 117], ItemStack.field_190927_a);
    }
    
    public void func_145839_a(final NBTTagCompound i) {
        super.func_145839_a(i);
        this.setSlotsNum(this.metadata = i.func_74762_e("metadata"));
        this.rotation = i.func_74762_e("rotation");
        MiscUtils.loadInventory((TileEntity)this, i);
    }
    
    public NBTTagCompound func_189515_b(final NBTTagCompound i) {
        super.func_189515_b(i);
        i.func_74768_a("metadata", this.metadata);
        i.func_74768_a("rotation", this.rotation);
        MiscUtils.saveInventory((TileEntity)this, i);
        return i;
    }
    
    public int func_70302_i_() {
        return this.inventory.length;
    }
    
    public ItemStack func_70301_a(final int slotIndex) {
        return this.inventory[slotIndex];
    }
    
    public ItemStack func_70298_a(final int slotIndex, final int decrementAmount) {
        ItemStack itemStack = this.func_70301_a(slotIndex);
        if (!itemStack.func_190926_b()) {
            if (itemStack.func_190916_E() <= decrementAmount) {
                this.func_70299_a(slotIndex, ItemStack.field_190927_a);
            }
            else {
                itemStack = itemStack.func_77979_a(decrementAmount);
                if (itemStack.func_190916_E() == 0) {
                    this.func_70299_a(slotIndex, ItemStack.field_190927_a);
                }
            }
        }
        return itemStack;
    }
    
    public ItemStack func_70304_b(final int slotIndex) {
        if (!this.inventory[slotIndex].func_190926_b()) {
            final ItemStack itemStack = this.inventory[slotIndex];
            this.inventory[slotIndex] = ItemStack.field_190927_a;
            return itemStack;
        }
        return ItemStack.field_190927_a;
    }
    
    public void func_70299_a(final int slotIndex, final ItemStack itemStack) {
        this.inventory[slotIndex] = itemStack;
        if (!itemStack.func_190926_b() && itemStack.func_190916_E() > this.func_70297_j_()) {
            itemStack.func_190920_e(this.func_70297_j_());
        }
        this.func_70296_d();
    }
    
    public String func_70005_c_() {
        return "magicalChest";
    }
    
    public boolean func_145818_k_() {
        return false;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public boolean func_70300_a(final EntityPlayer player) {
        return this.func_145831_w().func_175625_s(this.func_174877_v()) == this && player.field_71093_bK == this.func_145831_w().field_73011_w.getDimension() && this.func_174877_v().func_177957_d(player.field_70165_t, player.field_70163_u, player.field_70161_v) <= 64.0;
    }
    
    public void func_174889_b(final EntityPlayer p) {
        ++this.numUsingPlayers;
        this.func_145831_w().func_175641_c(this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c(), 1, this.numUsingPlayers);
    }
    
    public void func_174886_c(final EntityPlayer p) {
        --this.numUsingPlayers;
        this.func_145831_w().func_175641_c(this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c(), 1, this.numUsingPlayers);
    }
    
    public boolean func_94041_b(final int slotIndex, final ItemStack itemStack) {
        return true;
    }
    
    public void func_73660_a() {
        if (this.syncTick == 0) {
            if (this.tracker == null) {
                Notifier.notifyCustomMod("EssentialCraft", "[WARNING][SEVERE]TileEntity " + this + " at pos " + this.field_174879_c.func_177958_n() + ", " + this.field_174879_c.func_177956_o() + ", " + this.field_174879_c.func_177952_p() + " tries to sync itself, but has no TileTracker attached to it! SEND THIS MESSAGE TO THE DEVELOPER OF THE MOD!");
            }
            else if (!this.func_145831_w().field_72995_K && this.tracker.tileNeedsSyncing()) {
                MiscUtils.sendPacketToAllAround(this.func_145831_w(), (Packet)this.func_189518_D_(), this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p(), this.func_145831_w().field_73011_w.getDimension(), 32.0);
            }
            this.syncTick = 60;
        }
        else {
            --this.syncTick;
        }
        if (this.requestSync && this.func_145831_w().field_72995_K) {
            this.requestSync = false;
            ECUtils.requestScheduledTileSync(this, EssentialCraftCore.proxy.getClientPlayer());
        }
        if (++this.ticksSinceSync % 20 * 4 == 0) {
            this.func_145831_w().func_175641_c(this.field_174879_c, this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c(), 1, this.numUsingPlayers);
        }
        this.prevLidAngle = this.lidAngle;
        final float angleIncrement = 0.1f;
        if (this.numUsingPlayers > 0 && this.lidAngle == 0.0f) {
            this.func_145831_w().func_184133_a((EntityPlayer)null, this.field_174879_c, SoundEvents.field_187657_V, SoundCategory.BLOCKS, 0.5f, this.func_145831_w().field_73012_v.nextFloat() * 0.1f + 0.9f);
        }
        if ((this.numUsingPlayers == 0 && this.lidAngle > 0.0f) || (this.numUsingPlayers > 0 && this.lidAngle < 1.0f)) {
            final float var8 = this.lidAngle;
            if (this.numUsingPlayers > 0) {
                this.lidAngle += angleIncrement;
            }
            else {
                this.lidAngle -= angleIncrement;
            }
            if (this.lidAngle > 1.0f) {
                this.lidAngle = 1.0f;
            }
            if (this.lidAngle < 0.5f && var8 >= 0.5f) {
                this.func_145831_w().func_184133_a((EntityPlayer)null, this.field_174879_c, SoundEvents.field_187651_T, SoundCategory.BLOCKS, 0.5f, this.func_145831_w().field_73012_v.nextFloat() * 0.1f + 0.9f);
            }
            if (this.lidAngle < 0.0f) {
                this.lidAngle = 0.0f;
            }
        }
    }
    
    public boolean func_145842_c(final int eventID, final int numUsingPlayers) {
        if (eventID == 1) {
            this.numUsingPlayers = numUsingPlayers;
            return true;
        }
        return super.func_145842_c(eventID, numUsingPlayers);
    }
    
    public SPacketUpdateTileEntity func_189518_D_() {
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        this.func_189515_b(nbttagcompound);
        return new SPacketUpdateTileEntity(this.field_174879_c, -10, nbttagcompound);
    }
    
    public void onDataPacket(final NetworkManager net, final SPacketUpdateTileEntity pkt) {
        if (pkt.func_148853_f() == -10) {
            this.func_145839_a(pkt.func_148857_g());
        }
    }
    
    public int[] func_180463_a(final EnumFacing side) {
        final int[] ret = new int[this.inventory.length];
        for (int i = 0; i < ret.length; ++i) {
            ret[i] = i;
        }
        return ret;
    }
    
    public boolean func_180462_a(final int slot, final ItemStack stack, final EnumFacing side) {
        return true;
    }
    
    public boolean func_180461_b(final int slot, final ItemStack stack, final EnumFacing side) {
        return true;
    }
    
    public void func_174888_l() {
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            this.func_70299_a(i, ItemStack.field_190927_a);
        }
    }
    
    public int func_174887_a_(final int id) {
        return 0;
    }
    
    public void func_174885_b(final int id, final int value) {
    }
    
    public int func_174890_g() {
        return 0;
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability((Capability)capability, facing);
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) ? this.itemHandler : super.getCapability((Capability)capability, facing));
    }
    
    public boolean func_191420_l() {
        boolean ret = true;
        for (final ItemStack stk : this.inventory) {
            ret &= stk.func_190926_b();
        }
        return ret;
    }
}
