package essentialcraft.common.tile;

import net.minecraft.tileentity.*;
import net.minecraft.network.play.server.*;
import net.minecraft.world.biome.*;
import DummyCore.Utils.*;
import net.minecraft.nbt.*;
import net.minecraft.network.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.math.*;
import essentialcraft.utils.common.*;
import essentialcraft.common.registry.*;
import essentialcraft.common.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.potion.*;
import net.minecraft.block.*;
import java.util.*;
import net.minecraftforge.common.config.*;

public class TileCorruption extends TileEntity implements ITickable
{
    public static boolean canChangeBiome;
    public static boolean canDestroyBlocks;
    
    public void onDataPacket(final NetworkManager net, final SPacketUpdateTileEntity pkt) {
        if (pkt.func_148853_f() == -11) {
            final NBTTagCompound packetTag = pkt.func_148857_g();
            final int biomeID = packetTag.func_74762_e("biomeID");
            MiscUtils.changeBiome(this.func_145831_w(), Biome.func_150568_d(biomeID), this.field_174879_c.func_177958_n(), this.field_174879_c.func_177952_p());
        }
    }
    
    public void changeBiomeAtPos(final int biomeID) {
        if (TileCorruption.canChangeBiome) {
            MiscUtils.changeBiome(this.func_145831_w(), Biome.func_150568_d(biomeID), this.field_174879_c.func_177958_n(), this.field_174879_c.func_177952_p());
            final NBTTagCompound nbttagcompound = new NBTTagCompound();
            nbttagcompound.func_74768_a("biomeID", biomeID);
            final SPacketUpdateTileEntity pkt = new SPacketUpdateTileEntity(this.field_174879_c, -11, nbttagcompound);
            MiscUtils.sendPacketToAllAround(this.func_145831_w(), (Packet)pkt, this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p(), this.func_145831_w().field_73011_w.getDimension(), 32.0);
        }
    }
    
    public void addPotionEffectAtEntity(final EntityLivingBase e, final PotionEffect p) {
        if (!e.func_70644_a(p.func_188419_a())) {
            e.func_70690_d(p);
        }
    }
    
    public void func_73660_a() {
        try {
            Potion potionToAdd = PotionRegistry.mruCorruption;
            final Block blk = this.func_145831_w().func_180495_p(this.field_174879_c).func_177230_c();
            if (blk == BlocksCore.lightCorruption[0]) {
                potionToAdd = PotionRegistry.chaosInfluence;
            }
            if (blk == BlocksCore.lightCorruption[1]) {
                potionToAdd = PotionRegistry.frozenMind;
            }
            final List<EntityPlayer> players = (List<EntityPlayer>)this.func_145831_w().func_72872_a((Class)EntityPlayer.class, new AxisAlignedBB(this.field_174879_c));
            for (final EntityPlayer player : players) {
                if (!player.func_184812_l_() && !player.func_175149_v()) {
                    float increasement = 5.0f;
                    increasement *= ECUtils.getGenResistance(1, player);
                    ECUtils.calculateAndAddPE(player, potionToAdd, 2000, (int)increasement);
                }
            }
            if (!this.func_145831_w().field_72995_K && this.func_145831_w().field_73012_v.nextFloat() <= 1.0E-4f) {
                int biomeId = 0;
                if (blk == BlocksCore.lightCorruption[0]) {
                    biomeId = Biome.func_185362_a(BiomeRegistry.chaosCorruption);
                }
                if (blk == BlocksCore.lightCorruption[1]) {
                    biomeId = Biome.func_185362_a(BiomeRegistry.frozenCorruption);
                }
                if (blk == BlocksCore.lightCorruption[2]) {
                    biomeId = Biome.func_185362_a(BiomeRegistry.shadowCorruption);
                }
                if (blk == BlocksCore.lightCorruption[3]) {
                    biomeId = Biome.func_185362_a(BiomeRegistry.magicCorruption);
                }
                this.changeBiomeAtPos(biomeId);
            }
            final int metadata = (int)this.func_145831_w().func_180495_p(this.field_174879_c).func_177229_b((IProperty)BlockCorruption.LEVEL);
            if (metadata >= 7 && TileCorruption.canDestroyBlocks) {
                for (int i = 0; i < 6; ++i) {
                    final EnumFacing dir = EnumFacing.func_82600_a(i);
                    if (this.func_145831_w().func_175625_s(this.field_174879_c.func_177972_a(dir)) == null && this.func_145831_w().func_180495_p(this.field_174879_c.func_177972_a(dir)).func_177230_c().isSideSolid(this.func_145831_w().func_180495_p(this.field_174879_c.func_177972_a(dir)), (IBlockAccess)this.func_145831_w(), this.field_174879_c.func_177972_a(dir), dir.func_176734_d())) {
                        this.func_145831_w().func_180501_a(this.field_174879_c.func_177972_a(dir), blk.func_176203_a(0), 3);
                    }
                }
                this.func_145831_w().func_175698_g(this.field_174879_c);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.corruption";
            TileCorruption.canChangeBiome = cfg.get(category, "ChangeBiome", true).getBoolean();
            TileCorruption.canDestroyBlocks = cfg.get(category, "DestroyBlocks", true, "Destroy blocks if grown").getBoolean();
        }
        catch (Exception e) {}
    }
    
    static {
        TileCorruption.canChangeBiome = true;
        TileCorruption.canDestroyBlocks = true;
    }
}
