package essentialcraft.common.tile;

import essentialcraft.utils.common.*;
import essentialcraft.common.block.*;
import DummyCore.Utils.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraftforge.oredict.*;
import net.minecraft.util.*;
import net.minecraftforge.common.config.*;

public class TileCrystalFormer extends TileMRUGeneric
{
    public int progressLevel;
    public static int cfgMaxMRU;
    public static int mruUsage;
    public static int requiredTime;
    public static boolean generatesCorruption;
    public static int genCorruption;
    
    public TileCrystalFormer() {
        super(TileCrystalFormer.cfgMaxMRU);
        this.setSlotsNum(8);
    }
    
    @Override
    public void func_73660_a() {
        super.func_73660_a();
        this.mruStorage.update(this.func_174877_v(), this.func_145831_w(), this.func_70301_a(0));
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            this.doWork();
        }
        this.spawnParticles();
    }
    
    public void doWork() {
        if (this.canWork() && this.mruStorage.getMRU() >= TileCrystalFormer.mruUsage) {
            this.mruStorage.extractMRU(TileCrystalFormer.mruUsage, true);
            ++this.progressLevel;
            if (TileCrystalFormer.generatesCorruption) {
                ECUtils.randomIncreaseCorruptionAt(this.func_145831_w(), this.field_174879_c, this.func_145831_w().field_73012_v, TileCrystalFormer.genCorruption);
            }
            if (this.progressLevel >= TileCrystalFormer.requiredTime) {
                this.progressLevel = 0;
                this.createItem();
            }
        }
    }
    
    public void createItem() {
        final ItemStack b = new ItemStack(Items.field_151133_ar, 1, 0);
        this.func_70299_a(2, b);
        this.func_70299_a(3, b);
        this.func_70299_a(4, b);
        this.func_70298_a(5, 1);
        this.func_70298_a(6, 1);
        this.func_70298_a(7, 1);
        final ItemStack crystal = new ItemStack(BlocksCore.elementalCrystal, 1, 0);
        MiscUtils.getStackTag(crystal).func_74776_a("size", 1.0f);
        MiscUtils.getStackTag(crystal).func_74776_a("fire", 0.0f);
        MiscUtils.getStackTag(crystal).func_74776_a("water", 0.0f);
        MiscUtils.getStackTag(crystal).func_74776_a("earth", 0.0f);
        MiscUtils.getStackTag(crystal).func_74776_a("air", 0.0f);
        this.func_70299_a(1, crystal);
    }
    
    public boolean canWork() {
        final ItemStack[] s = new ItemStack[7];
        for (int i = 1; i < 8; ++i) {
            s[i - 1] = this.func_70301_a(i);
        }
        return s[0].func_190926_b() && s[1].func_77973_b() == Items.field_151131_as && s[2].func_77973_b() == Items.field_151131_as && s[3].func_77973_b() == Items.field_151131_as && this.isGlassBlock(s[4]) && this.isGlassBlock(s[5]) && s[6].func_77973_b() == Items.field_151045_i;
    }
    
    public boolean isGlassBlock(final ItemStack is) {
        if (is.func_190926_b()) {
            return false;
        }
        if (is.func_77973_b() == Item.func_150898_a(Blocks.field_150359_w) || is.func_77973_b() == Item.func_150898_a((Block)Blocks.field_150399_cn)) {
            return true;
        }
        if (OreDictionary.getOreIDs(is) != null && OreDictionary.getOreIDs(is).length > 0) {
            for (int i = 0; i < OreDictionary.getOreIDs(is).length; ++i) {
                final String name = OreDictionary.getOreName(OreDictionary.getOreIDs(is)[i]);
                if (name.equals("blockGlass")) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public void spawnParticles() {
        if (this.field_145850_b.field_72995_K && this.canWork() && this.mruStorage.getMRU() > 0) {
            for (int o = 0; o < 10; ++o) {
                this.func_145831_w().func_175688_a(EnumParticleTypes.REDSTONE, this.field_174879_c.func_177958_n() + 0.1 + this.func_145831_w().field_73012_v.nextDouble() / 1.1, (double)(this.field_174879_c.func_177956_o() + o / 10.0f), this.field_174879_c.func_177952_p() + 0.1 + this.func_145831_w().field_73012_v.nextDouble() / 1.1, -1.0, 1.0, 1.0, new int[0]);
            }
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.crystalformer";
            TileCrystalFormer.cfgMaxMRU = cfg.get(category, "MaxMRU", 5000).setMinValue(1).getInt();
            TileCrystalFormer.mruUsage = cfg.get(category, "MRUUsage", 100).setMinValue(0).setMaxValue(TileCrystalFormer.cfgMaxMRU).getInt();
            TileCrystalFormer.requiredTime = cfg.get(category, "TicksRequired", 1000, "Ticks required to create a crystal").setMinValue(0).getInt();
            TileCrystalFormer.generatesCorruption = cfg.get(category, "GenerateCorruption", true).getBoolean();
            TileCrystalFormer.genCorruption = cfg.get(category, "MaxCorruptionGen", 2, "Max amount of corruption generated per tick").setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[] { 1, 2, 3, 4 };
    }
    
    @Override
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return (slot == 0) ? this.isBoundGem(stack) : ((slot >= 2 && slot <= 4) ? (stack.func_77973_b() == Items.field_151131_as) : ((slot >= 5 && slot <= 6) ? this.isGlassBlock(stack) : (slot == 7 && stack.func_77973_b() == Items.field_151045_i)));
    }
    
    static {
        TileCrystalFormer.cfgMaxMRU = 5000;
        TileCrystalFormer.mruUsage = 100;
        TileCrystalFormer.requiredTime = 1000;
        TileCrystalFormer.generatesCorruption = true;
        TileCrystalFormer.genCorruption = 2;
    }
}
