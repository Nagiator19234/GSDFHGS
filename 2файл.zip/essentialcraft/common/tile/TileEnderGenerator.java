package essentialcraft.common.tile;

import net.minecraft.util.math.*;
import net.minecraft.entity.monster.*;
import net.minecraftforge.fml.common.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraftforge.common.config.*;

public class TileEnderGenerator extends TileMRUGeneric
{
    public static int cfgMaxMRU;
    public static float cfgBalance;
    public static int mruGenerated;
    public static int endermenCatchRadius;
    private boolean firstTick;
    
    public TileEnderGenerator() {
        super(TileEnderGenerator.cfgMaxMRU);
        this.firstTick = true;
        this.slot0IsBoundGem = false;
    }
    
    @Override
    public void func_73660_a() {
        if (this.firstTick) {
            if (TileEnderGenerator.cfgBalance < 0.0f) {
                this.mruStorage.setBalance(this.func_145831_w().field_73012_v.nextFloat() * 2.0f);
            }
            else {
                this.mruStorage.setBalance(TileEnderGenerator.cfgBalance);
            }
        }
        super.func_73660_a();
        this.firstTick = false;
        if (this.func_145831_w().func_175687_A(this.field_174879_c) == 0) {
            final AxisAlignedBB endermenTPRadius = new AxisAlignedBB((double)(this.field_174879_c.func_177958_n() - TileEnderGenerator.endermenCatchRadius), (double)(this.field_174879_c.func_177956_o() - TileEnderGenerator.endermenCatchRadius), (double)(this.field_174879_c.func_177952_p() - TileEnderGenerator.endermenCatchRadius), (double)(this.field_174879_c.func_177958_n() + TileEnderGenerator.endermenCatchRadius + 1), (double)(this.field_174879_c.func_177956_o() + TileEnderGenerator.endermenCatchRadius + 1), (double)(this.field_174879_c.func_177952_p() + TileEnderGenerator.endermenCatchRadius + 1));
            final List<EntityEnderman> l = (List<EntityEnderman>)this.func_145831_w().func_72872_a((Class)EntityEnderman.class, endermenTPRadius);
            if (Loader.isModLoaded("hardcoreenderexpansion")) {
                try {
                    l.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobAngryEnderman"), endermenTPRadius));
                    l.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobBabyEnderman"), endermenTPRadius));
                    l.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobEndermage"), endermenTPRadius));
                    l.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobEnderman"), endermenTPRadius));
                    l.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobParalyzedEnderman"), endermenTPRadius));
                }
                catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (!l.isEmpty()) {
                for (final EntityEnderman element : l) {
                    element.func_70080_a(this.field_174879_c.func_177958_n() + 0.5, this.field_174879_c.func_177956_o() + 1.0, this.field_174879_c.func_177952_p() + 0.5, 0.0f, 0.0f);
                }
            }
            final AxisAlignedBB endermanAttackRad = new AxisAlignedBB((double)(this.field_174879_c.func_177958_n() - 2), (double)(this.field_174879_c.func_177956_o() - 2), (double)(this.field_174879_c.func_177952_p() - 2), (double)(this.field_174879_c.func_177958_n() + 2), (double)(this.field_174879_c.func_177956_o() + 2), (double)(this.field_174879_c.func_177952_p() + 2));
            final List<EntityEnderman> l2 = (List<EntityEnderman>)this.func_145831_w().func_72872_a((Class)EntityEnderman.class, endermanAttackRad);
            if (Loader.isModLoaded("hardcoreenderexpansion")) {
                try {
                    l2.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobAngryEnderman"), endermanAttackRad));
                    l2.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobBabyEnderman"), endermanAttackRad));
                    l2.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobEndermage"), endermanAttackRad));
                    l2.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobEnderman"), endermanAttackRad));
                    l2.addAll(this.func_145831_w().func_72872_a((Class)Class.forName("chylex.hee.entity.mob.EntityMobParalyzedEnderman"), endermanAttackRad));
                }
                catch (ClassNotFoundException e2) {
                    e2.printStackTrace();
                }
            }
            if (!l2.isEmpty()) {
                for (final EntityEnderman element2 : l2) {
                    if (element2.func_70097_a(DamageSource.field_76376_m, 1.0f)) {
                        this.mruStorage.addMRU(TileEnderGenerator.mruGenerated, true);
                    }
                }
            }
        }
    }
    
    public static void setupConfig(final Configuration cfg) {
        try {
            final String category = "tileentities.endergenerator";
            TileEnderGenerator.cfgMaxMRU = cfg.get(category, "MaxMRU", 10000).setMinValue(1).getInt();
            TileEnderGenerator.cfgBalance = (float)cfg.get(category, "Balance", -1.0, "Default balance, -1 is random").setMinValue(-1.0).setMaxValue(2.0).getDouble();
            TileEnderGenerator.mruGenerated = cfg.get(category, "MRUGenerated", 500, "MRU generated per hit").setMinValue(0).getInt();
            TileEnderGenerator.endermenCatchRadius = cfg.get(category, "Radius", 8, "Radius of Endermen detection").setMinValue(0).getInt();
        }
        catch (Exception e) {}
    }
    
    @Override
    public int[] getOutputSlots() {
        return new int[0];
    }
    
    static {
        TileEnderGenerator.cfgMaxMRU = 10000;
        TileEnderGenerator.cfgBalance = -1.0f;
        TileEnderGenerator.mruGenerated = 500;
        TileEnderGenerator.endermenCatchRadius = 8;
    }
}
