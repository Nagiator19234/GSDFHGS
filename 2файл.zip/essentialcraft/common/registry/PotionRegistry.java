package essentialcraft.common.registry;

import essentialcraft.common.potion.*;
import net.minecraft.potion.*;
import net.minecraftforge.registries.*;

public class PotionRegistry
{
    public static PotionMRUCorruption mruCorruption;
    public static PotionFrozenMind frozenMind;
    public static PotionChaosInfluence chaosInfluence;
    public static PotionWindTouch windTouch;
    public static PotionUnnormalLightness paranormalLightness;
    public static PotionRadiation radiation;
    public static PotionShadeCorruption shadeCorruption;
    public static PotionPurpleFlame purpleFlame;
    public static PotionMindfoldParadox paradox;
    
    public static void registerPotions(final IForgeRegistry<Potion> registry) {
        PotionRegistry.mruCorruption = new PotionMRUCorruption(true, 16711935);
        PotionRegistry.chaosInfluence = new PotionChaosInfluence(true, 16711680);
        PotionRegistry.frozenMind = new PotionFrozenMind(true, 255);
        PotionRegistry.windTouch = new PotionWindTouch(true, 13434828);
        PotionRegistry.paranormalLightness = new PotionUnnormalLightness(true, 16777164);
        PotionRegistry.radiation = new PotionRadiation(true, 6684774);
        PotionRegistry.paradox = new PotionMindfoldParadox(true, 16777215);
        registry.register((IForgeRegistryEntry)PotionRegistry.mruCorruption);
        registry.register((IForgeRegistryEntry)PotionRegistry.chaosInfluence);
        registry.register((IForgeRegistryEntry)PotionRegistry.frozenMind);
        registry.register((IForgeRegistryEntry)PotionRegistry.windTouch);
        registry.register((IForgeRegistryEntry)PotionRegistry.paranormalLightness);
        registry.register((IForgeRegistryEntry)PotionRegistry.radiation);
        registry.register((IForgeRegistryEntry)PotionRegistry.paradox);
    }
}
