package essentialcraft.common.registry;

import net.minecraft.util.*;
import DummyCore.Registries.*;

public class SoundRegistry
{
    public static SoundEvent recordLetsBeFriends;
    public static SoundEvent recordArstotzkan;
    public static SoundEvent recordSecret;
    public static SoundEvent recordRopocalypse;
    public static SoundEvent bookPageTurn;
    public static SoundEvent machineDeepNoise;
    public static SoundEvent potionTinnitus;
    public static SoundEvent potionHeartbeat;
    public static SoundEvent machineGenElectricity;
    public static SoundEvent machineLightningHit;
    public static SoundEvent entityMRUCUNoise;
    public static SoundEvent gunBeam;
    public static SoundEvent entityDemonSummon;
    public static SoundEvent entityDemonSay;
    public static SoundEvent entityDemonDepart;
    public static SoundEvent entityDemonDoom;
    public static SoundEvent entityDemonTrade;
    public static SoundEvent entityHologramDamageMelee;
    public static SoundEvent entityHologramDamageProjectile;
    public static SoundEvent entityHologramShutdown;
    public static SoundEvent entityHologramStop;
    public static SoundEvent entityHologramStart;
    public static SoundEvent entityOrbitalStrike;
    
    public static void init() {
        SoundRegistry.recordLetsBeFriends = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:records.letsbefriends")).setRegistryName("essentialcraft:records.letsbefriends"));
        SoundRegistry.recordArstotzkan = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:records.arstotzkan")).setRegistryName("essentialcraft:records.arstotzkan"));
        SoundRegistry.recordSecret = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:records.secret")).setRegistryName("essentialcraft:records.secret"));
        SoundRegistry.recordRopocalypse = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:records.hologram")).setRegistryName("essentialcraft:records.hologram"));
        SoundRegistry.bookPageTurn = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.pageturn")).setRegistryName("essentialcraft:sound.pageturn"));
        SoundRegistry.machineDeepNoise = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.deepnoise")).setRegistryName("essentialcraft:sound.deepnoise"));
        SoundRegistry.potionTinnitus = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.tinnitus")).setRegistryName("essentialcraft:sound.tinnitus"));
        SoundRegistry.potionHeartbeat = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.heartbeat")).setRegistryName("essentialcraft:sound.heartbeat"));
        SoundRegistry.machineGenElectricity = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.gen_electricity")).setRegistryName("essentialcraft:sound.gen_electricity"));
        SoundRegistry.machineLightningHit = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.lightning_hit")).setRegistryName("essentialcraft:sound.lightning_hit"));
        SoundRegistry.entityMRUCUNoise = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mrucu_noise")).setRegistryName("essentialcraft:sound.mrucu_noise"));
        SoundRegistry.gunBeam = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.beam")).setRegistryName("essentialcraft:sound.beam"));
        SoundRegistry.entityDemonSummon = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.demon.summon")).setRegistryName("essentialcraft:sound.mob.demon.summon"));
        SoundRegistry.entityDemonSay = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.demon.say")).setRegistryName("essentialcraft:sound.mob.demon.say"));
        SoundRegistry.entityDemonDepart = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.demon.depart")).setRegistryName("essentialcraft:sound.mob.demon.depart"));
        SoundRegistry.entityDemonDoom = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.demon.doom")).setRegistryName("essentialcraft:sound.mob.demon.doom"));
        SoundRegistry.entityDemonTrade = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.demon.trade")).setRegistryName("essentialcraft:sound.mob.demon.trade"));
        SoundRegistry.entityHologramDamageMelee = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.hologram.damage.melee")).setRegistryName("essentialcraft:sound.mob.hologram.damage.melee"));
        SoundRegistry.entityHologramDamageProjectile = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.hologram.damage.projectile")).setRegistryName("essentialcraft:sound.mob.hologram.damage.projectile"));
        SoundRegistry.entityHologramShutdown = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.hologram.shutdown")).setRegistryName("essentialcraft:sound.mob.hologram.shutdown"));
        SoundRegistry.entityHologramStop = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.hologram.stop")).setRegistryName("essentialcraft:sound.mob.hologram.stop"));
        SoundRegistry.entityHologramStart = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.mob.hologram.start")).setRegistryName("essentialcraft:sound.mob.hologram.start"));
        SoundRegistry.entityOrbitalStrike = (SoundEvent)GenericRegistry.register(new SoundEvent(new ResourceLocation("essentialcraft:sound.orbital_strike")).setRegistryName("essentialcraft:sound.orbital_strike"));
    }
}
