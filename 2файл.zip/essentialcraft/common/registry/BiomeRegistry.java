package essentialcraft.common.registry;

import net.minecraft.world.biome.*;
import net.minecraftforge.event.terraingen.*;
import net.minecraftforge.fml.common.eventhandler.*;
import essentialcraft.common.world.biome.*;
import net.minecraftforge.registries.*;
import net.minecraftforge.common.*;

public class BiomeRegistry
{
    public static Biome chaosCorruption;
    public static Biome frozenCorruption;
    public static Biome shadowCorruption;
    public static Biome magicCorruption;
    public static Biome dreadlands;
    public static Biome desert;
    
    @SubscribeEvent
    public void manageBiomeGen(final WorldTypeEvent.InitBiomeGens event) {
    }
    
    public static void register(final IForgeRegistry<Biome> registry) {
        BiomeRegistry.chaosCorruption = (Biome)new BiomeChaosCorruption(new Biome.BiomeProperties("Chaos Corrupted Land")).setRegistryName("essentialcraft:chaoscorruption");
        BiomeRegistry.frozenCorruption = (Biome)new BiomeFrozenCorruption(new Biome.BiomeProperties("Frozen Corrupted Land")).setRegistryName("essentialcraft:frozencorruption");
        BiomeRegistry.shadowCorruption = (Biome)new BiomeShadowCorruption(new Biome.BiomeProperties("Shadow Corrupted Land")).setRegistryName("essentialcraft:shadowcorruption");
        BiomeRegistry.magicCorruption = (Biome)new BiomeMagicCorruption(new Biome.BiomeProperties("Magic Corrupted Land")).setRegistryName("essentialcraft:magiccorruption");
        BiomeRegistry.dreadlands = (Biome)new BiomeHoannaDreadlands(new Biome.BiomeProperties("Hoanna Dreadlands").func_185396_a().func_185410_a(2.0f).func_185395_b(0.0f).func_185398_c(0.125f).func_185400_d(0.126f)).setGrassColor(8951432).setWaterColor(8951432).setLeavesColor(8951432).setRegistryName("essentialcraft:dreadlands");
        BiomeRegistry.desert = (Biome)new BiomeHoannaDesert(new Biome.BiomeProperties("Hoanna Desert").func_185396_a().func_185410_a(2.0f).func_185395_b(0.0f).func_185398_c(0.125f).func_185400_d(0.05f)).setGrassColor(16421912).setLeavesColor(16421912).setWaterColor(16421912).setRegistryName("essentialcraft:desert");
        registry.register((IForgeRegistryEntry)BiomeRegistry.chaosCorruption);
        registry.register((IForgeRegistryEntry)BiomeRegistry.frozenCorruption);
        registry.register((IForgeRegistryEntry)BiomeRegistry.shadowCorruption);
        registry.register((IForgeRegistryEntry)BiomeRegistry.magicCorruption);
        registry.register((IForgeRegistryEntry)BiomeRegistry.dreadlands);
        registry.register((IForgeRegistryEntry)BiomeRegistry.desert);
        BiomeDictionary.addTypes(BiomeRegistry.chaosCorruption, new BiomeDictionary.Type[] { BiomeDictionary.Type.MAGICAL, BiomeDictionary.Type.WASTELAND, BiomeDictionary.Type.PLAINS });
        BiomeDictionary.addTypes(BiomeRegistry.frozenCorruption, new BiomeDictionary.Type[] { BiomeDictionary.Type.MAGICAL, BiomeDictionary.Type.WASTELAND, BiomeDictionary.Type.PLAINS });
        BiomeDictionary.addTypes(BiomeRegistry.shadowCorruption, new BiomeDictionary.Type[] { BiomeDictionary.Type.MAGICAL, BiomeDictionary.Type.WASTELAND, BiomeDictionary.Type.PLAINS, BiomeDictionary.Type.RARE });
        BiomeDictionary.addTypes(BiomeRegistry.magicCorruption, new BiomeDictionary.Type[] { BiomeDictionary.Type.MAGICAL, BiomeDictionary.Type.WASTELAND, BiomeDictionary.Type.PLAINS });
        BiomeDictionary.addTypes(BiomeRegistry.dreadlands, new BiomeDictionary.Type[] { BiomeDictionary.Type.HOT, BiomeDictionary.Type.DRY, BiomeDictionary.Type.DEAD });
        BiomeDictionary.addTypes(BiomeRegistry.desert, new BiomeDictionary.Type[] { BiomeDictionary.Type.HOT, BiomeDictionary.Type.DRY });
    }
}
