package essentialcraft.common.registry;

import net.minecraft.world.*;
import essentialcraft.utils.cfg.*;
import net.minecraftforge.common.*;
import essentialcraft.common.block.*;
import essentialcraft.common.world.dim.*;
import net.minecraft.util.*;
import net.minecraft.block.*;
import DummyCore.Utils.*;

public class DimensionRegistry
{
    public static DimensionType hoanna;
    
    public static void register() {
        DimensionRegistry.hoanna = DimensionType.register("hoanna", "_hoanna", Config.dimensionID, (Class)WorldProviderHoanna.class, false);
        DimensionManager.registerDimension(Config.dimensionID, DimensionRegistry.hoanna);
        DummyPortalHandler.registerPortal((Block)BlocksCore.portal, Config.dimensionID, 0, 200, false, (DummyPortalGenerator)PortalGeneratorHoanna.INSTANCE, new ResourceLocation("essentialcraft:blocks/portal"), 16777215);
    }
}
