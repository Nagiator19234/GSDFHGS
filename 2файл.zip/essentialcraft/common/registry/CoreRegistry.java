package essentialcraft.common.registry;

import essentialcraft.common.mod.*;
import net.minecraftforge.fml.common.network.*;
import net.minecraftforge.fml.common.*;
import net.minecraftforge.fml.relauncher.*;
import essentialcraft.proxy.*;
import essentialcraft.network.*;
import net.minecraftforge.common.*;
import essentialcraft.utils.common.*;
import essentialcraft.api.*;
import essentialcraft.common.world.event.*;

public class CoreRegistry
{
    public static void register() {
        if (EssentialCraftCore.proxy != null) {
            NetworkRegistry.INSTANCE.registerGuiHandler((Object)EssentialCraftCore.core, (IGuiHandler)EssentialCraftCore.proxy);
        }
        else {
            final Side s = FMLCommonHandler.instance().getEffectiveSide();
            if (s == Side.CLIENT) {
                EssentialCraftCore.proxy = new ClientProxy();
            }
            else {
                EssentialCraftCore.proxy = new CommonProxy();
            }
            NetworkRegistry.INSTANCE.registerGuiHandler((Object)EssentialCraftCore.core, (IGuiHandler)EssentialCraftCore.proxy);
        }
        (EssentialCraftCore.network = NetworkRegistry.INSTANCE.newSimpleChannel("essentialcraft3")).registerMessage((Class)ECPacketDispatcher.class, (Class)PacketNBT.class, 0, Side.SERVER);
        EssentialCraftCore.network.registerMessage((Class)ECPacketDispatcher.class, (Class)PacketNBT.class, 0, Side.CLIENT);
        MinecraftForge.EVENT_BUS.register((Object)new PlayerTickHandler());
        MinecraftForge.EVENT_BUS.register((Object)new ECEventHandler());
        MinecraftForge.TERRAIN_GEN_BUS.register((Object)new ECEventHandler());
        MinecraftForge.EVENT_BUS.register((Object)new PlayerTracker());
        WorldEventRegistry.registerWorldEvent(new WorldEventSunArray());
        WorldEventRegistry.registerWorldEvent(new WorldEventFumes());
        WorldEventRegistry.registerWorldEvent(new WorldEventDarkness());
        WorldEventRegistry.registerWorldEvent(new WorldEventEarthquake());
    }
}
