package essentialcraft.common.registry;

public class VillagersRegistry
{
    public static void register() {
    }
}
