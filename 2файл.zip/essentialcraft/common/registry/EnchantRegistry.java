package essentialcraft.common.registry;

import net.minecraft.enchantment.*;

public class EnchantRegistry
{
    public static Enchantment ec23;
    public static Enchantment magnetism;
    public static Enchantment repair;
    public static Enchantment overseeing;
    
    public static void register() {
    }
}
