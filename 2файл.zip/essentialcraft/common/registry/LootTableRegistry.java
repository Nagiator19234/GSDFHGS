package essentialcraft.common.registry;

import net.minecraft.util.*;
import net.minecraftforge.common.*;
import net.minecraftforge.event.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.world.storage.loot.conditions.*;
import net.minecraft.world.storage.loot.*;

public class LootTableRegistry
{
    public static final ResourceLocation CHEST_CATACOMBS;
    public static final ResourceLocation CHEST_TOWN_TOWER;
    public static final ResourceLocation CHEST_HOLOGRAM;
    public static final ResourceLocation ENTITY_WINDMAGE_APPRENTICE;
    public static final ResourceLocation ENTITY_WINDMAGE_NORMAL;
    public static final ResourceLocation ENTITY_WINDMAGE_ARCHMAGE;
    public static final ResourceLocation ENTITY_HOLOGRAM_ADDITION;
    public static final ResourceLocation ENTITY_HOLOGRAM_DIVISION;
    public static final ResourceLocation ENTITY_HOLOGRAM_MULTIPLICATION;
    public static final ResourceLocation ENTITY_HOLOGRAM_SUBTRACTION;
    public static final ResourceLocation INJECT_CHEST_SIMPLE_DUNGEON;
    
    public static void init() {
        MinecraftForge.EVENT_BUS.register((Object)new LootTableRegistry());
    }
    
    @SubscribeEvent
    public void lootTableEvent(final LootTableLoadEvent event) {
        if (event.getName().equals((Object)LootTableList.field_186422_d)) {
            event.getTable().addPool(getInjectPool(LootTableRegistry.INJECT_CHEST_SIMPLE_DUNGEON));
        }
    }
    
    public static LootPool getInjectPool(final ResourceLocation entryName) {
        return new LootPool(new LootEntry[] { (LootEntry)getInjectEntry(entryName, 1) }, new LootCondition[0], new RandomValueRange(1.0f), new RandomValueRange(0.0f), "essentialcraft_inject");
    }
    
    public static LootEntryTable getInjectEntry(final ResourceLocation name, final int weight) {
        return new LootEntryTable(name, weight, 0, new LootCondition[0], "essentialcraft_inject");
    }
    
    static {
        CHEST_CATACOMBS = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:chests/catacombs"));
        CHEST_TOWN_TOWER = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:chests/town_tower"));
        CHEST_HOLOGRAM = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:chests/hologram"));
        ENTITY_WINDMAGE_APPRENTICE = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/windmage_apprentice"));
        ENTITY_WINDMAGE_NORMAL = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/windmage_normal"));
        ENTITY_WINDMAGE_ARCHMAGE = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/windmage_archmage"));
        ENTITY_HOLOGRAM_ADDITION = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/hologram_addition"));
        ENTITY_HOLOGRAM_DIVISION = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/hologram_division"));
        ENTITY_HOLOGRAM_MULTIPLICATION = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/hologram_multiplication"));
        ENTITY_HOLOGRAM_SUBTRACTION = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:entities/hologram_subtraction"));
        INJECT_CHEST_SIMPLE_DUNGEON = LootTableList.func_186375_a(new ResourceLocation("essentialcraft:inject/chests/simple_dungeon"));
    }
}
