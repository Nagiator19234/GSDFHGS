package essentialcraft.common.registry;

import net.minecraft.block.*;
import net.minecraftforge.fml.common.registry.*;
import essentialcraft.utils.common.*;
import essentialcraft.common.block.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import DummyCore.Utils.*;
import net.minecraft.item.crafting.*;
import essentialcraft.api.*;
import net.minecraft.util.*;
import DummyCore.Registries.*;
import java.util.*;
import com.google.common.collect.*;

public class RecipesCore
{
    public boolean hasGregTech;
    private Class<?> GT_Class;
    public static HashMap<Block, ItemStack> fancyBlockRecipes;
    
    public RecipesCore() {
        this.hasGregTech = false;
    }
    
    public static void main() {
        registerFancyBlockCrafts();
        ForgeRegistries.RECIPES.register(new RecipeArmorDyes().setRegistryName("essentialcraft:armor_dyed"));
        registerMagicianTable();
        registerRadiatingChamber();
        registerMithrilineFurnace();
        registerWindRecipes();
        registerDemonTrades();
    }
    
    private static void registerRadiatingChamber() {
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(Blocks.field_150348_b), "ingotIron" }, new ItemStack(BlocksCore.fortifiedStone, 4, 0), 10, Float.MAX_VALUE, -3.4028235E38f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "blockGlass", "ingotIron" }, new ItemStack(BlocksCore.fortifiedGlass, 4, 0), 10, Float.MAX_VALUE, -3.4028235E38f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "dustRedstone", new ItemStack(Items.field_151065_br) }, new ItemStack(ItemsCore.genericItem, 1, 3), 100, Float.MAX_VALUE, -3.4028235E38f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.soulStone, 1, 0) }, new ItemStack(ItemsCore.matrixProj, 1, 0), 1000, Float.MAX_VALUE, -3.4028235E38f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.matrixProj, 1, 0) }, new ItemStack(ItemsCore.matrixProj, 1, 1), 10000, Float.MAX_VALUE, 1.5f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.matrixProj, 1, 0) }, new ItemStack(ItemsCore.matrixProj, 1, 2), 10000, 0.5f, -3.4028235E38f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.matrixProj, 1, 0) }, new ItemStack(ItemsCore.matrixProj, 1, 3), 20000, 1.5f, 0.5f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "gemLapis", "dustGlowstone" }, new ItemStack(ItemsCore.genericItem, 1, 38), 250, Float.MAX_VALUE, -3.4028235E38f, 20.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "blockLapis", "ingotGold" }, new ItemStack(ItemsCore.genericItem, 4, 39), 100, Float.MAX_VALUE, -3.4028235E38f, 80.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(BlocksCore.blockPale, 1, 0), "gemDiamond" }, new ItemStack(ItemsCore.genericItem, 4, 40), 250, Float.MAX_VALUE, -3.4028235E38f, 120.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(BlocksCore.blockPale, 1, 0), "gemEmerald" }, new ItemStack(ItemsCore.genericItem, 4, 40), 300, Float.MAX_VALUE, -3.4028235E38f, 100.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { new ItemStack(Blocks.field_150348_b), "gemElemental" }, new ItemStack(ItemsCore.genericItem, 1, 42), 100, Float.MAX_VALUE, -3.4028235E38f, 10.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "ingotIron", new ItemStack(ItemsCore.genericItem, 1, 3) }, new ItemStack(ItemsCore.genericItem, 1, 43), 1000, Float.MAX_VALUE, -3.4028235E38f, 1.0f);
        RadiatingChamberRecipes.addRecipe(new Object[] { "gemDiamond", "gemEmerald" }, new ItemStack(ItemsCore.genericItem, 1, 44), 100, Float.MAX_VALUE, -3.4028235E38f, 50.0f);
    }
    
    private static void registerMagicianTable() {
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", new ItemStack(ItemsCore.genericItem, 1, 79), "plateEnder", "plateEnder", new ItemStack(ItemsCore.genericItem, 1, 79) }, new ItemStack(ItemsCore.genericItem, 1, 0), 10000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "plateEnder", new ItemStack(ItemsCore.genericItem, 1, 79), new ItemStack(ItemsCore.genericItem, 1, 79), "plateEnder" }, new ItemStack(ItemsCore.genericItem, 1, 0), 10000);
        MagicianTableRecipes.addRecipe(new Object[] { "essentialcraft:gemEnderPearl", "ingotGoldMagical", "ingotGoldMagical", "ingotGoldMagical", "ingotGoldMagical" }, new ItemStack(ItemsCore.genericItem, 1, 4), 5000);
        MagicianTableRecipes.addRecipe(new Object[] { "ingotIron" }, new ItemStack(ItemsCore.genericItem, 1, 5), 50);
        MagicianTableRecipes.addRecipe(new Object[] { IngredientUtils.getIngredientNBT(PotionUtils.func_185188_a(new ItemStack((Item)Items.field_151068_bn), PotionTypes.field_185230_b)) }, new ItemStack(ItemsCore.genericItem, 1, 6), 250);
        MagicianTableRecipes.addRecipe(new Object[] { "stoneFortified" }, new ItemStack(ItemsCore.genericItem, 1, 7), 10);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "essentialcraft:gemEnderPearl", "essentialcraft:gemEnderPearl", "essentialcraft:gemEnderPearl", "essentialcraft:gemEnderPearl" }, new ItemStack(ItemsCore.genericItem, 1, 8), 1000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "blockGlass", "blockGlass", "blockGlass", "blockGlass" }, new ItemStack(ItemsCore.genericItem, 1, 9), 1000);
        MagicianTableRecipes.addRecipe(new Object[] { "ingotGold", "nuggetGold", "nuggetGold", "nuggetGold", "nuggetGold" }, new ItemStack(ItemsCore.genericItem, 1, 10), 250);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "dustRedstone", "dustRedstone", "dustRedstone", "dustRedstone" }, new ItemStack(ItemsCore.genericItem, 1, 11), 1000);
        MagicianTableRecipes.addRecipe(new Object[] { "gemQuartz" }, new ItemStack(ItemsCore.genericItem, 1, 12), 10);
        MagicianTableRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.genericItem, 1, 12) }, new ItemStack(ItemsCore.genericItem, 1, 13), 100);
        MagicianTableRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.genericItem, 1, 13) }, new ItemStack(ItemsCore.genericItem, 1, 14), 200);
        MagicianTableRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.genericItem, 1, 14) }, new ItemStack(ItemsCore.genericItem, 1, 15), 500);
        MagicianTableRecipes.addRecipe(new Object[] { new ItemStack(ItemsCore.genericItem, 1, 15) }, new ItemStack(ItemsCore.genericItem, 1, 16), 1000);
        MagicianTableRecipes.addRecipe(new Object[] { "dustMagic" }, new ItemStack(ItemsCore.genericItem, 1, 20), 3000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateGlass", "plateDiamond", "plateEmerald", "plateEmerald", "plateDiamond" }, new ItemStack(ItemsCore.genericItem, 1, 32), 10000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateGlass", "plateEmerald", "plateDiamond", "plateDiamond", "plateEmerald" }, new ItemStack(ItemsCore.genericItem, 1, 32), 10000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "ingotThaumium", "ingotThaumium", "ingotThaumium", "ingotThaumium" }, new ItemStack(ItemsCore.genericItem, 1, 34), 100);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "ingotPale", "ingotPale", "ingotPale", "ingotPale" }, new ItemStack(ItemsCore.genericItem, 1, 41), 100);
        MagicianTableRecipes.addRecipe(new Object[] { "gemQuartz", new ItemStack(ItemsCore.genericItem, 1, 12), new ItemStack(ItemsCore.genericItem, 1, 12), new ItemStack(ItemsCore.genericItem, 1, 12), new ItemStack(ItemsCore.genericItem, 1, 12) }, new ItemStack(ItemsCore.storage, 1, 0), 100);
        MagicianTableRecipes.addRecipe(new Object[] { "gemEmerald", new ItemStack(ItemsCore.genericItem, 1, 13), new ItemStack(ItemsCore.genericItem, 1, 13), new ItemStack(ItemsCore.genericItem, 1, 13), new ItemStack(ItemsCore.genericItem, 1, 13) }, new ItemStack(ItemsCore.storage, 1, 1), 500);
        MagicianTableRecipes.addRecipe(new Object[] { "essentialcraft:gemEnderPearl", new ItemStack(ItemsCore.genericItem, 1, 14), new ItemStack(ItemsCore.genericItem, 1, 14), new ItemStack(ItemsCore.genericItem, 1, 14), new ItemStack(ItemsCore.genericItem, 1, 14) }, new ItemStack(ItemsCore.storage, 1, 2), 100);
        MagicianTableRecipes.addRecipe(new Object[] { "gemDiamond", new ItemStack(ItemsCore.genericItem, 1, 15), new ItemStack(ItemsCore.genericItem, 1, 15), new ItemStack(ItemsCore.genericItem, 1, 15), new ItemStack(ItemsCore.genericItem, 1, 15) }, new ItemStack(ItemsCore.storage, 1, 3), 250);
        MagicianTableRecipes.addRecipe(new Object[] { "gemNetherStar", new ItemStack(ItemsCore.genericItem, 1, 16), new ItemStack(ItemsCore.genericItem, 1, 16), new ItemStack(ItemsCore.genericItem, 1, 16), new ItemStack(ItemsCore.genericItem, 1, 16) }, new ItemStack(ItemsCore.storage, 1, 4), 500);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "ingotMithrilineMetal", "ingotMithrilineMetal", "ingotMithrilineMetal", "ingotMithrilineMetal" }, new ItemStack(ItemsCore.genericItem, 1, 49), 400);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", "ingotDemonic", "ingotDemonic", "ingotDemonic", "ingotDemonic" }, new ItemStack(ItemsCore.genericItem, 4, 54), 2000);
        MagicianTableRecipes.addRecipe(new Object[] { "plateFortified", Items.field_151065_br, Items.field_151065_br, Items.field_151065_br, Items.field_151065_br }, new ItemStack(ItemsCore.genericItem, 1, 79), 500);
        final ItemStack book_t1 = new ItemStack(ItemsCore.research_book);
        MiscUtils.getStackTag(book_t1).func_74768_a("tier", 1);
        final ItemStack book_t2 = new ItemStack(ItemsCore.research_book);
        MiscUtils.getStackTag(book_t2).func_74768_a("tier", 2);
        MagicianTableRecipes.addRecipe(new Object[] { IngredientUtils.getIngredientNBT(book_t1) }, book_t2, 100);
        MagicianTableRecipes.addRecipe(new Object[] { "stoneVoid" }, new ItemStack(ItemsCore.genericItem, 1, 35), 1000);
    }
    
    private static void registerMithrilineFurnace() {
        MithrilineFurnaceRecipes.addRecipe("dustMithriline", new ItemStack(ItemsCore.genericItem, 1, 50), 60.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("gemResonant", new ItemStack(ItemsCore.genericItem, 1, 48), 120.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("gemMithrilineCrystal", new ItemStack(ItemsCore.genericItem, 1, 47), 240.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("gemFading", new ItemStack(ItemsCore.genericItem, 8, 46), 480.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("dustGlowstone", new ItemStack(ItemsCore.genericItem, 1, 51), 32.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("ingotIron", new ItemStack(Items.field_151043_k), 64.0f, 8);
        MithrilineFurnaceRecipes.addRecipe("ingotGold", new ItemStack(Items.field_151042_j, 8, 0), 64.0f, 1);
        MithrilineFurnaceRecipes.addRecipe("gemDiamond", new ItemStack(Items.field_151166_bC), 512.0f, 2);
        MithrilineFurnaceRecipes.addRecipe("gemEmerald", new ItemStack(Items.field_151045_i, 2, 0), 512.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 0), new ItemStack(Blocks.field_150344_f, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 1), new ItemStack(Blocks.field_150344_f, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 2), new ItemStack(Blocks.field_150344_f, 1, 3), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 3), new ItemStack(Blocks.field_150344_f, 1, 4), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 4), new ItemStack(Blocks.field_150344_f, 1, 5), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150344_f, 1, 5), new ItemStack(Blocks.field_150344_f, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 0), new ItemStack(Blocks.field_150345_g, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 1), new ItemStack(Blocks.field_150345_g, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 2), new ItemStack(Blocks.field_150345_g, 1, 3), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 3), new ItemStack(Blocks.field_150345_g, 1, 4), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 4), new ItemStack(Blocks.field_150345_g, 1, 5), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150345_g, 1, 5), new ItemStack(Blocks.field_150345_g, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150364_r, 1, 0), new ItemStack(Blocks.field_150364_r, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150364_r, 1, 1), new ItemStack(Blocks.field_150364_r, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150364_r, 1, 2), new ItemStack(Blocks.field_150364_r, 1, 3), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150364_r, 1, 3), new ItemStack(Blocks.field_150363_s, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150363_s, 1, 0), new ItemStack(Blocks.field_150363_s, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150363_s, 1, 1), new ItemStack(Blocks.field_150364_r, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150362_t, 1, 0), new ItemStack((Block)Blocks.field_150362_t, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150362_t, 1, 1), new ItemStack((Block)Blocks.field_150362_t, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150362_t, 1, 2), new ItemStack((Block)Blocks.field_150362_t, 1, 3), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150362_t, 1, 3), new ItemStack((Block)Blocks.field_150361_u, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150361_u, 1, 0), new ItemStack((Block)Blocks.field_150361_u, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150361_u, 1, 1), new ItemStack((Block)Blocks.field_150362_t, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150440_ba, 1, 0), new ItemStack(Blocks.field_150423_aK, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150423_aK, 1, 0), new ItemStack(Blocks.field_150440_ba, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150327_N, 1, 0), new ItemStack((Block)Blocks.field_150328_O, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 0), new ItemStack((Block)Blocks.field_150328_O, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 1), new ItemStack((Block)Blocks.field_150328_O, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 2), new ItemStack((Block)Blocks.field_150328_O, 1, 3), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 3), new ItemStack((Block)Blocks.field_150328_O, 1, 4), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 4), new ItemStack((Block)Blocks.field_150328_O, 1, 5), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 5), new ItemStack((Block)Blocks.field_150328_O, 1, 6), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 6), new ItemStack((Block)Blocks.field_150328_O, 1, 7), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 7), new ItemStack((Block)Blocks.field_150328_O, 1, 8), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150328_O, 1, 8), new ItemStack((Block)Blocks.field_150327_N, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150337_Q, 1, 0), new ItemStack((Block)Blocks.field_150338_P, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150338_P, 1, 0), new ItemStack((Block)Blocks.field_150337_Q, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151079_bi, 1, 0), new ItemStack(Items.field_151072_bj, 2, 0), 128.0f, 3);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151072_bj, 1, 0), new ItemStack(Items.field_151079_bi, 3, 0), 128.0f, 2);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151137_ax, 1, 0), new ItemStack(Items.field_151073_bk, 1, 0), 1024.0f, 64);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151073_bk, 1, 0), new ItemStack(Items.field_151137_ax, 64, 0), 1024.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151119_aD, 1, 0), new ItemStack(Items.field_151016_H, 1, 0), 32.0f, 12);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151016_H, 1, 0), new ItemStack(Items.field_151119_aD, 12, 0), 32.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151147_al, 1, 0), new ItemStack(Items.field_151082_bd, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151082_bd, 1, 0), new ItemStack(Items.field_151076_bf, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151076_bf, 1, 0), new ItemStack(Items.field_151115_aP, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151115_aP, 1, 0), new ItemStack(Items.field_151078_bh, 2, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151078_bh, 1, 0), new ItemStack(Items.field_179558_bo, 1, 0), 16.0f, 2);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179558_bo, 1, 0), new ItemStack(Items.field_179561_bm, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179561_bm, 1, 0), new ItemStack(Items.field_151147_al, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151157_am, 1, 0), new ItemStack(Items.field_151083_be, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151083_be, 1, 0), new ItemStack(Items.field_151077_bg, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151077_bg, 1, 0), new ItemStack(Items.field_179566_aV, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179566_aV, 1, 0), new ItemStack(Items.field_179566_aV, 1, 1), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179566_aV, 1, 1), new ItemStack(Items.field_179559_bp, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179559_bp, 1, 0), new ItemStack(Items.field_179557_bn, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_179557_bn, 1, 0), new ItemStack(Items.field_151157_am, 1, 0), 16.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151096_cd, 1, 0), new ItemStack(Items.field_151093_ce, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151093_ce, 1, 0), new ItemStack(Items.field_151094_cf, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151094_cf, 1, 0), new ItemStack(Items.field_151091_cg, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151091_cg, 1, 0), new ItemStack(Items.field_151092_ch, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151092_ch, 1, 0), new ItemStack(Items.field_151089_ci, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151089_ci, 1, 0), new ItemStack(Items.field_151090_cj, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151090_cj, 1, 0), new ItemStack(Items.field_151087_ck, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151087_ck, 1, 0), new ItemStack(Items.field_151088_cl, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151088_cl, 1, 0), new ItemStack(Items.field_151085_cm, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151085_cm, 1, 0), new ItemStack(Items.field_151086_cn, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151086_cn, 1, 0), new ItemStack(Items.field_151084_co, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151084_co, 1, 0), new ItemStack(Items.field_151096_cd, 1, 0), 256.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151102_aT, 1, 0), new ItemStack(Items.field_151123_aH, 4, 0), 16.0f, 3);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151123_aH, 1, 0), new ItemStack(Items.field_151102_aT, 3, 0), 16.0f, 4);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151110_aK, 1, 0), new ItemStack(Items.field_151103_aS, 2, 0), 48.0f, 9);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151103_aS, 1, 0), new ItemStack(Items.field_151110_aK, 9, 0), 48.0f, 2);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151144_bL, 1, 0), new ItemStack(Items.field_151144_bL, 1, 1), 64.0f, 3);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151144_bL, 1, 1), new ItemStack(Items.field_151144_bL, 3, 2), 64.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151144_bL, 1, 2), new ItemStack(Items.field_151144_bL, 1, 3), 64.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151144_bL, 1, 3), new ItemStack(Items.field_151144_bL, 1, 4), 64.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151144_bL, 1, 4), new ItemStack(Items.field_151144_bL, 1, 0), 64.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151015_O, 1, 0), new ItemStack(Items.field_151116_aA, 1, 0), 128.0f, 3);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151116_aA, 1, 0), new ItemStack(Items.field_151015_O, 3, 0), 128.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151115_aP, 1, 1), new ItemStack(Items.field_151115_aP, 1, 2), 24.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151115_aP, 1, 2), new ItemStack(Items.field_151115_aP, 1, 3), 24.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151115_aP, 1, 3), new ItemStack(Items.field_151115_aP, 1, 1), 24.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151120_aE, 1, 0), new ItemStack(Items.field_151008_G, 2, 0), 64.0f, 3);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151008_G, 1, 0), new ItemStack(Items.field_151120_aE, 3, 0), 64.0f, 2);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151044_h, 1, 0), new ItemStack(Items.field_151044_h, 1, 1), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Items.field_151044_h, 1, 1), new ItemStack(Items.field_151044_h, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150432_aD, 1, 0), new ItemStack((Block)Blocks.field_150349_c, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack((Block)Blocks.field_150349_c, 1, 0), new ItemStack(Blocks.field_150346_d, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150346_d, 1, 0), new ItemStack(Blocks.field_150346_d, 1, 2), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150346_d, 1, 2), new ItemStack(Blocks.field_150359_w, 1, 0), 1.0f, 1);
        MithrilineFurnaceRecipes.addRecipe(new ItemStack(Blocks.field_150359_w, 1, 0), new ItemStack(Blocks.field_150432_aD, 1, 0), 1.0f, 1);
    }
    
    private static void registerWindRecipes() {
        new WindImbueRecipe(new ItemStack(ItemsCore.soulStone, 1, 0), new ItemStack(ItemsCore.soulStone, 1, 0), 40000);
        new WindImbueRecipe(new ItemStack(Items.field_151045_i, 1, 0), new ItemStack(ItemsCore.genericItem, 1, 55), 10000);
        new WindImbueRecipe((Ingredient)IngredientUtils.getIngredientNBT(PotionUtils.func_185188_a(new ItemStack((Item)Items.field_151068_bn), PotionTypes.field_185230_b)), new ItemStack(ItemsCore.air_potion, 1, 0), 250);
    }
    
    private static void registerDemonTrades() {
        new DemonTrade(new ResourceLocation("minecraft:villager"));
        new DemonTrade(new ResourceLocation("minecraft:enderman"));
        new DemonTrade(new ResourceLocation("essentialcraft:entitywindmage"));
        new DemonTrade(new ItemStack(Blocks.field_150484_ah, 2, 0));
        new DemonTrade(new ItemStack(Blocks.field_150357_h, 1, 0));
        new DemonTrade(new ItemStack(Blocks.field_150339_S, 8, 0));
        new DemonTrade(new ItemStack(Blocks.field_150335_W, 64, 0));
        new DemonTrade(new ItemStack(Blocks.field_150381_bn, 16, 0));
        new DemonTrade(new ItemStack(Blocks.field_150342_X, 64, 0));
        new DemonTrade(new ItemStack(Blocks.field_150378_br, 3, 0));
        new DemonTrade(new ItemStack(Blocks.field_150380_bt, 1, 0));
        new DemonTrade(new ItemStack((Block)Blocks.field_150461_bJ, 1, 0));
        new DemonTrade(new ItemStack(Blocks.field_150483_bI, 1, 0));
        new DemonTrade(new ItemStack(Blocks.field_185777_dd, 1, 0));
        new DemonTrade(new ItemStack(Blocks.field_185776_dc, 1, 0));
        new DemonTrade(new ItemStack(Items.field_151153_ao, 1, 1));
        new DemonTrade(new ItemStack((Item)Items.field_151098_aY, 1, 32767));
        new DemonTrade(new ItemStack(Items.field_151061_bv, 32, 0));
        new DemonTrade(new ItemStack(Items.field_151144_bL, 1, 3));
        new DemonTrade(new ItemStack(Items.field_151156_bN, 1, 0));
        new DemonTrade(new ItemStack(Items.field_151086_cn, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.magicalEnchanter, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.magicalRepairer, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.heatGenerator, 3, 0));
        new DemonTrade(new ItemStack(BlocksCore.magicalTeleporter, 2, 0));
        new DemonTrade(new ItemStack(BlocksCore.mruCoil, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.ultraHeatGen, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.darknessObelisk, 1, 0));
        new DemonTrade(new ItemStack(BlocksCore.mithrilineCrystal, 12, 0));
        new DemonTrade(new ItemStack(BlocksCore.mithrilineCrystal, 6, 3));
        new DemonTrade(new ItemStack(BlocksCore.mithrilineCrystal, 3, 6));
        new DemonTrade(new ItemStack(BlocksCore.compressed, 32, 4));
        new DemonTrade(new ItemStack(ItemsCore.emeraldHeart, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.spikyShield, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.magicalShield, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.magicWaterBottle, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_elemental_pick, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_elemental_axe, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_elemental_hoe, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_elemental_shovel, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_elemental_sword, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_chestplate, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_helmet, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_boots, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.wind_leggings, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.magicalPorkchop, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.chaosFork, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.research_book, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.record_everlastingSummer, 1, 0));
        new DemonTrade(new ItemStack(ItemsCore.pistol, 1, 32767));
        new DemonTrade(new ItemStack(ItemsCore.rifle, 1, 32767));
        new DemonTrade(new ItemStack(ItemsCore.sniper, 1, 32767));
        new DemonTrade(new ItemStack(ItemsCore.gatling, 1, 32767));
    }
    
    public static void registerFancyBlockCrafts() {
        for (final Block fancy : BlocksCore.fancyBlocks) {
            final ItemStack createdFrom = RecipesCore.fancyBlockRecipes.get(fancy);
            RecipeRegistry.addShapelessOreRecipe(new ItemStack(fancy, 4, 1), new Object[] { createdFrom, new ItemStack(ItemsCore.magicalChisel, 1, 32767) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 2), new Object[] { "##", "##", '#', new ItemStack(fancy, 1, 1) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 7), new Object[] { " # ", "# #", " # ", '#', new ItemStack(fancy, 1, 2) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 0), new Object[] { "# #", "   ", "# #", '#', new ItemStack(fancy, 1, 1) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 9, 3), new Object[] { "###", "###", "###", '#', new ItemStack(fancy, 1, 1) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 4), new Object[] { "###", "# #", "###", '#', new ItemStack(fancy, 1, 2) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 5), new Object[] { "##", "##", '#', new ItemStack(fancy, 1, 7) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 9, 6), new Object[] { "###", "@$@", "###", '#', new ItemStack(fancy, 1, 1), '@', new ItemStack(fancy, 1, 3), '$', new ItemStack(fancy, 1, 0) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 8), new Object[] { " # ", "#@#", " # ", '#', new ItemStack(fancy, 1, 0), '@', new ItemStack(fancy, 1, 3) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 9), new Object[] { "###", "#@#", "###", '#', new ItemStack(fancy, 1, 8), '@', "dustRedstone" });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 10), new Object[] { "###", "#@#", "###", '#', new ItemStack(fancy, 1, 1), '@', new ItemStack(ItemsCore.genericItem, 1, 3) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 11), new Object[] { "###", "#@#", "###", '#', new ItemStack(fancy, 1, 1), '@', new ItemStack(ItemsCore.genericItem, 1, 12) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 12), new Object[] { "###", "#@#", "###", '#', new ItemStack(fancy, 1, 1), '@', "ingotIron" });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 8, 13), new Object[] { "###", "#@#", "###", '#', new ItemStack(fancy, 1, 1), '@', "leather" });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 14), new Object[] { "##", "##", '#', new ItemStack(fancy, 1, 13) });
            RecipeRegistry.addShapedOreRecipe(new ItemStack(fancy, 4, 15), new Object[] { "##", "##", '#', new ItemStack(fancy, 1, 12) });
        }
    }
    
    static {
        RecipesCore.fancyBlockRecipes = (HashMap<Block, ItemStack>)Maps.newHashMap();
    }
}
