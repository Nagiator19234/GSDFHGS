package essentialcraft.common.registry;

import essentialcraft.common.capabilities.mru.*;
import essentialcraft.common.capabilities.espe.*;

public class CapabilityRegistry
{
    public static void register() {
        CapabilityMRUHandler.register();
        CapabilityESPEHandler.register();
    }
}
