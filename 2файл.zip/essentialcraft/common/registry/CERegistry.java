package essentialcraft.common.registry;

import essentialcraft.api.*;
import essentialcraft.utils.common.*;

public class CERegistry
{
    public static int meta;
    
    public static void register() {
        effect(EnumCorruptionEffect.BODY, 6000);
        effect(EnumCorruptionEffect.BODY, 6000);
        effect(EnumCorruptionEffect.BODY, 6000);
        effect(EnumCorruptionEffect.BODY, 6000);
        effect(EnumCorruptionEffect.BODY, 6000);
        effect(EnumCorruptionEffect.MIND, 36000);
        effect(EnumCorruptionEffect.MIND, 36000);
        effect(EnumCorruptionEffect.MIND, 14400);
        effect(EnumCorruptionEffect.MIND, 18000);
        effect(EnumCorruptionEffect.MIND, 8000);
        effect(EnumCorruptionEffect.MIND, 8000);
        effect(EnumCorruptionEffect.MATRIX, 20000);
        effect(EnumCorruptionEffect.MATRIX, 72000);
        effect(EnumCorruptionEffect.MATRIX, 20000);
        effect(EnumCorruptionEffect.MATRIX, 4000);
        effect(EnumCorruptionEffect.MATRIX, 8000);
        effect(EnumCorruptionEffect.MATRIX, 2000);
        effect(EnumCorruptionEffect.MATRIX, 36000);
        effect(EnumCorruptionEffect.MATRIX, 14400);
        effect(EnumCorruptionEffect.MATRIX, 72000);
        effect(EnumCorruptionEffect.MATRIX, 72000);
        effect(EnumCorruptionEffect.MATRIX, 36000);
        effect(EnumCorruptionEffect.MATRIX, 36000);
        effect(EnumCorruptionEffect.MATRIX, 8000);
        effect(EnumCorruptionEffect.MATRIX, 4000);
    }
    
    public static CorruptionEffectECNBTBased effect(final EnumCorruptionEffect effect, final int cost) {
        return new CorruptionEffectECNBTBased().setMeta(gMeta()).setType(effect).setCost(cost).done();
    }
    
    public static int gMeta() {
        return ++CERegistry.meta;
    }
    
    static {
        CERegistry.meta = -1;
    }
}
