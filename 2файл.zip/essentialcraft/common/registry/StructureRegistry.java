package essentialcraft.common.registry;

import net.minecraft.world.gen.structure.*;
import essentialcraft.common.world.gen.structure.*;
import net.minecraft.block.*;
import essentialcraft.common.block.*;
import essentialcraft.utils.common.*;
import essentialcraft.api.*;
import java.util.*;

public class StructureRegistry
{
    public static void register() {
        MapGenStructureIO.func_143034_b((Class)MapGenTown.Start.class, "essentialcraft.Town");
        MapGenStructureIO.func_143034_b((Class)StructureModernShaftStart.class, "essentialcraft.ModernShafts");
        MapGenStructureIO.func_143034_b((Class)StructureOldCatacombs.Start.class, "essentialcraft.OldCatacombs");
        StructureTownPieces.registerTownComponents();
        StructureModernShaftPieces.registerShaftComponents();
        StructureOldCatacombs.registerCatacombComponents();
        final List<Block> structureBlocks_mrucucc = new ArrayList<Block>();
        structureBlocks_mrucucc.add(BlocksCore.fortifiedGlass);
        structureBlocks_mrucucc.add(BlocksCore.magicPlating);
        structureBlocks_mrucucc.add(BlocksCore.ecController);
        structureBlocks_mrucucc.add(BlocksCore.ecAcceptor);
        structureBlocks_mrucucc.add(BlocksCore.ecBalancer);
        structureBlocks_mrucucc.add(BlocksCore.ecEjector);
        structureBlocks_mrucucc.add(BlocksCore.ecHoldingChamber);
        structureBlocks_mrucucc.add(BlocksCore.ecRedstoneController);
        structureBlocks_mrucucc.add(BlocksCore.ecStateChecker);
        structureBlocks_mrucucc.add(BlocksCore.fortifiedStone);
        structureBlocks_mrucucc.add(BlocksCore.voidGlass);
        structureBlocks_mrucucc.add(BlocksCore.voidStone);
        structureBlocks_mrucucc.add(BlocksCore.platingPale);
        structureBlocks_mrucucc.add(BlocksCore.invertedBlock);
        structureBlocks_mrucucc.add(BlocksCore.demonicPlating);
        ECUtils.STRUCTURE_TO_BLOCKS_MAP.putAll((Object)EnumStructureType.MRUCUEC, (Iterable)structureBlocks_mrucucc);
        final List<Block> structureBlocks_mrucoil = new ArrayList<Block>();
        structureBlocks_mrucoil.add(BlocksCore.platingPale);
        structureBlocks_mrucoil.add(BlocksCore.magicPlating);
        structureBlocks_mrucoil.add(BlocksCore.voidStone);
        structureBlocks_mrucoil.add(BlocksCore.invertedBlock);
        structureBlocks_mrucoil.add(BlocksCore.demonicPlating);
        ECUtils.STRUCTURE_TO_BLOCKS_MAP.putAll((Object)EnumStructureType.MRU_COIL, (Iterable)structureBlocks_mrucoil);
        ECUtils.registerBlockResistance(BlocksCore.fortifiedGlass, 0, 3.0f);
        ECUtils.registerBlockResistance(BlocksCore.magicPlating, 0, 5.0f);
        ECUtils.registerBlockResistance(BlocksCore.platingPale, 0, 10.0f);
        ECUtils.registerBlockResistance(BlocksCore.invertedBlock, 0, 7.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecController, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecAcceptor, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecBalancer, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecEjector, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecHoldingChamber, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecRedstoneController, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.ecStateChecker, 0, 100.0f);
        ECUtils.registerBlockResistance(BlocksCore.fortifiedStone, -1, 2.0f);
        ECUtils.registerBlockResistance(BlocksCore.voidGlass, -1, 15.0f);
        ECUtils.registerBlockResistance(BlocksCore.voidStone, -1, 18.0f);
        ECUtils.registerBlockResistance(BlocksCore.demonicPlating, -1, 36.0f);
    }
}
