package essentialcraft.common.registry;

import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraftforge.common.config.*;
import java.util.*;

public class TileRegistry
{
    public static final List<Class<? extends TileEntity>> CONFIG_DEPENDANT;
    
    public static void register() {
        addTileToMapping(TileMRUCUECController.class);
        addTileToMapping(TileMRUCUECAcceptor.class);
        addTileToMapping(TileMRUCUECBalancer.class);
        addTileToMapping(TileMRUCUECEjector.class);
        addTileToMapping(TileMRUCUECHoldingChamber.class);
        addTileToMapping(TileMRUCUECRedstoneController.class);
        addTileToMapping(TileMRUCUECStateChecker.class);
        addTileToMapping(TileRayTower.class);
        addTileToMapping(TileCorruption.class);
        addTileToMapping(TileMoonWell.class);
        addTileToMapping(TileSolarPrism.class);
        addTileToMapping(TileSunRayAbsorber.class);
        addTileToMapping(TileColdDistillator.class);
        addTileToMapping(TileFlowerBurner.class);
        addTileToMapping(TileHeatGenerator.class);
        addTileToMapping(TileEnderGenerator.class);
        addTileToMapping(TileMagicianTable.class);
        addTileToMapping(TileMagicalQuarry.class);
        addTileToMapping(TileMonsterHolder.class);
        addTileToMapping(TilePotionSpreader.class);
        addTileToMapping(TileMagicalEnchanter.class);
        addTileToMapping(TileMonsterHarvester.class);
        addTileToMapping(TileMagicalRepairer.class);
        addTileToMapping(TileMatrixAbsorber.class);
        addTileToMapping(TileRadiatingChamber.class);
        addTileToMapping(TileMagmaticSmelter.class);
        addTileToMapping(TileMagicalJukebox.class);
        addTileToMapping(TileElementalCrystal.class);
        addTileToMapping(TileCrystalFormer.class);
        addTileToMapping(TileCrystalController.class);
        addTileToMapping(TileCrystalExtractor.class);
        addTileToMapping(TileChargingChamber.class);
        addTileToMapping(TileMagicalTeleporter.class);
        addTileToMapping(TileMagicalFurnace.class);
        addTileToMapping(TileEmberForge.class);
        addTileToMapping(TileMRUCoilHardener.class);
        addTileToMapping(TileMRUCoil.class);
        addTileToMapping(TileCorruptionCleaner.class);
        addTileToMapping(TileMRUReactor.class);
        addTileToMapping(TileDarknessObelisk.class);
        addTileToMapping(TileUltraHeatGenerator.class);
        addTileToMapping(TileUltraFlowerBurner.class);
        addTileToMapping(TileMagicalMirror.class);
        addTileToMapping(TileMagicalDisplay.class);
        addTileToMapping(TileMithrilineCrystal.class);
        addTileToMapping(TileMithrilineFurnace.class);
        addTileToMapping(TilePlayerPentacle.class);
        addTileToMapping(TileWindRune.class);
        addTileToMapping(TileRightClicker.class);
        addTileToMapping(TileRedstoneTransmitter.class);
        addTileToMapping(TileMagicalHopper.class);
        addTileToMapping(TileDemonicPentacle.class);
        addTileToMapping(TileWeaponMaker.class);
        addTileToMapping(TileFurnaceMagic.class);
        addTileToMapping(TileMagicalChest.class);
        addTileToMapping(TileMIMInventoryStorage.class);
        addTileToMapping(TileMIM.class);
        addTileToMapping(TileMIMScreen.class);
        addTileToMapping(TileMIMCraftingManager.class);
        addTileToMapping(TileMIMExportNode.class);
        addTileToMapping(TileMIMImportNode.class);
        addTileToMapping(TileAdvancedBlockBreaker.class);
        addTileToMapping(TileMIMExportNodePersistant.class);
        addTileToMapping(TileMIMImportNodePersistant.class);
        addTileToMapping(TileCrafter.class);
        addTileToMapping(TileCreativeMRUSource.class);
        addTileToMapping(TileAnimalSeparator.class);
        addTileToMapping(TileMimic.class);
        addTileToMapping(TileMRUChunkLoader.class);
        addTileToMapping(TileMRUDimensionalTransciever.class);
        addTileToMapping(TileMRUIntersector.class);
        addTileToMapping(TileWeatherController.class);
        addTileToMapping(TileCreativeESPESource.class);
        Config.config.save();
    }
    
    public static void addTileToMapping(final Class<? extends TileEntity> tile) {
        GameRegistry.registerTileEntity((Class)tile, new ResourceLocation("essentialcraft:" + tile.getCanonicalName()));
        try {
            if (tile.getMethod("setupConfig", Configuration.class) != null) {
                TileRegistry.CONFIG_DEPENDANT.add(tile);
                tile.getMethod("setupConfig", Configuration.class).invoke(null, Config.config);
            }
        }
        catch (NoSuchMethodException e2) {}
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static {
        CONFIG_DEPENDANT = new ArrayList<Class<? extends TileEntity>>();
    }
}
