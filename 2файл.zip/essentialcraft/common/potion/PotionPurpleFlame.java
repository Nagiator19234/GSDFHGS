package essentialcraft.common.potion;

import net.minecraft.potion.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.client.*;

public class PotionPurpleFlame extends Potion
{
    static final ResourceLocation rl;
    
    public PotionPurpleFlame(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(6, 2);
        this.func_76404_a(0.25);
        this.func_76390_b("potion.purpleFlame");
        this.setRegistryName("essentialcraft", "potion.purpleflame");
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
        if (!entity.func_130014_f_().field_72995_K && entity.func_130014_f_().field_73012_v.nextInt(16) < amplifier) {
            entity.func_70097_a(DamageSource.field_76376_m, 5.0f);
        }
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return duration % 20 == 0;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionPurpleFlame.rl);
        return super.func_76392_e();
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
