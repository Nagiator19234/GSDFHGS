package essentialcraft.common.potion;

import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.client.*;

public class PotionUnnormalLightness extends Potion
{
    static final ResourceLocation rl;
    
    public PotionUnnormalLightness(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(3, 2);
        this.func_76404_a(0.25);
        this.func_76390_b("potion.paranormalLightness");
        this.setRegistryName("essentialcraft", "potion.paranormalLightness");
        this.func_111184_a(SharedMonsterAttributes.field_111263_d, "91AEAA56-376B-4498-935B-2F7F68070636", 0.4, 2);
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
        final int duration = entity.func_70660_b((Potion)this).func_76459_b();
        entity.func_70690_d(new PotionEffect(MobEffects.field_76430_j, duration, amplifier));
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return true;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionUnnormalLightness.rl);
        return super.func_76392_e();
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
