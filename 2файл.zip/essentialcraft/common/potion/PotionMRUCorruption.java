package essentialcraft.common.potion;

import net.minecraft.potion.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import essentialcraft.utils.common.*;
import baubles.api.*;
import essentialcraft.common.item.*;
import net.minecraft.util.*;
import baubles.api.cap.*;
import net.minecraft.item.*;
import net.minecraft.client.*;

public class PotionMRUCorruption extends Potion
{
    static final ResourceLocation rl;
    
    public PotionMRUCorruption(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(3, 1);
        this.func_76404_a(0.25);
        this.func_76390_b("potion.mruCorruption");
        this.setRegistryName("essentialcraft", "potion.mrucorruption");
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
        if (!entity.func_130014_f_().field_72995_K && entity.func_130014_f_().field_73012_v.nextInt(16) < amplifier) {
            float damIndex = 5.0f;
            if (entity instanceof EntityPlayer) {
                damIndex *= ECUtils.getGenResistance(0, (EntityPlayer)entity);
                boolean heal = false;
                final IBaublesItemHandler b = BaublesApi.getBaublesHandler((EntityPlayer)entity);
                if (b != null) {
                    for (int i = 0; i < b.getSlots(); ++i) {
                        final ItemStack is = b.getStackInSlot(i);
                        if (is.func_77973_b() instanceof ItemBaublesSpecial && is.func_77952_i() == 10) {
                            heal = true;
                        }
                    }
                }
                if (!heal) {
                    entity.func_70097_a(DamageSource.field_76376_m, damIndex);
                }
                else {
                    entity.func_70691_i(damIndex);
                }
            }
        }
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return duration % 20 == 0;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionMRUCorruption.rl);
        return super.func_76392_e();
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
