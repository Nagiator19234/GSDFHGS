package essentialcraft.common.potion;

import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;
import net.minecraft.potion.*;

public class PotionWindTouch extends Potion
{
    static final ResourceLocation rl;
    
    public PotionWindTouch(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(6, 1);
        this.func_76404_a(0.25);
        this.func_76390_b("potion.windTouch");
        this.setRegistryName("essentialcraft", "potion.windtouch");
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return duration % 20 == 0;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionWindTouch.rl);
        return super.func_76392_e();
    }
    
    public void renderInventoryEffect(final int x, final int y, final PotionEffect effect, final Minecraft mc) {
        mc.field_71466_p.func_175063_a(effect.func_76458_c() + 1 + "", (float)(x + 19), (float)(y + 19), 16777215);
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
