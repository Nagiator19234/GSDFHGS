package essentialcraft.common.potion;

import net.minecraft.potion.*;
import net.minecraft.util.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import baubles.api.*;
import essentialcraft.common.item.*;
import baubles.api.cap.*;
import net.minecraft.item.*;
import net.minecraft.client.*;

public class PotionFrozenMind extends Potion
{
    static final ResourceLocation rl;
    
    public PotionFrozenMind(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(5, 1);
        this.func_76404_a(0.25);
        this.func_76390_b("potion.frozenMind");
        this.setRegistryName("essentialcraft", "potion.frozenmind");
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
        if (!(entity instanceof EntityPlayer)) {
            return;
        }
        boolean remove = false;
        final IBaublesItemHandler b = BaublesApi.getBaublesHandler((EntityPlayer)entity);
        if (b != null) {
            for (int i = 0; i < b.getSlots(); ++i) {
                final ItemStack is = b.getStackInSlot(i);
                if (is.func_77973_b() instanceof ItemBaublesSpecial && is.func_77952_i() == 31) {
                    remove = true;
                }
            }
        }
        if (remove) {
            entity.func_184589_d((Potion)this);
        }
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return duration % 20 == 0;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionFrozenMind.rl);
        return super.func_76392_e();
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
