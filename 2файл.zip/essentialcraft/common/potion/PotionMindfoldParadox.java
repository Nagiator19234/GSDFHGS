package essentialcraft.common.potion;

import net.minecraft.entity.*;
import essentialcraft.common.registry.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import net.minecraft.client.*;
import net.minecraft.potion.*;
import net.minecraft.util.text.translation.*;

public class PotionMindfoldParadox extends Potion
{
    static final ResourceLocation rl;
    
    public PotionMindfoldParadox(final boolean isBad, final int color) {
        super(isBad, color);
        this.func_76399_b(7, 2);
        this.func_76390_b("potion.paradox");
        this.setRegistryName("essentialcraft", "potion.paradox");
    }
    
    public void func_76394_a(final EntityLivingBase entity, final int amplifier) {
        final int duration = entity.func_70660_b((Potion)this).func_76459_b();
        if (duration == 2000) {
            if (entity.func_130014_f_().field_72995_K) {
                entity.func_130014_f_().func_184134_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, SoundRegistry.potionTinnitus, SoundCategory.PLAYERS, 100.0f, 1.0f, true);
            }
            MiscUtils.setShaders(2);
        }
    }
    
    public boolean func_76397_a(final int duration, final int amplifier) {
        return true;
    }
    
    public boolean func_76400_d() {
        return true;
    }
    
    public int func_76392_e() {
        Minecraft.func_71410_x().field_71446_o.func_110577_a(PotionMindfoldParadox.rl);
        return super.func_76392_e();
    }
    
    public boolean shouldRenderInvText(final PotionEffect effect) {
        return false;
    }
    
    public void renderInventoryEffect(final int x, final int y, final PotionEffect effect, final Minecraft mc) {
        final String s1 = I18n.func_74838_a(effect.func_76453_d());
        mc.field_71466_p.func_175063_a(s1, (float)(x + 10 + 18), (float)(y + 6), 16777215);
        mc.field_71466_p.func_175063_a(I18n.func_74838_a("potion.paradox.txt"), (float)(x + 10 + 18), (float)(y + 16), 16777215);
    }
    
    static {
        rl = new ResourceLocation("essentialcraft", "textures/special/potions.png");
    }
}
