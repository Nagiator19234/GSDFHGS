package essentialcraft.common.entity;

import net.minecraft.item.*;
import net.minecraft.world.*;
import essentialcraft.api.*;
import essentialcraft.common.item.*;
import DummyCore.Utils.*;
import essentialcraft.common.registry.*;
import net.minecraft.entity.item.*;
import essentialcraft.common.block.*;
import essentialcraft.common.tile.*;
import net.minecraft.entity.monster.*;
import net.minecraft.util.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import java.util.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.mod.*;
import essentialcraft.utils.cfg.*;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityDemon extends EntityLiving implements IInventory
{
    public ItemStack inventory;
    public ItemStack desiredItem;
    public static final DataParameter<ItemStack> DESIRED;
    
    protected boolean func_70692_ba() {
        return false;
    }
    
    public EntityDemon(final World w) {
        super(w);
        this.inventory = ItemStack.field_190927_a;
        this.desiredItem = ItemStack.field_190927_a;
        final DemonTrade trade = (DemonTrade)MathUtils.randomElement((Iterable)DemonTrade.TRADES, w.field_73012_v);
        if (trade.entityType != null) {
            this.desiredItem = new ItemStack(ItemsCore.soul, w.field_73012_v.nextInt(7) + 1, 0);
            MiscUtils.getStackTag(this.desiredItem).func_74778_a("entity", trade.entityType.getRegistryName().toString());
        }
        else {
            this.desiredItem = trade.desiredItem;
        }
    }
    
    protected SoundEvent func_184639_G() {
        return this.func_130014_f_().field_73012_v.nextBoolean() ? SoundRegistry.entityDemonSay : SoundRegistry.entityDemonSummon;
    }
    
    protected SoundEvent func_184601_bQ(final DamageSource s) {
        return SoundRegistry.entityDemonDepart;
    }
    
    public boolean func_70097_a(final DamageSource damageSource, final float amount) {
        this.func_184185_a(this.func_184601_bQ(damageSource), 1.0f, 1.0f);
        this.func_70106_y();
        for (int i = 0; i < 400; ++i) {
            final double d2 = this.field_70146_Z.nextGaussian() * 0.02;
            final double d3 = this.field_70146_Z.nextGaussian() * 0.02;
            final double d4 = this.field_70146_Z.nextGaussian() * 0.02;
            this.func_130014_f_().func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, this.field_70165_t + this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0f - this.field_70130_N, this.field_70163_u + this.field_70146_Z.nextFloat() * this.field_70131_O, this.field_70161_v + this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0f - this.field_70130_N, d2, d3, d4, new int[0]);
        }
        return false;
    }
    
    public void func_70071_h_() {
        if (!this.func_130014_f_().field_72995_K) {
            this.func_184212_Q().func_187227_b((DataParameter)EntityDemon.DESIRED, (Object)this.desiredItem);
        }
        super.func_70071_h_();
        if (!this.func_70301_a(0).func_190926_b() && !this.desiredItem.func_190926_b() && this.func_70301_a(0).func_190916_E() >= this.desiredItem.func_190916_E() && ((this.desiredItem.func_77952_i() != 32767 && this.desiredItem.func_77969_a(this.func_70301_a(0)) && (!this.desiredItem.func_77942_o() || ItemStack.func_77970_a(this.desiredItem, this.func_70301_a(0)))) || (this.desiredItem.func_77952_i() == 32767 && this.func_70301_a(0).func_77973_b() == this.desiredItem.func_77973_b()))) {
            this.func_70106_y();
            for (int i = 0; i < 400; ++i) {
                final double d2 = this.field_70146_Z.nextGaussian() * 0.02;
                final double d3 = this.field_70146_Z.nextGaussian() * 0.02;
                final double d4 = this.field_70146_Z.nextGaussian() * 0.02;
                this.func_130014_f_().func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, this.field_70165_t + this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0f - this.field_70130_N, this.field_70163_u + this.field_70146_Z.nextFloat() * this.field_70131_O, this.field_70161_v + this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0f - this.field_70130_N, d2, d3, d4, new int[0]);
            }
            this.func_130014_f_().func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundRegistry.entityDemonDoom, SoundCategory.HOSTILE, this.func_70599_aP(), this.func_70647_i(), false);
            final ItemStack result = new ItemStack(ItemsCore.genericItem, 3 + this.func_130014_f_().field_73012_v.nextInt(6), 52);
            final EntityItem itm = new EntityItem(this.func_130014_f_(), this.field_70165_t, this.field_70163_u, this.field_70161_v, result);
            if (!this.func_130014_f_().field_72995_K) {
                this.func_130014_f_().func_72838_d((Entity)itm);
            }
        }
        if (this.func_130014_f_().func_72896_J() && this.func_130014_f_().func_175710_j(new BlockPos(MathHelper.func_76128_c(this.field_70165_t), MathHelper.func_76128_c(this.field_70163_u + 1.0), MathHelper.func_76128_c(this.field_70161_v)))) {
            for (int i = 0; i < 20; ++i) {
                this.func_130014_f_().func_175688_a(EnumParticleTypes.SMOKE_NORMAL, this.field_70165_t + MathUtils.randomDouble(this.func_70681_au()), this.field_70163_u + 1.3 + MathUtils.randomDouble(this.func_70681_au()) * 2.0, this.field_70161_v + MathUtils.randomDouble(this.func_70681_au()), 0.0, 0.1, 0.0, new int[0]);
            }
        }
        if (this.field_70173_aa % 40 == 0) {
            for (int dx = -1; dx <= 1; ++dx) {
                for (int dz = -1; dz <= 1; ++dz) {
                    final Block b = this.func_130014_f_().func_180495_p(new BlockPos(MathHelper.func_76128_c(this.field_70165_t) + dx, MathHelper.func_76128_c(this.field_70163_u), MathHelper.func_76128_c(this.field_70161_v) + dz)).func_177230_c();
                    if (b instanceof BlockDemonicPentacle) {
                        final TileDemonicPentacle tile = (TileDemonicPentacle)this.func_130014_f_().func_175625_s(new BlockPos(MathHelper.func_76128_c(this.field_70165_t) + dx, MathHelper.func_76128_c(this.field_70163_u), MathHelper.func_76128_c(this.field_70161_v) + dz));
                        if (tile.tier >= 0) {
                            return;
                        }
                    }
                }
            }
            this.func_70097_a(DamageSource.field_76380_i, 1.0f);
        }
        if (this.field_70173_aa % 20 == 0) {
            final List<EntityMob> zombies = (List<EntityMob>)this.func_130014_f_().func_72872_a((Class)EntityMob.class, new AxisAlignedBB(this.field_70165_t - 0.5, this.field_70163_u - 0.5, this.field_70161_v - 0.5, this.field_70165_t + 0.5, this.field_70163_u + 0.5, this.field_70161_v + 0.5).func_72314_b(12.0, 12.0, 12.0));
            if (!zombies.isEmpty()) {
                final EntityMob z = zombies.get(this.func_70681_au().nextInt(zombies.size()));
                if (z.func_70089_S()) {
                    this.func_184609_a(EnumHand.MAIN_HAND);
                    z.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), z.func_110138_aP() * 1.6f);
                    this.func_130014_f_().func_72876_a((Entity)this, z.field_70165_t, z.field_70163_u, z.field_70161_v, 2.0f, false);
                }
            }
        }
        if (this.func_130014_f_().field_72995_K) {
            this.desiredItem = (ItemStack)this.func_184212_Q().func_187225_a((DataParameter)EntityDemon.DESIRED);
        }
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.field_70180_af.func_187214_a((DataParameter)EntityDemon.DESIRED, (Object)new ItemStack(Items.field_151034_e, 1, 0));
    }
    
    public Iterable<ItemStack> func_184214_aD() {
        return (Iterable<ItemStack>)Collections.emptySet();
    }
    
    public ItemStack func_184582_a(final EntityEquipmentSlot slotIn) {
        return ItemStack.field_190927_a;
    }
    
    public void func_184201_a(final EntityEquipmentSlot slotIn, final ItemStack stack) {
    }
    
    public int func_70302_i_() {
        return 1;
    }
    
    public ItemStack func_70301_a(final int slot) {
        return this.inventory;
    }
    
    public ItemStack func_70298_a(final int slot, final int i) {
        this.inventory.func_190918_g(i);
        if (this.inventory.func_190916_E() <= 0) {
            this.func_70299_a(0, ItemStack.field_190927_a);
        }
        return this.inventory;
    }
    
    public void func_70299_a(final int slot, final ItemStack stk) {
        this.inventory = stk;
    }
    
    public String func_70005_c_() {
        return "demon";
    }
    
    public boolean func_145818_k_() {
        return false;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public void func_70296_d() {
    }
    
    public boolean func_70300_a(final EntityPlayer p) {
        return !this.field_70128_L && p.field_71093_bK == this.field_71093_bK && this.func_174791_d().func_186679_c(p.field_70165_t, p.field_70163_u, p.field_70161_v) <= 64.0;
    }
    
    public void func_174889_b(final EntityPlayer p) {
    }
    
    public void func_174886_c(final EntityPlayer p) {
    }
    
    public boolean func_184645_a(final EntityPlayer p, final EnumHand hand) {
        this.func_184185_a(SoundRegistry.entityDemonTrade, this.func_70599_aP(), this.func_70647_i());
        p.openGui((Object)EssentialCraftCore.core, Config.guiID[1], this.func_130014_f_(), MathHelper.func_76128_c(this.field_70165_t), MathHelper.func_76128_c(this.field_70163_u), MathHelper.func_76128_c(this.field_70161_v));
        return true;
    }
    
    public void func_70014_b(final NBTTagCompound tag) {
        super.func_70014_b(tag);
        if (!this.desiredItem.func_190926_b()) {
            final NBTTagCompound itemTag = new NBTTagCompound();
            this.desiredItem.func_77955_b(itemTag);
            tag.func_74782_a("desired", (NBTBase)itemTag);
        }
        else {
            tag.func_82580_o("desired");
        }
        if (!this.inventory.func_190926_b()) {
            final NBTTagCompound itemTag = new NBTTagCompound();
            this.inventory.func_77955_b(itemTag);
            tag.func_74782_a("inventory", (NBTBase)itemTag);
        }
        else {
            tag.func_82580_o("inventory");
        }
    }
    
    public void func_70037_a(final NBTTagCompound tag) {
        super.func_70037_a(tag);
        if (tag.func_74764_b("desired")) {
            this.desiredItem = new ItemStack(tag.func_74775_l("desired"));
        }
        if (tag.func_74764_b("inventory")) {
            this.inventory = new ItemStack(tag.func_74775_l("inventory"));
        }
    }
    
    public boolean func_94041_b(final int slot, final ItemStack stk) {
        return true;
    }
    
    public ItemStack func_70304_b(final int index) {
        final ItemStack stk = this.inventory;
        this.inventory = ItemStack.field_190927_a;
        return stk;
    }
    
    public int func_174887_a_(final int id) {
        return 0;
    }
    
    public void func_174885_b(final int id, final int value) {
    }
    
    public int func_174890_g() {
        return 0;
    }
    
    public void func_174888_l() {
        this.inventory = ItemStack.field_190927_a;
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    public boolean func_191420_l() {
        return this.inventory.func_190926_b();
    }
    
    static {
        DESIRED = EntityDataManager.func_187226_a((Class)EntityDemon.class, DataSerializers.field_187196_f);
    }
}
