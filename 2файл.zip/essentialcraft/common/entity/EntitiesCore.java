package essentialcraft.common.entity;

import net.minecraft.entity.*;
import net.minecraft.util.*;
import essentialcraft.common.mod.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.world.biome.*;
import java.util.stream.*;
import net.minecraft.init.*;
import net.minecraftforge.common.*;
import java.util.*;

public class EntitiesCore
{
    public static final List<EntityEntry> REGISTERED_ENTITIES;
    public static int id;
    
    public static void registerEntities() {
        registerEntity((Class<? extends Entity>)EntityMRUPresence.class, 64, 1, true);
        registerEntity((Class<? extends Entity>)EntityMRUArrow.class, 64, 1, true);
        registerEntity((Class<? extends Entity>)EntitySolarBeam.class, 64, 1, true);
        registerEntity((Class<? extends Entity>)EntityWindMage.class, 64, 1, true);
        registerEntity((Class<? extends Entity>)EntityPoisonFume.class, 64, 1, true);
        registerEntity((Class<? extends Entity>)EntityShadowKnife.class, 32, 1, true);
        registerEntity(EntityMRURay.class, 128, 1, true);
        registerEntity((Class<? extends Entity>)EntityDemon.class, 32, 1, true);
        registerEntity((Class<? extends Entity>)EntityHologram.class, 32, 1, true);
        registerEntity((Class<? extends Entity>)EntityPlayerClone.class, 32, 1, true);
        registerEntity(EntityOrbitalStrike.class, 32, 1, true);
        registerEntity(EntityDivider.class, 32, 1, true);
        registerEntity((Class<? extends Entity>)EntityArmorDestroyer.class, 32, 1, true);
        registerEntity((Class<? extends Entity>)EntityDividerProjectile.class, 32, 1, true);
        EntityRegistry.addSpawn((Class)EntityWindMage.class, 2, 1, 6, EnumCreatureType.MONSTER, biomesToSpawn());
        EntityRegistry.addSpawn((Class)EntityPoisonFume.class, 100, 8, 16, EnumCreatureType.MONSTER, biomesToSpawn());
    }
    
    public static void registerEntity(final Class<? extends Entity> entityClass, final int trackingRange, final int tickDelay, final boolean trackRotation) {
        final ResourceLocation rl = new ResourceLocation("essentialcraft:" + entityClass.getSimpleName().toLowerCase(Locale.US));
        EntityRegistry.registerModEntity(rl, (Class)entityClass, entityClass.getName(), nextID(), (Object)EssentialCraftCore.core, trackingRange, tickDelay, trackRotation);
        EntitiesCore.REGISTERED_ENTITIES.add((EntityEntry)ForgeRegistries.ENTITIES.getValue(rl));
    }
    
    private static int nextID() {
        return ++EntitiesCore.id;
    }
    
    public static Biome[] biomesToSpawn() {
        return StreamSupport.stream((Spliterator<Object>)Biome.field_185377_q.spliterator(), false).filter(biome -> biome != null && biome != Biomes.field_76778_j && biome != Biomes.field_76779_k && biome.func_76747_a(EnumCreatureType.MONSTER) != null && !biome.func_76747_a(EnumCreatureType.MONSTER).isEmpty() && !BiomeDictionary.hasType(biome, BiomeDictionary.Type.END) && !BiomeDictionary.hasType(biome, BiomeDictionary.Type.NETHER)).toArray(Biome[]::new);
    }
    
    public static void fixMappings() {
    }
    
    static {
        REGISTERED_ENTITIES = new ArrayList<EntityEntry>();
        EntitiesCore.id = -1;
    }
}
