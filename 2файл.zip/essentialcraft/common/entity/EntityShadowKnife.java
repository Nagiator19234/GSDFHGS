package essentialcraft.common.entity;

import net.minecraft.entity.projectile.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.item.*;
import net.minecraft.item.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntityShadowKnife extends EntityThrowable
{
    public EntityShadowKnife(final World w, final EntityLivingBase t) {
        super(w, t);
    }
    
    public EntityShadowKnife(final World w) {
        super(w);
    }
    
    protected void func_70184_a(final RayTraceResult mop) {
        if (mop.field_72308_g != null && mop.field_72308_g instanceof EntityLivingBase) {
            ((EntityLivingBase)mop.field_72308_g).func_70097_a(DamageSource.func_76358_a(this.func_85052_h()), 12.0f);
            this.teleportRandomly(mop.field_72308_g);
            this.func_70106_y();
            if (mop.field_72308_g instanceof EntityPlayer) {
                ShadeUtils.attackPlayerWithShade((EntityPlayer)mop.field_72308_g, this.func_85052_h(), new ItemStack(ItemsCore.shadeKnife, 1, 0));
            }
        }
    }
    
    protected boolean teleportRandomly(final Entity e) {
        final double d0 = e.field_70165_t + (this.field_70146_Z.nextDouble() - 0.5) * 64.0;
        final double d2 = e.field_70163_u + (this.field_70146_Z.nextInt(64) - 32);
        final double d3 = e.field_70161_v + (this.field_70146_Z.nextDouble() - 0.5) * 64.0;
        return this.teleport(e, d0, d2, d3);
    }
    
    protected boolean teleport(final Entity e, final double x, final double y, final double z) {
        final double d3 = e.field_70165_t;
        final double d4 = e.field_70163_u;
        final double d5 = e.field_70161_v;
        e.field_70165_t = x;
        e.field_70163_u = y;
        e.field_70161_v = z;
        boolean flag = false;
        final int i = MathHelper.func_76128_c(e.field_70165_t);
        int j = MathHelper.func_76128_c(e.field_70163_u);
        final int k = MathHelper.func_76128_c(e.field_70161_v);
        if (this.func_130014_f_().func_175667_e(new BlockPos(i, j, k))) {
            boolean flag2 = false;
            while (!flag2 && j > 0) {
                final IBlockState block = e.func_130014_f_().func_180495_p(new BlockPos(i, j - 1, k));
                if (block.func_185904_a().func_76230_c()) {
                    flag2 = true;
                }
                else {
                    --e.field_70163_u;
                    --j;
                }
            }
            if (flag2) {
                e.func_70107_b(e.field_70165_t, e.field_70163_u, e.field_70161_v);
                if (e.func_130014_f_().func_184144_a(e, e.func_174813_aQ()).isEmpty() && !e.func_130014_f_().func_72953_d(e.func_174813_aQ())) {
                    flag = true;
                }
            }
        }
        if (!flag) {
            e.func_70107_b(d3, d4, d5);
            return false;
        }
        final short short1 = 128;
        for (int l = 0; l < short1; ++l) {
            final double d6 = l / (short1 - 1.0);
            final float f = (this.field_70146_Z.nextFloat() - 0.5f) * 0.2f;
            final float f2 = (this.field_70146_Z.nextFloat() - 0.5f) * 0.2f;
            final float f3 = (this.field_70146_Z.nextFloat() - 0.5f) * 0.2f;
            final double d7 = d3 + (e.field_70165_t - d3) * d6 + (this.field_70146_Z.nextDouble() - 0.5) * e.field_70130_N * 2.0;
            final double d8 = d4 + (e.field_70163_u - d4) * d6 + this.field_70146_Z.nextDouble() * e.field_70131_O;
            final double d9 = d5 + (e.field_70161_v - d5) * d6 + (this.field_70146_Z.nextDouble() - 0.5) * e.field_70130_N * 2.0;
            e.func_130014_f_().func_175688_a(EnumParticleTypes.PORTAL, d7, d8, d9, (double)f, (double)f2, (double)f3, new int[0]);
        }
        e.func_130014_f_().func_184148_a((EntityPlayer)null, d3, d4, d5, SoundEvents.field_187534_aX, SoundCategory.PLAYERS, 1.0f, 1.0f);
        e.func_184185_a(SoundEvents.field_187534_aX, 1.0f, 1.0f);
        return true;
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
