package essentialcraft.common.entity;

import net.minecraft.world.*;
import net.minecraft.nbt.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityDivider extends Entity
{
    public static final DataParameter<String> DATA;
    public EntityLivingBase attacker;
    public double delay;
    public double damage;
    public static final double RANGE = 3.0;
    
    public EntityDivider(final World w) {
        super(w);
        this.delay = 2.0;
        this.damage = 1.0;
        this.func_70105_a(0.3f, 0.3f);
    }
    
    public EntityDivider(final World w, final double x, final double y, final double z) {
        this(w);
        this.func_70080_a(x, y, z, 0.0f, 0.0f);
    }
    
    public EntityDivider(final World w, final double x, final double y, final double z, final double damage, final double delay, final EntityLivingBase base) {
        this(w, x, y, z);
        this.damage = damage;
        this.delay = delay;
    }
    
    protected void func_70088_a() {
        this.func_184212_Q().func_187214_a((DataParameter)EntityDivider.DATA, (Object)"||null:null");
    }
    
    protected void func_70037_a(final NBTTagCompound tag) {
        this.delay = tag.func_74769_h("delay");
        this.damage = tag.func_74769_h("damage");
    }
    
    protected void func_70014_b(final NBTTagCompound tag) {
        tag.func_74780_a("delay", this.delay);
        tag.func_74780_a("damage", this.damage);
    }
    
    public void func_70071_h_() {
        this.delay -= 0.05;
        if (this.field_70173_aa % 10 == 0) {
            this.func_184185_a(SoundEvents.field_187572_ar, 1.0f, 0.5f);
        }
        this.func_130014_f_().func_175688_a(EnumParticleTypes.REDSTONE, this.field_70165_t, this.field_70163_u, this.field_70161_v, 1.0, 0.0, 1.0, new int[0]);
        if (this.delay <= 0.0 && !this.field_70128_L) {
            final List<EntityLivingBase> allEntities = (List<EntityLivingBase>)this.func_130014_f_().func_72872_a((Class)EntityLivingBase.class, new AxisAlignedBB(this.field_70165_t - 0.5, this.field_70163_u - 0.5, this.field_70161_v - 0.5, this.field_70165_t + 0.5, this.field_70163_u + 0.5, this.field_70161_v + 0.5).func_72314_b(3.0, 3.0, 3.0));
            for (final EntityLivingBase elb : allEntities) {
                if (elb != null && !elb.field_70128_L && elb != this.attacker) {
                    if (elb instanceof EntityHologram) {
                        continue;
                    }
                    if (elb instanceof EntityPlayer && (((EntityPlayer)elb).func_184812_l_() || ((EntityPlayer)elb).func_175149_v())) {
                        continue;
                    }
                    if (elb.func_70032_d((Entity)this) > 3.0f) {
                        continue;
                    }
                    if (this.func_130014_f_().field_72995_K) {
                        return;
                    }
                    elb.func_70606_j(elb.func_110143_aJ() / 2.0f);
                    elb.func_70690_d(new PotionEffect(MobEffects.field_76437_t, 200, 4, true, true));
                    elb.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 200, 4, true, true));
                    elb.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 200, 4, true, true));
                    elb.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 100, 0, true, true));
                }
            }
            this.func_70106_y();
        }
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    static {
        DATA = EntityDataManager.func_187226_a((Class)EntityDivider.class, DataSerializers.field_187194_d);
    }
}
