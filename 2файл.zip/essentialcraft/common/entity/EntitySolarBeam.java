package essentialcraft.common.entity;

import net.minecraft.entity.effect.*;
import net.minecraft.world.*;
import net.minecraft.block.material.*;
import net.minecraft.init.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntitySolarBeam extends EntityWeatherEffect
{
    public int beamLiveTime;
    
    public EntitySolarBeam(final World world) {
        super(world);
        this.beamLiveTime = 20;
        this.field_70158_ak = true;
        this.func_70105_a(0.3f, 0.3f);
    }
    
    public EntitySolarBeam(final World world, final double x, final double y, final double z) {
        super(world);
        this.beamLiveTime = 20;
        this.func_70012_b(x, y, z, 0.0f, 0.0f);
        this.beamLiveTime = 20;
        if (!world.field_72995_K && world.func_82736_K().func_82766_b("doFireTick") && world.func_175697_a(new BlockPos(MathHelper.func_76128_c(x), MathHelper.func_76128_c(y), MathHelper.func_76128_c(z)), 10)) {
            int i = MathHelper.func_76128_c(x);
            int j = MathHelper.func_76128_c(y);
            int k = MathHelper.func_76128_c(z);
            if (world.func_180495_p(new BlockPos(i, j, k)).func_185904_a() == Material.field_151579_a && Blocks.field_150480_ab.func_176196_c(world, new BlockPos(i, j, k))) {
                world.func_175656_a(new BlockPos(i, j, k), Blocks.field_150480_ab.func_176223_P());
            }
            for (i = 0; i < 32; ++i) {
                j = MathHelper.func_76128_c(x) + this.field_70146_Z.nextInt(13) - 1;
                k = MathHelper.func_76128_c(y) + this.field_70146_Z.nextInt(13) - 1;
                final int l = MathHelper.func_76128_c(z) + this.field_70146_Z.nextInt(13) - 1;
                if (world.func_180495_p(new BlockPos(j, k, l)).func_185904_a() == Material.field_151579_a && Blocks.field_150480_ab.func_176196_c(world, new BlockPos(j, k, l))) {
                    world.func_175656_a(new BlockPos(j, k, l), Blocks.field_150480_ab.func_176223_P());
                }
            }
        }
    }
    
    public void func_70071_h_() {
        super.func_70071_h_();
        final int beamLiveTime = this.beamLiveTime - 1;
        this.beamLiveTime = beamLiveTime;
        if (beamLiveTime <= 0) {
            this.func_70106_y();
        }
        if (this.beamLiveTime % 5 == 0) {
            this.func_130014_f_().func_184148_a((EntityPlayer)null, this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187643_bs, SoundCategory.WEATHER, 10.0f, 2.0f);
        }
        final double d0 = 6.0;
        final List<?> list = (List<?>)this.func_130014_f_().func_72839_b((Entity)this, new AxisAlignedBB(this.field_70165_t - d0, this.field_70163_u - d0, this.field_70161_v - d0, this.field_70165_t + d0, this.field_70163_u + 128.0 + d0, this.field_70161_v + d0));
        for (final Object element : list) {
            final Entity entity = (Entity)element;
            entity.func_70015_d(5);
            entity.func_70097_a(DamageSource.field_76370_b, 3.0f);
        }
    }
    
    protected void func_70088_a() {
    }
    
    protected void func_70037_a(final NBTTagCompound nbt) {
    }
    
    protected void func_70014_b(final NBTTagCompound nbt) {
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
