package essentialcraft.common.entity;

import net.minecraft.item.*;
import essentialcraft.common.mod.*;
import net.minecraft.init.*;
import net.minecraft.tileentity.*;
import java.util.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import essentialcraft.common.registry.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.server.*;
import net.minecraft.server.management.*;
import net.minecraft.nbt.*;
import net.minecraftforge.common.util.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityHologram extends EntityLiving
{
    public static final double RANGE = 24.0;
    public static final DataParameter<String> DATA;
    public int attackID;
    public int attackTimer;
    public int restingTime;
    public int prevAttackID;
    public int damage;
    public double basePosX;
    public double basePosY;
    public double basePosZ;
    public List<UUID> players;
    public final BossInfoServer bossInfo;
    
    public void func_180430_e(final float distance, final float damageMultiplier) {
    }
    
    protected ResourceLocation func_184647_J() {
        if (this.prevAttackID == -1) {
            this.prevAttackID = this.func_130014_f_().field_73012_v.nextInt(4);
        }
        switch (this.prevAttackID) {
            case 0: {
                return LootTableRegistry.ENTITY_HOLOGRAM_ADDITION;
            }
            case 1: {
                return LootTableRegistry.ENTITY_HOLOGRAM_SUBTRACTION;
            }
            case 2: {
                return LootTableRegistry.ENTITY_HOLOGRAM_MULTIPLICATION;
            }
            case 3: {
                return LootTableRegistry.ENTITY_HOLOGRAM_DIVISION;
            }
            default: {
                return null;
            }
        }
    }
    
    public void func_70645_a(final DamageSource cause) {
        super.func_70645_a(cause);
        if (!this.func_130014_f_().field_72995_K) {
            for (final UUID player : this.players) {
                final EntityPlayer p = MiscUtils.getPlayerFromUUID(player);
                boolean addBig = true;
                for (int j = 0; j < 4; ++j) {
                    if (!((ItemStack)p.field_71071_by.field_70460_b.get(j)).func_190926_b()) {
                        addBig = false;
                    }
                }
                if (addBig) {}
            }
        }
        EssentialCraftCore.proxy.stopSound("hologram");
        final World w = this.func_130014_f_();
        w.func_175656_a(this.func_180425_c(), Blocks.field_150486_ae.func_176223_P());
        final TileEntityChest chest = (TileEntityChest)w.func_175625_s(this.func_180425_c());
        if (chest != null) {
            chest.func_189404_a(LootTableRegistry.CHEST_HOLOGRAM, w.field_73012_v.nextLong());
        }
    }
    
    public EntityHologram(final World w) {
        super(w);
        this.attackID = -1;
        this.prevAttackID = -1;
        this.damage = 1;
        this.players = new ArrayList<UUID>();
        this.bossInfo = new BossInfoServer(this.func_145748_c_(), BossInfo.Color.RED, BossInfo.Overlay.PROGRESS);
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.0);
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(400.0);
        this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0);
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.func_184212_Q().func_187214_a((DataParameter)EntityHologram.DATA, (Object)"||null:null");
    }
    
    protected SoundEvent func_184639_G() {
        return null;
    }
    
    protected SoundEvent func_184601_bQ(final DamageSource s) {
        return null;
    }
    
    protected SoundEvent func_184615_bR() {
        return SoundRegistry.entityHologramShutdown;
    }
    
    public void dwWrite() {
        if (!this.func_130014_f_().field_72995_K) {
            this.func_184212_Q().func_187227_b((DataParameter)EntityHologram.DATA, (Object)("||aID:" + this.attackID + "||aTi:" + this.attackTimer + "||rTi:" + this.restingTime));
        }
    }
    
    public void dwRead() {
        if (this.func_130014_f_().field_72995_K) {
            final String str = (String)this.func_184212_Q().func_187225_a((DataParameter)EntityHologram.DATA);
            if (str != null && !str.isEmpty() && !str.equals("||null:null")) {
                try {
                    final DummyData[] genDat = DataStorage.parseData(str);
                    this.attackID = Integer.parseInt(genDat[0].fieldValue);
                    this.attackTimer = Integer.parseInt(genDat[1].fieldValue);
                    this.restingTime = Integer.parseInt(genDat[2].fieldValue);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public void func_70071_h_() {
        if (this.field_70173_aa == 1) {
            this.basePosX = this.field_70165_t;
            this.basePosY = this.field_70163_u;
            this.basePosZ = this.field_70161_v;
        }
        if (this.field_70165_t != this.basePosX || this.field_70163_u != this.basePosY || this.field_70161_v != this.basePosZ) {
            this.func_70080_a(this.basePosX, this.basePosY, this.basePosZ, this.field_70177_z, this.field_70125_A);
        }
        if (this.field_70725_aQ != 0) {
            EssentialCraftCore.proxy.stopSound("hologram");
        }
        else if (!this.field_70128_L) {
            EssentialCraftCore.proxy.startRecord("hologram", "essentialcraft:records.hologram", this.func_180425_c());
        }
        this.dwWrite();
        if (this.field_70181_x < 0.002) {
            this.field_70181_x = 0.002;
        }
        super.func_70071_h_();
        this.dwRead();
        if (this.func_70027_ad()) {
            this.func_70066_B();
        }
        if (!this.func_70651_bq().isEmpty()) {
            this.func_70674_bp();
        }
        if (!this.func_130014_f_().field_72995_K) {
            if (this.restingTime == 0 && this.attackID == -1) {
                final int rndID = this.func_130014_f_().field_73012_v.nextInt(4);
                this.attackID = rndID;
                this.attackTimer = 100;
                ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "essentialcraft:sound.mob.hologram.stop", 5.0f, 2.0f, 16.0, this.field_71093_bK);
                this.damage = 1;
            }
            if (this.attackTimer != 0 && this.attackID != -1) {
                --this.attackTimer;
                if (this.attackID == 0 && this.attackTimer == 20) {
                    final int hMax = 3 - MathHelper.func_76141_d(this.func_110143_aJ() / this.func_110138_aP() * 3.0f);
                    for (final UUID player : this.players) {
                        final EntityPlayer p = MiscUtils.getPlayerFromUUID(player);
                        if (p != null) {
                            for (int j = 0; j < 1 + hMax; ++j) {
                                final EntityPlayerClone clone = new EntityPlayerClone(p.func_130014_f_());
                                clone.setClonedPlayer(player);
                                clone.func_70080_a(p.field_70165_t + MathUtils.randomDouble(this.field_70146_Z) * 6.0, p.field_70163_u, p.field_70161_v + MathUtils.randomDouble(this.field_70146_Z) * 6.0, p.field_70177_z, p.field_70125_A);
                                clone.func_184201_a(EntityEquipmentSlot.MAINHAND, p.func_184614_ca().func_190926_b() ? ItemStack.field_190927_a : p.func_184614_ca().func_77946_l());
                                clone.func_184201_a(EntityEquipmentSlot.OFFHAND, p.func_184592_cb().func_190926_b() ? p.func_184592_cb().func_77946_l() : ItemStack.field_190927_a);
                                clone.func_184201_a(EntityEquipmentSlot.HEAD, ((ItemStack)p.field_71071_by.field_70460_b.get(3)).func_190926_b() ? ((ItemStack)p.field_71071_by.field_70460_b.get(3)).func_77946_l() : ItemStack.field_190927_a);
                                clone.func_184201_a(EntityEquipmentSlot.CHEST, ((ItemStack)p.field_71071_by.field_70460_b.get(2)).func_190926_b() ? ((ItemStack)p.field_71071_by.field_70460_b.get(2)).func_77946_l() : ItemStack.field_190927_a);
                                clone.func_184201_a(EntityEquipmentSlot.LEGS, ((ItemStack)p.field_71071_by.field_70460_b.get(1)).func_190926_b() ? ((ItemStack)p.field_71071_by.field_70460_b.get(1)).func_77946_l() : ItemStack.field_190927_a);
                                clone.func_184201_a(EntityEquipmentSlot.FEET, ((ItemStack)p.field_71071_by.field_70460_b.get(0)).func_190926_b() ? ((ItemStack)p.field_71071_by.field_70460_b.get(0)).func_77946_l() : ItemStack.field_190927_a);
                                this.func_130014_f_().func_72838_d((Entity)clone);
                            }
                        }
                    }
                }
                if (this.attackID == 1) {
                    for (final UUID player2 : this.players) {
                        if (player2 == null) {
                            continue;
                        }
                        this.func_70625_a((Entity)MiscUtils.getPlayerFromUUID(player2), 360.0f, 180.0f);
                        final EntityArmorDestroyer destr = new EntityArmorDestroyer(this.func_130014_f_(), (EntityLivingBase)this);
                        destr.func_184538_a((Entity)this, this.field_70125_A, this.field_70177_z, 0.0f, 1.5f, 0.5f);
                        this.field_70177_z = this.func_130014_f_().field_73012_v.nextFloat() * 360.0f;
                        this.field_70125_A = 90.0f - this.func_130014_f_().field_73012_v.nextFloat() * 180.0f;
                        this.func_130014_f_().func_72838_d((Entity)destr);
                    }
                }
                if (this.attackID == 2 && this.attackTimer % 10 == 0 && this.players.size() > 0) {
                    final int i = this.func_130014_f_().field_73012_v.nextInt(this.players.size());
                    final EntityPlayer p2 = MiscUtils.getPlayerFromUUID((UUID)this.players.get(i));
                    if (p2 != null) {
                        final EntityOrbitalStrike strike = new EntityOrbitalStrike(this.func_130014_f_(), p2.field_70165_t, p2.field_70163_u, p2.field_70161_v, this.damage, 3.0f - (2.0f - this.func_110143_aJ() / this.func_110138_aP() * 2.0f), (EntityLivingBase)this);
                        this.func_130014_f_().func_72838_d((Entity)strike);
                    }
                    this.damage *= 2;
                }
                if (this.attackID == 3 && this.attackTimer % 20 == 0) {
                    for (int i = 0; i < 6 - MathHelper.func_76141_d(this.func_110143_aJ() / this.func_110138_aP() * 5.0f); ++i) {
                        if (this.players.size() > 0) {
                            final int i2 = this.func_130014_f_().field_73012_v.nextInt(this.players.size());
                            final EntityPlayer p3 = MiscUtils.getPlayerFromUUID((UUID)this.players.get(i2));
                            if (p3 != null) {
                                final EntityDivider d = new EntityDivider(this.func_130014_f_(), p3.field_70165_t, p3.field_70163_u, p3.field_70161_v, this.damage, 2.0, (EntityLivingBase)this);
                                this.func_130014_f_().func_72838_d((Entity)d);
                            }
                        }
                    }
                }
            }
            if (this.attackTimer == 0 && this.attackID != -1) {
                this.prevAttackID = this.attackID;
                this.attackID = -1;
                this.restingTime = 100 - MathHelper.func_76141_d(80.0f - this.func_110143_aJ() / this.func_110138_aP() * 80.0f);
                ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "essentialcraft:sound.mob.hologram.stop", 5.0f, 0.01f, 16.0, this.field_71093_bK);
            }
            if (this.restingTime > 0) {
                --this.restingTime;
            }
        }
        else {
            final EntityPlayer p4 = EssentialCraftCore.proxy.getClientPlayer();
            if (p4 != null && !p4.func_184812_l_() && !p4.func_175149_v() && p4.field_71075_bZ.field_75100_b && p4.func_70032_d((Entity)this) <= 24.0 && p4.field_71093_bK == this.field_71093_bK) {
                p4.field_71075_bZ.field_75100_b = false;
            }
        }
        if (!this.func_130014_f_().field_72995_K && this.field_70173_aa % 10 == 0) {
            final MinecraftServer server = this.func_130014_f_().func_73046_m();
            final PlayerList manager = server.func_184103_al();
            for (int k = 0; k < this.players.size(); ++k) {
                final EntityPlayer p = MiscUtils.getPlayerFromUUID((UUID)this.players.get(k));
                if (p == null || p.field_70128_L) {
                    this.players.remove(k);
                    --k;
                }
            }
            for (int k = 0; k < manager.func_72394_k(); ++k) {
                final EntityPlayerMP player3 = manager.func_181057_v().get(k);
                if (player3 != null) {
                    if (this.players.contains(MiscUtils.getUUIDFromPlayer((EntityPlayer)player3))) {
                        if (player3.field_70128_L) {
                            this.players.remove(MiscUtils.getUUIDFromPlayer((EntityPlayer)player3));
                        }
                        else {
                            if (this.field_71093_bK != player3.field_71093_bK) {
                                manager.func_187242_a(player3, this.field_71093_bK);
                            }
                            final double distance = player3.func_70032_d((Entity)this);
                            if (distance > 24.0) {
                                player3.func_70080_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, player3.field_70177_z, player3.field_70125_A);
                                ECUtils.changePlayerPositionOnClient((EntityPlayer)player3);
                                player3.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), 5.0f);
                                ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "random.anvil_break", 1.0f, 0.01f, 8.0, this.field_71093_bK);
                            }
                            if (player3.field_71075_bZ.field_75100_b) {
                                player3.field_71075_bZ.field_75100_b = false;
                            }
                        }
                    }
                    else if (this.field_71093_bK == player3.field_71093_bK) {
                        final double distance = player3.func_70032_d((Entity)this);
                        if (distance <= 24.0) {
                            this.players.add(MiscUtils.getUUIDFromPlayer((EntityPlayer)player3));
                        }
                    }
                }
            }
        }
    }
    
    public void func_70014_b(final NBTTagCompound tag) {
        super.func_70014_b(tag);
        tag.func_74768_a("attackID", this.attackID);
        tag.func_74768_a("attackTimer", this.attackTimer);
        tag.func_74768_a("restingTime", this.restingTime);
        tag.func_74768_a("prevAttackID", this.prevAttackID);
        tag.func_74768_a("listSize", this.players.size());
        tag.func_74768_a("damage", this.damage);
        tag.func_74780_a("basePosX", this.basePosX);
        tag.func_74780_a("basePosY", this.basePosY);
        tag.func_74780_a("basePosZ", this.basePosZ);
        for (int i = 0; i < this.players.size(); ++i) {
            tag.func_186854_a("player_" + i, (UUID)this.players.get(i));
        }
    }
    
    public void func_70037_a(final NBTTagCompound tag) {
        super.func_70037_a(tag);
        this.attackID = tag.func_74762_e("attackID");
        this.attackTimer = tag.func_74762_e("attackTimer");
        this.restingTime = tag.func_74762_e("restingTime");
        this.prevAttackID = tag.func_74762_e("prevAttackID");
        this.damage = tag.func_74762_e("damage");
        this.basePosX = tag.func_74769_h("basePosX");
        this.basePosY = tag.func_74769_h("basePosY");
        this.basePosZ = tag.func_74769_h("basePosZ");
        for (int i = 0; i < tag.func_74762_e("listSize"); ++i) {
            this.players.add(tag.func_186857_a("player_" + i));
        }
    }
    
    public void func_70108_f(final Entity e) {
    }
    
    protected void func_82160_b(final boolean wasRecentlyHit, final int lootingModifier) {
    }
    
    protected void func_82167_n(final Entity e) {
    }
    
    public boolean func_70097_a(final DamageSource src, float f) {
        if (src == null || src.func_76346_g() == null || !(src.func_76346_g() instanceof EntityPlayer) || src.func_76346_g() instanceof FakePlayer) {
            return false;
        }
        if (!((EntityPlayer)src.func_76346_g()).func_184812_l_() && this.attackID != -1) {
            return false;
        }
        this.damage += (int)f;
        if (f > 40.0f || this.damage > 40) {
            this.restingTime = 1;
        }
        if (src.func_76352_a()) {
            f /= 4.0f;
        }
        if (src.func_76352_a()) {
            ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "essentialcraft:sound.mob.hologram.damage.projectile", 5.0f, this.func_130014_f_().field_73012_v.nextFloat() * 2.0f, 16.0, this.field_71093_bK);
        }
        else {
            ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "essentialcraft:sound.mob.hologram.damage.melee", 0.3f, this.func_130014_f_().field_73012_v.nextFloat() * 2.0f, 16.0, this.field_71093_bK);
        }
        return super.func_70097_a(src, f);
    }
    
    public boolean func_184222_aU() {
        return false;
    }
    
    protected void func_70619_bc() {
        super.func_70619_bc();
        this.bossInfo.func_186735_a(this.func_110143_aJ() / this.func_110138_aP());
    }
    
    public void func_184178_b(final EntityPlayerMP player) {
        super.func_184178_b(player);
        this.bossInfo.func_186760_a(player);
    }
    
    public void func_184203_c(final EntityPlayerMP player) {
        super.func_184203_c(player);
        this.bossInfo.func_186761_b(player);
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    static {
        DATA = EntityDataManager.func_187226_a((Class)EntityHologram.class, DataSerializers.field_187194_d);
    }
}
