package essentialcraft.common.entity;

import net.minecraft.entity.projectile.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntityDividerProjectile extends EntityThrowable
{
    public EntityDividerProjectile(final World w) {
        super(w);
    }
    
    public EntityDividerProjectile(final World world, final EntityLivingBase thower) {
        super(world, thower);
    }
    
    protected void func_70184_a(final RayTraceResult result) {
        if (result.field_72313_a == RayTraceResult.Type.BLOCK) {
            final EntityDivider div = new EntityDivider(this.func_130014_f_(), this.field_70165_t, this.field_70163_u, this.field_70161_v, 0.0, 2.0, this.func_85052_h());
            if (!this.func_130014_f_().field_72995_K) {
                this.func_130014_f_().func_72838_d((Entity)div);
            }
            this.func_70106_y();
        }
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
