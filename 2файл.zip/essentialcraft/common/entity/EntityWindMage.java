package essentialcraft.common.entity;

import net.minecraft.entity.monster.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.ai.*;
import com.google.common.base.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import essentialcraft.common.registry.*;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityWindMage extends EntityMob implements IRangedAttackMob
{
    public static final DataParameter<Byte> TYPE;
    private EntityAIAttackRanged aiArrowAttack;
    private EntityAIAttackMelee aiAttackOnCollide;
    
    public EntityWindMage(final World world) {
        super(world);
        this.aiArrowAttack = new EntityAIAttackRanged((IRangedAttackMob)this, 1.0, 20, 60, 15.0f);
        this.aiAttackOnCollide = new EntityAIAttackMelee((EntityCreature)this, 1.2, false);
        this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityPlayer.class, 8.0f));
        this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
        this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget((EntityCreature)this, false, new Class[0]));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, (Class)EntityPlayer.class, 0, true, false, (Predicate)null));
        if (world != null && !world.field_72995_K) {
            this.setCombatTask();
        }
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.25);
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.func_184212_Q().func_187214_a((DataParameter)EntityWindMage.TYPE, (Object)new Byte((byte)0));
    }
    
    protected SoundEvent func_184601_bQ(final DamageSource s) {
        return SoundEvents.field_187912_gl;
    }
    
    protected SoundEvent func_184615_bR() {
        return SoundEvents.field_187911_gk;
    }
    
    public EnumCreatureAttribute func_70668_bt() {
        return EnumCreatureAttribute.UNDEFINED;
    }
    
    public void func_70098_U() {
        super.func_70098_U();
        if (this.func_184187_bx() instanceof EntityCreature) {
            final EntityCreature entitycreature = (EntityCreature)this.func_184187_bx();
            this.field_70761_aq = entitycreature.field_70761_aq;
        }
    }
    
    protected ResourceLocation func_184647_J() {
        switch (this.getType()) {
            case 0: {
                return LootTableRegistry.ENTITY_WINDMAGE_APPRENTICE;
            }
            case 1: {
                return LootTableRegistry.ENTITY_WINDMAGE_NORMAL;
            }
            case 2: {
                return LootTableRegistry.ENTITY_WINDMAGE_ARCHMAGE;
            }
            default: {
                return null;
            }
        }
    }
    
    public void setCombatTask() {
        this.field_70714_bg.func_85156_a((EntityAIBase)this.aiAttackOnCollide);
        this.field_70714_bg.func_85156_a((EntityAIBase)this.aiArrowAttack);
        this.field_70714_bg.func_75776_a(4, (EntityAIBase)this.aiArrowAttack);
    }
    
    public void func_82196_d(final EntityLivingBase target, final float distanceFactor) {
        final EntityMRUArrow entityarrow = new EntityMRUArrow(this.func_130014_f_(), (EntityLivingBase)this, 1.6f);
        final double d0 = target.field_70165_t - this.field_70165_t;
        final double d2 = target.func_174813_aQ().field_72338_b + target.field_70131_O / 3.0f - entityarrow.field_70163_u;
        final double d3 = target.field_70161_v - this.field_70161_v;
        final double d4 = MathHelper.func_76133_a(d0 * d0 + d3 * d3);
        entityarrow.func_70186_c(d0, d2 + d4 * 0.2, d3, 1.6f, (float)(14 - this.func_130014_f_().func_175659_aa().func_151525_a() * 4));
        entityarrow.func_70239_b((double)((this.getType() + 1) * 3));
        this.func_130014_f_().func_72838_d((Entity)entityarrow);
    }
    
    public int getType() {
        return (byte)this.func_184212_Q().func_187225_a((DataParameter)EntityWindMage.TYPE);
    }
    
    public void setType(final int type) {
        this.func_184212_Q().func_187227_b((DataParameter)EntityWindMage.TYPE, (Object)(byte)type);
    }
    
    public void func_70037_a(final NBTTagCompound nbt) {
        super.func_70037_a(nbt);
        if (nbt.func_74764_b("Type")) {
            final byte b0 = nbt.func_74771_c("Type");
            this.setType(b0);
        }
        this.setCombatTask();
    }
    
    public void func_70014_b(final NBTTagCompound nbt) {
        super.func_70014_b(nbt);
        nbt.func_74774_a("Type", (byte)this.getType());
    }
    
    public IEntityLivingData func_180482_a(final DifficultyInstance difficulty, IEntityLivingData livingData) {
        livingData = super.func_180482_a(difficulty, livingData);
        this.setType(this.func_130014_f_().field_73012_v.nextInt(3));
        return livingData;
    }
    
    public double func_70033_W() {
        return super.func_70033_W() - 0.5;
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    public void func_184724_a(final boolean swingingArms) {
    }
    
    static {
        TYPE = EntityDataManager.func_187226_a((Class)EntityWindMage.class, DataSerializers.field_187191_a);
    }
}
