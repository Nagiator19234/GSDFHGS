package essentialcraft.common.entity;

import net.minecraft.entity.monster.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import essentialcraft.utils.cfg.*;
import DummyCore.Utils.*;
import essentialcraft.common.mod.*;
import net.minecraft.entity.player.*;
import baubles.api.*;
import essentialcraft.utils.common.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import java.util.*;
import baubles.api.cap.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntityPoisonFume extends EntityMob
{
    private float heightOffset;
    private int heightOffsetUpdateTime;
    public double mX;
    public double mY;
    public double mZ;
    
    public EntityPoisonFume(final World world) {
        super(world);
        this.heightOffset = 0.5f;
        this.field_70178_ae = true;
        this.func_70105_a(0.6f, 0.6f);
    }
    
    public boolean func_70097_a(final DamageSource damageSource, final float amount) {
        return false;
    }
    
    public int func_70070_b() {
        return 15728880;
    }
    
    public float func_70013_c() {
        return 1.0f;
    }
    
    public void func_70636_d() {
        if (this.field_71093_bK != Config.dimensionID || !ECUtils.isEventActive("essentialcraft.event.fumes")) {
            this.func_70106_y();
        }
        if (!this.func_130014_f_().field_72995_K) {
            --this.heightOffsetUpdateTime;
            if (this.heightOffsetUpdateTime <= 0) {
                this.heightOffsetUpdateTime = 100;
                this.mX = MathUtils.randomDouble(this.func_130014_f_().field_73012_v);
                this.mY = MathUtils.randomDouble(this.func_130014_f_().field_73012_v);
                this.mZ = MathUtils.randomDouble(this.func_130014_f_().field_73012_v);
                this.setHeightOffset(0.5f + (float)this.field_70146_Z.nextGaussian() * 3.0f);
            }
            this.field_70159_w = this.mX / 10.0;
            this.field_70181_x = this.mY / 10.0;
            this.field_70179_y = this.mZ / 10.0;
            if (this.field_70173_aa > 1000) {
                this.func_70106_y();
            }
        }
        EssentialCraftCore.proxy.spawnParticle("fogFX", (float)this.field_70165_t, (float)this.field_70163_u + 2.0f, (float)this.field_70161_v, 0.0, 1.0, 0.0);
        final List<EntityPlayer> players = (List<EntityPlayer>)this.func_130014_f_().func_72872_a((Class)EntityPlayer.class, new AxisAlignedBB(this.field_70165_t - 1.0, this.field_70163_u - 1.0, this.field_70161_v - 1.0, this.field_70165_t + 1.0, this.field_70163_u + 1.0, this.field_70161_v + 1.0).func_72314_b(6.0, 3.0, 6.0));
        for (final EntityPlayer p : players) {
            boolean ignorePoison = false;
            final IBaublesItemHandler b = BaublesApi.getBaublesHandler(p);
            if (b != null) {
                for (int i1 = 0; i1 < b.getSlots(); ++i1) {
                    final ItemStack is = b.getStackInSlot(i1);
                    if ((is.func_77973_b() instanceof ItemBaublesSpecial && is.func_77952_i() == 19) || p.field_71075_bZ.field_75098_d) {
                        ignorePoison = true;
                    }
                }
            }
            if (!p.func_130014_f_().field_72995_K && !ignorePoison) {
                RadiationManager.increasePlayerRadiation(p, 10);
                p.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 200, 1));
            }
        }
        super.func_70636_d();
    }
    
    public boolean func_70652_k(final Entity entity) {
        return false;
    }
    
    public void func_180430_e(final float distance, final float s) {
    }
    
    public boolean func_70027_ad() {
        return false;
    }
    
    protected boolean func_70814_o() {
        return true;
    }
    
    public boolean func_70601_bi() {
        return this.field_71093_bK == Config.dimensionID && ECUtils.isEventActive("essentialcraft.event.fumes");
    }
    
    public float getHeightOffset() {
        return this.heightOffset;
    }
    
    public void setHeightOffset(final float heightOffset) {
        this.heightOffset = heightOffset;
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
