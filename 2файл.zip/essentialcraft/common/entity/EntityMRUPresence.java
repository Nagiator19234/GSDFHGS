package essentialcraft.common.entity;

import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.block.state.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import essentialcraft.utils.cfg.*;
import essentialcraft.common.block.*;
import net.minecraft.init.*;
import net.minecraft.entity.player.*;
import essentialcraft.common.registry.*;
import net.minecraft.block.*;
import net.minecraft.block.material.*;
import net.minecraft.entity.effect.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import java.util.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraftforge.common.capabilities.*;
import net.minecraft.util.*;
import essentialcraft.common.capabilities.mru.*;
import net.minecraft.network.datasync.*;

public class EntityMRUPresence extends EntityLivingBase
{
    public float renderIndex;
    public int tickTimer;
    public boolean firstTick;
    public MRUEntityStorage mruStorage;
    public static final DataParameter<NBTTagCompound> MRU_STORAGE;
    
    public EntityMRUPresence(final World world) {
        super(world);
        this.firstTick = true;
        this.mruStorage = new MRUEntityStorage(20000);
        this.func_70105_a(0.3f, 0.3f);
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0);
        this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0);
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.field_70180_af.func_187214_a((DataParameter)EntityMRUPresence.MRU_STORAGE, (Object)new NBTTagCompound());
    }
    
    public void func_70037_a(final NBTTagCompound var1) {
        super.func_70037_a(var1);
        this.mruStorage.readFromNBT(var1);
    }
    
    public void func_70014_b(final NBTTagCompound var1) {
        super.func_70014_b(var1);
        this.mruStorage.writeToNBT(var1);
    }
    
    protected boolean func_70041_e_() {
        return false;
    }
    
    protected void func_184231_a(final double par1, final boolean par3, final IBlockState par4, final BlockPos par5) {
    }
    
    public void func_70015_d(final int par1) {
    }
    
    protected void func_70044_A() {
    }
    
    public void merge() {
        if (!this.field_70128_L) {
            final List<EntityMRUPresence> l = (List<EntityMRUPresence>)this.func_130014_f_().func_175647_a((Class)EntityMRUPresence.class, new AxisAlignedBB(this.field_70165_t - 0.5, this.field_70163_u - 0.5, this.field_70161_v - 0.5, this.field_70165_t + 0.5, this.field_70163_u + 0.5, this.field_70161_v + 0.5), entity -> entity != this && entity.mruStorage.getMRU() <= this.mruStorage.getMRU());
            if (!l.isEmpty()) {
                for (final EntityMRUPresence presence : l) {
                    if (!presence.field_70128_L) {
                        presence.func_70106_y();
                        this.mruStorage.setBalance((this.mruStorage.getBalance() * this.mruStorage.getMRU() + presence.mruStorage.getBalance() * presence.mruStorage.getMRU()) / (this.mruStorage.getMRU() + presence.mruStorage.getMRU()));
                        this.mruStorage.addMRU(presence.mruStorage.getMRU(), true);
                    }
                }
            }
        }
    }
    
    public void func_70030_z() {
        this.updateMRUStorage();
        super.func_70030_z();
        this.field_70181_x = 0.0;
        this.field_70159_w = 0.0;
        this.field_70179_y = 0.0;
        this.field_70145_X = true;
        this.field_70158_ak = true;
        this.merge();
        if (!this.func_130014_f_().field_72995_K && !this.field_70128_L) {
            if (this.tickTimer <= 0) {
                this.tickTimer = 20;
                float diff = 0.0f;
                Block id = BlocksCore.lightCorruption[3];
                if (this.mruStorage.getBalance() < 1.0f) {
                    id = BlocksCore.lightCorruption[1];
                    diff = 1.0f - this.mruStorage.getBalance();
                }
                if (this.mruStorage.getBalance() > 1.0f) {
                    id = BlocksCore.lightCorruption[0];
                    diff = this.mruStorage.getBalance() - 1.0f;
                }
                final float mainMRUState = diff * this.mruStorage.getMRU() / 6000.0f;
                Vec3d vec = new Vec3d(1.0, 0.0, 0.0);
                vec = vec.func_178789_a(this.func_130014_f_().field_73012_v.nextFloat() * 360.0f);
                vec = vec.func_178785_b(this.func_130014_f_().field_73012_v.nextFloat() * 360.0f);
                if (!this.mruStorage.getFlag()) {
                    for (int i = 0; i < mainMRUState; ++i) {
                        final Vec3d vc = new Vec3d(vec.field_72450_a * i, vec.field_72448_b * i, vec.field_72449_c * i);
                        final Vec3d vc2 = new Vec3d(vec.field_72450_a * (i + 1), vec.field_72448_b * (i + 1), vec.field_72449_c * (i + 1));
                        final Block blk = this.func_130014_f_().func_180495_p(new BlockPos((int)(vc.field_72450_a + this.field_70165_t), (int)(vc.field_72448_b + this.field_70163_u), (int)(vc.field_72449_c + this.field_70161_v))).func_177230_c();
                        final Block blk2 = this.func_130014_f_().func_180495_p(new BlockPos((int)(vc2.field_72450_a + this.field_70165_t), (int)(vc2.field_72448_b + this.field_70163_u), (int)(vc2.field_72449_c + this.field_70161_v))).func_177230_c();
                        int meta = blk2.func_176201_c(this.func_130014_f_().func_180495_p(new BlockPos((int)(vc2.field_72450_a + this.field_70165_t), (int)(vc2.field_72448_b + this.field_70163_u), (int)(vc2.field_72449_c + this.field_70161_v))));
                        float resistance = 1.0f;
                        if (ECUtils.IGNORE_META.containsKey(blk2.func_149739_a()) && ECUtils.IGNORE_META.get(blk2.func_149739_a())) {
                            meta = -1;
                        }
                        final DummyData dt = new DummyData(blk2.func_149739_a(), (Object)meta);
                        if (ECUtils.MRU_RESISTANCES.containsKey(dt.toString())) {
                            resistance = ECUtils.MRU_RESISTANCES.get(dt.toString());
                        }
                        else {
                            resistance = 1.0f;
                        }
                        if (Config.isCorruptionAllowed) {
                            if (!(blk2 instanceof BlockCorruption) && !(blk instanceof BlockCorruption) && blk2 != Blocks.field_150350_a && blk == Blocks.field_150350_a && !this.func_130014_f_().field_72995_K && this.func_130014_f_().field_73012_v.nextInt((int)(1000.0f * resistance)) <= mainMRUState) {
                                this.func_130014_f_().func_180501_a(new BlockPos((int)(vc.field_72450_a + this.field_70165_t), (int)(vc.field_72448_b + this.field_70163_u), (int)(vc.field_72449_c + this.field_70161_v)), id.func_176203_a(0), 3);
                                break;
                            }
                            if (blk instanceof BlockCorruption) {
                                final int metadata = blk.func_176201_c(this.func_130014_f_().func_180495_p(new BlockPos((int)(vc.field_72450_a + this.field_70165_t), (int)(vc.field_72448_b + this.field_70163_u), (int)(vc.field_72449_c + this.field_70161_v))));
                                if (metadata < 7 && this.func_130014_f_().field_73012_v.nextInt((int)(1000.0f * resistance)) <= mainMRUState) {
                                    this.func_130014_f_().func_180501_a(new BlockPos((int)(vc.field_72450_a + this.field_70165_t), (int)(vc.field_72448_b + this.field_70163_u), (int)(vc.field_72449_c + this.field_70161_v)), blk.func_176203_a(metadata + 1), 3);
                                }
                            }
                        }
                    }
                    final List<EntityPlayer> players = (List<EntityPlayer>)this.func_130014_f_().func_72872_a((Class)EntityPlayer.class, new AxisAlignedBB(this.field_70165_t - 0.5, this.field_70163_u - 0.5, this.field_70161_v - 0.5, this.field_70165_t + 0.5, this.field_70163_u + 0.5, this.field_70161_v + 0.5).func_72314_b(12.0, 12.0, 12.0));
                    for (final EntityPlayer player : players) {
                        final Vec3d playerCheck = new Vec3d(player.field_70165_t - this.field_70165_t, player.field_70163_u - this.field_70163_u, player.field_70161_v - this.field_70161_v);
                        float resistance2 = 1.0f;
                        for (double j = 0.0; j < playerCheck.func_72433_c(); j += 0.5) {
                            final double checkIndexX = playerCheck.field_72450_a / playerCheck.func_72433_c() * j;
                            final double checkIndexY = playerCheck.field_72448_b / playerCheck.func_72433_c() * j;
                            final double checkIndexZ = playerCheck.field_72449_c / playerCheck.func_72433_c() * j;
                            final int dX = MathHelper.func_76128_c(this.field_70165_t + checkIndexX);
                            final int dY = MathHelper.func_76128_c(this.field_70163_u + checkIndexY);
                            final int dZ = MathHelper.func_76128_c(this.field_70161_v + checkIndexZ);
                            final Block b = this.func_130014_f_().func_180495_p(new BlockPos(dX, dY, dZ)).func_177230_c();
                            int meta2 = b.func_176201_c(this.func_130014_f_().func_180495_p(new BlockPos(dX, dY, dZ)));
                            if (ECUtils.IGNORE_META.containsKey(b.func_149739_a()) && ECUtils.IGNORE_META.get(b.func_149739_a())) {
                                meta2 = -1;
                            }
                            final DummyData dt2 = new DummyData(b.func_149739_a(), (Object)meta2);
                            if (ECUtils.MRU_RESISTANCES.containsKey(dt2.toString())) {
                                if (resistance2 < ECUtils.MRU_RESISTANCES.get(dt2.toString())) {
                                    resistance2 = ECUtils.MRU_RESISTANCES.get(dt2.toString());
                                }
                            }
                            else if (resistance2 < 1.0f) {
                                resistance2 = 1.0f;
                            }
                        }
                        if (this.func_130014_f_().field_73012_v.nextInt(MathHelper.func_76141_d(resistance2)) == 0) {
                            float genResistance = ECUtils.getGenResistance(0, player);
                            if (genResistance >= 1.0f) {
                                genResistance = 0.99f;
                            }
                            final float matrixDamage = 4.0f * (this.mruStorage.getMRU() / 10000 / (10.0f - genResistance * 10.0f));
                            if (matrixDamage < 1.0f) {
                                continue;
                            }
                            ECUtils.getData(player).modifyOverhaulDamage(ECUtils.getData(player).getOverhaulDamage() + MathHelper.func_76141_d(matrixDamage));
                        }
                    }
                    players.clear();
                }
                else {
                    this.mruStorage.setFlag(false);
                }
            }
            else {
                --this.tickTimer;
            }
        }
        else if (this.func_130014_f_().field_73012_v.nextFloat() < 0.025f) {
            this.func_130014_f_().func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundRegistry.entityMRUCUNoise, SoundCategory.BLOCKS, this.mruStorage.getMRU() / 60000.0f, 0.1f + this.func_130014_f_().field_73012_v.nextFloat(), false);
        }
        this.renderIndex += 0.001f * this.mruStorage.getBalance();
        if (this.renderIndex > 4.0f) {
            this.renderIndex = 0.0f;
        }
        this.firstTick = false;
    }
    
    protected void updateMRUStorage() {
        if (!this.field_70170_p.field_72995_K) {
            this.field_70180_af.func_187227_b((DataParameter)EntityMRUPresence.MRU_STORAGE, (Object)this.mruStorage.writeToNBT(new NBTTagCompound()));
        }
        else {
            this.mruStorage.readFromNBT((NBTTagCompound)this.field_70180_af.func_187225_a((DataParameter)EntityMRUPresence.MRU_STORAGE));
        }
    }
    
    public void func_180430_e(final float par1, final float par2) {
    }
    
    protected void func_70081_e(final int par1) {
    }
    
    public boolean func_70072_I() {
        return false;
    }
    
    public boolean func_70055_a(final Material par1Material) {
        return false;
    }
    
    public void func_191958_b(final float par1, final float par2, final float par3, final float par4) {
    }
    
    public int func_70070_b() {
        return 1;
    }
    
    public float func_70013_c() {
        return 1.0f;
    }
    
    public void func_70108_f(final Entity par1Entity) {
    }
    
    public boolean func_70097_a(final DamageSource par1DamageSource, final float par2) {
        return false;
    }
    
    public boolean func_70094_T() {
        return false;
    }
    
    public float func_70111_Y() {
        return 0.0f;
    }
    
    public void func_70077_a(final EntityLightningBolt par1EntityLightningBolt) {
    }
    
    public ItemStack func_184586_b(final EnumHand hand) {
        return ItemStack.field_190927_a;
    }
    
    public ItemStack func_184582_a(final EntityEquipmentSlot slot) {
        return ItemStack.field_190927_a;
    }
    
    public void func_184201_a(final EntityEquipmentSlot slot, final ItemStack stack) {
    }
    
    public Iterable<ItemStack> func_184193_aE() {
        return (Iterable<ItemStack>)Collections.emptyList();
    }
    
    public EnumHandSide func_184591_cq() {
        return EnumHandSide.RIGHT;
    }
    
    public void func_174812_G() {
        this.func_70106_y();
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    public boolean hasCapability(final Capability<?> capability, final EnumFacing facing) {
        return capability == CapabilityMRUHandler.MRU_HANDLER_ENTITY_CAPABILITY || super.hasCapability((Capability)capability, facing);
    }
    
    public <T> T getCapability(final Capability<T> capability, final EnumFacing facing) {
        return (T)((capability == CapabilityMRUHandler.MRU_HANDLER_ENTITY_CAPABILITY) ? this.mruStorage : super.getCapability((Capability)capability, facing));
    }
    
    static {
        MRU_STORAGE = EntityDataManager.func_187226_a((Class)EntityMRUPresence.class, DataSerializers.field_192734_n);
    }
}
