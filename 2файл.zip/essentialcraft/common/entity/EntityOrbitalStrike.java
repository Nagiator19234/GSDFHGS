package essentialcraft.common.entity;

import net.minecraft.world.*;
import net.minecraft.nbt.*;
import essentialcraft.utils.common.*;
import net.minecraft.util.*;
import DummyCore.Utils.*;
import net.minecraft.block.material.*;
import net.minecraft.init.*;
import net.minecraft.item.crafting.*;
import net.minecraft.item.*;
import net.minecraft.entity.item.*;
import java.util.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityOrbitalStrike extends Entity
{
    public static final DataParameter<String> DATA;
    public EntityLivingBase attacker;
    public double delay;
    public double damage;
    
    public EntityOrbitalStrike(final World w) {
        super(w);
        this.delay = 3.0;
        this.damage = 1.0;
        this.func_70105_a(0.3f, 0.3f);
    }
    
    public EntityOrbitalStrike(final World w, final double x, final double y, final double z) {
        this(w);
        this.func_70080_a(x, y, z, 0.0f, 0.0f);
    }
    
    public EntityOrbitalStrike(final World w, final double x, final double y, final double z, final double damage, final double delay, final EntityLivingBase base) {
        this(w, x, y, z);
        this.damage = damage;
        this.delay = delay;
        this.attacker = base;
    }
    
    protected void func_70088_a() {
        this.func_184212_Q().func_187214_a((DataParameter)EntityOrbitalStrike.DATA, (Object)"||null:null");
    }
    
    protected void func_70037_a(final NBTTagCompound tag) {
        this.delay = tag.func_74769_h("delay");
        this.damage = tag.func_74769_h("damage");
    }
    
    protected void func_70014_b(final NBTTagCompound tag) {
        tag.func_74780_a("delay", this.delay);
        tag.func_74780_a("damage", this.damage);
    }
    
    public void func_70071_h_() {
        this.delay -= 0.05;
        if (!this.func_130014_f_().field_72995_K) {
            this.func_184212_Q().func_187227_b((DataParameter)EntityOrbitalStrike.DATA, (Object)String.valueOf(this.delay));
        }
        if (this.field_70173_aa == 3) {
            ECUtils.playSoundToAllNearby(this.field_70165_t, this.field_70163_u, this.field_70161_v, "essentialcraft:sound.orbital_strike", 1.0f, 1.0f, 16.0, this.field_71093_bK);
        }
        if (this.delay <= 0.0 && !this.field_70128_L) {
            if (!this.func_130014_f_().field_72995_K) {
                final List<EntityLivingBase> allEntities = (List<EntityLivingBase>)this.func_130014_f_().func_72872_a((Class)EntityLivingBase.class, new AxisAlignedBB(this.field_70165_t - 0.5, this.field_70163_u - 0.5, this.field_70161_v - 0.5, this.field_70165_t + 0.5, this.field_70163_u + 0.5, this.field_70161_v + 0.5).func_72314_b(2.0, 2.0, 2.0));
                for (final EntityLivingBase elb : allEntities) {
                    if (elb != null && !elb.field_70128_L) {
                        if (elb == this.attacker) {
                            continue;
                        }
                        elb.func_70015_d(2);
                        elb.func_70097_a(new DamageSource("orbitalStrike") {
                            public Entity func_76364_f() {
                                return (Entity)EntityOrbitalStrike.this.attacker;
                            }
                        }.func_151518_m(), (float)this.damage);
                    }
                }
                this.func_70106_y();
            }
            for (int i = 0; i < 3; ++i) {
                this.func_130014_f_().func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187539_bB, SoundCategory.BLOCKS, 1.0f, this.field_70146_Z.nextFloat() * 2.0f, false);
            }
            for (int i = 0; i < 20; ++i) {
                this.func_130014_f_().func_175688_a(EnumParticleTypes.EXPLOSION_HUGE, this.field_70165_t + MathUtils.randomDouble(this.field_70146_Z), this.field_70163_u + MathUtils.randomDouble(this.field_70146_Z), this.field_70161_v + MathUtils.randomDouble(this.field_70146_Z), 0.0, 0.0, 0.0, new int[0]);
            }
            if (!this.func_130014_f_().field_72995_K && this.func_130014_f_().func_82736_K().func_82766_b("mobGriefing")) {
                for (int dx = -2; dx <= 2; ++dx) {
                    final int x = MathHelper.func_76128_c(this.field_70165_t) + dx;
                    for (int dy = -2; dy <= 2; ++dy) {
                        final int y = MathHelper.func_76128_c(this.field_70163_u) + dy;
                        for (int dz = -2; dz <= 2; ++dz) {
                            final int z = MathHelper.func_76128_c(this.field_70161_v) + dz;
                            final IBlockState b = this.func_130014_f_().func_180495_p(new BlockPos(x, y, z));
                            if (!this.func_130014_f_().func_175623_d(new BlockPos(x, y, z))) {
                                if (b.func_185904_a() == Material.field_151586_h || b.func_185904_a() == Material.field_151588_w || b.func_185904_a() == Material.field_151597_y) {
                                    if (!this.func_130014_f_().field_72995_K) {
                                        this.func_130014_f_().func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                                    }
                                    this.func_130014_f_().func_184134_a((double)(x + 0.5f), (double)(y + 0.5f), (double)(z + 0.5f), SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 0.5f, 2.6f + (this.func_130014_f_().field_73012_v.nextFloat() - this.func_130014_f_().field_73012_v.nextFloat()) * 0.8f, false);
                                    for (int l = 0; l < 8; ++l) {
                                        this.func_130014_f_().func_175688_a(EnumParticleTypes.SMOKE_LARGE, x + Math.random(), y + Math.random(), z + Math.random(), 0.0, 0.0, 0.0, new int[0]);
                                    }
                                }
                                else {
                                    final ItemStack is = new ItemStack(b.func_177230_c(), 1, b.func_177230_c().func_176201_c(b));
                                    final ItemStack result = FurnaceRecipes.func_77602_a().func_151395_a(is);
                                    if (!result.func_190926_b()) {
                                        if (result.func_77973_b() instanceof ItemBlock) {
                                            final Block setTo = ((ItemBlock)result.func_77973_b()).func_179223_d();
                                            if (setTo != null && !this.func_130014_f_().field_72995_K) {
                                                this.func_130014_f_().func_180501_a(new BlockPos(x, y, z), setTo.func_176203_a(result.func_77952_i()), 3);
                                            }
                                        }
                                        else {
                                            if (!this.func_130014_f_().field_72995_K) {
                                                this.func_130014_f_().func_180501_a(new BlockPos(x, y, z), Blocks.field_150350_a.func_176223_P(), 3);
                                            }
                                            final EntityItem itm = new EntityItem(this.func_130014_f_(), (double)x, (double)y, (double)z, result.func_77946_l());
                                            if (!this.func_130014_f_().field_72995_K) {
                                                this.func_130014_f_().func_72838_d((Entity)itm);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.func_130014_f_().field_72995_K) {
            try {
                this.delay = Double.parseDouble((String)this.func_184212_Q().func_187225_a((DataParameter)EntityOrbitalStrike.DATA));
            }
            catch (Exception ex) {}
        }
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    static {
        DATA = EntityDataManager.func_187226_a((Class)EntityOrbitalStrike.class, DataSerializers.field_187194_d);
    }
}
