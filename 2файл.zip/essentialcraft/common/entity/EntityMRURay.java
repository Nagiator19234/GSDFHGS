package essentialcraft.common.entity;

import net.minecraft.world.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import essentialcraft.utils.common.*;
import net.minecraft.block.state.*;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityMRURay extends Entity
{
    public static final DataParameter<String> DATA;
    public float balance;
    public float damage;
    public EntityLivingBase shootingEntity;
    public double pX;
    public double pY;
    public double pZ;
    List<EntityLivingBase> hitEntities;
    
    public EntityMRURay(final World w) {
        super(w);
        this.hitEntities = new ArrayList<EntityLivingBase>();
    }
    
    public void func_70030_z() {
        if (this.field_70173_aa >= 60) {
            this.func_70106_y();
        }
        if (!this.func_130014_f_().field_72995_K) {
            this.func_184212_Q().func_187227_b((DataParameter)EntityMRURay.DATA, (Object)("||x:" + this.pX + "||y:" + this.pY + "||z:" + this.pZ + "||b:" + (double)this.balance));
        }
        if (this.func_130014_f_().field_72995_K) {
            final String dataStr = (String)this.func_184212_Q().func_187225_a((DataParameter)EntityMRURay.DATA);
            if (dataStr != null && !dataStr.isEmpty()) {
                final DummyData[] posData = DataStorage.parseData(dataStr);
                this.pX = Double.parseDouble(posData[0].fieldValue);
                this.pY = Double.parseDouble(posData[1].fieldValue);
                this.pZ = Double.parseDouble(posData[2].fieldValue);
                this.balance = (float)Double.parseDouble(posData[3].fieldValue);
            }
        }
    }
    
    public EntityMRURay(final World w, final EntityLivingBase base) {
        super(w);
        this.hitEntities = new ArrayList<EntityLivingBase>();
        this.field_70177_z = base.field_70759_as;
        this.field_70125_A = base.field_70125_A;
        this.shootingEntity = base;
        this.pX = this.shootingEntity.field_70165_t;
        this.pY = this.shootingEntity.field_70163_u + this.shootingEntity.func_70047_e();
        this.pZ = this.shootingEntity.field_70161_v;
        this.field_70165_t = base.field_70165_t;
        this.field_70163_u = base.field_70163_u + this.shootingEntity.func_70047_e();
        this.field_70161_v = base.field_70161_v;
    }
    
    public EntityMRURay(final World w, final EntityLivingBase base, final float damage, final float offset, final float balance) {
        super(w);
        this.hitEntities = new ArrayList<EntityLivingBase>();
        this.field_70165_t = base.field_70165_t;
        this.field_70163_u = base.field_70163_u + base.func_70047_e();
        this.field_70161_v = base.field_70161_v;
        final float rY = base.field_70177_z;
        final float rP = base.field_70125_A;
        if (!w.field_72995_K) {
            base.field_70177_z = (float)(base.field_70759_as + MathUtils.randomDouble(w.field_73012_v) * offset);
            base.field_70125_A += (float)(MathUtils.randomDouble(w.field_73012_v) * offset);
        }
        this.damage = damage;
        this.balance = balance;
        this.shootingEntity = base;
        this.pX = this.shootingEntity.field_70165_t;
        this.pY = this.shootingEntity.field_70163_u + this.shootingEntity.func_70047_e();
        this.pZ = this.shootingEntity.field_70161_v;
        if (!this.func_130014_f_().field_72995_K) {
            this.shoot(rY, rP);
        }
    }
    
    public DamageSource causeMRUDamage(final EntityLivingBase attacker, final EntityLivingBase attacked) {
        if (attacked instanceof EntityPlayer) {
            final EntityPlayer player = (EntityPlayer)attacked;
            if (!player.func_130014_f_().field_72995_K && this.func_130014_f_().func_73046_m().func_71219_W()) {
                if (attacker instanceof EntityPlayer) {
                    final EntityPlayer attackerPlayer = (EntityPlayer)attacker;
                    if ((attackerPlayer.func_96124_cp() == null || player == null || !player.func_96124_cp().func_142054_a(attackerPlayer.func_96124_cp())) && !this.func_130014_f_().func_82736_K().func_82766_b("essentialcraft:weaponMatrixDamage")) {
                        ECUtils.getData(player).modifyOverhaulDamage(ECUtils.getData(player).getOverhaulDamage() + MathHelper.func_76141_d(this.damage * 100.0f));
                    }
                }
                else if (!this.func_130014_f_().func_82736_K().func_82766_b("essentialcraft:weaponMatrixDamage")) {
                    ECUtils.getData(player).modifyOverhaulDamage(ECUtils.getData(player).getOverhaulDamage() + MathHelper.func_76141_d(this.damage * 100.0f));
                }
            }
            if (this.balance == 4.0f) {
                ShadeUtils.attackPlayerWithShade(player, attacker, ItemStack.field_190927_a);
            }
        }
        return new DamageSource("mru") {
            public Entity func_76364_f() {
                return (Entity)attacker;
            }
        }.func_76349_b();
    }
    
    public void shoot(final float f, final float f1) {
        final Vec3d vec = this.shootingEntity.func_70040_Z();
        for (int i = 0; i < 128; ++i) {
            final float vX = (float)(vec.field_72450_a * i / 2.0 + this.field_70165_t);
            final float vY = (float)(vec.field_72448_b * i / 2.0 + this.field_70163_u);
            final float vZ = (float)(vec.field_72449_c * i / 2.0 + this.field_70161_v);
            final int bVX = MathHelper.func_76141_d(vX);
            final int bVY = MathHelper.func_76141_d(vY);
            final int bVZ = MathHelper.func_76141_d(vZ);
            final double d = 0.5;
            final AxisAlignedBB aabb = new AxisAlignedBB(vX - d, vY - d, vZ - d, vX + d, vY + d, vZ + d);
            final List<EntityLivingBase> entities = (List<EntityLivingBase>)this.func_130014_f_().func_72872_a((Class)EntityLivingBase.class, aabb);
            for (int j = 0; j < entities.size(); ++j) {
                final EntityLivingBase base = entities.get(j);
                if (base != this.shootingEntity && !base.field_70128_L && !this.hitEntities.contains(base)) {
                    base.func_70097_a(this.causeMRUDamage(this.shootingEntity, base), this.damage);
                    this.hitEntities.add(base);
                }
            }
            final IBlockState b = this.func_130014_f_().func_180495_p(new BlockPos(bVX, bVY, bVZ));
            if (b.func_185915_l() || i == 127) {
                this.func_70080_a((double)vX, (double)vY, (double)vZ, 0.0f, 0.0f);
                break;
            }
        }
        this.shootingEntity.field_70177_z = f;
        this.shootingEntity.field_70125_A = f1;
    }
    
    protected void func_70088_a() {
        this.func_184212_Q().func_187214_a((DataParameter)EntityMRURay.DATA, (Object)"");
    }
    
    protected void func_70037_a(final NBTTagCompound tag) {
        this.pX = tag.func_74769_h("pX");
        this.pY = tag.func_74769_h("pY");
        this.pZ = tag.func_74769_h("pZ");
        this.balance = tag.func_74760_g("balance");
    }
    
    protected void func_70014_b(final NBTTagCompound tag) {
        tag.func_74780_a("pX", this.pX);
        tag.func_74780_a("pY", this.pY);
        tag.func_74780_a("pZ", this.pZ);
        tag.func_74776_a("balance", this.balance);
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    static {
        DATA = EntityDataManager.func_187226_a((Class)EntityMRURay.class, DataSerializers.field_187194_d);
    }
}
