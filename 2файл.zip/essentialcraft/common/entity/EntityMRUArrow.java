package essentialcraft.common.entity;

import net.minecraft.entity.projectile.*;
import net.minecraft.world.*;
import essentialcraft.common.mod.*;
import DummyCore.Utils.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntityMRUArrow extends EntityArrow
{
    public EntityMRUArrow(final World world) {
        super(world);
    }
    
    public EntityMRUArrow(final World world, final EntityLivingBase shooter, final float f) {
        super(world, shooter);
        this.field_70251_a = EntityArrow.PickupStatus.DISALLOWED;
    }
    
    public void func_70071_h_() {
        super.func_70071_h_();
        if (this.field_70173_aa > 60) {
            this.func_70106_y();
        }
        for (int i = 0; i < 2; ++i) {
            EssentialCraftCore.proxy.spawnParticle("cSpellFX", (float)this.field_70165_t + MathUtils.randomFloat(this.field_70146_Z) / 10.0f, (float)this.field_70163_u + MathUtils.randomFloat(this.field_70146_Z) / 10.0f, (float)this.field_70161_v + MathUtils.randomFloat(this.field_70146_Z) / 10.0f, this.field_70159_w * 10.0, this.field_70181_x * 10.0, this.field_70179_y * 10.0);
        }
    }
    
    protected ItemStack func_184550_j() {
        return ItemStack.field_190927_a;
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
