package essentialcraft.common.entity;

import net.minecraft.entity.monster.*;
import net.minecraft.entity.player.*;
import java.util.*;
import com.google.common.base.*;
import net.minecraft.world.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import net.minecraft.util.*;
import net.minecraft.nbt.*;
import net.minecraft.entity.ai.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;
import net.minecraft.network.datasync.*;

public class EntityPlayerClone extends EntityZombie
{
    public EntityPlayer playerToAttack;
    protected UUID clonedPlayer;
    private boolean firstTick;
    public static final DataParameter<Optional<UUID>> CLONED;
    
    public EntityPlayerClone(final World w) {
        super(w);
        this.playerToAttack = null;
        this.firstTick = true;
        this.field_82174_bp[0] = 0.0f;
        this.field_82174_bp[1] = 0.0f;
        this.field_184655_bs[0] = 0.0f;
        this.field_184655_bs[1] = 0.0f;
        this.field_184655_bs[2] = 0.0f;
        this.field_184655_bs[3] = 0.0f;
    }
    
    public Entity findPlayerToAttack() {
        return (Entity)(this.playerToAttack = this.func_130014_f_().func_184142_a((Entity)this, 16.0, 16.0));
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(2.0);
    }
    
    protected void func_82160_b(final boolean wasRecentlyHit, final int lootingModifier) {
    }
    
    public void func_70071_h_() {
        if (!this.func_70644_a(MobEffects.field_76424_c)) {
            this.func_70690_d(new PotionEffect(MobEffects.field_76424_c, 200, 3, true, true));
        }
        if (this.field_70725_aQ > 0) {
            this.func_70106_y();
        }
        super.func_70071_h_();
        if (this.field_70173_aa % 200 == 0) {
            this.func_70106_y();
        }
        this.firstTick = false;
    }
    
    protected SoundEvent func_184639_G() {
        return null;
    }
    
    protected SoundEvent func_184601_bQ(final DamageSource s) {
        return null;
    }
    
    protected SoundEvent func_184615_bR() {
        return null;
    }
    
    protected ResourceLocation func_184647_J() {
        return null;
    }
    
    public UUID getClonedPlayer() {
        return (UUID)((Optional)this.field_70180_af.func_187225_a((DataParameter)EntityPlayerClone.CLONED)).orNull();
    }
    
    public void setClonedPlayer(final UUID clonedPlayer) {
        if (!this.field_70128_L) {
            this.field_70180_af.func_187227_b((DataParameter)EntityPlayerClone.CLONED, (Object)Optional.fromNullable((Object)clonedPlayer));
        }
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.field_70180_af.func_187214_a((DataParameter)EntityPlayerClone.CLONED, (Object)Optional.absent());
    }
    
    public void func_70014_b(final NBTTagCompound compound) {
        super.func_70014_b(compound);
        if (this.clonedPlayer != null) {
            compound.func_186854_a("cloned", this.clonedPlayer);
        }
        else {
            compound.func_82580_o("cloned");
        }
    }
    
    public void func_70037_a(final NBTTagCompound compound) {
        super.func_70037_a(compound);
        this.clonedPlayer = compound.func_186857_a("cloned");
    }
    
    public void updateClonedPlayer() {
        if (!this.func_130014_f_().field_72995_K) {
            this.setClonedPlayer(this.getClonedPlayer());
        }
        if (this.func_130014_f_().field_72995_K && !this.firstTick) {
            this.clonedPlayer = this.getClonedPlayer();
        }
    }
    
    public void func_70636_d() {
        super.func_70636_d();
        this.func_70066_B();
    }
    
    protected void func_184651_r() {
        this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIZombieAttack((EntityZombie)this, 1.0, false));
        this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIMoveTowardsRestriction((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityPlayer.class, 8.0f));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, (Class)EntityPlayer.class, true));
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
    
    static {
        CLONED = EntityDataManager.func_187226_a((Class)EntityPlayerClone.class, DataSerializers.field_187203_m);
    }
}
