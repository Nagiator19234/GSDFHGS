package essentialcraft.common.entity;

import net.minecraft.entity.projectile.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraftforge.common.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import essentialcraft.common.item.*;
import net.minecraftforge.fml.common.registry.*;
import net.minecraft.entity.*;

public class EntityArmorDestroyer extends EntityThrowable
{
    public EntityArmorDestroyer(final World w) {
        super(w);
    }
    
    public EntityArmorDestroyer(final World world, final EntityLivingBase thower) {
        super(world, thower);
    }
    
    protected void func_70184_a(final RayTraceResult result) {
        if (result.field_72308_g != null) {
            if (result.field_72308_g == this.func_85052_h() || !(result.field_72308_g instanceof EntityPlayer)) {
                return;
            }
            final EntityPlayer p = (EntityPlayer)result.field_72308_g;
            if (p != null) {
                final ItemStack c = p.func_184614_ca();
                final ItemStack c2 = p.func_184592_cb();
                if (!c.func_190926_b()) {
                    c.func_77972_a(5, (EntityLivingBase)p);
                }
                if (!c2.func_190926_b()) {
                    c2.func_77972_a(5, (EntityLivingBase)p);
                }
                for (int j = 0; j < 4; ++j) {
                    final ItemStack a = (ItemStack)p.field_71071_by.field_70460_b.get(j);
                    if (!a.func_190926_b()) {
                        if (a.func_77973_b() instanceof ISpecialArmor) {
                            ((ISpecialArmor)a.func_77973_b()).damageArmor((EntityLivingBase)p, a, DamageSource.field_82728_o, 5, j);
                        }
                        else {
                            a.func_77972_a(5, (EntityLivingBase)p);
                        }
                    }
                }
            }
        }
        if (!this.func_130014_f_().field_72995_K) {
            this.func_70106_y();
        }
        this.func_130014_f_().func_184134_a(this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187635_cQ, SoundCategory.PLAYERS, 0.3f, 2.0f, false);
    }
    
    public ItemStack getPickedResult(final RayTraceResult target) {
        return new ItemStack(ItemsCore.entityEgg, 1, EntitiesCore.REGISTERED_ENTITIES.indexOf(ForgeRegistries.ENTITIES.getValue(EntityList.func_191306_a((Class)this.getClass()))));
    }
}
