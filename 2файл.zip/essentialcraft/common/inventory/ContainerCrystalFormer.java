package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerCrystalFormer extends ContainerInventory
{
    public ContainerCrystalFormer(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 26, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 108, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 126, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 144, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 108, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 144, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 126, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 82, 5));
        this.setupPlayerInventory();
    }
}
