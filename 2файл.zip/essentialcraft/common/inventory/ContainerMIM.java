package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;
import net.minecraft.util.math.*;

public class ContainerMIM extends ContainerInventory
{
    public ContainerMIM(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.pInvOffsetX = 10;
        this.pInvOffsetZ = 90;
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 5, 147));
        final Class<TileMIMInventoryStorage> isc = TileMIMInventoryStorage.class;
        final Class<TileMIMScreen> msc = TileMIMScreen.class;
        final Class<TileMIMCraftingManager> cmc = TileMIMCraftingManager.class;
        final Class<TileMIMExportNode> enc = TileMIMExportNode.class;
        final Class<TileMIMImportNode> inc = TileMIMImportNode.class;
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 1, 28, 20, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 2, 46, 20, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 3, 64, 20, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 4, 28, 38, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 5, 46, 38, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 6, 64, 38, isc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 7, 91, 20, msc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 8, 109, 20, msc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 9, 91, 38, msc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 10, 109, 38, msc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 11, 136, 20, cmc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 12, 154, 20, cmc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 13, 172, 20, cmc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 14, 136, 38, cmc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 15, 154, 38, cmc));
        this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 16, 172, 38, cmc));
        for (int i = 0; i < 18; ++i) {
            this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 17 + i, 28 + i % 9 * 18, 74 + i / 9 * 18, inc));
        }
        for (int i = 0; i < 18; ++i) {
            this.func_75146_a((Slot)new SlotBGTEClassDepenant(this.inv, 35 + i, 28 + i % 9 * 18, 128 + i / 9 * 18, enc));
        }
        this.setupPlayerInventory();
    }
    
    public static class SlotBGTEClassDepenant extends Slot
    {
        Class<? extends TileEntity> dependant;
        
        public SlotBGTEClassDepenant(final IInventory inv, final int id, final int x, final int y, final Class<? extends TileEntity> c) {
            super(inv, id, x, y);
            this.dependant = c;
        }
        
        public boolean func_75214_a(final ItemStack stk) {
            if (!(stk.func_77973_b() instanceof ItemBoundGem) || stk.func_77978_p() == null || !stk.func_77978_p().func_74764_b("pos")) {
                return false;
            }
            final TileEntity tile = (TileEntity)this.field_75224_c;
            if (stk.func_77978_p().func_74762_e("dim") != tile.func_145831_w().field_73011_w.getDimension()) {
                return false;
            }
            final int[] coords = ItemBoundGem.getCoords(stk);
            final TileEntity t = tile.func_145831_w().func_175625_s(new BlockPos(coords[0], coords[1], coords[2]));
            return t != null && this.dependant.isAssignableFrom(t.getClass());
        }
    }
}
