package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMIMInventoryStorage extends ContainerInventory
{
    private int chestInventoryRows;
    private int chestInventoryColumns;
    
    public ContainerMIMInventoryStorage(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.pInvOffsetZ = 56;
        this.chestInventoryRows = 6;
        this.chestInventoryColumns = 9;
        for (int chestRowIndex = 0; chestRowIndex < this.chestInventoryRows; ++chestRowIndex) {
            for (int chestColumnIndex = 0; chestColumnIndex < this.chestInventoryColumns; ++chestColumnIndex) {
                this.func_75146_a(new Slot(this.inv, chestColumnIndex + chestRowIndex * this.chestInventoryColumns, 8 + chestColumnIndex * 18, 18 + chestRowIndex * 18));
            }
        }
        this.setupPlayerInventory();
    }
}
