package essentialcraft.common.inventory;

import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

public class ContainerPlayerPentacle extends Container
{
    public boolean func_75145_c(final EntityPlayer playerIn) {
        return true;
    }
}
