package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerCrafter extends ContainerInventory
{
    public ContainerCrafter(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        for (int o = 0; o < 9; ++o) {
            this.func_75146_a((Slot)new SlotGeneric(this.inv, o, 30 + o % 3 * 18, 17 + o / 3 * 18));
        }
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 124, 35));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 10, 94, 17));
        this.setupPlayerInventory();
    }
}
