package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMagicalChest extends ContainerInventory
{
    private int chestInventoryRows;
    private int chestInventoryColumns;
    
    public ContainerMagicalChest(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        if (this.tile.func_145832_p() == 0) {
            this.pInvOffsetX = 0;
            this.pInvOffsetZ = 56;
            this.chestInventoryRows = 6;
            this.chestInventoryColumns = 9;
        }
        else if (this.tile.func_145832_p() == 1) {
            this.pInvOffsetX = 40;
            this.pInvOffsetZ = 90;
            this.chestInventoryRows = 9;
            this.chestInventoryColumns = 13;
        }
        for (int chestRowIndex = 0; chestRowIndex < this.chestInventoryRows; ++chestRowIndex) {
            for (int chestColumnIndex = 0; chestColumnIndex < this.chestInventoryColumns; ++chestColumnIndex) {
                if (this.tile.func_145832_p() == 0) {
                    this.func_75146_a(new Slot(this.inv, chestColumnIndex + chestRowIndex * this.chestInventoryColumns, 8 + chestColumnIndex * 18, 18 + chestRowIndex * 18));
                }
                else if (this.tile.func_145832_p() == 1) {
                    this.func_75146_a(new Slot(this.inv, chestColumnIndex + chestRowIndex * this.chestInventoryColumns, 12 + chestColumnIndex * 18, 8 + chestRowIndex * 18));
                }
            }
        }
        this.setupPlayerInventory();
    }
}
