package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMonsterHarvester extends ContainerInventory
{
    public ContainerMonsterHarvester(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 126, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 108, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 126, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 144, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 117, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 135, 41));
        this.setupPlayerInventory();
    }
}
