package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerPotionSpreader extends ContainerInventory
{
    public ContainerPotionSpreader(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 155, 23));
        for (int j = 0; j < 4; ++j) {
            for (int k = 0; k < 2; ++k) {
                this.func_75146_a((Slot)new SlotGeneric(this.inv, j + k * 4 + 1, 26 + j * 18, 23 + k * 18));
            }
        }
        this.setupPlayerInventory();
    }
}
