package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMonsterHolder extends ContainerInventory
{
    public ContainerMonsterHolder(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 26, 5));
        this.setupPlayerInventory();
    }
}
