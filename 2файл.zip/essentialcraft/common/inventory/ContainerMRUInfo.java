package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;

public class ContainerMRUInfo extends ContainerGeneric
{
    public ContainerMRUInfo(final InventoryPlayer invPlayer) {
        super(invPlayer);
    }
    
    public ItemStack func_82846_b(final EntityPlayer par1EntityPlayer, final int par2) {
        return ItemStack.field_190927_a;
    }
}
