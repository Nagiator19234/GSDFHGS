package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMatrixAbsorber extends ContainerInventory
{
    public ContainerMatrixAbsorber(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a(new Slot(this.inv, 0, 26, 5));
        this.setupPlayerInventory();
    }
}
