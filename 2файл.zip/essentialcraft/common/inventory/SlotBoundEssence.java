package essentialcraft.common.inventory;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;

public class SlotBoundEssence extends Slot
{
    public SlotBoundEssence(final IInventory inventory, final int index, final int x, final int y) {
        super(inventory, index, x, y);
        this.setBackgroundName("essentialcraft:items/elemental/drop_air");
    }
    
    public boolean func_75214_a(final ItemStack stack) {
        return stack.func_77973_b() instanceof ItemBoundGem;
    }
}
