package essentialcraft.common.inventory;

import net.minecraft.inventory.*;
import net.minecraft.item.*;
import java.util.*;
import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.nbt.*;
import net.minecraft.util.text.*;

public class InventoryCraftingFrame implements IInventory
{
    public ItemStack[] inventory;
    public UUID randomUUID;
    public ItemStack filterStack;
    
    public InventoryCraftingFrame(final ItemStack filter) {
        this.inventory = new ItemStack[10];
        this.filterStack = ItemStack.field_190927_a;
        Arrays.fill(this.inventory, ItemStack.field_190927_a);
        if (!filter.func_77942_o()) {
            final NBTTagCompound theTag = MiscUtils.getStackTag(filter);
            this.randomUUID = UUID.randomUUID();
            theTag.func_74778_a("uniqueID", this.randomUUID.toString());
        }
        this.readFromNBTTagCompound(MiscUtils.getStackTag(filter));
        this.filterStack = filter;
    }
    
    public int func_70302_i_() {
        return this.inventory.length;
    }
    
    public ItemStack func_70301_a(final int slot) {
        return this.inventory[slot];
    }
    
    public ItemStack func_70298_a(final int slot, final int amount) {
        return ItemStack.field_190927_a;
    }
    
    public void func_70299_a(final int slot, final ItemStack stack) {
        this.inventory[slot] = stack;
    }
    
    public String func_70005_c_() {
        return "essentialcraft.inventory.craftingFrame";
    }
    
    public boolean func_145818_k_() {
        return false;
    }
    
    public int func_70297_j_() {
        return 64;
    }
    
    public void func_70296_d() {
    }
    
    public boolean func_70300_a(final EntityPlayer player) {
        return true;
    }
    
    public void func_174889_b(final EntityPlayer p) {
    }
    
    public void func_174886_c(final EntityPlayer p) {
    }
    
    public boolean func_94041_b(final int slot, final ItemStack stack) {
        return true;
    }
    
    public void readFromNBTTagCompound(final NBTTagCompound tag) {
        final NBTTagCompound inventoryTag = (NBTTagCompound)tag.func_74781_a("inventory");
        if (inventoryTag == null) {
            return;
        }
        if (this.randomUUID == null) {
            this.randomUUID = UUID.fromString(tag.func_74779_i("uniqueID"));
            if (this.randomUUID == null) {
                this.randomUUID = UUID.randomUUID();
            }
        }
        final NBTTagList actualInventory = inventoryTag.func_150295_c("items", 10);
        for (int i = 0; i < actualInventory.func_74745_c() && i < this.inventory.length; ++i) {
            final NBTTagCompound indexTag = actualInventory.func_150305_b(i);
            final int index = indexTag.func_74762_e("index");
            try {
                this.inventory[index] = new ItemStack(indexTag);
            }
            catch (Exception e) {
                this.inventory[index] = ItemStack.field_190927_a;
            }
        }
    }
    
    public NBTTagCompound writeToNBT(final NBTTagCompound tag) {
        final NBTTagList items = new NBTTagList();
        for (int i = 0; i < this.inventory.length; ++i) {
            if (!this.inventory[i].func_190926_b()) {
                final NBTTagCompound indexTag = new NBTTagCompound();
                items.func_74742_a((NBTBase)indexTag);
                indexTag.func_74768_a("index", i);
                this.inventory[i].func_77955_b(indexTag);
            }
        }
        final NBTTagCompound inventoryTag = new NBTTagCompound();
        inventoryTag.func_74782_a("items", (NBTBase)items);
        tag.func_74782_a("inventory", (NBTBase)inventoryTag);
        if (this.randomUUID == null) {
            this.randomUUID = UUID.randomUUID();
        }
        tag.func_74778_a("uniqueID", this.randomUUID.toString());
        return tag;
    }
    
    public ITextComponent func_145748_c_() {
        return null;
    }
    
    public ItemStack func_70304_b(final int index) {
        final ItemStack returnStack = this.func_70301_a(index);
        this.func_70299_a(index, ItemStack.field_190927_a);
        return returnStack;
    }
    
    public int func_174887_a_(final int id) {
        return 0;
    }
    
    public void func_174885_b(final int id, final int value) {
    }
    
    public int func_174890_g() {
        return 0;
    }
    
    public void func_174888_l() {
        for (int i = 0; i < this.func_70302_i_(); ++i) {
            this.func_70299_a(i, ItemStack.field_190927_a);
        }
    }
    
    public boolean func_191420_l() {
        boolean ret = true;
        for (final ItemStack stk : this.inventory) {
            ret &= stk.func_190926_b();
        }
        return ret;
    }
}
