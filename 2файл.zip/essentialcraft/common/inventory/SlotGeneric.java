package essentialcraft.common.inventory;

import net.minecraft.inventory.*;
import net.minecraft.util.*;
import net.minecraft.item.*;

public class SlotGeneric extends Slot
{
    public int slot;
    
    public SlotGeneric(final IInventory inv, final int slot, final int xPos, final int yPos) {
        super(inv, slot, xPos, yPos);
        this.slot = slot;
    }
    
    public SlotGeneric(final IInventory inv, final int slot, final int xPos, final int yPos, final ResourceLocation background) {
        super(inv, slot, xPos, yPos);
        this.slot = slot;
        this.setBackgroundName(background.toString());
    }
    
    public SlotGeneric(final IInventory inv, final int slot, final int xPos, final int yPos, final String background) {
        super(inv, slot, xPos, yPos);
        this.slot = slot;
        this.setBackgroundName(background);
    }
    
    public boolean func_75214_a(final ItemStack stack) {
        return this.field_75224_c.func_94041_b(this.slot, stack);
    }
}
