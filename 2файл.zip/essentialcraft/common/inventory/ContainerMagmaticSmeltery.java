package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerMagmaticSmeltery extends ContainerInventory
{
    public ContainerMagmaticSmeltery(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 108, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 44, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 62, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 126, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 126, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 155, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 155, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 140, 41));
        this.setupPlayerInventory();
    }
}
