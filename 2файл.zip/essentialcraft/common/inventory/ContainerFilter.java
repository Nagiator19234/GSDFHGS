package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.inventory.*;

public class ContainerFilter extends ContainerInventory
{
    public InventoryMagicFilter inventory;
    
    public ContainerFilter(final EntityPlayer p, final InventoryMagicFilter inv) {
        super(p, (IInventory)inv);
        this.inventory = inv;
    }
    
    public boolean func_75145_c(final EntityPlayer p) {
        return true;
    }
    
    public void saveToNBT(final ItemStack itemStack) {
        if (!itemStack.func_77942_o()) {
            itemStack.func_77982_d(new NBTTagCompound());
        }
        this.inventory.writeToNBT(itemStack.func_77978_p());
    }
    
    public void setupSlots() {
        for (int o = 0; o < 9; ++o) {
            this.func_75146_a(new Slot(this.inv, o, 62 + o % 3 * 18, 17 + o / 3 * 18));
        }
        this.setupPlayerInventory();
    }
}
