package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;

public class ContainerCrystalExtractor extends ContainerInventory
{
    public ContainerCrystalExtractor(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotBoundEssence(this.inv, 0, 108, 5));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 26, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 44, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 62, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 80, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 98, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 116, 23));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 26, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 8, 44, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 62, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 10, 80, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 11, 98, 41));
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 12, 116, 41));
        this.setupPlayerInventory();
    }
}
