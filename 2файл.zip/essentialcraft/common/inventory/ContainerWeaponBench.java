package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import essentialcraft.common.tile.*;
import net.minecraft.inventory.*;

public class ContainerWeaponBench extends ContainerInventory
{
    public ContainerWeaponBench(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        final TileWeaponMaker maker = (TileWeaponMaker)this.tile;
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 0, 152, 37));
        if (maker.index == 0) {
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 40, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 60, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 20, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 60, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 40, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 60, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 80, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 8, 80, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 80, 57));
            this.sizeInventory = 10;
        }
        if (maker.index == 1) {
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 40, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 60, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 20, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 40, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 20, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 60, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 80, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 8, 60, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 80, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 10, 20, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 11, 40, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 12, 80, 57));
            this.sizeInventory = 13;
        }
        if (maker.index == 2) {
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 60, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 40, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 20, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 60, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 40, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 80, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 40, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 8, 80, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 100, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 10, 100, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 11, 60, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 12, 80, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 13, 100, 57));
            this.sizeInventory = 14;
        }
        if (maker.index == 3) {
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 1, 80, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 2, 40, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 3, 20, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 4, 20, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 5, 20, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 6, 40, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 7, 60, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 8, 80, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 9, 100, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 10, 120, 17));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 11, 40, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 12, 120, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 13, 60, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 14, 100, 37));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 15, 60, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 16, 80, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 17, 100, 57));
            this.func_75146_a((Slot)new SlotGeneric(this.inv, 18, 120, 57));
            this.sizeInventory = 19;
        }
        this.setupPlayerInventory();
    }
}
