package essentialcraft.common.inventory;

import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.inventory.*;
import essentialcraft.utils.common.*;
import DummyCore.Utils.*;
import net.minecraft.item.crafting.*;

public class ContainerCraftingFrame extends ContainerInventory
{
    public InventoryCraftingFrame inventory;
    
    public ContainerCraftingFrame(final EntityPlayer p, final InventoryCraftingFrame inv) {
        super(p, (IInventory)inv);
        this.inventory = inv;
    }
    
    public boolean func_75145_c(final EntityPlayer p) {
        return true;
    }
    
    public void saveToNBT(final ItemStack itemStack) {
        if (!itemStack.func_77942_o()) {
            itemStack.func_77982_d(new NBTTagCompound());
        }
        this.inventory.writeToNBT(itemStack.func_77978_p());
    }
    
    public ItemStack func_184996_a(final int slotID, final int buttonPressed, final ClickType flag, final EntityPlayer player) {
        Slot tmpSlot;
        if (slotID >= 0 && slotID < this.field_75151_b.size()) {
            tmpSlot = this.field_75151_b.get(slotID);
        }
        else {
            tmpSlot = null;
        }
        if (tmpSlot != null && tmpSlot.func_75217_a((IInventory)player.field_71071_by, player.field_71071_by.field_70461_c)) {
            return tmpSlot.func_75211_c();
        }
        return super.func_184996_a(slotID, buttonPressed, flag, player);
    }
    
    public ItemStack func_82846_b(final EntityPlayer player, final int slot) {
        return ItemStack.field_190927_a;
    }
    
    public void setupSlots() {
        for (int o = 0; o < 9; ++o) {
            this.func_75146_a((Slot)new SlotFake(this.player, this, this.inv, o, 30 + o / 3 * 18, 17 + o % 3 * 18));
        }
        this.func_75146_a((Slot)new SlotFake(this.player, this, this.inv, 9, 124, 35));
        this.setupPlayerInventory();
    }
    
    public static class SlotFake extends Slot
    {
        ContainerCraftingFrame parent;
        EntityPlayer player;
        
        public SlotFake(final EntityPlayer p, final ContainerCraftingFrame c, final IInventory inv, final int id, final int x, final int y) {
            super(inv, id, x, y);
            this.parent = c;
            this.player = p;
        }
        
        public ItemStack func_190901_a(final EntityPlayer pickuper, final ItemStack stk) {
            this.field_75224_c.func_70299_a(this.field_75222_d, ItemStack.field_190927_a);
            this.func_75218_e();
            return stk;
        }
        
        public boolean func_82869_a(final EntityPlayer player) {
            InventoryCrafting crafting = new InventoryCrafting((Container)this.parent, 3, 3);
            for (int i = 0; i < 9; ++i) {
                crafting.func_70299_a(i, this.parent.inventory.func_70301_a(i % 3 * 3 + i / 3));
            }
            ItemStack result = CraftingManager.func_82787_a(crafting, player.func_130014_f_());
            this.parent.inventory.func_70299_a(9, result.func_190926_b() ? ItemStack.field_190927_a : result.func_77946_l());
            crafting = null;
            if (this.field_75222_d == 9 && result.func_190926_b()) {
                this.field_75224_c.func_70299_a(this.field_75222_d, ItemStack.field_190927_a);
            }
            if (this.field_75222_d != 9) {
                this.field_75224_c.func_70299_a(this.field_75222_d, ItemStack.field_190927_a);
                crafting = new InventoryCrafting((Container)this.parent, 3, 3);
                for (int j = 0; j < 9; ++j) {
                    crafting.func_70299_a(j, this.parent.inventory.func_70301_a(j));
                }
                result = CraftingManager.func_82787_a(crafting, player.func_130014_f_());
                this.parent.inventory.func_70299_a(9, result.func_190926_b() ? ItemStack.field_190927_a : result.func_77946_l());
                crafting = null;
            }
            this.func_75218_e();
            return false;
        }
        
        public boolean func_75214_a(final ItemStack stk) {
            if (!stk.func_190926_b()) {
                if (this.field_75222_d != 9) {
                    final ItemStack setTo = stk.func_77946_l();
                    setTo.func_190920_e(1);
                    this.field_75224_c.func_70299_a(this.field_75222_d, setTo);
                    InventoryCrafting crafting = new InventoryCrafting((Container)this.parent, 3, 3);
                    for (int i = 0; i < 9; ++i) {
                        crafting.func_70299_a(i, this.parent.inventory.func_70301_a(i % 3 * 3 + i / 3));
                    }
                    final ItemStack result = CraftingManager.func_82787_a(crafting, this.player.func_130014_f_());
                    this.parent.inventory.func_70299_a(9, result.func_190926_b() ? ItemStack.field_190927_a : result.func_77946_l());
                    crafting = null;
                    this.func_75218_e();
                    this.parent.field_75151_b.get(9).func_75218_e();
                }
                else {
                    IRecipe settedRec = null;
                    if (!this.func_75216_d()) {
                        IRecipe rec = ECUtils.findRecipeByIS(stk, 0);
                        if (rec == null && !this.parent.player.func_184614_ca().func_77978_p().func_74767_n("ignoreOreDict")) {
                            rec = ECUtils.findRecipeByIS(stk, 2);
                        }
                        if ((settedRec = rec) != null) {
                            for (int i = 0; i < 9; ++i) {
                                this.parent.inventory.func_70299_a(i, ItemStack.field_190927_a);
                                final IRecipe srec = rec;
                                if (((Ingredient)srec.func_192400_c().get(i)).func_193365_a().length > 0) {
                                    final UnformedItemStack ust = new UnformedItemStack(((Ingredient)srec.func_192400_c().get(i)).func_193365_a());
                                    this.parent.inventory.func_70299_a(i, ust.possibleStacks.get(this.player.func_130014_f_().field_73012_v.nextInt(ust.possibleStacks.size())));
                                }
                                else {
                                    this.parent.inventory.func_70299_a(i, ItemStack.field_190927_a);
                                }
                                this.parent.field_75151_b.get(i).func_75218_e();
                            }
                        }
                    }
                    this.field_75224_c.func_70299_a(this.field_75222_d, (settedRec == null || settedRec.func_77571_b().func_190926_b()) ? ItemStack.field_190927_a : settedRec.func_77571_b().func_77946_l());
                }
            }
            return false;
        }
    }
}
