package essentialcraft.common.inventory;

import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;

public class ContainerEnderGenerator extends Container
{
    public ContainerEnderGenerator(final InventoryPlayer par1InventoryPlayer, final TileEntity par2) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.func_75146_a(new Slot((IInventory)par1InventoryPlayer, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.func_75146_a(new Slot((IInventory)par1InventoryPlayer, i, 8 + i * 18, 142));
        }
    }
    
    public boolean func_75145_c(final EntityPlayer player) {
        return true;
    }
    
    public ItemStack func_82846_b(final EntityPlayer par1EntityPlayer, final int par2) {
        return ItemStack.field_190927_a;
    }
}
