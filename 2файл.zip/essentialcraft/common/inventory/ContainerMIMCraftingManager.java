package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.tileentity.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import essentialcraft.common.item.*;

public class ContainerMIMCraftingManager extends ContainerInventory
{
    private int chestInventoryRows;
    private int chestInventoryColumns;
    
    public ContainerMIMCraftingManager(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public void setupSlots() {
        this.pInvOffsetZ = 56;
        this.chestInventoryRows = 6;
        this.chestInventoryColumns = 9;
        for (int chestRowIndex = 0; chestRowIndex < this.chestInventoryRows; ++chestRowIndex) {
            for (int chestColumnIndex = 0; chestColumnIndex < this.chestInventoryColumns; ++chestColumnIndex) {
                this.func_75146_a((Slot)new Slot(this.inv, chestColumnIndex + chestRowIndex * this.chestInventoryColumns, 8 + chestColumnIndex * 18, 18 + chestRowIndex * 18) {
                    public boolean func_75214_a(final ItemStack stk) {
                        return stk.func_77973_b() instanceof ItemCraftingFrame && stk.func_77942_o();
                    }
                });
            }
        }
        this.setupPlayerInventory();
    }
}
