package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import net.minecraft.inventory.*;

public class ContainerDemon extends ContainerInventory
{
    public ContainerDemon(final EntityPlayer player, final Entity entity) {
        super(player, entity);
    }
    
    public void setupSlots() {
        this.func_75146_a((Slot)new SlotGeneric(this.inv, 0, 80, 30));
        this.setupPlayerInventory();
    }
}
