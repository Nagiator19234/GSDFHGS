package essentialcraft.common.inventory;

import DummyCore.Utils.*;
import net.minecraft.tileentity.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;

public class ContainerUltraFlowerBurner extends ContainerInventory
{
    public ContainerUltraFlowerBurner(final InventoryPlayer invPlayer, final TileEntity tile) {
        super(invPlayer, tile);
    }
    
    public boolean func_75145_c(final EntityPlayer player) {
        return true;
    }
    
    public ItemStack func_82846_b(final EntityPlayer par1EntityPlayer, final int par2) {
        return ItemStack.field_190927_a;
    }
    
    public void setupSlots() {
        this.setupPlayerInventory();
    }
}
